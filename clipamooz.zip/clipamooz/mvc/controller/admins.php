<?php
class AdminsController {


  /**
   * AdminController constructor.
   */
  public function __construct() {

   // GrantAdmin();

  }
  public function CPanel() {
    $data = array();
    $data['pageTitle'] = "Panel ADMIN";
    View::renderCPanelAdmins("/admins/home.php",$data);
  }
  public function all($pageIndex) {
    if (!isAdmin()) {
      message('limit-access', _limit_access, true);
      return;
    }
    $result = UserModel::view_users();
    if (count($result) == 0) {
      message("not-found-information", _not_found_information);
      return;
    }
    $NameTable = 'users';
    $SortType = 'username';
    $keyword = "";
    $groupby='';
    $data = ListAjax($NameTable, $pageIndex,$keyword,$SortType,$groupby);
    View::renderCPanelAdmins("/user/all-user.php", $data);
  }
  public function search_admins() {
    if (isset($_POST['keyword'])) {
      $keyword = $_POST['keyword'];
    } else {
      $keyword = "";
    }
    $records= UserModel::Search($keyword);
    $record_codemelli = CommonModel::Fetch_by_every('info_person','codemelli',$keyword);
    if ($record_codemelli['codemelli']=='') {
      echo json_encode(array('status' => 'not_codemelli',));
    }else{
    echo json_encode($records);
    }
  }
}