<div class="rtl">

  <input type="text" style="display: none" id="user_id"  value="<?=$id?>" autocomplete="off">

</div>
<div id="paginationUpdate"></div>
<script>

  $("#keyword").on('keyup', function () {
    all_clip_buy(<?=$pageIndex?>);
  });
  $(function () {
    all_clip_buy(<?=$pageIndex?>);
  });

  function all_clip_buy(pageIndex) {
    var keyword = $("#keyword").val();
    var SearchFiled = $("#UserFind").val();
    var user_id = $("#user_id").val();
    $.ajax({
      url: '/clip/RefreshData_clip_buy/'+pageIndex,
      method: 'POST',
      dataType: 'json',
      data: {
        user_id:user_id,
        keyword: keyword,
        SearchFiled: SearchFiled
      },
      success: function (output) {
       // console.log(output);
        $("#paginationUpdate").html(output.html);
      }
    });
  }


</script>









