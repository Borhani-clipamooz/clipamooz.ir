<?php
  $id = $_POST['id'];
  $field = $_POST['field'];
  $filesize = $_POST['count_chunk'];
  $file_name = $_POST['file_name'];
  $chunksFolder = $_SERVER['DOCUMENT_ROOT'] ."/uploadfile" .'/chunks/'.$file_name.'/';
  $address_Save_to_DataBase='/uploadfile/video/videos_secret_folder8642087/'.$file_name.'.mp4';
if (!file_exists($chunksFolder)) {
  mkdir($chunksFolder, 0777, true);
}
if(isset($_FILES['myfile']["tmp_name"])) {
 // $num_chunks = $_POST['num_chunks'];
  if (move_uploaded_file($_FILES["myfile"]["tmp_name"],$chunksFolder. $_FILES["myfile"]["name"])){
    echo $chunksFolder.$_FILES["myfile"]["name"];
    // count ammount of uploaded chunks
    $chunksUploaded = 0;
    for ( $i = 0; $i < $filesize; $i++ ) {
      if ( file_exists( $chunksFolder.$i ) ) {
        ++$chunksUploaded;
      }
    }


    if ($chunksUploaded == $filesize) {
      $DIRECTORY_SEPARATOR='/';

      $targetFolder = $chunksFolder;
      $targetPath = join($DIRECTORY_SEPARATOR, array($_SERVER['DOCUMENT_ROOT'] . "/uploadfile/video/", 'videos_secret_folder8642087', $file_name.'.mp4'));
      if (!file_exists($targetPath)){
        mkdir(dirname($targetPath), 0777, true);
      }
      $target = fopen($targetPath, 'wb');

      for ($i=0; $i<$filesize; $i++){
        $chunk = fopen($chunksFolder.$i, "rb");
        stream_copy_to_stream($chunk, $target);
        fclose($chunk);
      }

      // Success
      fclose($target);
      $url='https://www.clipamooz.ir/uploader/video_finish/';
      get_web_page( $url,$address_Save_to_DataBase,$id,$field );
      for ($i=0; $i<$filesize; $i++){
        unlink($chunksFolder.$DIRECTORY_SEPARATOR.$i);
      }

      rmdir($chunksFolder);
    }


  }else{
    echo 'NO';
  }
}


function get_web_page( $target_url,$address_Save_to_DataBase,$id,$field  )
{
  $ch = curl_init();
  $data=array('address_Save_to_DataBase'=>$address_Save_to_DataBase,'id'=>$id,'field'=>$field);
  curl_setopt($ch, CURLOPT_URL,$target_url);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
  curl_setopt($ch, CURLOPT_POST,true);
  curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
  $content = curl_exec( $ch );
  curl_close( $ch );
  return $content;
}



?>
