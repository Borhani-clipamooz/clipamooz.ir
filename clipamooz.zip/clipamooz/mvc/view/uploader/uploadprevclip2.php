<div class="content">
  <div class="upload_prev_clip">
    <div class="row">
      <video id="previewPrevClip" style="width: 100%" controls ></video>
    </div>
     <div class="row" style="padding-bottom: 15px">
      <label class="btn btn_style" for="FilePreviewClip" class="btn ">آپلود</label>20MG
      <input class="btn-brown" type="button" value="عملیات آپلود" name="" onclick=uploadNEWFile('FilePreviewClip',1,<?=$id?>,'<?=$table_name?>','<?=$feild_name?>')>
      <progress id="progressBarFilePreviewClip" value="0" max="100" style="width:100px;"></progress>
      <input type="file" style="display:none"   id="FilePreviewClip">
      <input type="text" style="display: none"  id="id" value="<?=$id?>">
      <input type="text" style="display: none"  id="field_prev_clip" value="<?=$feild_name?>">
      <input type="text" style="display: none"   id="filename_prev_clip" value="<?=generateApiKey()?>">
    </div>
    <tr>
      <td>
        <h3 id="statusFilePreviewClip"></h3>
        <p id="loaded_n_totalFilePreviewClip"></p>
        <p id="FilePreviewClip"></p>
      </td>
    </tr>
  </div>
  </div>
 <script>
   $(function(){
     $('#FilePreviewClip').on('change',function(){
       var file =this.files[0];
       var type=file.type;
       var size=file.size;
       if(size >20000000) {
         swal("ببخشید حداکثر فایل پیش نمایش 20مگابایت می باشد.");
         return;
       }
       if(type != "video/mp4" ) {
         swal("ببخشید فایل انتخابی را با پسوند mp4 انتخاب نمایید . با تشکر");
         return;
       }
       var reader=new FileReader();
       reader.onload=viewer.load;
       reader.readAsDataURL(file);
       viewer.setProperties(file);

       var viewer={
         load:function(e){
           $('#FilePreviewClip').attr('src', e.target.result);
         },
         setProperties:function(file){

           $('#filenameFilePreviewClip').text(file.name);
           $('#filetypeFilePreviewClip').text(file.type);
           $('#filesizeFilePreviewClip').text(Math.round(file.size/1024));
         }
       });
     });
   });

 </script>
