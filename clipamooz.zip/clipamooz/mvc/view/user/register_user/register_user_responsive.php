<script src="/asset/js/lib/hash/md5.min.js"></script>
<script src="/asset/js/lib/hash/sha1.min.js"></script>
<script>

    $(function () {
      $("input").each(function () {
        // validateInput($(this));
        $(this).on('keyup', function () {
          validateInput($(this));
        });
      });
        $("#submit_responsive").on('click', function () {
            var validation = true;
          console.log(validation);
          $("input").each(function () {
                if ($(this).hasClass("wrong")) {
                    validation = false;
          console.log(validation);
                    return;
                }
            var user_name=$("#user_name_responsive").val();
            var email=$("#email_register_responsive").val();
            var password1=$("#password1_responsive").val();
            var password2=$("#password2_responsive").val();
                if (user_name==''||email==''||password1==''||password2=='') {
                    validation = false;
                    return;
                }
            })
            if (!validation) {
           swal("اطلاعات وارد شده دارای اشکال می باشد.");
             } else {
              captcha_SaveRegister_responsive();
            }
        });
    });
</script>

<div class="tac content">
  <div class="border">
 <div class="row">
   <div class="colx-2 colm-4 cols-0"></div>
    <div class="colx-3 colm-1 cols-fill">
      نام کاربری
    </div>
    <div class="colx-2 colm-2 cols-fill ">
      <input  type="text"  data-rule="user_name_is_Free_responsive" id="user_name_responsive"  name="user_name_responsive" >
    </div>
    <div class="colx-5 colm-5  cols-0 "></div>
 </div>
    <div class="row">
      <div class="colx-3 colm-4 cols-0"></div>
      <div class="colx-2 colm-1 cols-fill">
        ایمیل
      </div>
      <div class="colx-2 colm-2 cols-fill ">
        <input style="color: #000"  data-rule="email_is_Free_responsive" type="text" id="email_register_responsive" name="user_email_responsive">
      </div>
      <div class="colx-5 colm-5  cols-0 "></div>
    </div>
    <div class="row">
      <div class="colx-2 colm-4 cols-0"></div>
      <div class="colx-3 colm-1 cols-fill">
        رمز عبور
      </div>
      <div class="colx-2 colm-2 cols-fill ">
        <input style="color: #000"  data-rule="password_responsive" type="password" id="password1_responsive" name="password1_responsive">
      </div>
      <div class="colx-5 colm-5  cols-0 "></div>
    </div>

    <div class="row">
      <div class="colx-1 colm-4 cols-0"></div>
      <div class="colx-4 colm-1 cols-fill">
        تکرار رمز عبور
      </div>
      <div class="colx-2 colm-2 cols-fill ">
        <input style="color: #000"   data-rule="password_responsive" type="password" id="password2_responsive" name="password2_responsive">
        <input  type="hidden"  id="password_responsive" name="password_responsive">
      </div>
      <div class="colx-5 colm-5  cols-0 "></div>
    </div>
  <div class="row">
    <div class="colx-3 colm-3 cols-fill"> <button class="btn_style btn-brown"  id="reset" onclick="Reset()">بازنشانی</button></div>
    <div class="colx-3 colm-3 cols-fill"><input style="width: 100%" class="tac hf" type="text" id="captcha_SaveRegister_responsive"></div>
    <div class="colx-3 colm-3 cols-fill"><img src="/mvc/view/common/captcha/captcha_image.jpg.php"></div>
    <div class="colx-3 colm-3 cols-fill"> <button class="btn_style btn-brown" id="submit_responsive">ثبت نام </button></div>
    </div>
    <div id="Register_message_1_responsive" style="display: none">
      <span id="Register_message_responsive"></span>
    </div>
  </div>

    <div style="display: none">
      <td>تاریخ عضویت</td>
      <td><input type="datetime"  value="<?=getCurrentDateTime()?>" id="member_date_responsive"  style="text-align: center"></td>
    </div>

  </div>
</div>
<script>
  function Reset(){
    $("#user_name_responsive").val('');
    $("#email_register_responsive").val('');
    $("#password1_responsive").val('');
    $("#password2_responsive").val('');
  }
  function captcha_SaveRegister_responsive(){
    var captcha=$("#captcha_SaveRegister_responsive").val();
    $.ajax({
      url:'/captcha',
      type: 'POST',
      dataType:'json',
      data:{
        captcha:captcha
      },
      success:function(data){
        if(data.status==false){
          swal("کد وارد شده ایراد دارد.");
          return;
        }else{
          SaveRegisterUser_responsive();
        }
      }
    });

  }
  function SaveRegisterUser_responsive(){
    var user_name=$("#user_name_responsive").val();
    var email=$("#email_register_responsive").val();
    var password=$("#password_responsive").val();
    var member_date=$("#member_date_responsive").val();
    $("#submit_responsive").after('<div id="loader_responsive"><span class="icon-spinner9 huge spin "></span></div>');
    $.ajax({
      url:'/registerUser/',
      type: 'POST',
      dataType:'json',
      data:{
        user_name:user_name,
        email:email,
        password:password,
        member_date:member_date
      },
      success:function(data){
        $('#loader_responsive').slideUp(1000, function() {
          $(this).remove();
        });
        switch (data.status) {
          case 'false':
          {
            swal("کاربر عزیز قبلا ثبت نام کردید.");
            break;
          }
          case 'true':
          {
            swal({
                title: "به کلیپ آموز خوش آمدید.",
                text: "لینک فعال سازی به ایمیلتون ارسال گردید.",
                imageUrl: "/asset/images/logo/logo.png",
                closeOnConfirm: false,
                showLoaderOnConfirm: true
              },
              function () {
                setTimeout(function () {
                  window.location.href = "/page/home";
                }, 2000);
              });
            break;
          }
          default:
          //  window.location.href = "/h"+name_fa+"/"+subcategory;
        }
      }
    });
  }
</script>