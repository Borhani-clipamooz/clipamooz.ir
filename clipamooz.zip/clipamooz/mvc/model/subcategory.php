<?php
class SubcategoryModel {

  public static function insert($categoryID,$subcategory_name,$subcategory_english){
    $db = Db::getInstance();
    $db->query("INSERT INTO subcategories (categoryID,subcategory_name,subcategory_english)
             VALUES ( :categoryID, :subcategory_name,:subcategory_english)",
      array(
        'categoryID'         => $categoryID,
        'subcategory_name'         => $subcategory_name,
        'subcategory_english'         => $subcategory_english,
      ));


  }

  public static function update($id,$categoryID,$subcategory_name,$subcategory_english){
    $db = Db::getInstance();
    $db->modify("UPDATE subcategories SET
     categoryID=:categoryID ,
     subcategory_name=:subcategory_name,
     subcategory_english=:subcategory_english
     WHERE id=:id",
      array(
      'id' => $id,
      'categoryID' => $categoryID,
      'subcategory_name' => $subcategory_name,
      'subcategory_english' => $subcategory_english,

    ));
  }
  public static function compelete_clips_subcategory_ajax($startIndex,$count,$goal)
  {
    $db=Db::getInstance();
    $record=$db->query("select * from clips where (subcategory=$goal)AND (status=1) LIMIT $startIndex,$count");
    return $record;
  }


  public static function view_single($id)
  {
    $db=Db::getInstance();
    $record=$db->query("select * from subcategories where id=:id",array('id'=>$id,));
    return $record;

  }
  public static function DelSqlRecord($id)
  {
    $db=Db::getInstance();
    $db->query("DELETE FROM subcategories where id=:id",array('id'=>$id,));

  }
}