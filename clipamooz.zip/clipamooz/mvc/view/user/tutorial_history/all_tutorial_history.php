<div id="paginationUpdate"></div>
<input type="text" style="display: none" id="user_id"  value="<?=$id?>" autocomplete="off">

<script>

   $(function () {
     tutorial_history(<?=$pageIndex?>);
  });

  function tutorial_history(pageIndex) {
    var user_id = $("#user_id").val();
    $.ajax({
      url: '/user/Refresh_all_tutorial_history/'+pageIndex,
      method: 'POST',
      dataType: 'json',
      data: {
        user_id:user_id
      },
      success: function (output) {
        //console.log(output);
        $("#paginationUpdate").html(output.html);
      }
    });
  }


</script>









