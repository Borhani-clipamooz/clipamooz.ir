<?
global $config;
if($_SESSION['user_id']!=$user_id){
    header("Location:/");
    return;
}
?>

<input type="text" style="display: none" id="id"   value="<?=$id?>">
<div class="content">
  <div class="single_clip">
    <div class="row">
      <div class="colx-4 cols-8 tac">
        <div>
          <?require(getcwd() . "/mvc/view/clip/excute/clip_link_playing.php")?>
        </div>
      </div>
    </div>
    <div class="row"><!-- video-grid-->
      <?
      $data=CommonModel::Fetch_by_every('users','id',$user_id);
      $user_name="";
      $user_img="";
      $user_name=$data['user_name'];
      $user_img=$data['profile_pic'];
      $login_status=$data['login_status'];
      ?>
      <input type="text" style="display: none" id="clip_api_key" value="<?=$clip_api_key?>">
      <input type="text"  style="display: none" id="subcategory" value="<?=$subcategory?>">
      <input type="text"  style="display: none" id="user_id" value="<?=$user_id?>">
      <input type="text"  style="display: none" id="clip_name" value="<?=$name_fa?>">
        <div class="row">
          <div class="colx-1">
            <span ><?=DateTimeCommon_without_time($created_at)?></span>
          </div>
        </div>
    </div>
  </div>
</div>
<div class="row"><!--Deatail-->
  <div class="colx-4 tar">
    <div class="time">
      <i style="font-family: traffic">
        <?
        $x=$clip_long_time;
        if($x>=3600){
          echo gmdate("H:i:s", $clip_long_time);
        }else{
          echo gmdate("i:s", $clip_long_time);
        }
        ?>
      </i>
      <span class="icon-clock"></span>
    </div>
  </div>
  <div class="colx-4 tac">
    <div class="opens">
      <span class=" icon-eye" aria-hidden="true"><span style="font-family: traffic">&nbsp;<?=number_format($opens)?></span></span>
    </div>
  </div>
  <div class="colx-4 tal">
    <div class="views">
      <span class="icon-play" aria-hidden="true"><span style="font-family: traffic">&nbsp;<?=number_format($views)?></span></span>
    </div>
  </div>
</div>
<div class="row tac pd5">
  <div  style="color: #21DEEF;font-size:14pt;line-height: 25px;"><?=$name_fa?></div>
</div>
<div class="row pd5"><!--Category-->
  <?
  $data=CommonModel::Fetch_by_every('category','id',$category);
  $namecategory="";
  $namecategory=$data['name_fa'];

  $data=CommonModel::Fetch_by_every('subcategories','id',$subcategory);
  $name_sub_category="";
  $name_sub_category=$data['subcategory_name'];
  //********************************mizane opens ra ba hesab ip va clip_id hesab kard ***************************************
  $count=0;
  $ip="";
  $parts_one=array();

  $data_ip=CommonModel::Fetch_by_every('ip_network','ip',$_SESSION['ip']);
  $value="";
  $parts_one = explode(',',  $data_ip['clip_id_views']);
  for ($i = 0; $i < count($parts_one); $i++) {

    $value=$value.$parts_one[$i].",";
  }
  if(!in_array($id,$parts_one))
  {
    $count= $views+1;
    CommonModel::update_spacial_field($id,'clips','views',$count);
    $clip_id='';
    $clip_id=$value.$id;
  if($data_ip['id']!=null) {
    CommonModel::update_spacial_field($data_ip['id'], 'ip_network', 'clip_id_views', $clip_id);
  }else{
    Ip_networkModel::insert($_SESSION['ip']);
  }
  }

  //*********************   END   ***********************************************************************************************
  ?>
  <h2 class="">دسته بندی : &nbsp;<span style="color:#322010"><?= $namecategory?>:<?=$name_sub_category?></span></h2>
</div>
<div class="row profile"><!-- Rating USER_name Profile-->
  <div class="colx-1 cols-2">
    <? global $config;?>
    <?  if($user_img !=''){
      if($login_status==1){?>
        <a href="/profile/<?=$user_id?>"> <img style="border:2px solid  greenyellow;" src="<?=$config['upload'].$user_img?>"></a>
      <?  }else{?>
        <a href="/profile/<?=$user_id?>"> <img style="border:2px solid  red;" src="<?=$config['upload'].$user_img?>"></a>
      <?} ?>
    <?}else{
      if($login_status==1){ ?>
        <a  href="/profile/<?=$user_id?>"><img style="border:2px solid  greenyellow;" src="/asset/images/empty/empty-profile/empty-profile-24.png"></a>
      <?  }else{?>
        <a  href="/profile/<?=$user_id?>"><img style="border:2px solid  red;"
                                               src="/asset/images/empty/empty-profile/empty-profile-24.png"></a>
      <?}}?>
  </div>
  <div class="colx-3 cols-3 tar">
    <h3 style="color: #322010;font-size: 14pt;"><?=$user_name?></h3>
  </div>
  <div class="colx-8 cols-7 tal">
    <?
    if (strpos($rating, '.5') !== false) {
      $R_rating=$rating;
    }else{
      $R_rating=round($rating);
    }
    ?>
    <a href="#rating" class="rating"><?=rating($R_rating,'30px','30px');?></a>
  </div>
</div>
<div class="row">
  <div class="colx-2 colm-fill cols-fill tac" >
    <h2 id="explain" class="tac read-more">توضیحات</h2>
  </div>
  <div class="colx-2 colm-fill cols-fill tac" >
    <h2 onclick="Comments(1)" class="tac read-more">نظرات کاربران</h2>
  </div>
  <div class="colx-2 colm-fill cols-fill tac" >
    <h2 onclick="questions(1)" class="tac read-more">پرسش و پاسخ</h2>
  </div>
  <div class="colx-2 colm-fill cols-fill tac" >
    <h2 ><a class="tac read-more" href="<?=baseUrl().'/profile/'.$user_id?>">پروفایل کاربر</a></h2>
  </div>
  <? if ($uploadfile !='') {?>
  <div class="colx-3 colm-fill cols-fill tac" >
    <?global $config;?>
    <h2 ><a class="tac read-more" href="<?=$config['upload'].$uploadfile ?>" download>دانلود پیوست فایل</a></h2>
  </div>
 <? }?>
</div>
<div  id="explain_panel">
  <p><?=$long_desc_fa?></p>
</div>
<div id="page_final_clip"></div>
<input  type="text" style="display: none" id="user_id_buyer" value="<?=$_SESSION['user_id']?>">
<!-- ****Rating ****************************************************************************************-->
<div style="display:none">
  <div id="rating">
    <?Common_CURL(baseUrl().'/rating/showrating/'.$id)?>
  </div>
</div>
<script>
  $(function(){
    $("#explain").click(function(){
      $("#explain_panel").toggle(200);
      $("#page_final_clip").hide();
    });
    var id = $("#id").val();
    $(".rating").colorbox({
      inline: true,
      width: "100%",
      height: "400"
    });
    $(".donate").colorbox({
      inline: true,
      width: "100%"
    });
  });

  function Comments(pageIndex){

    var id = $("#id").val();
    $.ajax({
      url: '/clip_comments'+pageIndex,
      method: 'POST',
      dataType: 'json',
      data: {
        id: id
      },
      success: function (output) {
        //console.log(output.html);
        $("#explain_panel").hide();
        $("#page_final_clip").html(output.html);
        $("#page_final_clip").show();
      }
    });
  }
  function questions(pageIndex){

    var id = $("#id").val();
    var user_id = $("#user_id").val();
    var clip_name = $("#clip_name").val();
    $.ajax({
      url: '/clip_questions/'+pageIndex,
      method: 'POST',
      dataType: 'json',
      data: {
        id: id,
        user_id: user_id,
        clip_name: clip_name
      },
      success: function (output) {
        //console.log(output.html);
        $("#explain_panel").hide();
        $("#page_final_clip").html(output.html);
        $("#page_final_clip").show();
      }
    });
  }
</script>