<?php

function Unsuccessful_login(){
  if (!isVip()) {
    header("Location:/Unsuccessful_login");
    return;
  }
}
 function Common_CURL($URL) {
    $target_url = $URL;
    $ch = curl_init();
   curl_setopt($ch, CURLINFO_HEADER_OUT, true);
    curl_setopt($ch, CURLOPT_URL,$target_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
    curl_setopt($ch, CURLOPT_POST,true);
    $result=curl_exec ($ch);
    echo $result;

}
function send_message_email($Reciver_email,$MsgHTML,$subject,$message,$image,$alt){
  require_once ("pps/class.phpmailer.php");
  $mail = new PHPMailer(true);
  $mail->IsSMTP();
  try {
    $mail->Host       = "localhost"; // آدرس SMTP سایت گوگل
    $mail->SMTPAuth   = true;                  // استفاده از SMTP authentication
    $mail->SMTPSecure = "none";                 // استفاده از پروتکل امن
    $mail->Port       = 25;                   // درگاه خروجی سرویس ایمیل گوگل
    $mail->Username   = "info@clipamooz.ir"; // نام کاربری حساب گوگل
    $mail->Password   = "Borhan@8683054";        // کلمه عبور حساب گوگل
    $mail->AddReplyTo('info@clipamooz.ir', 'info@clipamooz.ir'); // افزودن پاسخ به ارسال کننده
    // $mail->AddAddress($_POST['email'], 'Daneshjooyar'); // تنظیم آدرس گیرنده ایمیل
    $mail->AddAddress($Reciver_email, $Reciver_email); // تنظیم آدرس گیرنده ایمیل
    // $mail->AddAddress('android.borhani@gmail.com', 'Daneshjooyar'); // تنظیم آدرس گیرنده ایمیل
    $mail->SetFrom('info@clipamooz.ir', 'info@clipamooz.ir'); // تنظیم قسمت ارسال کننده ایمیل
    // $mail->Subject = ''.$_POST['subject'].''; // موضوع ایمیل
    $mail->Subject = ''.$subject.''; // موضوع ایمیل
    //$mail->AltBody = 'برنامه شما از این ایمیل پشتیبانی نمی کند، برای دیدن آن، لطفا از برنامه دیگری استفاده نمائید'; // متنی برای کاربرانی که نمی توانند ایمیل را به درستی مشاهده کنند
    $mail->CharSet = 'UTF-8'; // یونیکد برای زبان فارسی
    $mail->ContentType = 'text/html'; // استفاده از html
    //$mail->MsgHTML(''.$_POST['messagetext'].''); // متن پیام به صورت html
   $mail->MsgHTML(''.$MsgHTML.'   '.$message.''); // متن پیام به صورت html
    // Add attachments
    /*$mail->addAttachment('docs/netparadis_1.pdf');
    $mail->addAttachment('docs/netparadis_2.docs');*/
    // Set email format to HTML
    $mail->isHTML(true);
   // $mail->AddEmbeddedImage('https://www.clipamooz.ir/asset/logo/logo.png','logo');
// $mail->addAttachment($image); //set new name
    $mail->MsgHTML(
      '<html>
             <body style="background:#c27b3d;border: 1px solid #000;text-align: center;font-family:Tahoma">
                  <h1 style="color:#CC0000;" >'.$MsgHTML.'</h1>
                   <hr><br>
               
                  <hr>
                  <h4 style="color:#000;">'.$message.'</h4>

            </body>
      </html>'
    ); // متن پیام به صورت html
    $mail->Send(); // ارسال

    echo 'b';
    echo "<span style='text-align:center;color:green;'>ایمیل اسال شد</span>";
  }
  catch (phpmailerException $e)
  {
    echo $e->errorMessage(); // پیام خطا از phpmailer
  }
  catch (Exception $e)
  {
    echo $e->getMessage(); // سایر خطاها
  }


}
function Receive_message_email($Sender_email,$family,$subject,$message){
  require_once ("pps/class.phpmailer.php");
  $mail = new PHPMailer(true);
  $mail->IsSMTP();
  try {
    $mail->Host       = "localhost"; // آدرس SMTP سایت گوگل
    $mail->SMTPAuth   = 'yes';                  // استفاده از SMTP authentication
    $mail->SMTPSecure = "none";                 // استفاده از پروتکل امن
    $mail->Port       = 25;                   // درگاه خروجی سرویس ایمیل گوگل
    $mail->Username   = "info@clipamooz.ir"; // نام کاربری حساب گوگل
    $mail->Password   = "Borhan@8683054";        // کلمه عبور حساب گوگل
    $mail->AddReplyTo($Sender_email, $Sender_email); // افزودن پاسخ به ارسال کننده
    // $mail->AddAddress($_POST['email'], 'Daneshjooyar'); // تنظیم آدرس گیرنده ایمیل
    $mail->AddAddress('info@clipamooz.ir', 'info@clipamooz.ir'); // تنظیم آدرس گیرنده ایمیل
    // $mail->AddAddress('android.borhani@gmail.com', 'Daneshjooyar'); // تنظیم آدرس گیرنده ایمیل
    $mail->SetFrom($Sender_email, $Sender_email); // تنظیم قسمت ارسال کننده ایمیل
    // $mail->Subject = ''.$_POST['subject'].''; // موضوع ایمیل
    $mail->Subject = ''.$subject.''; // موضوع ایمیل
    //$mail->AltBody = 'برنامه شما از این ایمیل پشتیبانی نمی کند، برای دیدن آن، لطفا از برنامه دیگری استفاده نمائید'; // متنی برای کاربرانی که نمی توانند ایمیل را به درستی مشاهده کنند
    $mail->CharSet = 'UTF-8'; // یونیکد برای زبان فارسی
    //$mail->ContentType = 'text/html'; // استفاده از html
    //$mail->MsgHTML(''.$_POST['messagetext'].''); // متن پیام به صورت html
    $mail->MsgHTML(''.DateTimeCommon(getCurrentDateTime()).'|'.$family.':'.$message.''); // متن پیام به صورت html
    $mail->Send(); // ارسال
    echo 'b';
    echo "<span style='text-align:center;color:green;'>ایمیل اسال شد</span>";
  }
  catch (phpmailerException $e)
  {
    echo $e->errorMessage(); // پیام خطا از phpmailer
  }
  catch (Exception $e)
  {
    echo $e->getMessage(); // سایر خطاها
  }


}
function sync_uploader(){
  $data_string = 'zone_id=261&api_key=LfIywmp7BnnA9BoI7ilBA11IAzjRk6PVbojxAyv2MIsM9Gk7OwyfopNPOXwZUcKW&action=sync';
  $ch = curl_init('http://cl.parspack.com/push_panel/user_api.php');
  curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
  curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  $result = curl_exec($ch);
  echo $result;
}
 function send_message_telegram($clip_name,$clip_api_key,$subcategory){
  $token='441404292:AAFPfcorBdH0c_KVPB6nPZJEdP3i0eA7Px4';
  $url='https://api.telegram.org/bot'.$token.'/';
  file_get_contents($url.'sendMessage?chat_id='.'@clipamooz_ir'.'&text='.baseUrl().'/g'.$clip_api_key.'/'.$subcategory.'/'.$clip_name);// payame roye kanal

}


function hr($return = false){
  if ($return){
    return "<hr>\n";
  } else {
    echo "<hr>\n";
  }
}

function br($return = false){
  if ($return){
    return "<br>\n";
  } else {
    echo "<br>\n";
  }

}

function dump_unco($var, $return = false){
  if (is_array($var)){
    $out = print_r($var, true);
  } else if (is_object($var)) {
    $out = var_export($var, true);
  } else {
    $out = $var;
  }

  if ($return){
    return "\n<pre style='direction: ltr'>$out</pre>\n";
  } else {
    echo "\n<pre style='direction: ltr'>$out</pre>\n";
  }
}



function encryptPassword($password){
  global $config;
  return sha1(md5($password . $config['salt']));
}

function getFullUrl(){
  $fullurl = 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
  return $fullurl;
}

function getRequestUri(){
  global $config;
 // $_SERVER['REQUEST_URI']=rawurldecode($_SERVER['UNENCODED_URL']);
  return $config['base'].$_SERVER['REQUEST_URI'] ;
}

function baseUrl(){
  global $config;
  return $config['base'];
}
function baseUrl_local(){
  global $config;
  return $config['base_local'];
}
function baseUrl_upload(){
  global $config;
  return $config['upload'];
}

function fullBaseUrl(){
  global $config;
  return 'https://' . $_SERVER['HTTP_HOST'] . $config['base'];
}

function strhas($string, $search, $caseSensitive = false){
  if ($caseSensitive){
    return strpos($string, $search) !== false;
  } else {
    return strpos(strtolower($string), strtolower($search)) !== false;
  }
}

function message($type, $message, $mustExit = false) {
  $data['message'] = $message;
  View::render("/message/$type.php", $data);

}
function message_CPanelSuperAdmin($type, $message, $mustExit = false) {
  $data['message'] = $message;
  View::renderCPanelSuperAdmin("/message/$type.php", $data);
  if ($mustExit){
    exit;
  }
}
function getCurrentDateTime(){
   return date("Y-m-d H:i:s");
 // return date("Y-m-d");
}
function getCurrentDateTime2(){
   return date("Y-m-d\TH:i:s");
}
function twoDigitNumber($number){
  return ($number < 10) ? $number = "0" . $number : $number;
}
function DateTimeTimeZone($DateTime){
  $date = new DateTime($DateTime);
  $result = $date->format("Y-m-d\TH:i:s");
  return $result;
}
function DateTimeCommon($DateTime){
  $date = new DateTime($DateTime);
  $result = $date->format(jdate($DateTime).'  '.'H:i');
  return $result;
}
function DateTimeCommon_without_time($DateTime){
  $date = new DateTime($DateTime);
  $result = $date->format(jdate($DateTime));
  return $result;
}
function play($id){
  $dd=$id;
  return $dd;
}

function generateApiKey() {
  return time(). uniqid();
}
/*function generateApiKey() {
  return time(). md5(uniqid(rand(), true));
}*/


function generateRandomString() {
  $length = 6;
  $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
  $charactersLength = strlen($characters);
  $randomString = '';
  for ($i = 0; $i < $length; $i++) {
    $randomString .= $characters[rand(0, $charactersLength - 1)];
  }
  return $randomString;
}
function jdate($date, $format="Y/m/d"){
  $timestamp = strtotime($date);
  $secondsInOneDay = 24*60*60;
  $MinuteInOneDay = 24*60;
  $HourInOneDay = 24*60*60*60*30;

  $daysPassed = floor($timestamp / $secondsInOneDay) ;
  $Hour = floor($timestamp / $HourInOneDay) ;

  $days = $daysPassed;
  $month = 11;
  $year = 1348;

  $days -= 19;

  $daysInMonths = array( 31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29 );

  $monthNames = array(    'فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند',  );


  while (true){
    if ($days > $daysInMonths[$month-1]){
      $days -= $daysInMonths[$month-1];
      $month++;
      if ($month == 13){
        $year++;
        if (($year - 1347) % 4 == 0){
          $days--;
        }
        $month = 1;
      }
    } else {
      break;
    }
  }

  $month = twoDigitNumber($month);
  $days =  twoDigitNumber($days);

  $monthName = $monthNames[$month-1];

  $output = $format;
  $output = str_replace("Y", $year, $output);
  $output = str_replace("m", $month, $output);
  $output = str_replace("d", $days, $output);
  $output = str_replace("M", $monthName, $output);


  return $output;
}

function pagination($url, $showCount, $activeClass, $deactiveClass, $currentPageIndex, $pageCount, $jsFunction = null){
  ob_start();
  if ($jsFunction){
    $tags = "span";
    $action = 'onclick="' . $jsFunction . '(#)"';
  } else {
    $tags = "a";
    $action = 'href="' . $url . '/#"';
  }
  ?>

  <? $rAction = str_replace("#", "1", $action); ?>
  <<?=$tags?> <?=$rAction?> class="<?=$activeClass?>">1</<?=$tags?>>
  <span>..</span>
  <? for ($i=$currentPageIndex-$showCount; $i<=$currentPageIndex+$showCount; $i++){ ?>
    <? if ($i <= 1) { continue; } ?>
    <? if ($i >= $pageCount) { continue; } ?>
    <? if ($i == $currentPageIndex) { ?>
      <span class="<?=$deactiveClass?>"><?=$i?></span>
    <? } else { ?>
      <? $rAction = str_replace("#", $i, $action); ?>
      <<?=$tags?> <?=$rAction?> class="<?=$activeClass?>"><?=$i?></<?=$tags?>>
    <? } ?>
  <? } ?>
  <span>..</span>
  <? $rAction = str_replace("#", $pageCount, $action); ?>
  <<?=$tags?> <?=$rAction?> class="<?=$activeClass?>"><?=$pageCount?></<?=$tags?>>

  <?
  $output = ob_get_clean();
  return $output;
}
function pagination_responsive($url, $showCount, $activeClass, $deactiveClass, $currentPageIndex, $pageCount, $jsFunction = null){
  ob_start();
  if ($jsFunction){
    $tags = "div";
    $action = 'onclick="' . $jsFunction . '(#)"';
  } else {
    $tags = "a";
    $action = 'href="' . $url . '/#"';
  }
  ?>

  <? $rAction = str_replace("#", "1", $action); ?>
  <<?=$tags?> <?=$rAction?> class="<?=$activeClass?>">1</<?=$tags?>>
  <span>..</span>
  <? for ($i=$currentPageIndex-$showCount; $i<=$currentPageIndex+$showCount; $i++){ ?>
    <? if ($i <= 1) { continue; } ?>
    <? if ($i >= $pageCount) { continue; } ?>
    <? if ($i == $currentPageIndex) { ?>
      <div class="<?=$deactiveClass?>"><?=$i?></div>
    <? } else { ?>
      <? $rAction = str_replace("#", $i, $action); ?>
      <<?=$tags?> <?=$rAction?> class="<?=$activeClass?>"><?=$i?></<?=$tags?>>
    <? } ?>
  <? } ?>
  <span>..</span>
  <? $rAction = str_replace("#", $pageCount, $action); ?>
  <<?=$tags?> <?=$rAction?> class="<?=$activeClass?>"><?=$pageCount?></<?=$tags?>>
  <?
  $output = ob_get_clean();
  return $output;
}

function generateHash($length = 32) {
  $characters = '2345679acdefghjkmnpqrstuvwxyz';
  $charactersLength = strlen($characters);
  $randomString = '';
  for ($i = 0; $i < $length; $i++) {
    $randomString .= $characters[rand(0, $charactersLength - 1)];
  }
  return $randomString;
}

function ListAjax($NameTable,$pageIndex,$SearchFiled,$keyword,$SortType,$groupby)
{
  $count=10;
  $startIndex=($pageIndex-1)* $count;
  $data['list']=CommonModel::CatalogByPage($NameTable,$startIndex,$count,$SearchFiled,$keyword,$SortType,$groupby);
  $recordcount=CommonModel::CatalogConutPage($NameTable);
  $data['pageCount']=ceil($recordcount/10);
  $data['pageIndex']=$pageIndex;
  return $data;
}
function ListAjaxPartial($NameTable,$pageIndex,$WhichField,$content,$SearchFiled,$keyword,$SortType,$count,$groupby)
{
  $startIndex=($pageIndex-1)* $count;
  $data['list']=CommonModel::CatalogByPagePartial($NameTable,$startIndex,$count,$WhichField,$content,$SearchFiled,$keyword,$SortType,$groupby);
  $recordcount=CommonModel::CatalogConutPage($NameTable);
  $data['pageCount']=ceil($recordcount/$count);
  $data['pageIndex']=$pageIndex;
  return $data;
}

function fast_array_merge(&$source, $newarray)
{
  foreach ($newarray AS $new) $source[] = $new;
}
function explode_multiple($contents, $breaks, $emptyresult = false)
{
  if (!is_array($contents)) $contents = array($contents);
  if (!is_array($breaks) OR (is_array($breaks) AND sizeof($breaks) == 0)) return $contents;

  $result = array();
  $break = array_shift($breaks);

  foreach ($contents AS $content)
  {
    if (is_array($content))
    {
      foreach ($content AS $ar)
      {
        fast_array_merge($result, explode($break, $ar));
      }
    }
    else
    {
      fast_array_merge($result, explode($break, $content));
    }
  }

  if (sizeof($breaks) > 0)
  {
    return explode_multiple($result, $breaks, $emptyresult);
  }
  else
  {
    if ($emptyresult)
    {
      return $result;
    }
    else
    {
      $clenresult = array();
      foreach ($result AS $value) if (trim($value) != '') $clenresult[] = $value;
      return $clenresult;
    }
  }
}

function rating($value,$width,$height){
  switch($value){
    case 0:
    {
    echo  '
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star_empty.png" alt="christmas_star_empty">
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star_empty.png" alt="christmas_star_empty">
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star_empty.png" alt="christmas_star_empty">
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star_empty.png" alt="christmas_star_empty">
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star_empty.png" alt="christmas_star_empty">

          ';
      break;
    }
    case 0.5:
    {
    echo  '
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/half_christmas_star.png"  alt="christmas_star_empty">
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star_empty.png" alt="christmas_star_empty">
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star_empty.png" alt="christmas_star_empty">
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star_empty.png" alt="christmas_star_empty">
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star_empty.png" alt="christmas_star_empty">

          ';
      break;
    }
    case 1:
    {
    echo  '
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star.png"       alt="christmas_star_empty">
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star_empty.png" alt="christmas_star_empty">
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star_empty.png" alt="christmas_star_empty">
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star_empty.png" alt="christmas_star_empty">
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star_empty.png" alt="christmas_star_empty">

          ';
      break;
    }
    case 1.5:
    {
    echo  '
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star.png"       alt="christmas_star_empty>
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/half_christmas_star.png"  alt="christmas_star_empty>
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star_empty.png" alt="christmas_star_empty>
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star_empty.png" alt="christmas_star_empty>
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star_empty.png" alt="christmas_star_empty>

          ';
      break;
    }
    case 2:
    {
    echo  '
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star.png"       alt="christmas_star_empty">
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star.png"       alt="christmas_star_empty">
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star_empty.png" alt="christmas_star_empty">
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star_empty.png" alt="christmas_star_empty">
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star_empty.png" alt="christmas_star_empty">

          ';
      break;
    }
    case 2.5:
    {
    echo  '
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star.png"       alt="christmas_star_empty">
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star.png"       alt="christmas_star_empty">
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/half_christmas_star.png"  alt="christmas_star_empty">
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star_empty.png" alt="christmas_star_empty">
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star_empty.png" alt="christmas_star_empty">

          ';
      break;
    }
    case 3:
    {
    echo  '
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star.png"      alt="christmas_star_empty">
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star.png"      alt="christmas_star_empty">
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star.png"      alt="christmas_star_empty">
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star_empty.png" alt="christmas_star_empty">
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star_empty.png" alt="christmas_star_empty">

          ';
      break;
    }
    case 3.5:
    {
    echo  '
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star.png" alt="christmas_star_empty">
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star.png" alt="christmas_star_empty">
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star.png" alt="christmas_star_empty">
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/half_christmas_star.png"  alt="christmas_star_empty">
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star_empty.png" alt="christmas_star_empty">

          ';
      break;
    }
    case 4:
    {
    echo  '
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star.png" alt="christmas_star_empty">
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star.png" alt="christmas_star_empty">
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star.png" alt="christmas_star_empty">
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star.png" alt="christmas_star_empty">
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star_empty.png" alt="christmas_star_empty">

          ';
      break;
    }
    case 4.5:
    {
    echo  '
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star.png" alt="christmas_star_empty">
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star.png" alt="christmas_star_empty">
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star.png" alt="christmas_star_empty">
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star.png" alt="christmas_star_empty">
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/half_christmas_star.png" alt="christmas_star_empty">

          ';
      break;
    }
    case 5:
    {
    echo  '
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star.png" alt="christmas_star_empty">
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star.png" alt="christmas_star_empty">
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star.png" alt="christmas_star_empty">
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star.png" alt="christmas_star_empty">
           <img style="display:inline-block;width: '.$width.';height:'.$height.';" src="/asset/images/star/christmas_star.png" alt="christmas_star_empty">

          ';
      break;
    }

  }
}
 function makeClickableLinks($s) {
  return preg_replace('@(https?://([-\w\.]+[-\w])+(:\d+)?(/([\w/_\.#-]*(\?\S+)?[^\.\s])?)?)@', '<a href="$1" target="_blank">$1</a>', $s);
}