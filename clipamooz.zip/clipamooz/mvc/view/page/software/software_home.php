<div class="row">
  <section id="section-2">
    <div class="about-landing">
      <div class="container">
        <div class="about-text">
          <h2 style="color: #fffccc;">توضیحاتی کوتاه</h2>
          <p style="font-size: 12pt;text-align: justify">
نرم افزارهای کاربردی که نیاز هست مدرسین برای توسعه آموزش های خود استفاده کنند قرار می گیرد.
          </p>
          <p style="font-size: 12pt;text-align: justify">
            در اینجا نرم افزار ها به صورت تفکیک ارائه شده است.
          </p>

        </div>
        <div class="thumb wow animated zoomIn"><img style="border-radius: 5px;width: 100%;height: 250px" src="/asset/images/software/applist.png" alt="پاسارگاد"></div>
      </div>
    </div>
  </section>

</div>