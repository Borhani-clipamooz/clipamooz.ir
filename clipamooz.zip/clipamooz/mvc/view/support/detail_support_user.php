<script>
  $(document).ready(function(){
    $("#replay").click(function(){
      $("#replay_panel").slideToggle("slow");
    });
  });
</script>
<div class=" content">
<div class="detail_support_user">
  <div style="cursor: pointer" id="replay" class="row">
    <i class="icon-reply huge">پاسخ : </i>
    <div class="row read-more"><?= $subject ?></div>
  </div>
  <div class="row">
    <div class="read-more">
    <h1 ><?= $subject ?></h1>
    </div>
  </div>
  <div id="replay_panel" style="display: none">
    <div class="row">
      <textarea id="body"  style="height: 150px;width: 100%"></textarea>
    </div>
    <div class="row">
      <button class="btn_style btn-brown"  id="send" onclick="Replay_user()">ارسال</button>
    </div>
  </div>
  <div class="row">
<!--    <div class="colx-1 colm-0 cols-0"><h2>پروفایل</h2></div>-->
<!--    <div class="colx-1"><h2>نام کاربری</h2></div>-->
    <div class="colx-7"><h2>پیام</h2></div>
    <div class="colx-3"><h2>تاریخ</h2></div>
  </div>
  <? foreach ($list as $feild) {?>
  <div class="row">
    <?$data=CommonModel::Fetch_by_every('users','id',$feild['sender_user_id']);?>

<!--    <div class="colx-1"><h3>--><?//= $data['user_name'] ?><!--</h3></div>-->
    <div class="colx-7"><h3><?= $feild['body'] ?></h3></div>
    <div class="colx-3"><h3><?=DateTimeCommon_without_time( $feild['created_at'] )?></h3></div>
  </div>
    <?}?>
       <input type="hidden"id="user_id" value="<?=$_SESSION['user_id']?>">
  <input style="display: none" id="target_user_id" value="<?=$target_user_id?>">
       <input type="hidden"id="ticket_id" value="<?=$ticket_id?>">
       <input type="hidden"id="subject" value="<?=$subject?>">
<div class="row">
  <button class="btn_style btn-brown" onclick="back(<?= $pageIndex ?>)">برگشت</button>
</div>
</div>
</div>
<script>
  function Replay_user(){
    var user_id=$("#user_id").val();
    var ticket_id=$("#ticket_id").val();
    var target_user_id=$("#target_user_id").val();
    var subject=$("#subject").val();
    var body=$("#body").val();
    $.ajax({
      url:'/Replay_user/'+user_id,
      type: 'POST',
      dataType:'json',
      data:{
        user_id:user_id,
        target_user_id:target_user_id,
        ticket_id:ticket_id,
        subject:subject,
        body:body
      },
      success:function(data){
    location.reload();
      }
    });

  }
  function back(pageIndex){
    all_support_ticket(pageIndex);
  }
</script>
