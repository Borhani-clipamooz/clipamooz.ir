<?header("Content-Type: text/html; charset=utf-8");?>
  <div class="row">
    <div class="box-new">
      <h2>محبوب ترین ها</h2>
    </div>
  </div>
  <!--  Demos -->
<section style="background-color: #c49962;">
    <div id="owl-popularclip" class="owl-carousel owl-theme">
      <? $data=CommonModel::Fetch_by_all_limit('clips','status',1,'rating',0,12);
      foreach ($data as  $key=>$feild) {?>
        <div class="item">
          <div class="box-items">
            <div class="row">
              <div class="box-image">
                <?
                if($feild['img_link']!=''){?>
                  <? global $config;?>
                  <a href="/g/<?=$feild['clip_api_key']?>" title="<?= $feild['name_fa']?>"><img  src="<?=$config['upload'].$feild['img_link']?>" alt="<?= $feild['name_fa']?>" /></a>
                <? } else{ ?>
                  <a href="/g/<?=$feild['clip_api_key']?>"  title="<?= $feild['name_fa']?>"><img  src="/asset/images/empty/empty-play/play.png" alt="<?= $feild['name_fa']?>" /></a>
                <?}?>
              </div>
            </div>
            <div class="row box-one">
              <div class="colx-4 tar">
                <?
                if($feild['clip_long_time']>=3600){
                  echo gmdate("H:i:s", $feild['clip_long_time']);
                }else{
                  echo gmdate("i:s", $feild['clip_long_time']);
                }
                ?>
                <span class="icon-clock"></span>
              </div>
              <div class="colx-4 tac">
                <span class=" icon-eye" aria-hidden="true"><span style="font-family: traffic">&nbsp;<?
                    $number =  number_format( $feild['opens']);
                    echo $number;?></span>
                </span>
              </div>
              <div class="colx-4 tal">
                <span class="icon-play" aria-hidden="true"><span style="font-family: traffic">&nbsp;<?= $feild['views']?></span></span>
              </div>
            </div>
            <div class="row">
              <h4><strong><?= $feild['name_fa']?></strong></h4>
            </div>
            <div class="row">
              <div class="colx-8 tar">
                <?
                $data1=CommonModel::Fetch_by_every('category','id',$feild['category']);
                $name_category="";
                $name_category=$data1['name_fa'];
                $data2=CommonModel::Fetch_by_every('subcategories','id',$feild['subcategory']);
                $name_sub_category="";
                $name_sub_category=$data2['subcategory_name'];
                ?>
                <h5><?= $name_category?>:<?= $name_sub_category?></h5>
              </div>
              <div class="colx-4 tal">
                <?$data=CommonModel::Fetch_by_every('users','id',$feild['user_id']);?>
                <h6><em><?=$data['user_name']?></em></h6>
              </div>
            </div>
            <div class="row">
              <div class="colx-3 tac" style="padding-right: 10px">
                <?
                if($data['profile_pic'] !=''){?>
                  <img style="width: 30px;height: 30px;border-radius: 2px" src="<?=$config['upload'].$data['profile_pic']?>" alt="<?=$data['user_name']?>" title="<?=$data['user_name']?>">
                <?}else{?>
                  <img style="width: 30px;height: 30px;border-radius: 2px" src="/asset/images/empty/empty-profile/empty-profile-24.png" alt="user_name_empty" title="نام کاربری">
                <?}?>
              </div>
              <div class="colx-9 tal">
                <div class="rating">
                  <?
                  if (strpos($feild['rating'], '.5') !== false) {
                    $R_rating=$feild['rating'];
                  }else{
                    $R_rating=round($feild['rating']);
                  }
                  ?>
                  <?=rating($R_rating,'20px','20px');?>
                </div>
              </div>
            </div>
          </div>
        </div>
      <?}?>
    </div>
  </section>
<script>
  $(function () {
    $("#owl-popularclip").owlCarousel({
      loop:true,
      //  margin:10,
      dots:false,
      autoplay:true,
      autoplayTimeout:6000,
      rtl:true,
      responsive:{
        0:{
          items:1
        },
        640:{
          items:2
        },
        1000:{
          items:4
        }
      }
    });
  });

</script>
