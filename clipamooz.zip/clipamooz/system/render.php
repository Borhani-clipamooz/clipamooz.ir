<?php
class View {
  public static function render($filePath, $data = array()){
    extract($data);
    ob_start();
    require_once(getcwd() . "/mvc/view" . $filePath);
    $content = ob_get_clean();
    require_once(getcwd() ."/mvc/view/theme/main.php");
  }
  public static function renderSingleClip($filePath, $data = array()){
    extract($data);
    ob_start();
    require_once(getcwd() . "/mvc/view" . $filePath);
    $content = ob_get_clean();
    require_once(getcwd() ."/mvc/view/theme/single_clip.php");
  }
  public static function renderCPanelSuperAdmin($filePath, $data = array()){
    extract($data);
    ob_start();
    require_once(getcwd() . "/mvc/view" . $filePath);
    $content = ob_get_clean();
    require_once(getcwd() ."/mvc/view/theme/cpanel_superadmin.php");
  }
  public static function renderCPanelAdmins($filePath, $data = array()){
      extract($data);
    ob_start();
    require_once(getcwd() . "/mvc/view" . $filePath);
    $content = ob_get_clean();

    require_once(getcwd() ."/mvc/view/theme/cpanel_admins.php");
  }
  public static function renderCPanelUser($filePath, $data = array()){
      extract($data);
    ob_start();
    require_once(getcwd() . "/mvc/view" . $filePath);
    $content = ob_get_clean();

    require_once(getcwd() ."/mvc/view/theme/cpanel_user.php");
  }

  public static function renderPartial($filePath, $data = array()){
    extract($data);

    require_once(getcwd() . "/mvc/view" . $filePath);
  }
  public static function render_direct_path($filePath, $data = array()){
    extract($data);

    require_once(  $filePath);
  }
}