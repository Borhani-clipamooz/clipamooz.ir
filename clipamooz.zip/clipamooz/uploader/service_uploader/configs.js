module.exports = {
    server: {
        host: "127.0.0.1",
        port: 4000
    },
    uploader: {
        tempDir: '/tmp/uploader/',
        mainDir: '/home/clipam/public_html/uploaderResult'     /* should be made '/opt/uploaderResult'*/
    }
}
