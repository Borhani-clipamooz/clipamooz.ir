<style type="text/css">
  .error1 {
    display:block;
    padding:4px;
    border:0px #666 solid;
    color:#C00;
    width:300px;
  }
  #uploadfile-process1{
    z-index:1000;
    visibility:hidden;
  }
</style>
<form action="/uploader/zipfile/<?=$id?>/<?=$feild_name?>/<?=$table_name?>" method="post" enctype="multipart/form-data" target="upload-target1" onsubmit="upload_start1();">
  <label for="user-file"></label>
  <input type="file" id="user-file" name="user-file" /><br><br>
  <span>10 MG</span>
  <input type="submit" value="آپلود فایل" />
</form>
<div id="uploadfile-process1"><img src="/asset/images/loading.gif" height="20" width="20" alt="loading" /> در حال پردازش...</div>
<div id="upload-form1"></div>
<iframe id="upload-target1" name="upload-target1" class="frame" style="width:0;height:0;border:0; border:none;">></iframe>
<script type="text/javascript">
  function upload_start1(){
    document.getElementById('uploadfile-process1').style.visibility = 'visible';
    return true;
  }
  function upload_end1(check_upload){
    var server_response = '';
    if (check_upload == 1){
      server_response = '<span class="ok">فایل با موفقیت آپلود شد!<\/span>';
      location.reload();
    }
    else {
      server_response = '<span class="error1">انتقال فایل به سرور انجام نشد!<\/span>';
    }
    document.getElementById('uploadfile-process1').style.visibility = 'hidden';
    document.getElementById('upload-form1').innerHTML = server_response;
    return true;
  }
</script>