  <style type="text/css">
    .error {
      display:block;
      padding:4px;
      border:0px #666 solid;
      color:#C00;
      width:300px;
    }
    #upload-process{
      z-index:1000;
      visibility:hidden;
    }
      </style>
<form action="/uploader/cropimage/<?=$id?>/<?=$feild_name?>/<?=$table_name?>/<?=$width?>/<?=$height?>" method="post" enctype="multipart/form-data" target="upload-target" onsubmit="upload_start();">
  <label for="user-file"></label>
  <input type="file" id="user-file" name="user-file" /><br><br>
  <span>1 MG</span>
  <input type="submit" value="آپلود تصویر" />
</form>
<div id="upload-process"><img src="/asset/images/loading.gif" height="20" width="20" alt="loading" /> در حال پردازش...</div>
<div id="upload-form"></div>
<iframe id="upload-target" name="upload-target" class="frame" style="width:0;height:0;border:0; border:none;">></iframe>
  <script type="text/javascript">
    function upload_start(){
      document.getElementById('upload-process').style.visibility = 'visible';
      return true;
    }
    function upload_end(check_upload){
      var server_response = '';
      if (check_upload == 1){
        server_response = '<span class="ok">فایل با موفقیت آپلود شد!<\/span>';
        location.reload();
      }
      else {
        server_response = '<span class="error">انتقال فایل به سرور انجام نشد!<\/span>';
      }
      document.getElementById('upload-process').style.visibility = 'hidden';
      document.getElementById('upload-form').innerHTML = server_response;
      return true;
    }
  </script>