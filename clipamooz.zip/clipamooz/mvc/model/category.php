<?php
class CategoryModel {

  public static function insert($name_fa,$name_en,$description_fa,$description_en,$image){
    $db = Db::getInstance();
    $db->query("INSERT INTO category (name_fa,name_en,description_fa,description_en,image)
             VALUES ( :name_fa, :name_en, :description_fa,:description_en,:image)",
      array(
        'name_fa'         => $name_fa,
        'name_en'         => $name_en,
        'description_fa'         => $description_fa,
        'description_en'         => $description_en,
        'image'         => $image,
      ));


  }

  public static function update($id,$name_fa,$name_en,$description_fa,$description_en){
    $db = Db::getInstance();
    $db->modify("UPDATE category SET
     name_fa=:name_fa ,
     name_en=:name_en,
     description_fa=:description_fa,
     description_en=:description_en

     WHERE id=:id",
      array(
      'id' => $id,
      'name_fa' => $name_fa,
      'name_en' => $name_en,
      'description_fa' => $description_fa,
      'description_en' => $description_en,

    ));
  }


  public static function view_single($id)
  {
    $db=Db::getInstance();
    $record=$db->query("select * from category where id=:id",array('id'=>$id,));
    return $record;

  }
  public static function DelSqlRecord($id)
  {
    $db=Db::getInstance();
    $db->query("DELETE FROM category where id=:id",array('id'=>$id,));

  }
}