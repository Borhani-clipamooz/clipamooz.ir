<?php
class CommonModel {
  public static function last_record($name_table){
    $db = Db::getInstance();
    $record=$db->first("SELECT * FROM $name_table ORDER BY id DESC LIMIT 1" );
    return $record;

  }
  public static function last_record_with_if($name_table,$whichFeild,$content,$orderby){
    $db = Db::getInstance();
    $record=$db->first("SELECT * FROM $name_table WHERE $whichFeild='$content' ORDER BY $orderby DESC LIMIT 1" );
    return $record;

  }
  public static function Remove_item($id,$table)
  {
    $db=Db::getInstance();
    $db->query_insert("DELETE FROM $table where id=:id",array('id'=>$id,));

  }
  public static function Remove_items($table,$whichField,$content)
  {
    $db=Db::getInstance();
    $db->query_insert("DELETE FROM $table where $whichField=:$whichField",array($whichField=>$content,));

  }
  public static function Remove_items_two_all($NameTabel,$feild1,$content1,$feild2,$content2)
  {
    $db=Db::getInstance();
     $db->query_insert("DELETE FROM $NameTabel WHERE ($feild1='$content1')AND ($feild2='$content2')",array("$feild1"=>$content1,"$feild2"=>$content2));
  }

  public static function Detail_Record($name_table,$id)
  {
    $db=Db::getInstance();
    $record=$db->first("select * from $name_table where id=:id",array('id'=>$id,));
    return $record;

  }
  public static function CatalogByPage($NameTable,$startIndex=0,$count=10,$SearchFiled,$keyword,$SortType,$groupby)
  {
    if($groupby != '')
    {
      $bygroup=' GROUP BY '.$groupby;
    }
    $db=Db::getInstance();
    $record=$db->query("select * from $NameTable where $SearchFiled LIKE '%$keyword%' ORDER BY $SortType LIMIT $startIndex,$count");
    return $record;

  }
  public static function CatalogByPagePartial($NameTable,$startIndex=0,$count=10,$whichField,$content,$SearchFiled,$keyword,$SortType,$groupby)
  {
    $output_keyword='';
    $SearchFiled1=$SearchFiled;
    if($keyword != '')
    {
      $output_keyword='AND ('.$SearchFiled1.' '.'like'.' '."'".'%'.$keyword.'%'."'".') ';
    }
    if($groupby != '')
    {
      $bygroup=' GROUP BY '.$groupby;
    }
      $db=Db::getInstance();
      $record=$db->query("select * from $NameTable where ($whichField='$content')$output_keyword $groupby ORDER BY $SortType LIMIT $startIndex,$count");
      return $record;
  }
  public static function CatalogConutPage($NameTable)
  {
    $db=Db::getInstance();
    $record=$db->query("select count(*) AS total from $NameTable");
    return $record['0']['total'];

  }

  public static function update_spacial_field($id,$name_table,$whichFeild,$content){

    $db = Db::getInstance();
    $db->modify("UPDATE $name_table SET $whichFeild='$content' WHERE id=$id" );
  }

  public static function Fetch_by_every($NameTabel,$whichFeild,$content){
    $db = Db::getInstance();
    $record = $db->first("SELECT * FROM $NameTabel WHERE $whichFeild='$content'",array("$whichFeild"=>$content));
    return $record;
  }
  public static function Fetch_by_every_orderby($NameTabel,$whichFeild,$content){
    $db = Db::getInstance();
    $record = $db->first("SELECT * FROM $NameTabel WHERE $whichFeild='$content' ORDER by 'DESC'",array("$whichFeild"=>$content));
    return $record;
  }
  public static function Fetch_by_two($NameTabel,$feild1,$content1,$feild2,$content2){
    $db = Db::getInstance();
    $record = $db->first("SELECT * FROM $NameTabel WHERE ($feild1='$content1')AND ($feild2='$content2')",array("$feild1"=>$content1,"$feild2"=>$content2));
    return $record;
  }
  public static function Fetch_by_two_all($NameTabel,$feild1,$content1,$feild2,$content2,$order_by){
    $db = Db::getInstance();
    $record = $db->query("SELECT * FROM $NameTabel WHERE ($feild1='$content1')AND ($feild2='$content2') $order_by",array("$feild1"=>$content1,"$feild2"=>$content2));
    return $record;
  }
  public static function Fetch_by_all($NameTabel,$whichFeild,$content,$order_by){
    $db = Db::getInstance();
    $record = $db->query("SELECT * FROM $NameTabel WHERE $whichFeild='$content' $order_by",array("$whichFeild"=>$content));
    return $record;
  }
  public static function Fetch_by_all_Date($NameTabel,$whichFeild,$content){
    $db = Db::getInstance();
    $record = $db->query("SELECT * FROM $NameTabel WHERE  $whichFeild > '$content' ",array("$whichFeild"=>$content));
    return $record;
  }
  public static function Fetch_by_all_Distinct($Distinct,$NameTabel,$whichFeild,$content){
    $db = Db::getInstance();
    $record = $db->query("SELECT DISTINCT '$Distinct' FROM $NameTabel WHERE $whichFeild='$content' ",array("$whichFeild"=>$content));
    return $record;
  }

  public static function Fetch_by_all_limit($NameTabel,$whichFeild,$content,$orderby,$start,$end){
    $db = Db::getInstance();
    $record = $db->query("SELECT * FROM $NameTabel WHERE $whichFeild='$content' ORDER BY $orderby DESC LIMIT $end OFFSET $start",array("$whichFeild"=>$content));
    return $record;

  }
  public static function View_All($NameTabel){
    $db = Db::getInstance();
    $record = $db->query("SELECT * FROM $NameTabel");
    return $record;
  }
  public static function View_All_onlyFeild($NameTabel,$whichFeild){
    $db = Db::getInstance();
    $record = $db->query("SELECT $whichFeild FROM $NameTabel ");
    return $record;
  }
  public static function DeleteFile_Remote_Host($dirPath) {
      $ch = curl_init();
      $data=array('dirPath'=>$dirPath);
      $target_url = 'http://stg.pz10251.parspack.net/delete_file.php';
      curl_setopt($ch, CURLOPT_URL,$target_url);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
      curl_setopt($ch, CURLOPT_POST,true);
      curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
      $result=curl_exec ($ch);
     // echo $result;

  }
  public static function DeleteFile($dirPath) {
    $dir ='';
    $parts= explode('/', $dirPath);
    for($i=0;$i<count($parts)-1;$i++){
      $dir=$dir.$parts[$i]."/";
    }
    $file_name =$parts[3];
    $dir_name =$_SERVER['DOCUMENT_ROOT'] .'/'. $dir;

    if ( !is_dir($dir_name) )
    {
      die ();
    }

    $d = opendir ( $dir_name );

    while ( $f=readdir($d) )
    {
      if ( is_file($del_file=$dir_name."/".$f) and $f==$file_name )
      {
        unlink ( $del_file );
        echo "<br/>file deleted :  $file_name";
      }
    }

  }
  public static function identification_user($user_access){
    switch ($user_access)
    {
      case '|superadmin|':
        $output='مدیر کل';
        break;
      case '|admin|':
        $output='مدیر';
        break;
      case '|vip|':
        $output='کاربر ویژه';
        break;
      case '|author|':
        $output='نویسنده';
        break;
      case '|author_vip|':
        $output='نویسنده ویژه';
        break;
      case '|user|':
        $output='کاربر عادی';
        break;
    }
    return $output;
  }
  public static function SearchFile($dirPath) {
   // $dir    ='uploadfile/';
    $dir ='';
    $parts= explode('/', $dirPath);
    for($i=0;$i<count($parts)-1;$i++){
      $dir=$dir.$parts[$i]."/";
    }
    $dir=substr($dir,1) ;
   $nameFile=$parts[count($parts)-1];
   // $nameFile="bkgaddgroup.jpg";

    if (is_dir($dir)) {
      if ($dh = opendir($dir)) {
        while (($file = readdir($dh)) !== false) {
          //echo "filename: .".$file."<br />";
          if($file==$nameFile){return true;}
        }
        closedir($dh);
      }
    }

  }

}