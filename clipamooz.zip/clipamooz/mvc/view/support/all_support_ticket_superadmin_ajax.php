<div class="content">
  <div class="all_message_ajax">
    <div class="row">
      <div class="colx-1"><h2>جزئیات</h2></div>
      <div class="colx-1"><h2>نمایش</h2></div>
      <div class="colx-1"><h2>پروفایل</h2></div>
      <div class="colx-2"><h2>نام کاربری</h2></div>
      <div class="colx-5"><h2>پیام</h2></div>
      <div class="colx-2"><h2>تاریخ</h2></div>
    </div>
    <? foreach ($list as $feild) {?>
      <div class="row">
        <div class="colx-1"><h3><span onclick="Remove_item('<?= $feild['ticket_id']?>','<?= $feild['sender_user_id']?>',<?=$pageIndex?>)"><i style="cursor: pointer;margin-top: 5px" class="icon-bin large"></i></span></h3></div>
        <div class="colx-1"><h3> <span onclick="support_superadmin_replay_view('<?= $feild['ticket_id']?>','<?= $feild['sender_user_id']?>','<?= $feild['target_user_id']?>',<?=$pageIndex?>,'<?= $feild['subject']?>')"><i class="icon-eye large"></i></span></h3></div>
        <? global $config;?>
        <?$data2=CommonModel::Fetch_by_every('users','id',$feild['target_user_id']);?>
        <div class="colx-1"><h3>
            <?  if($data2['profile_pic'] !=''){?>
              <a  href="/profile/<?=$data2['id']?>" style="color: #f88;font-size: 14pt"><img style="width: 40px;height: 40px;border-radius: 50px" src="<?=$config['upload'].$data2['profile_pic']?>"></a>
            <?}else{?>
              <a  href="/profile/<?=$data2['id']?>" style="color: #f88;font-size: 14pt"><img style="width: 40px;height: 40px;border-radius: 50px" src="/asset/images/empty/empty-profile/empty-profile-24.png"></a>
            <?}?>
          </h3></div>
        <div class="colx-2"><h3><?= $data2['user_name'] ?></h3></div>
        <div class="colx-5">
          <?if($feild['status']==0){?>
            <span style="color: darkred"><h3><?= $feild['body'] ?></h3></span>
          <?}else{?>
            <span style="color: greenyellow"><h3><?= $feild['body'] ?></h3></span>
          <? } ?>
        </div>
        <div class="colx-2"><h3><?= DateTimeCommon($feild['created_at']); ?></h3></div>
      </div>
    <? } ?>
    <br>
    <!--Buttons Filter-->
    <div class="row">
      <div><?=pagination('',3,'btn_style btn-brown','btn',$pageIndex,$pageCount,'getPage')?></div>
    </div>
    <br>
  </div>
  <div class="all_message_ajax_responsive">
    <? foreach ($list as $feild) {?>
      <div class="row">
        <div class="colx-2"><h2>جزئیات</h2></div>
        <div class="colx-10"><h3><span onclick="Remove_item('<?= $feild['ticket_id']?>','<?= $feild['sender_user_id']?>',<?=$pageIndex?>)"><i style="cursor: pointer;margin-top: 5px" class="icon-bin large"></i></span></h3>    </div>
      </div>
      <div class="row">
        <div class="colx-2"><h2>نمایش</h2></div>
        <div class="colx-10"><h3> <span onclick="support_superadmin_replay_view('<?= $feild['ticket_id']?>','<?= $feild['sender_user_id']?>','<?= $feild['target_user_id']?>',<?=$pageIndex?>,'<?= $feild['subject']?>')"><i class="icon-eye large"></i></span></h3></div>
      </div>
      <div class="row">
        <div class="colx-2"><h2>پروفایل</h2></div>
        <?$data2=CommonModel::Fetch_by_every('users','id',$feild['target_user_id']);?>
        <div class="colx-10">
          <?  if($data2['profile_pic'] !=''){?>
            <a  href="/profile/<?=$data2['id']?>" style="color: #f88;font-size: 14pt"><img style="width: 40px;height: 40px;border-radius: 50px" src="<?=$data2['profile_pic']?>"></a>
          <?}else{?>
            <a  href="/profile/<?=$data2['id']?>" style="color: #f88;font-size: 14pt"><img style="width: 40px;height: 40px;border-radius: 50px" src="/asset/images/empty/empty-profile/empty-profile-24.png"></a>
          <?}?>
        </div>
      </div>
      <div class="row">
        <div class="colx-2"><h2>نام کاربری</h2></div>
        <div class="colx-10"><h3><?= $data2['user_name'] ?></h3></div>
      </div>
      <div class="row">
        <div class="colx-2"><h2>پیام</h2></div>
        <div class="colx-10">
          <?if($feild['status']==0){?>
            <span style="color: darkred"><h3><?= $feild['body'] ?></h3></span>
          <?}else{?>
            <span style="color: greenyellow"><h3><?= $feild['body'] ?></h3></span>
          <? } ?>
        </div>
      </div>
      <div class="row">
        <div class="colx-2"><h2>تاریخ</h2></div>
        <div class="colx-10"><h3><?=  DateTimeCommon($feild['created_at']);?></h3></div>
      </div>
      <hr>
    <? } ?>
    <!--Buttons Filter-->
    <div class="row">
      <div><?=pagination_responsive('',3,'btn_style btn-brown','btn',$pageIndex,$pageCount,'getPage')?></div>
    </div>
  </div>
</div>

<script>
  function support_superadmin_replay_view(ticket_id,sender_user_id,target_user_id,PageIndex,subject) {

    $.ajax({
      url: '/support/detail_support_superadmin/' + ticket_id,
      type: 'POST',
      dataType: 'json',
      data:{
        sender_user_id:sender_user_id,
        target_user_id:target_user_id,
        subject:subject,
        pageIndex:PageIndex
      },
      success: function (data) {
        $("#paginationUpdate").html(data.html);
      }
    });
  }
  function Remove_item(ticket_id,sender_user_id,PageIndex) {

    $.ajax({
      url: '/support/Remove_sql_data/' + ticket_id,
      type: 'POST',
      dataType: 'json',
      data:{
        sender_user_id:sender_user_id,
        pageIndex:PageIndex
      },
      success: function (data) {
        $("#paginationUpdate").html(data.html);
      }
    });
  }
</script>


        <!--  <?/*$record=CommonModel::Fetch_by_all('support','ticket_id',$feild['ticket_id'],'order by id DESC');
          $arr   = end($record);
            */?>
          <?/*if($arr['status']==0){*/?>
            <td ><span style="color: red">در انتظار پاسخ</span></td>
          <?/*}else{*/?>
            <td ><span style="color: greenyellow">پاسخ داده شد</span></td>
         <?/* } */?>
          <td ><?/*= DateTimeCommon($feild['created_at']) */?></td>
        </tr>

        --><?/* } */?>





