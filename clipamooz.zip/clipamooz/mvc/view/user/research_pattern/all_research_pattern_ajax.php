<div class="content">
  <div class="all_reasearch_pattern_panel">
  <div id="reasearch_pattern" class="titrbox "> <h1>&nbsp;&nbsp;سوابق طرح‌های پژوهشی و تحقيقاتی :<i id="icon_reasearch_pattern_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
    <div class="row">
      <div class="colx-1">
        <h2 >جزئیات</h2>
      </div>
      <div class="colx-1">
        <h2 >حذف</h2>
      </div>
      <div class="colx-2">
        <h2 >عنوان طرح</h2>
      </div>
      <div class="colx-2">
        <h2>سمت</h2>
      </div>
      <div class="colx-2">
        <h2>کارفرما</h2>
      </div>
      <div class="colx-1">
        <h2 >تاريخ شروع</h2>
      </div>
      <div class="colx-1">
        <h2 >تاریخ پايان</h2>
      </div>
      <div class="colx-2">
        <h2 >اعتبار طرح (ریال)</h2>
      </div>
    </div>
    <? foreach ($list as $field) {?>
      <div class="row">
        <div class="colx-1">
          <h3 onclick="View_Detail(<?= $field['id']?>)"><i class="icon-folder-open large"></i></h3>
        </div>
        <div class="colx-1">
          <h3 onclick="Remove_item(<?= $field['id']?>,<?=$pageIndex?>,'research_pattern',<?=$field['user_id']?>)"><i class="icon-bin"></i></h3>
        </div>
        <div class="colx-2">
          <h3><?=$field['research_name']?></h3>
        </div>
        <div class="colx-2">
          <h3><?=$field['responsibility']?></h3>
        </div>
        <div class="colx-2">
          <h3><?=$field['employer']?></h3>
        </div>
        <div class="colx-1">
          <h3><?=$field['start_date']?></h3>
        </div>
        <div class="colx-1">
          <h3><?=$field['finish_date']?></h3>
        </div>
        <div class="colx-2">
          <h3><?=number_format($field['schedule_validity'])?></h3>
        </div>
      </div>
    <?}?>
    <br>
    <div class="row tac">
      <?=pagination('',3,'btn_style btn-brown','btn',$pageIndex,$pageCount,'research_pattern')?>
    </div>
  </div>
  <br>
  <div class="all_reasearch_pattern_panel_responsive">
  <div id="reasearch_pattern" class="titrbox "> <h1>&nbsp;&nbsp;سوابق طرح‌های پژوهشی و تحقيقاتی :<i id="icon_reasearch_pattern_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
    <? foreach ($list as $field) {?>
   <div class="row">
     <div class="colx-6">
       <h2 >جزئیات</h2>
     </div>
     <div class="colx-6">
       <h3 onclick="View_Detail(<?= $field['id']?>)"><i class="icon-folder-open large"></i></h3>
     </div>
   </div>
   <div class="row">
     <div class="colx-6">
       <h2 >حذف</h2>
     </div>
     <div class="colx-6">
       <h3 onclick="Remove_item(<?= $field['id']?>,<?=$pageIndex?>,'research_pattern',<?=$field['user_id']?>)"><i class="icon-bin"></i></h3>
     </div>
   </div>
   <div class="row">
     <div class="colx-6">
       <h2 >عنوان طرح</h2>
     </div>
     <div class="colx-6">
       <h3><?=$field['research_name']?></h3>
     </div>
   </div>
   <div class="row">
     <div class="colx-6">
       <h2>سمت</h2>
     </div>
     <div class="colx-6">
       <h3><?=$field['responsibility']?></h3>
     </div>
   </div>
   <div class="row">
     <div class="colx-6">
       <h2>کارفرما</h2>
     </div>
     <div class="colx-6">
       <h3><?=$field['employer']?></h3>
     </div>
   </div>
   <div class="row">
     <div class="colx-6">
       <h2 >تاريخ شروع</h2>
     </div>
     <div class="colx-6">
       <h3><?=$field['start_date']?></h3>
     </div>
   </div>
   <div class="row">
     <div class="colx-6">
       <h2 >تاریخ پايان</h2>
     </div>
     <div class="colx-6">
       <h3><?=$field['finish_date']?></h3>
     </div>
   </div>
    <div class="row">
      <div class="colx-6">
        <h2 >اعتبار طرح (ریال)</h2>
      </div>
      <div class="colx-6">
        <h3><?=number_format($field['schedule_validity'])?></h3>
      </div>
    </div>
      <hr>
    <?}?>
    <div class="row">
      <?=pagination_responsive('',3,'btn_style btn-brown','btn',$pageIndex,$pageCount,'research_pattern')?>
    </div>
  </div>
  <div class="row tac">
    <button class="btn_style btn-brown" onclick="Insert_all_research_pattern_ToSql(<?=$pageIndex?>,<?=$_SESSION['user_id']?>)" >سابقه جدید را اضافه بفرمایید</button>
  </div>
  </div>
  <br>
  <!--Buttons Filter-->


</div>

<script>

  function View_Detail(id){
    $.ajax({
      url: '/user/detail_research_pattern/' + id,
      method: 'POST',
      dataType: 'json',
      data: {
      },
      success: function (output) {
        //console.log(output);
        $("#paginationUpdate").html(output.html);
      }
    });
  }
  function Insert_all_research_pattern_ToSql(pageIndex,user_id) {
    $.ajax({
      url: '/user/Insert_all_research_pattern_ToSql/'+pageIndex,
      type: 'POST',
      dataType: 'json',
      data:{
        user_id:user_id
      },
      success: function (data) {
        $("#paginationUpdate").html(data.html);
      }
    });
  }
  function Remove_item(id,pageIndex,table_name,user_id) {
    swal({
        title: "آیا مطمئن هستید؟",
        text: "شما دیگر قادر به بازیابی این فایل نخواهید بود.",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#5d4126",
        confirmButtonText: "آره، آن را حذف کنید.",
        cancelButtonText: "لغو",
        closeOnConfirm: false
      },
      function(){
        $.ajax({
          url: '/user/Remove_item_research_pattern/'+pageIndex,
          type: 'POST',
          dataType: 'json',
          data:{
            id:id,
            user_id:user_id,
            table_name:table_name
          },
          success: function (data) {
            $("#paginationUpdate").html(data.html);
          }
        });
        swal("حذف گردید.");
      });

  }
</script>


