<div class="rtl">
  <input type="text" style="display: none" id="user_id"  value="<?=$id?>" autocomplete="off">
</div>
<div id="paginationUpdate"></div>
<script>
  $(function () {
    SuperAdmin_withdraw_money(<?=$pageIndex?>);
  });
  function SuperAdmin_withdraw_money(pageIndex) {
    $.ajax({
      url: '/payment/SuperAdmin_all_withdraw_money_ajax/'+pageIndex,
      method: 'POST',
      dataType: 'json',
      data: {
      },
      success: function (output) {
        $("#paginationUpdate").html(output.html);
      }
    });
  }
</script>