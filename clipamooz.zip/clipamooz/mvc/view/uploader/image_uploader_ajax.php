<ul>
  <li>
    <table >
      <tr>
        <!--  <td rowspan="3"><video id="preview"  src="" style="width: 300px;height: 200px" controls ></video></td> -->
        <img id="previewImage"    alt="" style="width: 300px;height: 200px" >
<!--        <td><span >نام فایل :  <span style="color: #322010"id="filenameImage"></span></span></td>-->
      </tr>
   <!--   <tr>
        <td> <span>سایز فایل : <span style="color: #322010" id="filesizeImage"></span>&nbsp;&nbsp;کیلو بایت &nbsp;</span></td>
      </tr>
      <tr>
        <td><span >نوع فایل : <span style="color: #322010"id="filetypeImage"></span></span></td>
      </tr>-->
      <tr>
        <td>
          <label class="btn-brown" for="FileImage" class="btn ">انتخاب فایل </label>
          <input  id="FileImage" type="file" name="file1"style="width:1%;visibility: hidden" >
        </td>
      </tr>
      <tr>
        <td>
          <input class="btn-brown" type="button" value="عملیات آپلود" name="" onclick=uploadNEWFile('UploadImage',0,<?=$id?>,'<?=$table_name?>','<?=$feild_name?>',<?=$width?>,<?=$height?>)>
          <progress id="progressBarFileImage" value="0" max="100" style="width:100px;"></progress>
        </td>
      </tr>
      <tr>
        <td>
          <h3 id="statusFileImage"></h3>
          <p id="loaded_n_totalFileImage"></p>
          <p id="FileImage"></p>
        </td>
      </tr>
    </table>
  </li>
</ul>
<script>
  $(function(){
    $('#FileImage').on('change',function(){

      var file =this.files[0];
      var type=file.type;
      /*switch(!type) {
       case "image/jpeg":
       swal("ببخشید پسوند عکس  png یا jpg می باشد.");
       break;
       case "image/png":
       swal("ببخشید پسوند عکس  png یا jpg می باشد.");
       break;
       case "image/jpg":
       swal("ببخشید پسوند عکس  png یا jpg می باشد.");
       break;
       default:
       swal("ببخشید پسوند عکس  png یا jpg می باشد.");
       }*/

      var reader=new FileReader();
      reader.onload=viewer.load;
      reader.readAsDataURL(file);
      viewer.setProperties(file);
    });
    var viewer={
      load:function(e){
        $('#previewImage').attr('src', e.target.result);

      },
      setProperties:function(file){

        $('#filenameImage').text(file.name);
        $('#filetypeImage').text(file.type);
        $('#filesizeImage').text(Math.round(file.size/1024));
      }
    }
  });
</script>