<html xmlns="http://www.w3.org/1999/xhtml">
<head id="Head1" runat="server">
  <title>BP PGW Test</title>
  <link href="/mvc/view/payment/back/Style.css" rel="stylesheet" type="text/css" />
</head>

<body>
<form id="form1" runat="server">
  <table width="100%" cellspacing="0" cellpadding="0" align="center">
    <tr>
      <td>
        <table class="MainTable" cellspacing="5" cellpadding="1" align="center">
          <tr class="HeaderTr">
            <td colspan="2" align="center" height="25">
              <span class="HeaderText">CallBack Params</span>
            </td>
          </tr>
          <tr>
            <td class="LabelTd">
              <span>RefId</span>
            </td>
            <td>
              <span><?php echo $_POST['RefId']; ?></span>
              <input type="text" id="RefId" value="<?=$_POST['RefId']?>">
            </td>
          </tr>
          <tr>
            <td class="LabelTd">
              <span>ResCode</span>
            </td>
            <td>
              <span><?php echo $_POST['ResCode']; ?></span>
              <input type="text" id="ResCode" value="<?=$_POST['ResCode']?>">
            </td>
          </tr>
          <tr>
            <td class="LabelTd">
              <span>SaleOrderId</span>
            </td>
            <td>
              <span><?php echo $_POST['SaleOrderId']; ?></span>
              <input type="text" id="SaleOrderId" value="<?=$_POST['SaleOrderId']?>">
            </td>
          </tr>
          <tr>
            <td class="LabelTd">
              <span>SaleReferenceId</span>
            </td>
            <td>
              <span><?php echo $_POST['SaleReferenceId']; ?></span>
              <input type="text" id="SaleReferenceId" value="<?=$_POST['SaleReferenceId']?>">
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</form>
</body>
</html>
<script>
  $(function(){
    var RefId=$('#RefId').val();
    var ResCode=$('#ResCode').val();
    var SaleOrderId=$('#SaleOrderId').val();
    var SaleReferenceId=$('#SaleReferenceId').val();
    $.ajax({
      url: '/payment/Update_back',
      method: 'POST',
      dataType: 'json',
      data: {
        RefId: RefId,
        ResCode: ResCode,
        SaleOrderId: SaleOrderId,
        SaleReferenceId: SaleReferenceId

      },
      success: function (output) {
        //console.log(output.html);
      }
    });
  });
</script>
