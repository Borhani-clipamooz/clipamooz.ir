<div class="content">
 <div class="notices">
   <input type="hidden"id="id" value="<?=$id?>">
   <input type="hidden"id="user_id" value="<?=$user_id?>">
  <div class="row"><h2>گرافیک</h2></div>
    <div class="row">
   <div class="colx-4">
     فوتوشاپ <input type="checkbox" id="photoshop" value="<?=$photoshop?>" >
   </div>
  </div>
  <div class="row"><h2>شبکه</h2></div>
    <div class="row">
    <div class="colx-4">
     <?=_MCSA_2016?> <input type="checkbox" id="MCSE2012" value="<?=$MCSE2012?>" >
    </div>
  </div>
  <div class="row"><h2>برق</h2></div>
    <div class="row">
    <div class="colx-4">
      LabVIEW <input type="checkbox" id="LabVIEW" value="<?=$LabVIEW?>" >
    </div>
  </div>
  <div class="row"><h2>برنامه نویسی</h2></div>
    <div class="row">
    <div class="colx-4">
      JAVASCRIPT <input type="checkbox" id="javascript" value="<?=$javascript?>" >
    </div>
  </div>

 </div>
</div>
<script>
  $(function () {
    //**********************************************************************************
    $("#photoshop").on('click', function () {
      var id=$("#id").val();
      var check_card=$("#photoshop").val();
      if(check_card==0){
        check_card=1;
      }else{
        check_card=0;
      }
      $.ajax({
        url:'/Update_checkbox_notices/',
        type:'POST',
        dataType:'json',
        data:{
          id:id,
          check_card:check_card,
          whichFeild:'photoshop'
        },
        success:function(data){
          console.log(data);
        }
      });

    });
    if(document.getElementById("photoshop").value==0)
    {
      document.getElementById("photoshop").checked=false;
    }else{
      document.getElementById("photoshop").checked=true;
    };
    //**********************************************************************************
    $("#MCSE2012").on('click', function () {
      var id=$("#id").val();
      var check_card=$("#MCSE2012").val();
      if(check_card==0){
        check_card=1;
      }else{
        check_card=0;
      }
      $.ajax({
        url:'/Update_checkbox_notices/',
        type:'POST',
        dataType:'json',
        data:{
          id:id,
          check_card:check_card,
          whichFeild:'MCSE2012'
        },
        success:function(data){
          console.log(data);
        }
      });

    });
    if(document.getElementById("MCSE2012").value==0)
    {
      document.getElementById("MCSE2012").checked=false;
    }else{
      document.getElementById("MCSE2012").checked=true;
    };
    //********************************************************************************************************************************
    $("#LabVIEW").on('click', function () {
      var id=$("#id").val();
      var check_card=$("#LabVIEW").val();
      if(check_card==0){
        check_card=1;
      }else{
        check_card=0;
      }
      $.ajax({
        url:'/Update_checkbox_notices/',
        type:'POST',
        dataType:'json',
        data:{
          id:id,
          check_card:check_card,
          whichFeild:'LabVIEW'
        },
        success:function(data){
          console.log(data);
        }
      });

    });
    if(document.getElementById("LabVIEW").value==0)
    {
      document.getElementById("LabVIEW").checked=false;
    }else{
      document.getElementById("LabVIEW").checked=true;
    };
    //********************************************************************************************************************************
    //**********************************************************************************
    $("#javascript").on('click', function () {
      var id=$("#id").val();
      var check_card=$("#javascript").val();
      if(check_card==0){
        check_card=1;
      }else{
        check_card=0;
      }
      $.ajax({
        url:'/Update_checkbox_notices/',
        type:'POST',
        dataType:'json',
        data:{
          id:id,
          check_card:check_card,
          whichFeild:'javascript'
        },
        success:function(data){
          console.log(data);
        }
      });

    });
    if(document.getElementById("javascript").value==0)
    {
      document.getElementById("javascript").checked=false;
    }else{
      document.getElementById("javascript").checked=true;
    };
    //********************************************************************************************************************************
  });

</script>


