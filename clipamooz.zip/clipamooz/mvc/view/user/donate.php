  <div class="content">
    <div class="donati">
      <div class="row">
          <img style="border-radius: 5px;" src="/asset/images/thankyou.jpg"><br>
      </div>
      <?if($user_id_buyer!=null){
        if($user_id_buyer!=$user_id_seller){
          ?>
   <div class="row">
     <div class="colx-6">
       <h1>موجودی حساب</h1>
     </div>
     <div class="colx-6">
       <h2><?=$cash_buyer?></h2>
     </div>
   </div>
   <div class="row">
     <h1><button   class="btn_style btn-brown"onclick="cash_amount();" >افزایش موجودی</button></h1>
   </div>
   <div class="row">
     <div class="colx-6">
       <h1>مبلغ اهدایی</h1>
     </div>
     <div class="colx-6">
     <input type="text" id="send_mony" >
     </div>
   </div>
   <div class="row">
       <h1><button class="btn_style btn-brown" onclick="donate_pay();">واریز</button></h1>
   </div>
   <div class="row">
     <h3 id="messageDonate"></h3>
   </div>

     <?}else{?>
   <div class="row">
       <h3>دوست عزیز نمی توان برای کلیپ خود واریزی داشته باشید.</h3>
   </div>
     <? }?>
     <?}else{?>
      <div class="row">
       <h3>دوست عزیز لطفا به وب سایت وارد شوید.</h3>
        </div>
     <?}?>
    </div>
  </div>

<input type="text" style="display: none" id="clip_id" value="<?=$clip_id?>">
<input type="text" style="display: none" id="user_id_buyer" value="<?=$user_id_buyer?>">
<input type="text" style="display: none" id="cash_buyer" value="<?=$cash_buyer?>">
<input type="text" style="display: none" id="user_id_seller" value="<?=$user_id_seller?>">
<input type="text" style="display: none" id="cash_seller" value="<?=$cash_seller?>">
<script>
  function donate_pay(){
    var clip_id = $("#clip_id").val();
    var user_id_seller = $("#user_id_seller").val();
    var cash_seller = $("#cash_seller").val();
    var user_id_buyer = $("#user_id_buyer").val();
    var cash_buyer = $("#cash_buyer").val();
    var send_mony = $("#send_mony").val();
    $.ajax({
      url: '/donate_pay/',
      method: 'POST',
      dataType: 'json',
      data: {
        clip_id: clip_id,
        user_id_seller: user_id_seller,
        cash_seller: cash_seller,
        user_id_buyer: user_id_buyer,
        cash_buyer: cash_buyer,
        send_mony: send_mony
      },
      success: function (data) {
       // console.log(data.status);
        switch (data.status) {
         case 'not_enter':
          {
            document.getElementById("messageDonate").innerHTML="کاربر عزیز ابتدا به کلیپ آموز وارد شوید.";
            break;
          }
          case 'The_payment_amount_is_not_correct':
          {
            document.getElementById("messageDonate").innerHTML="مبلغ واریزی صحیح نمی باشد.";
            break;
          }
          case 'The_inventory_is_low':
          {
            document.getElementById("messageDonate").innerHTML="موجودی کافی نمی باشد.";
            break;
          }
          case 'ok':
          {
            document.getElementById("messageDonate").innerHTML="مبلغ واریز شد از حسن نگاه تون تشکر و قدردانی میکنیم.";
            break;
          }
          default:
          //  window.location.href = "/h"+name_fa+"/"+subcategory;
        }
      }
    });
  }
  function cash_amount(){
    var user_id_buyer = $("#user_id_buyer").val();
      window.location.href = href="/payment/cash_user_donate/"+user_id_buyer;
  }
</script>



