<?php 
/************************************************************
	Author			: Chandan Kumar 
	Organization	: http://tradebooster.com
	Created On		: 15-09-2012
*****************************************************************/
class MyNetwork
{

	function my_network($userKey,$level)
	{

		$levelArr = array();
		$levelArr[0] = $this->LevelZero($userKey);
//    dump_unco($levelArr);
		for($i=1,$j=0; $i<= $level; $i++,$j++)
		{
			$levelArr[$i] = $this->BuildLevelArr($levelArr[$j]);
		}

		//echo "<pre>";print_r($levelArr);exit;
		return $levelArr;


	}
	/*----------------------------------------------------------------------------------
	Level 0th
	------------------------------------------------------------------------------------*/
	function LevelZero($userKey)
	{
	    if(isset($userKey))
		{
      $db = Db::getInstance();
      $rs = $db->query("SELECT
							id,user_id,name, user_key,sponsor_key,
							DATE_FORMAT(`create_date`,'%d %M %Y') as creationDate,
							payment_status, paid_date
					FROM network
					WHERE `user_key` = '".$userKey."'",array("user_key"=>$userKey));
				$i=0;

			if(count($rs)>0)
			{
        foreach($rs as $row)
				{
					$listArr[$i]['name'] = $row['name'];
					$listArr[$i]['userKey'] = $row['user_key'];
					$listArr[$i]['parentKey'] ='';
					$listArr[$i]['payment_status'] = $row['name'];
					$listArr[$i]['created'] = $row['creationDate'];
					$i++;
				}
				$newArr = array($listArr);  //Array of array
				return $newArr;
			//	return $rs;

			}
		}

	}
	/*----------------------------------------------------------------------------------
	Level others
	------------------------------------------------------------------------------------*/
	function BuildLevelArr($levelArr)
	{

	    if(isset($levelArr) && count($levelArr)>0)
		{
			//echo "<pre>";print_r($levelArr);exit;
			$i=0;
			$listArr = array();
			foreach($levelArr as $details=>$rows)
			{
				foreach($rows as $row)
				{
					if(isset($row['userKey']) && $row['userKey']!='')
					{
						$listArr[$i] = $this->getChildDetailByParent($row['userKey']);
						$i++;
					}	
				}
			}
		//	echo "<pre>";print_r($listArr);exit;
			return $listArr;
		}
	}
		
	function getChildDetailByParent($key)
	{
		if(isset($key))
		{
      $db = Db::getInstance();
      $rs = $db->query("SELECT
							id,user_id,name, user_key,sponsor_key,leg,
							DATE_FORMAT(`create_date`,'%d %M %Y') as creationDate,
							payment_status, paid_date
					FROM network
					WHERE 	`parent_key` = '".$key."'ORDER BY leg");
			$i=0;
			if(count($rs)==2)
			{
        foreach($rs as $row)
				{
					$listArr[$i]['name'] = $row['name'];
					$listArr[$i]['userKey'] = $row['user_key'];
					$listArr[$i]['parentKey'] = $key;
					$listArr[$i]['payment_status'] = '';
					$listArr[$i]['created'] = $row['creationDate'];
					$listArr[$i]['leg'] = $row['leg'];
					$i++;
				}

			}else if(count($rs)==1){
        foreach($rs as $row)
        {
          $leg = $row['leg'];
        }
				if($leg==0)
				{
					$listArr[0]['name'] = $row['name'];
					$listArr[0]['userKey'] = $row['user_key'];
					$listArr[0]['parentKey'] = $key;
					$listArr[0]['payment_status'] = '';
					$listArr[0]['created'] = $row['creationDate'];
					$listArr[0]['leg'] = $row['leg'];
					
					$listArr[1]['name'] = '<span style="color:red">Empty Right</span>';
					$listArr[1]['userKey'] = '';
					$listArr[1]['payment_status'] = '';
					$listArr[1]['parentKey'] = $key;
					$listArr[1]['created'] = '';
					$listArr[1]['leg'] = 1;
					
				}else{
				
					$listArr[0]['name'] = '<span style="color:red">Empty Left</span>';
					$listArr[0]['userKey'] = '';
					$listArr[0]['parentKey'] = $key;
					$listArr[0]['payment_status'] = '';
					$listArr[0]['created'] = '';
					$listArr[0]['leg'] = 0;
					
					$listArr[1]['name'] =  $row['name'];
					$listArr[1]['userKey'] = $row['user_key'];
					$listArr[1]['parentKey'] = $key;
					$listArr[1]['payment_status'] = '';
					$listArr[1]['created'] = $row['creationDate'];
					$listArr[1]['leg'] = $row['leg'];
				}

			}else{

				$listArr[0]['name'] = '<span style="color:red">Empty Left</span>';
				$listArr[0]['userKey'] = '';
				$listArr[0]['parentKey'] = $key;
				$listArr[0]['payment_status'] ='';
				$listArr[0]['created'] = '';
				$listArr[0]['leg'] = 0;	
				
				$listArr[1]['name'] = '<span style="color:red">Empty Right</span>';
				$listArr[1]['userKey'] = '';
				$listArr[1]['parentKey'] = $key;
				$listArr[1]['payment_status'] = '';
				$listArr[1]['created'] = '';
				$listArr[1]['leg'] = 1;
				
				//echo "<pre>";print_r($listArr);exit;
			}
			return $listArr;

		}
	}
	
	
/*end of the class*/

}

?>