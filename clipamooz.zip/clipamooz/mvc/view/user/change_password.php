<script src="/asset/js/lib/hash/md5.min.js"></script>
<script src="/asset/js/lib/hash/sha1.min.js"></script>
<div class="content">
  <div class="change_password">
    <div class="row">
      <div class="colx-4"><h2>رمز عبور فعلی</h2></div>
      <div class="colx-8 tar">
        <input type="text"  class="tac rtl" id="passwordUser">
        <input  type="hidden" id="passwordUserEncrypt" >
      </div>
    </div>
    <div class="row">
      <div class="colx-4"><h2>رمز عبور جدید</h2></div>
      <div class="colx-8 tar">
        <input type="password"  class="tac rtl" data-rule="password" type="password" id="password1">
      </div>
    </div>
    <div class="row">
      <div class="colx-4"><h2>تکرار رمز عبور جدید</h2></div>
      <div class="colx-8 tar">
        <input type="password"  class="tac rtl" data-rule="password" type="password" id="password2">
        <input  type="hidden"  id="password" name="password">
      </div>
    </div>
    <div class="row">
      <button id="btn_change_password"  class="btn_style btn-brown" style="margin-top: 5px"><?=_btn_save?></button>
    </div>
    <div class="row">
      <h3 id="messageCHangePassword"></h3>
    </div>
    <input type="text" style="display: none" id="user_id"  value="<?=$id?>">

  </div>


</div>

<script>
  $(function(){
    $("input").each(function () {
      $(this).on('keyup', function () {
        validateInput($(this));
      });
    });
    $("#btn_change_password").on('click', function () {
      var validation = true;
      $("input").each(function () {
        if ($(this).hasClass("wrong")) {
          validation = false;
          return;
        }
        var passwordUser=$("#passwordUser").val();
        var password1=$("#password1").val();
        var password2=$("#password2").val();
        if (passwordUser==''||password1==''||password2=='') {
          validation = false;
          return;
        }
      })
      if (!validation) {
        swal("اطلاعات وارد شده دارای اشکال می باشد.");
      } else {
        change_password();
      }
    });
  });
  $("#passwordUser").on("keyup", function (event) {
    $("#passwordUserEncrypt").val(js_encryptPassword($(this).val()));
  });
  $("#passwordUser").on("change", function (event) {
    $("#passwordUserEncrypt").val(js_encryptPassword($(this).val()));
  });

  function Reset(){
    $("#passwordUser").val('');
    $("#password1").val('');
    $("#password2").val('');
  }
  function change_password(){
    var password=$("#password").val();
    var user_id=$("#user_id").val();
    var passwordUserEncrypt=$("#passwordUserEncrypt").val();
    $("#btn_change_password").after('<div id="loader"><span class="icon-spinner9 huge spin "></span></div>');
    $.ajax({
      url: '/change_password_update',
      method: 'POST',
      dataType: 'json',
      data: {
        user_id:user_id,
        password:password,
        passwordUserEncrypt:passwordUserEncrypt
      },
      success: function (data) {
        $('#loader').slideUp(1000, function() {
          $(this).remove();
        });
        switch(data.status) {
          case 'wrong_current_password':
            document.getElementById("messageCHangePassword").innerHTML="رمز عبور فعلی اشتباه وارد شده است.";
            break;
          case 'successchangePassword':
            document.getElementById("messageCHangePassword").innerHTML="پسورد با موفقیت تغییر یافت.";
            Reset();
            break;
         default:
        }
  }
  });
  }

</script>