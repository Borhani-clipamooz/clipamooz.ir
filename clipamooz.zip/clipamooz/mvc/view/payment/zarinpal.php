<?
//*************************************************************************************************************************
/*$master_apikey='663141746538386975324C79394C547158424D4C39396C7249766B364D464652592B496D3354484B68704D3D';
$sub_apikey='37422F2B565546376B61496247324765434E5A687049526962716D6F77514C6151653865744D317058686B3D';
      $ch = curl_init();
      $master='http://api.kavenegar.com/v1/'.$master_apikey.'/client/fetch.json?apikey='.$sub_apikey;
http://api.kavenegar.com/v1/{API_KEY}/client/fetch.json
// set url
      curl_setopt($ch, CURLOPT_URL, $master);
//return the transfer as a string
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
// $output contains the output string
      $output = curl_exec($ch);
      echo $output;
      $parsed_json = json_decode($output);
      $apikey_sub_customer= $parsed_json->entries->apikey;
      $price= $parsed_json->entries->remaincredit;
      $fullname= $parsed_json->entries->fullname;
      echo $price;
      curl_close( $ch );*/
?>
<div class="middle">
  <h1>افزایش شارژ پنل پیامک</h1>
  <form action="/pay_clipamooz" method="post" id="my_captcha_form" target="_blank">
 <div class="row">
  <div id="fancy-inputs">
    <label class="input" >
      <input type="text" id="Amount" name="Amount" autocomplete="off" onkeypress="javascript:return isNumber(event)"/>
<!--      <span><span>--><?//=$fullname?><!--حداکثر مبلغ شارژ : </span></span>-->
      <span><span> مبلغ شارژ : </span></span>
      <input type="hidden" id="clientId"   name="clientId" value="<?=$clientId?>"/>
    </label>
  </div>
 </div>
    <div class="row" style="padding: 20px 0;">
      <div class="colx-2"></div>
      <div class="colx-8"> <div  class="g-recaptcha" data-sitekey="6Lf752AUAAAAAPzdy25QhXt-ONhder1bySkZkmwr"></div></div>
      <div class="colx-2"></div>
    </div>
    <input type="submit"  class="btn_pay" value="پرداخت">
  </form>
</div>
<!--<script src="https://www.zarinpal.com/webservice/TrustCode" type="text/javascript"></script>-->
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
<script>
  function isNumber(evt) {
    var iKeyCode = (evt.which) ? evt.which : evt.keyCode
    if ( iKeyCode > 31 && (iKeyCode < 48 || iKeyCode > 57))
      return false;

    return true;
  }
  document.getElementById("my_captcha_form").addEventListener("submit",function(evt)
  {

    var response = grecaptcha.getResponse();
    var Amount= $("#Amount").val();
    if(Amount == '')
    {
      //reCaptcha not verified
      swal('مبلغ وارد نشده است');
      evt.preventDefault();
      return false;
    }
    if(response.length == 0)
    {
      //reCaptcha not verified
      swal('لطفاً تیک ربات را بزنید');
      evt.preventDefault();
      return false;
    }
    //captcha verified
    //do the rest of your validations here

  });

  $('#fancy-inputs input[type=text]').blur(function(){
    var $this = $(this);
    if($this.val().length > 0){
      $this.addClass('white');
    }else{
      $this.removeClass('white');
    }

  })


  $('#fancy-radio input[type=radio]').click(function(){

    $('label.radio').removeClass('selected');

    var inputtype = $(this).attr('id');
    // inputtype = m
    if($(this).is(':checked')){
      $('.'+inputtype).addClass('selected');
      // .m .selected
    }else{
      $('.'+inputtype).removeClass('selected');
    }

  })
</script>