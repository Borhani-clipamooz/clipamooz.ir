<div class="rtl">
  <strong style="color: #fff">نوع نمایش</strong>
  <select id="UserFind">
    <option value="name_fa">نام کلیپ</option>
  </select>
  <input type="text" style="width:100px;height: 20px" id="keyword" placeholder="جستجو" value="" autocomplete="off">

</div>
<div id="pageUpdate_superadmin_all_clip"></div>
<script>

  $("#keyword").on('keyup', function () {
    superadmin_all_clip(<?=$pageIndex?>);
  });
  $(function () {
    superadmin_all_clip(<?=$pageIndex?>);
  });

  function superadmin_all_clip(pageIndex) {
    var keyword = $("#keyword").val();
    var SearchFiled = $("#UserFind").val();
    $.ajax({
      url: '/clip/RefreshData_superadmin_all_clip_ajax/' + pageIndex,
      method: 'POST',
      dataType: 'json',
      data: {
        keyword: keyword,
        SearchFiled: SearchFiled
      },
      success: function (output) {
       // console.log(output);
        $("#pageUpdate_superadmin_all_clip").html(output.html);
      }
    });
  }


</script>









