<?php
class PaymentController {

    //  SuperAdmin **** withdraw_money***************************************************
  public function SuperAdmin_withdraw_money($pageIndex) {
    $data['pageIndex'] = $pageIndex;
    View::renderCPanelSuperAdmin("/superadmin/withdraw_money/all_withdraw_money.php", $data);
  }
  public function SuperAdmin_all_withdraw_money_ajax($pageIndex) {
    $NameTable = 'withdraw_money';
    if (isset($_POST['SearchFiled'])) {
      $SearchFiled = $_POST['SearchFiled'];
    } else {
      $SearchFiled = "create_at";
    }
    if (isset($_POST['keyword'])) {
      $keyword = $_POST['keyword'];
    } else {
      $keyword = "";
    }
    $SortType = "id DESC";
    $groupby = '';
    $data = ListAjax($NameTable,$pageIndex,$SearchFiled,$keyword,$SortType,$groupby);
    ob_start();
    View::renderPartial("/superadmin/withdraw_money/all_withdraw_money_ajax.php", $data);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));
  }
  public function detail_clip_upload_user($id) {
    if (isset($_POST['pageIndex'])) {
      $pageIndex = $_POST['pageIndex'];
    } else {
      $pageIndex = 1;
    }
    $record =CommonModel::Fetch_by_every('clips','id',$id);
    ob_start();
    $record['pageIndex'] = $pageIndex;
    View::renderPartial("/clip/user/detail_clip_upload.php", $record);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }
  public function superAdmin_replay_view() {
    if (isset($_POST['pageIndex'])) {
      $pageIndex = $_POST['pageIndex'];
    } else {
      $pageIndex = 1;
    }
    $id = $_POST['id'];
    $record =CommonModel::Fetch_by_every('withdraw_money','id',$id);
    ob_start();
    $record['pageIndex'] = $pageIndex;
    View::renderPartial("/payment/withdraw_money/replay_view.php", $record);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));
  }
  public function superAdmin_update_description() {
      $discription = $_POST['discription'];
      $id = $_POST['id'];
    CommonModel::update_spacial_field($id, 'withdraw_money', 'discription', $discription);
    echo json_encode(array('status' => true));
  }
    //  END SuperAdmin **** withdraw_money***************************************************

  public function request_money() {
    $user_id = $_POST['user_id'];
    $user_cash = $_POST['user_cash'];
    $request_money = $_POST['request_money'];
    if($request_money>$user_cash){
    echo json_encode(array('status' => 'More_than_the_limit',));
    }else{
      $value=$user_cash-$request_money;
      CommonModel::update_spacial_field($user_id, 'users', 'cash', $value);
      PaymentModel:: withdraw_money($user_id, $request_money, getCurrentDateTime(),'');
      echo json_encode(array('status' => 'Successful_requset',));
    }
  }
  public function not_free_pay() {
    //  seller **** froshande***************************************************
    $clip_api_key = $_POST['clip_api_key'];//name_fa->clip name
    $data = CommonModel::Fetch_by_every('clips', 'clip_api_key', $clip_api_key);
    $data2 = CommonModel::Fetch_by_every('users', 'id', $data['user_id']);
    $seller_id = $data2['id'];
    $seller_cash = $data2['cash'];
    $price_clip = $data['price'];
    $amount = $price_clip * (30 / 100);
    $amount2 = $price_clip - $amount;
    //buy   **** kharidar*******************************************************
    $data3 = CommonModel::Fetch_by_every('users', 'id', $_SESSION['user_id']);
    $user_buy_cash = $data3['cash'];

    if ($price_clip == 0) {
      echo json_encode(array('status' => 'free',));
      return;
    }
    if ($user_buy_cash < $price_clip) {
      echo json_encode(array('status' => 'cash',));
      return;
    } else {
      PaymentModel:: pay_buy_clip_insert($_SESSION['user_id'], $data['id'], getCurrentDateTime(), 0, 0);
      $value = $data3['cash'] - ($data['price']);
      CommonModel::update_spacial_field($_SESSION['user_id'], 'users', 'cash', $value);

      CommonModel::update_spacial_field($seller_id, 'users', 'cash', $seller_cash + $amount2);
      echo json_encode(array('status' => 'ok',));
      return;
    }

  }

  public function donate_pay() {
    $clip_id = $_POST['clip_id'];
    $send_mony = $_POST['send_mony'];
    $user_id_seller = $_POST['user_id_seller'];
    $cash_seller = $_POST['cash_seller'];
    $user_id_buyer = $_POST['user_id_buyer'];
    $cash_buyer = $_POST['cash_buyer'];

    if ($user_id_buyer == '') {
      echo json_encode(array('status' => 'not_enter',));
      return;
    }

    if (is_numeric($send_mony) && $send_mony > 0 && $send_mony == round($send_mony, 0)) {
      $amount = $send_mony * (30 / 100);
      $amount2 = $send_mony - $amount;
      if ($cash_buyer < $send_mony) {
        echo json_encode(array('status' => 'The_inventory_is_low',));
        return;
      } elseif ($cash_buyer < $amount2) {
        echo json_encode(array('status' => 'The_inventory_is_low',));
        return;
      } else {
        $data = CommonModel::Fetch_by_all('clips_buy', 'user_id', $user_id_buyer);
        if (in_array($clip_id, array_column($data, 'clip_id'))) {
          // return;
        } else {
          PaymentModel:: pay_buy_clip_insert($user_id_buyer, $clip_id, getCurrentDateTime(), 0, 0);
        }
        $value = $cash_buyer - $send_mony;
        CommonModel::update_spacial_field($user_id_buyer, 'users', 'cash', $value);
        CommonModel::update_spacial_field($user_id_seller, 'users', 'cash', $cash_seller + $amount2);
        echo json_encode(array('status' => 'ok',));
        return;
      }
    } else {
      echo json_encode(array('status' => 'The_payment_amount_is_not_correct',));
      return;
    }
  }

  public function cash_user($id) {
    $data2 = CommonModel::Fetch_by_every('users', 'id', $id);
    $data['user_cash'] = $data2['cash'];
    $data['user_id'] = $data2['id'];
    $data['shaba'] = $data2['shaba'];
    $data['id'] = $id;
    View::renderCPanelUser("/payment/cash.php", $data);
  }
  public function back_payment($id) {
    $data2 = CommonModel::Fetch_by_every('users', 'id', $id);
    $data['user_cash'] = $data2['cash'];
    $data['user_id'] = $data2['id'];
    $data['shaba'] = $data2['shaba'];
    $data['id'] = $id;
    View::renderCPanelUser("/payment/back.php", $data);
  }
  public function shaba() {
   $user_id=$_POST['user_id'];
    $shaba=$_POST['shaba'];
    CommonModel::update_spacial_field($user_id,'users','shaba',$shaba);
  }
  public function cash_user_donate($user_buyer_id) {
    $data2 = CommonModel::Fetch_by_every('users', 'id', $user_buyer_id);
    $data['user_cash'] = $data2['cash'];
    $data['user_id'] = $data2['id'];
    View::renderCPanelUser("/payment/cash.php", $data);
  }

  public function deposits($id,$pageIndex) {
    Unsuccessful_login();
    $data['pageIndex'] = $pageIndex;
    $data['id'] = $id;
    View::renderCPanelUser("/payment/deposits/all_deposits.php", $data);
  }

  public function all_deposits_ajax($pageIndex) {
    $NameTable = 'pay';
    $content = $_POST['user_id'];
    if (isset($_POST['SearchFiled'])) {
      $SearchFiled = $_POST['SearchFiled'];
    } else {
      $SearchFiled = "create_at";
    }
    if (isset($_POST['keyword'])) {
      $keyword = $_POST['keyword'];
    } else {
      $keyword = "";
    }
    $SortType = "id DESC";
    $count = 10;
    $groupby = '';
    $data = ListAjaxPartial($NameTable, $pageIndex, 'user_id', $content, $SearchFiled, $keyword, $SortType, $count, $groupby);
    ob_start();
    View::renderPartial("/payment/deposits/all_deposits_ajax.php", $data);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }
  public function withdraw_money($id,$pageIndex) {
    Unsuccessful_login();
    $data['pageIndex'] = $pageIndex;
    $data['id'] = $id;
    View::renderCPanelUser("/payment/withdraw_money/all_withdraw_money.php", $data);
  }

  public function all_withdraw_money_ajax($pageIndex) {
    $NameTable = 'withdraw_money';
    $content = $_POST['user_id'];
    if (isset($_POST['SearchFiled'])) {
      $SearchFiled = $_POST['SearchFiled'];
    } else {
      $SearchFiled = "create_at";
    }
    if (isset($_POST['keyword'])) {
      $keyword = $_POST['keyword'];
    } else {
      $keyword = "";
    }
    $SortType = "id DESC";
    $count = 10;
    $groupby = '';
    $data = ListAjaxPartial($NameTable, $pageIndex, 'user_id', $content, $SearchFiled, $keyword, $SortType, $count, $groupby);
    ob_start();
    View::renderPartial("/payment/withdraw_money/all_withdraw_money_ajax.php", $data);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));
  }
  public function Check_SaleReferenceId() {
    $SaleReferenceId = $_POST['SaleReferenceId'];
    $Check = CommonModel::Fetch_by_every('pay', 'salerefid', $SaleReferenceId);
    if (!$Check) {
      echo json_encode(array('status' => true,));
    } else {
      echo json_encode(array('status' => false,));
    }
  }
  public function pay_mellat() {
    $price = $_POST['price'];
    $user_id = $_POST['user_id'];
    date_default_timezone_set("Asia/Tehran");
    // $_SESSION["user_id"] = 1039280;
    require_once(getcwd() . '/lib/nusoap/nusoap.php');
    $webservice = "https://bpm.shaparak.ir/pgwchannel/services/pgw?wsdl";
    $newserver = "https://bpm.shaparak.ir/pgwchannel/startpay.mellat";
    $namespace = "http://interfaces.core.sw.bps.com/";
    if (is_numeric($price)) {
      $client = new nusoap_client($webservice);
      if ($client->getError()) {
        //error
        echo "Error:" . $client->getError();
      } else {
        $terminal_id = "2876682";
        $username = "clipamooz1";
        $password = "53321852";
        $amount = $price;
        $localDate = date("Ymd");
        $localTime = date("His");
        $detail = " ";
        $callBackUrl = "https://www.clipamooz.ir/back_payment/$user_id";
        $payer_id = 0;
        $user_id = $_SESSION["user_id"];
        $create = getCurrentDateTime();
        PaymentModel::pay_mony_insert($user_id, $amount, 0, 0, 0, $create);
        $result = CommonModel::last_record('pay');
        $order_id = $result['id'];
        //send parameters
        $params = array(
          "terminalId" => $terminal_id,
          "userName" => $username,
          "userPassword" => $password,
          "orderId" => $order_id,
          //  "orderId" => 111,
          "amount" => $amount,
          "localDate" => $localDate,
          "localTime" => $localTime,
          "additionalData" => $detail,
          "callBackUrl" => $callBackUrl,
          "payerId" => $payer_id
        );

        $result = $client->call("bpPayRequest", $params, $namespace);
        if ($client->fault) {
          echo "Error fault:" . $client->fault;
        } else {
          if ($client->getError()) {
            echo "Error:" . $client->getError();
          } else {
            $result_val = explode(",", $result);
            // $result_val[0] -> result
            //$result_val[1] -> refid
            // echo $result_val[0]." ".$result_val[1];
            echo json_encode(array('result' => $result_val[0], 'refid' => $result_val[1],));
          }
        }
      }
    } else {
      echo "Price is not number!";
    }
  }
  public function verify() {
    $user_id = $_POST['user_id'];
    $RefId = $_POST['RefId'];
    $ResCode = $_POST['ResCode'];
    $SaleOrderId = $_POST['SaleOrderId'];
    $SaleReferenceId = $_POST['SaleReferenceId'];
    if ($ResCode == 0) {
      try {
        $client = @new SoapClient('https://bpm.shaparak.ir/pgwchannel/services/pgw?wsdl');
      } catch (Exception $e) {
        die($e->getMessage());
      }
      $namespace = 'http://interfaces.core.sw.bps.com/';
      $terminalId = "2876682";
      $userName = "clipamooz1";
      $userPassword = "53321852";
      $parameters = array(
        'terminalId' => $terminalId,
        'userName' => $userName,
        'userPassword' => $userPassword,
        'orderId' => $SaleOrderId,
        'saleOrderId' => $SaleOrderId,
        'saleReferenceId' => $SaleReferenceId);
      $result = $client->bpVerifyRequest($parameters, $namespace);

      $resultStr = $result->return;
      $res = @explode(',', $resultStr);
      if (is_array($res)) {

        echo "<script>alert('Pay Response is : " . $resultStr . "');</script>";
//echo "Pay Response is : " . $resultStr;
        $ResCode = $res[0];
        if ($ResCode == "0") {
// Update table, Save RefId
          $resultsettle = $client->bpSettleRequest($parameters, $namespace);
          $resultStrsettle = $resultsettle->return;
          $ressettle = @explode(',', $resultStrsettle);
          $ResCodesettle = $ressettle[0];
          if ($ResCodesettle == "0") {
            $paymentdone = "done";
            $total=0;
            PaymentModel::Update_back($SaleOrderId, $RefId, $SaleReferenceId, $ResCode);
            $data_cash = CommonModel::Fetch_by_every('users', 'id', $user_id);
            $data_mount = CommonModel::Fetch_by_every('pay', 'refid', $RefId);
            $total = $data_cash['cash'] + $data_mount['amount'];
            CommonModel::update_spacial_field($user_id, 'users', 'cash', $total);
          }
        } else {
// log error in app
// Update table, log the error
// Show proper message to user
        }
      }
    }
  }
  public function smsclipamooz() {
    $data['userId'] = $_GET['userId'];
    $data['clientId'] = $_GET['clientId'];
    $data['orderKind'] = $_GET['orderKind'];
    View::render("/payment/zarinpal.php", $data);
  }
  public function pay_clipamooz() {
    $curlx = curl_init();

    curl_setopt($curlx, CURLOPT_URL, "https://www.google.com/recaptcha/api/siteverify");
    curl_setopt($curlx, CURLOPT_HEADER, 0);
    curl_setopt($curlx, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curlx, CURLOPT_POST, 1);

    $post_data =
      [
        'secret' => '6Lf752AUAAAAAE38R0EpPqr_XJMYkPvTHwfDDJMh', //<--- your reCaptcha secret key
        'response' => $_POST['g-recaptcha-response']
      ];

    curl_setopt($curlx, CURLOPT_POSTFIELDS, $post_data);

    $resp = json_decode(curl_exec($curlx));

    curl_close($curlx);

    if ($resp->success)
    {
      //success!
    //  echo 'success!';
      $MerchantID = '2ba6aa08-94ad-48c1-b46e-651c4958fc16'; //Required
      $Amount = $_POST['Amount'];
      $orderKind = $_POST['orderKind'];
      $clientId = $_POST['clientId'];
      $userId = $_POST['userId'];
      $_SESSION['Amount']=$Amount;
      $_SESSION['orderKind']=$orderKind;
      $_SESSION['clientId']=$clientId;
      $_SESSION['userId']=$userId;
      $master_apikey='663141746538386975324C79394C547158424D4C39396C7249766B364D464652592B496D3354484B68704D3D';
// ***************************************************************************************************************************
      $ch = curl_init();
      $master='http://api.kavenegar.com/v1/'.$master_apikey.'/client/fetchbylocalid.json?Localid='.$clientId;
// set url
      curl_setopt($ch, CURLOPT_URL, $master);
//return the transfer as a string
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
// $output contains the output string
      $output = curl_exec($ch);
      $parsed_json = json_decode($output);
      $apikey_sub_customer= $parsed_json->entries->apikey;
      $price= $parsed_json->entries->remaincredit;
      $fullname= $parsed_json->entries->fullname;
      curl_close( $ch );

      $Description = $fullname.': مبلغ'.$Amount; // Required
      $Email = 'clipamooz.ir@gmail.com'; // Optional
      $Mobile = '09153018177'; // Optional
      $CallbackURL = 'https://www.clipamooz.ir/back_payment_zarin'; // Required
      $client = new SoapClient('https://www.zarinpal.com/pg/services/WebGate/wsdl', ['encoding' => 'UTF-8']);
      $result = $client->PaymentRequest(
        [
          'MerchantID' => $MerchantID,
          'Amount' => $Amount,
          'Description' => $Description,
          'Email' => $Email,
          'Mobile' => $Mobile,
          'CallbackURL' => $CallbackURL,
        ]
      );
//Redirect to URL You can do it also by creating a form
      if ($result->Status == 100) {
         // Header('Location: https://www.zarinpal.com/pg/StartPay/'.$result->Authority);
      Header('Location: https://www.zarinpal.com/pg/StartPay/'.$result->Authority.'/ZarinGate');
      } else {
        echo'ERR: '.$result->Status;
      }
    } else
    {
      // failed
      echo "error";
      exit;
    }




  }
  public function back_payment_zarin() {
    $data['id'] = '123';
    View::render("/payment/backzarinpal.php", $data);
  }

}