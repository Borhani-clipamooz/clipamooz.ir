<div class="rtl">
  <strong style="color: #fff">نوع نمایش</strong>
  <select id="UserFind">
    <option value="subject">نام دسته</option>
  </select>
  <input type="text" style="width:100px;height: 20px" id="keyword" placeholder="جستجو" value="" autocomplete="off">

</div>
<div id="paginationUpdate"></div>
<script>

  $("#keyword").on('keyup', function () {
    getPage(<?=$pageIndex?>);
  });
  $(function () {
     getPage(<?=$pageIndex?>);
  });

  function getPage(pageIndex) {

    var keyword = $("#keyword").val();
    var SearchFiled = $("#UserFind").val();
    $.ajax({
      url: '/RefreshData_contact_us/' + pageIndex,
      method: 'POST',
      dataType: 'json',
      data: {
        keyword: keyword,
        SearchFiled: SearchFiled
      },
      success: function (output) {
       // console.log(output);
        $("#paginationUpdate").html(output.html);
      }
    });
  }


</script>









