<?php
$dirPath=$_POST['dirPath'];
// $dir    ='uploadfile/';
#??? ???? ?? ??????
$dir ='';
$parts= explode('/', $dirPath);
for($i=0;$i<count($parts)-1;$i++){
  $dir=$dir.$parts[$i]."/";
}
$file_name =$parts[4];
#??? ???? ?? ??????
$dir_name =$_SERVER['DOCUMENT_ROOT'] .'/'. $dir;

if ( !is_dir($dir_name) )
{
  echo "<br/>this dir does not exist !";
  die ();
}

$d = opendir ( $dir_name );

while ( $f=readdir($d) )
{
  if ( is_file($del_file=$dir_name."/".$f) and $f==$file_name )
  {
    unlink ( $del_file );
    echo "<br/>file deleted :  $file_name";
  }
}



?>