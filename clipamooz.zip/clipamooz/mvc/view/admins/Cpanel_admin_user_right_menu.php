    <div class="titrbox ">
      <div class="row tac" style="background-color: #9b6231">
      <a style="color: #cccfff" href="/main">
        <i  class="icon-home large"></i>&nbsp;&nbsp;خانه اصلی
      </a>
      </div>
    </div>
<div class="title">مدیریت کاربران</div>
<div class="titrbox">
  <ul>
<!--    <a href="/superadmin/all_user_admin/1">  <li>مدیران</li></a>-->
<!--    <a href="/superadmin/all_user_vip/1"><li>کاربران</li></a>-->
  </ul>
</div>

<div class="titrbox">
  <ul>
    <a href="/user/logout/<?=$_SESSION['user_id']?>"><li><?=_exit?></li></a>
  </ul>
</div>


