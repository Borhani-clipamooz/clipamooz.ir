<div class="content">
  <div class="cash">
    <div class="row">
      <div class="colx-4">حساب بانکی : شماره شبا</div>
      <div class="colx-8">
        <h3><input style="width: 100%" type="text"  id="shaba"  value="<?= $shaba ?>"></h3>
      </div>
    </div>
    <div class="row">
      <div class="colx-4">موجودی</div>
      <div class="colx-8">
        <?if($user_cash<=0){?>
            <h3 style="color: red"><?=number_format($user_cash)?>&nbsp;<?=_radio_reial?></h3>
        <?}else{?>
          <?=number_format($user_cash)?>&nbsp;<?=_radio_reial?>
        <? }?>
      </div>
    </div>
    <div class="row">
      <div class="colx-4">افزایش موجودی</div>
      <div class="colx-8">
        <button onclick="cash()" class="btn_style btn-brown" id="submit">پیشنهادات</button>
      </div>
    </div>
    <div class="row" id="cash" style="display: none">
      <div class="container_radiobutton">
        <ul class="list">
          <li class="list__item">
            <input type="radio" class="radio-btn" name="choise" id="a-opt" value="50000" />
            <label for="a-opt" class="label">&nbsp;5 هزار تومان</label>
          </li>
          <li class="list__item">
            <input type="radio" class="radio-btn" name="choise" id="b-opt" value="250000" />
            <label for="b-opt" class="label">&nbsp;25 هزار تومان</label>
          </li>
          <li class="list__item">
            <input type="radio" class="radio-btn" name="choise" id="c-opt" value="500000" />
            <label for="c-opt" class="label">&nbsp;50 هزار تومان</label>
          </li>
          <li class="list__item">
            <input type="radio" class="radio-btn" name="choise" id="d-opt" value="1000000" />
            <label for="d-opt" class="label">&nbsp;100 هزار تومان</label>
          </li>
        </ul>
      </div>
      <button class="btn_style btn-brown" onclick="choice_price()" id="submit">پرداخت</button>
    </div>

  </div>

  <input type="hidden" id="RefId" value="<?=$_POST['RefId']?>">
  <input type="hidden" id="ResCode" value="<?=$_POST['ResCode']?>">
  <input type="hidden" id="SaleOrderId" value="<?=$_POST['SaleOrderId']?>">
  <input type="hidden" id="SaleReferenceId" value="<?=$_POST['SaleReferenceId']?>">
  <input type="hidden" id="Result" value="<?=$_POST['result']?>">
  <input type="hidden" id="user_id" value="<?=$user_id?>">
  <input type="hidden" id="user_cash" value="<?=$user_cash?>">
</div>
<div class="content">
  <div class="cash">
    <div class="row">
      <div class="colx-4">برداشت از حساب مبلغ:</div>
      <div class="colx-8">
        <h3><input style="width: 100%" type="text"  id="request_money" ></h3>
      </div>
    </div>
    <div class="row">
      <div class="colx-4"></div>
      <div class="colx-8">
      <button onclick="submit_application()" class="btn_style btn-brown" >ثبت درخواست</button>
      </div>
    </div>
  </div>
</div>
<script>
  $(function(){
    $("input").each(function () {
      $(this).on('keyup', function () {
        SaveInput();
      });
    });
  });
  function choice_price(){
    $("#submit").after('<div id="loader"><span class="icon-spinner9 huge spin "></span></div>');
    var rates = document.getElementsByName('choise');
    var rate_value,price;
    var user_id = $("#user_id").val();
    for(var i = 0; i < rates.length; i++){
      if(rates[i].checked){
        price = rates[i].value;
     //   window.location = 'http://clipamooz.ir/payment/pay_mellat/' + rate_value;
        $.ajax({
          url:'/payment/pay_mellat',
          type: 'POST',
          dataType:'json',
          data:{
            price:price,
            user_id:user_id
          },
          success:function(data){
            sendData(data.refid);
            //window.location = 'https://bpm.shaparak.ir/pgwchannel/startpay.mellat?RefId=' + data.refid;
            function sendData(value){
              var form=document.createElement("form");
              form.setAttribute("method","post");
              form.setAttribute("action","https://bpm.shaparak.ir/pgwchannel/startpay.mellat");
              var i=document.createElement("input");
              i.setAttribute("name","RefId");
              i.setAttribute("value",value);
              form.appendChild(i);
              document.body.appendChild(form);
              form.submit();
              document.body.removeChild(form);
            }
          }
        });
      }
    }
  }
  function cash(){
    $('#cash').show();
  }
  function SaveInput(){
    var user_id=$("#user_id").val();
    var shaba=$("#shaba").val();

    $.ajax({
      url:'/shaba',
      type: 'POST',
      dataType:'json',
      data:{
        user_id:user_id,
        shaba:shaba

      },
      success:function(data){
      }
    });
  }
  function submit_application(){
    var user_cash=$("#user_cash").val();
    var request_money=$("#request_money").val();
    var user_id=$("#user_id").val();
    $.ajax({
      url:'/payment/request_money',
      type: 'POST',
      dataType:'json',
      data:{
        user_id:user_id,
        user_cash:user_cash,
        request_money:request_money
      },
      success:function(data){
        console.log(data.status);
        switch(data.status)
        {
          case 'More_than_the_limit':
            swal('مبلغ درخواستی بیشتر از موجودی شما می باشد.');
            break;
          case 'Successful_requset':
            swal('مبلغ شما با موفقیت ثبت گردید.');
            break;
        }
      }
    });
  }
</script>
<style>
  * {
    /*box-sizing: border-box;*/
  }

  .container_radiobutton {
    display: flex;
    justify-content: center;
    align-items: center;
   /*width: 960px;*/
    /*min-height: 100vh;*/
    margin: 0 auto;
    line-height: 20px;
    /*background-color: #1B1B1E;*/
  }

  .list {
    flex: 0 80%;
  }
  .list__item {
    position: relative;
  }
  .list__item:hover label {
    color: #000;
  }
  .list__item:hover .label::before {
    border: 3px solid #000;
    margin-right: 30px;
  }

  .radio-btn {
    position: absolute;
    visibility: hidden;
  }
  .radio-btn:checked ~ .label {
    color: #3f250e;
  }
  .radio-btn:checked ~ .label::before {
    margin-right: 30px;
    border: 3px solid #3f250e;
    background: #000;
  }

  .label {
    display: flex;
    align-items: center;
    /*padding: 25px 0 25px 20px;*/
    color: #F8F7FF;
    /*font-size: 20px;*/
    font-weight: 300;
    text-transform: uppercase;
    cursor: pointer;
    transition: all 0.25s linear;
  }

  .label::before {
    display: block;
    content: '';
    border: 3px solid #F8F7FF;
    border-radius: 50%;
    height: 18px;
    width: 18px;
    margin-right: 10px;
    transition: all .25s linear;
  }

</style>
