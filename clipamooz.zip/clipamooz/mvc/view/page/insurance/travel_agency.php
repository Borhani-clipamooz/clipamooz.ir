<div class="row">
  <section id="section-2">
    <div class="about-landing">
      <div class="container">
        <div class="about-text">
          <h2 style="color: #fffccc;">بیمه نامه مدیران آژانس های مسافرتی</h2>
          <p>
            جبران خسارات جانی شامل فوت و نقص عضو و هزینه های پزشکی وارد به شرکت کنندگان در اردو / تور به مشخصات اعلام شده بدین معنا که چنانچه در نتیجه قصور و یا اهمال بیمه گذار خسارتی به افراد مورد اشاره وارد آید و بیمه گذار بر اساس رای مراجع قضایی مسئول جبران خسارت شناخته گردد بیمه گر حداکثر تا سقف تعهدات مندرج در بیمه نامه نسبت به جبران خسارت اقدام خواهد نمود
          </p>
        </div>
        <div class="thumb wow animated zoomIn"><img style="border-radius: 10px" src="/asset/images/insurance/travel_agency.jpg" alt="آژانس های مسافرتی"></div>
      </div>
    </div>
  </section>
  </div>
<div class="row">
  <section>
    <div class="container">
    <div class="info_person">
      <div id="panel1_travel_agency" class="titrbox "> <h1>&nbsp;&nbsp;این بیمه نامه را بیشتر بشناسید<i id="icon_panel1_travel_agency_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="panel1_travel_agency_panel" style="display: none">
        <p style="font-size: 12pt;text-align: justify">
          این بیمه نامه ، هم برای تورهای داخل کشور و هم خارج از کشور صادر میگردد
        </p>
        <p style="font-size: 12pt;text-align: justify">
          چنانچه بیمه گذار درخواست پوشش خسارات ناشی از کوهنوردی را داشته باشد قابل ارائه می باشد
        </p>
        <p style="font-size: 12pt;text-align: justify">
          چنانچه بیمه گذار درخواست پوشش خسارات ناشی از وسایل نقلیه موتوری را داشته باشد قابل ارائه می باشد
        </p>
        <p style="font-size: 12pt;text-align: justify">
          در صورت درخواست پوشش حوادث ناشی از وسایل نقلیه موتوری ، تعهد بیمه گر صرفا مازاد بر بیمه نامه ثالث اتومبیل خواهد بود. (در صورت عدم وجود بیمه نامه معتبر شخص ثالث خسارت قابل پرداخت نمی باشد ) و مجموع پرداختی بیمه گر بابت این پوشش از مبلغ ۵۰۰٫۰۰۰٫۰۰۰ ریال بیشتر نخواهد بود.
        </p>
        <p style="font-size: 12pt;text-align: justify">
          موظف است ۲۴ ساعت قبل از حرکت مشخصات اردو شامل نام و نام خانوادگی و شماره ملی شرکت کنندگان ، مبدا مقصد تاریخ و ساعت حرکت و برگشت را به بیمه گر اعلام نماید در غیر اینصورت بیمه گر تعهدی برای جبران خسارت نخواهد داشت .
        </p>
        <p style="font-size: 12pt;text-align: justify">
          این بیمه نامه صرفا جهت آژانس های مسافرتی که دارای مجوز تور و اردو می باشند و همچنین مراکز علمی و دانشگاهی صادر میگردد
        </p>
        <p style="font-size: 12pt;text-align: justify">
          علاوه بر استثنائات مندرج در شرایط عمومی بیمه نامه ، خسارات ناشی از حوادث دریا نیز استثناست.
        </p>
      </div><!--     END  panel1_kindergarten ****************-->
      <div id="panel2_travel_agency" class="titrbox "> <h1>&nbsp;&nbsp;خطرات تحت پوشش<i id="icon_panel2_travel_agency_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="panel2_travel_agency_panel" style="display: none">
        <p style="font-size: 12pt;text-align: justify">
          جبران خسارت هاي بدنی و مالی وارد به استفاده کنندگان از تورهای مسافرتی در جريان اجرای وظايف بيمه گذار در محل مورد بيمه که منجر به مسئوليت بيمه گذار گردد با رعايت شرايط و مندرجات بيمه نامه
        </p>
        <p style="font-size: 12pt;text-align: justify">
          خسارت ها شامل :
        </p>
        <p style="font-size: 12pt;text-align: justify">
          ۱- هزينه پزشکی
        </p>
        <p style="font-size: 12pt;text-align: justify">
          ۲-نقص عضو
        </p>
        <p style="font-size: 12pt;text-align: justify">
          ۳-فوت
        </p>
        <p style="font-size: 12pt;text-align: justify">
          ۴- مالی
        </p>
      </div>
      <div id="panel3_travel_agency" class="titrbox "> <h1>&nbsp;&nbsp;استثنائات<i id="icon_panel3_travel_agency_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="panel3_travel_agency_panel" style="display: none">
        <p style="font-size: 12pt;text-align: justify">
          ۱-     عوامل مستقيم يا غيرمستقيم جنگ داخلي و خارجي (اعم از اينكه جنگ اعلان شده يا نشده باشد)، تهاجم، عمليات خصمانه، اعتصاب، شورش، اغتشاش، كودتا، حكومت نظامي، محاصره، تصرف و يا اقدامات احتياطي دولت و يا هر مقام مملكتي ديگر، مشاركت شخص و يا اشخاص در مناقشات كارگاهي و يا اعتراضات خصمانه توسط شخص و يا اشخاص در رابطه با تشكيلات سياسي
        </p>
        <p style="font-size: 12pt;text-align: justify">
          ۲-     عوامل مستقيم يا غيرمستقيم در رابطه با قصد و اقدام هرگونه تشكيلات و يا جماعت و گروه بمنظور براندازی دولت قانونی و يا عمليات تروريستی و مشابع.
        </p>
        <p style="font-size: 12pt;text-align: justify">
          ۳-  خسارت مستقيم و غير مستقيم ناشی از انفجارات اتمی و تشعشعات هسته ای
        </p>
        <p style="font-size: 12pt;text-align: justify">
          ۴-     عمد بيمه گذار در تحقق خطر
        </p>
        <p style="font-size: 12pt;text-align: justify">
          ۵-     نزاع و زد و خورد
        </p>
        <p style="font-size: 12pt;text-align: justify">
          ۶ -خسارتهای وارده به اموال متعلق به پيمانكار يا پيمانكاران يا صاحب كار يا هر موسسه ديگری كه در انجام كار دخالت دارند يا كاركنان يا كارگران اين اشخاص و موسسات، همچنين خسارت وارد به اموالی كه در اختيار يا در امانت يا تحت مراقبت آنان باشد.
        </p>
      </div>
      </div>
    </div>
    <!--***********  INFO ---   Person   --   Responsive   ********************************************************************************-->
    </div>
  </section>
  <section>
  <p style="font-size: 12pt;color: #fffccc;text-align: right">
            <span>
              <strong>خرید بیمه نامه :</strong>
            </span>
  </p>
  <p style="font-size: 12pt;text-align: justify">
    جهت خرید بیمه نامه لطفا فرم زیر را  دانلود و پس از تکمیل به یکی از روشها شبکه های اجتماعی (سروش ، تلگرام ، واتس آپ ) و یا ایمیل برای اینجانب ارسال نمایید تا فرم اعلام حق بیمه و متعاقب آن صدور بیمه نامه صورت پذیرد .
  </p>
  </section>
<div class="row">
  <button class="btn btn-brown" onclick="window.location.href='/pdf/travel_agency'">دانلود بیمه نامه مدیران آژانس های مسافرتی</button>
</div>