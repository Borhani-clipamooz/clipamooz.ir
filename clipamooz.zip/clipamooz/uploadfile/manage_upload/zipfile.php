  <?php
  $id = $_POST['id'];
  $field = $_POST['field'];
  $table = $_POST['table'];
  if(isset($_FILES['user-file']["tmp_name"])) {
  //تعیین فرمت یا اندازه مجاز و سایر پارامترها
    $fileExt = pathinfo(@$_FILES['user-file']['name'], PATHINFO_EXTENSION);
  if ($fileExt == 'zip' && $_FILES["user-file"]["size"] <= 10000000) {
    //بررسی سایر خطاهای سرور
    if ($_FILES["user-file"]["error"] > 0){
      echo "<div class=\"server\">خطا: " . $_FILES["user-file"]["error"] . "</div><br />";
      $check_result = 0;
    }
    //بررسی وجود یا عدم وجود فایل با نام مشابه در سرور
    else{
      if (file_exists("user-upload/" . $_FILES["user-file"]["name"])){
        echo "<div class=\"server\">این فایل در حال حاضر وجود دارد! <br /><br />".$_FILES["user-file"]["name"]. "</div><br />";
        $check_result = 0;
      }
      //انتقال و ذخیره فایل در سرور
      else{
        if( @$_FILES['user-file']['name'] != "" )
        {
          $fileName = $_FILES['user-file']['tmp_name'];
          $resizeFileName = time().md5(uniqid(rand(), true));
          $uploadPath =$_SERVER['DOCUMENT_ROOT'] ."/uploadfile/zipfile/files/";

          $address_Save_to_DataBase='/uploadfile/zipfile/files/www.clipamooz.ir'.$resizeFileName.'.'. $fileExt;
          move_uploaded_file($_FILES["user-file"]["tmp_name"],$uploadPath . 'www.clipamooz.ir'.$resizeFileName.'.'. $fileExt);
         $url='https://www.clipamooz.ir/uploader/image_finish/';
        get_web_page($url,$address_Save_to_DataBase,$id,$field,$table);
          }

        else
        {
          die("No file specified!");
        }
        $check_result = 1;
      }
    }
  }
//خطای تعیین فرمت یا اندازه مجاز و سایر پارامترها
  else{
    if($_FILES["user-file"]["size"] > 1000000){
      echo "<div class=\"server\">حجم فایل خیلی زیاد است!</div>";
    }
    else{
      echo "<div class=\"server\">فرمت فایل مجاز نیست!</div>";
    }
    $check_result = 0;
  }
  }
  function get_web_page( $target_url,$address_Save_to_DataBase,$id,$field,$table)
  {
    $ch = curl_init();
    $data=array('address_Save_to_DataBase'=>$address_Save_to_DataBase,'id'=>$id,'field'=>$field,'table'=>$table);
    curl_setopt($ch, CURLOPT_URL,$target_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
    curl_setopt($ch, CURLOPT_POST,true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $content = curl_exec( $ch );
    curl_close( $ch );
    return $content;
  }
  ?>
  <script type="text/javascript">
    window.top.window.upload_end1(<?php echo $check_result; ?>);
  </script>
