<div class="content">
      <input type="text" style="display: none" id="user_id" value="<?=$user_id?>">

<div class="row">
  <div class="title">اطلاعات پایه</div>
  <div class="titrbox">
    <ul>
      <a onclick="info_person_vip(<?=$user_id?>)" ><li>اطلاعات فردی</li></a>
      <a onclick="info_all_clip(1)"><li>کلیپ هایش</li></a>
      <a href="/profile/<?=$user_id?>"><li>پروفایل</li></a>
    </ul>
  </div>
</div>
  <row>
    <div id="info_person_vip"></div>
    <div id="info_all_clip"></div>
  </row>

</div>
<script>
  function info_person_vip(id){
    $.ajax({
      url: '/superadmin/info_person_vip/'+id,
      method: 'POST',
      dataType: 'json',
      data: {
      },
      success: function (output) {
        //console.log(output);
        $("#info_person_vip").html(output.html);
       $("#info_all_clip").html('');
      }
    });
  }
  $("#keyword_detail_user_vip").on('keyup', function () {
    info_all_clip(1);
  });
  function info_all_clip(pageIndex){
    var keyword = $("#keyword_detail_user_vip").val();
    var SearchFiled = $("#UserFind_detail_user_vip").val();
    var user_id = $("#user_id").val();
    $.ajax({
      url: '/superadmin/info_all_clip/'+pageIndex,
      method: 'POST',
      dataType: 'json',
      data: {
        user_id:user_id,
        keyword: keyword,
        SearchFiled: SearchFiled
      },
      success: function (output) {
     //   console.log(output);
        $("#info_all_clip").html(output.html);
        $("#info_person_vip").html('');
      }
    });
  }

</script>















