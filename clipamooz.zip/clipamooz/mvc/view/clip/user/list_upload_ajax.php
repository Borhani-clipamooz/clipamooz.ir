<div class="content">
<div class="all_clip_upload">
  <div class="row">
  <div class="colx-1"><h2>جزئیات</h2>  </div>
  <div class="colx-1"><h2>حذف  </h2></div>
  <div class="colx-10"><h2>  نام کلیپ </h2></div>
</div>
  <? foreach ($list as $feild) {?>
<div class="row">
  <div class="colx-1" style="cursor: pointer"><h3 onclick="View_list_upload_ajax(<?= $feild['id']?>,<?=$pageIndex?>)" class="icon-file-video large"></h3></div>
  <div class="colx-1" style="cursor: pointer"><h3 onclick="Remove('<?= $feild['id']?>','uploader','<?= $feild['address']?>')" class="icon-bin large" ></h3></div>
  <div class="colx-10"><?= $feild['upload_name'] ?></div>
</div>
    <? } ?>
  <br>
  <div class="row">
    <?=pagination('',3,'btn_style btn-brown','btn',$pageIndex,$pageCount,'upload_list')?>
  </div>
  <br>
</div>
<div class="all_clip_upload_responsive">
  <? foreach ($list as $feild) {?>
 <div class="row">
   <div class="colx-2">
     <h2>جزئیات</h2>
   </div>
   <div class="colx-10">
     <h3 onclick="View_list_upload_ajax(<?= $feild['id']?>,<?=$pageIndex?>)" class="icon-file-video large"></h3>
   </div>
 </div>
 <div class="row">
   <div class="colx-2">
     <h2>حذف</h2>
   </div>
   <div class="colx-10">
     <h3 onclick="Remove(<?= $feild['id']?>,'uploader','<?= $feild['address']?>')" class="icon-bin large" ></h3>
   </div>
 </div>
 <div class="row">
   <div class="colx-2">
     <h2>  نام کلیپ </h2>
   </div>
   <div class="colx-10"><?= $feild['upload_name'] ?></div>
 </div>
  <hr>
  <? } ?>
  <div class="row">
    <?=pagination_responsive('',3,'btn_style btn-brown','btn',$pageIndex,$pageCount,'upload_list')?>
  </div>
</div>
  <!--Buttons Filter-->
</div>

<script>
  function View_list_upload_ajax(Id,PageIndex) {
    $.ajax({
      url: '/clip/list_detail_upload_user/' + Id,
      type: 'POST',
      dataType: 'json',
      data:{
        pageIndex:PageIndex
      },
      success: function (data) {
        $("#pageUpdate_list_upload").html(data.html);
      }
    });
  }

  function Remove(Id,table_name,pathFile) {
    swal({
        title: "آیا مطمئن هستید؟",
        text: "شما دیگر قادر به بازیابی این فایل نخواهید بود.",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#5d4126",
        confirmButtonText: "آره، آن را حذف کنید.",
        closeOnConfirm: false,
        cancelButtonText: "لغو"
      },
      function(){
        $.ajax({
          url: '/common/CommonRemove/',
          type: 'POST',
          dataType: 'json',
          data:{
            Id:Id,
            table_name:table_name,
            pathFile:pathFile
          },
          success: function (data) {
           location.reload();
          }
        });
       swal("حذف گردید.");
      });



  }


</script>


