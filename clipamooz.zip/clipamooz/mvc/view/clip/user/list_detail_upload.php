<div class="content">
  <input type="hidden"id="id" value="<?=$id?>">
  <input type="hidden"id="user_id" value="<?=$user_id?>">
<div class="detail_clip_upload">
  <div class="row">
    <div class="colx-2 colm-fill cols-fill"><h2>نام کلیپ</h2></div>
    <div class="colx-9 colm-fill cols-fill">
      <h3><input style="width: 100%" type="text"  id="name_fa"  name="name_fa" value="<?= $upload_name ?>"></h3>
    </div>
    <div class="colx-1 "></div>
  </div>
  <div class="row">
    <div class="colx-2 colm-fill cols-fill"></div>
    <div class="colx-9 colm-fill cols-fill">
      <video id="myplayer_clip_prev_link" style="width: 100%;height:338px" controls autoplay>
        <source src="<?=$config['upload'].$address?>" type="video/mp4">
      </video>
    </div>
    <div class="colx-1 "></div>
  </div>
  <div class="row">
    <div class="colx-2 colm-fill cols-fill"><h2>آدرس</h2></div>
    <div class="colx-9 colm-fill cols-fill"><input  type="text" style="width: 100%" id="myInput" value="<?=$address?>"></div>
    <div class="colx-1 "><button class="btn_style titrbox" onclick="copyAddress();"><h1><h3 class="icon-copy large"></h3></button></div>
  </div>
  <!--<div class="row">
    <button class="btn_style btn-brown" onclick="back(<?/*=$pageIndex*/?>)" >برگشت</button>

  </div>-->
  </div>
</div>
<script>
 /* function back(pageIndex){
    upload_list(pageIndex);
  }*/
  function copyAddress() {
    var copyText = document.getElementById("myInput");
    copyText.select();
    document.execCommand("copy");
    swal("آدرس کپی شد");
  }
  $(function () {
    var id = $("#id").val();
    $("input").each(function () {
      $(this).on('keyup', function () {
        SaveInput();
      });
    });
  });
  /*function back(pageIndex){
    list_upload(pageIndex);
  }*/
  function SaveInput(){
    var id=$("#id").val();
    var name_fa=$("#name_fa").val();
    $.ajax({
      url:'/uploader/UpdateNameClipUpload',
      type: 'POST',
      dataType:'json',
      data:{
        id:id,
        name_fa:name_fa
      },
      success:function(data){
      }
    });
  }
</script>
