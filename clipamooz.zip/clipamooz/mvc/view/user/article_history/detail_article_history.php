<div class=" content">
  <div class="detail_article_history_panel">
  <div id="article_history" class="titrbox "> <h1>&nbsp;&nbsp;مهمترین کتاب‌ها و مقاله‌ها :<i id="icon_academic_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
    <input type="hidden"id="id"value="<?=$id?>">
   <div class="row">
     <div class="colx-6">
       <h2 >نوع(کتاب،مقالهISI،مقاله علمی-پژوهشی و...)</h2>
     </div>
     <div class="colx-6">
       <h2>عنوان</h2>
     </div>
   </div>
    <div class="row">
      <div class="colx-6">
        <h3><input  type="text"  id="article_type"  name="" value="<?=$article_type?>"></h3>
      </div>
      <div class="colx-6">
        <h3><input  type="text"  id="article_name"  name="" value="<?=$article_name?>"></h3>
      </div>
    </div>
    <div class="row">
      <div class="colx-6">
        <h2>سال انتشار</h2>
      </div>
      <div class="colx-6">
        <h2 >نام انتشارات، نشریه و ...</h2>
      </div>
    </div>
      <div class="row">
        <div class="colx-6">
          <h3><input type="text"  id="release_time"  value="<?= $release_time?>"></h3>
        </div>
        <div class="colx-6">
          <h3><input type="text"  id="article_location"  value="<?=$article_location?>"></h3>
        </div>
      </div>
  </div>
<div class="row tac">
  <button  class="btn_style btn-brown" onclick="back(<?=$pageIndex?>)">بازگشت</button>
</div>
</div>
<script>
$(function(){
  $("input").each(function () {
    $(this).on('keyup', function () {
      var id=$("#id").val();
      var article_type=$("#article_type").val();
      var article_name=$("#article_name").val();
      var release_time=$("#release_time").val();
      var article_location=$("#article_location").val();
      $.ajax({
        url:'/user/detail_article_history_update',
        type: 'POST',
        dataType:'json',
        data:{
          id:id,
          article_type:article_type,
          article_name:article_name,
          release_time:release_time,
          article_location:article_location
        },
        success:function(data){
          //console.log(data);
        }
      });


    });
  });
});
  function back(pageIndex){
    article_history(pageIndex);
  }
</script>















