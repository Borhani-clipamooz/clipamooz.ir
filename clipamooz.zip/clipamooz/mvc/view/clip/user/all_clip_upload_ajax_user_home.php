<div class="content">
  <div class="all_clip_upload_user_home">
    <div class="row">
      <div class="colx-1 ">
        <h2 >نمایش</h2>
      </div>
      <div class="colx-5">
        <h2>نام کلیپ</h2>
      </div>
      <div class="colx-1">
        <h2>بازدید</h2>
      </div>
      <div class="colx-1">
        <h2>کلیپ اصلی</h2>
      </div>
      <div class="colx-2">
        <h2>دسته بندی</h2>
      </div>
      <div class="colx-2">
        <h2>بارگزاری</h2>
      </div>
    </div>
      <? foreach ($list as $feild) {?>
    <div class="row">

        <div class="colx-1">
          <h3>    <a href="/g/<?=$feild['clip_api_key']?>" title="<?= $feild['name_fa']?>"><i class="icon-play huge"></i>   </a></h3>
        </div>
        <div class="colx-5">
          <h3><?= $feild['name_fa'] ?></h3>
        </div>
        <div class="colx-1">
          <h3><?=number_format( $feild['opens']) ?></h3>
        </div>
        <div class="colx-1">
          <h3><?=$feild['views']?></h3>
        </div>
        <div class="colx-2">
          <?
          $data=CommonModel::Fetch_by_every('category','id',$feild['category']);
          $data2=CommonModel::Fetch_by_every('subcategories','id',$feild['subcategory']);
          ?>
          <h3><?= $data['name_fa'] ?>/<?=$data2['subcategory_name']?></h3>
        </div>
        <div class="colx-2">
          <h3><?=DateTimeCommon( $feild['created_at'] )?></h3>
        </div>
    </div>
      <?}?>
    <div class="pagination">
      <?=pagination('',3,'btn_style btn-brown','btn',$pageIndex,$pageCount,'clips_panel')?>
    </div>
  </div>
  <div class="all_clip_upload_user_home_responsive">
    <div class="row">
      <div class="colx-6">
        <h2>نام کلیپ</h2>
      </div>
      <div class="colx-4 ">
        <h2 >دسته بندی</h2>
      </div>
      <div class="colx-2">
        <h2>دیده شده</h2>
      </div>
    </div>
    <hr>
      <? foreach ($list as $feild) {?>
      <a href="/g/<?=$feild['clip_api_key']?>">
    <div class="row">
        <div class="colx-6">
          <h3><?= $feild['name_fa'] ?></h3>
        </div>
      <div class="colx-4">
        <?
        $data=CommonModel::Fetch_by_every('category','id',$feild['category']);
        $data2=CommonModel::Fetch_by_every('subcategories','id',$feild['subcategory']);
        ?>
        <h3><?= $data['name_fa'] ?>/<?=$data2['subcategory_name']?></h3>
      </div>
        <div class="colx-2">
          <h3><?=number_format( $feild['opens']) ?> </h3>
        </div>
    </div>
        <hr>
      </a>
      <?}?>
    <div class="pagination">
      <?=pagination_responsive('',1,'btn_style btn-brown','btn',$pageIndex,$pageCount,'clips_panel_responsive')?>
    </div>
    </div>

  </div>

  <!--Buttons Filter-->
</div>



