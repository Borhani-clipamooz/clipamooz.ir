<?
$data=  CommonModel::Fetch_by_every('rating','clip_id',$_SESSION[$clipid]);
?>
<div class="rating">
           <div class="row tac pd5 hf bold"> جزئیات امتیاز </div>
           <div class="row pd3">
             <div class="colx-1"></div>
             <div class="colx-4 hf"><h2>رای دهندگان : </h2></div>
             <div class="colx-6 hf"><h3> <?=$data['count_rate']?></h3></div>
             <div class="colx-1"></div>
           </div>
           <div class="row pd3">
             <div class="colx-1"></div>
             <div class="colx-4 hf"><h2>امتیاز : </h2></div>
             <div class="colx-6 hf"><h3> <?=$data['average']?></h3></div>
             <div class="colx-1"></div>
           </div>
           <div class="row">
             <div class="colx-1"></div>
            <div class="colx-4 hf"><?=$data['rate1']?></div>
            <div class="colx-6"><?echo rating(1,'30px','30px');?></div>
             <div class="colx-1"></div>
           </div>
           <div class="row">
             <div class="colx-1"></div>
            <div class="colx-4 hf"><?=$data['rate2']?></div>
            <div class="colx-6"><?echo rating(2,'30px','30px');?></div>
             <div class="colx-1"></div>
           </div>
           <div class="row">
             <div class="colx-1"></div>
            <div class="colx-4 hf"><?=$data['rate3']?></div>
            <div class="colx-6"><?echo rating(3,'30px','30px');?></div>
             <div class="colx-1"></div>
           </div>
           <div class="row">
             <div class="colx-1"></div>
            <div class="colx-4 hf"><?=$data['rate4']?></div>
            <div class="colx-6"><?echo rating(4,'30px','30px');?></div>
             <div class="colx-1"></div>
           </div>
           <div class="row">
             <div class="colx-1"></div>
            <div class="colx-4 hf"><?=$data['rate5']?></div>
            <div class="colx-6"><?echo rating(5,'30px','30px');?></div>
             <div class="colx-1"></div>
           </div>
</div>

