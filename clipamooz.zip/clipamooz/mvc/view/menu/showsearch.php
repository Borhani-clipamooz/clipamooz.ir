<? global $config;?>
<div style="height: 501px"  id="bob" class="relation_clip" >
  <? foreach ($list as $feild) {?>
    <a href="/g/<?=$feild['clip_api_key']?>" title="<?= $feild['name_fa']?>">
      <div class="row pd0">
        <div class="colx-4">
          <?if($feild['img_link']!=''){?>
          <div class="row">
            <img src="<?= $config['upload'].$feild['img_link'] ?>">
            <? } else{ ?>
              <img src="<?= $config['empty_play']?>" >
            <?}?>
          </div>
          <div class="row">
            <?
            if (strpos($feild['rating'], '.5') !== false) {
              $R_rating=$feild['rating'];
            }else{
              $R_rating=round($feild['rating']);
            }
            rating($R_rating,'15px','15px');?>
          </div>
        </div>

        <div class="colx-8">
          <div class="row">
            <h1 class="video_title" ><?= $feild['name_fa'] ?></h1>
          </div>
          <div class="row">
            <div class="colx-2">
              <?
              $data=CommonModel::Fetch_by_every('users','id',$feild['user_id']);
              $user_name="";
              $user_img="";
              $user_name=$data['user_name'];
              $user_img=$data['profile_pic'];
              ?>
              <?  if($user_img !=''){?>
                <img style="width: 30px;height: 30px;border-radius: 2px" src="<?= $config['upload'].$user_img?>">
              <?}else{?>
                <img style="width: 30px;height: 30px;border-radius: 2px" src="/asset/images/empty/empty-profile/empty-profile-24.png">
              <?}?>
            </div>
            <div class="colx-10">
              <div class="row">
                <div><h3 style="color: #3f250e;font-weight: bold;"><?=$user_name?></h3></div>
              </div>
              <div class="row">
                <?
                $data=CommonModel::Fetch_by_every('category','id',$feild['category']);
                $name_category=$data['name_fa'];

                $data=CommonModel::Fetch_by_every('subcategories','id',$feild['subcategory']);
                $name_sub_category=$data['subcategory_name'];
                ?>
                <div> <h2 class="category_slider"><span style="font-size: 12px;font-weight: bold;"><?= $name_category?>:<?= $name_sub_category?></span></h2></div>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="row box-one" >
            <div class="colx-4 tar">
              <?
              if($feild['clip_long_time']>=3600){
                echo gmdate("H:i:s", $feild['clip_long_time']);
              }else{
                echo gmdate("i:s", $feild['clip_long_time']);
              }
              ?>
              </i>
              <span class="icon-clock"></span>
            </div>
            <div class="colx-4 tac">
                <span class=" icon-eye" aria-hidden="true"><span style="font-family: traffic">&nbsp;<?
                    $number =  number_format( $feild['opens']);
                    echo $number;?></span>
                </span>
            </div>
            <div class="colx-4 tal">
              <span class="icon-play" aria-hidden="true"><span style="font-family: traffic">&nbsp;<?= $feild['views']?></span></span>
            </div>
          </div>
        </div>
    </a>
  <? }?>
  <?
  if(count($list)>=4){?>
    <div style="text-align: center"><a href="/complete_search/<?=$keyword?>"><button onclick="" class="btn_style btn-brown">جستجوی بیشتر</button></a></div>
  <?}?>
</div>


