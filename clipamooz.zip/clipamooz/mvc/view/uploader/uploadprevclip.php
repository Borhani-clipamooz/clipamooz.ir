<div class="content">
  <div class="upload_prev_clip">
    <div class="row">
      <video id="previewPrevClip" style="width: 100%" controls ></video>
    </div>
    <div class="row">
      <img id="img_previewPrevClip" src="/asset/images/loading.gif" style="display: none" />
      <div id="progressBarFilePreviewClip"></div>
    </div>
    <div class="row" style="padding-bottom: 15px">
      <label class="btn btn_style" for="FilePreviewClip" class="btn ">آپلود</label>50MG
      <input type="file" style="display:none"   id="FilePreviewClip">
      <input type="text" style="display: none"  id="id" value="<?=$id?>">
      <input type="text" style="display: none"  id="field_prev_clip" value="<?=$feild_name?>">
      <input type="text" style="display: none"   id="filename_prev_clip" value="<?=generateApiKey()?>">
    </div>
  </div>
</div>
<script type="text/javascript">
  $(function(){
    $('#FilePreviewClip').on('change',function(){
      $('#previewPrevClip').hide();
      var file =this.files[0];
      var type=file.type;
      var size=file.size;
      if(size >50000000) {
        swal("ببخشید حداکثر فایل پیش نمایش 50مگابایت می باشد.");
        $('#img_previewClip').hide();
        return;
      }
      if(type != "video/mp4" ) {
        swal("ببخشید فایل انتخابی را با پسوند mp4 انتخاب نمایید . با تشکر");
        $('#img_previewPrevClip').hide();
        return;
      }
      var fr=new FileReader();
      fr.onload = function(e) {
        $('#img_previewPrevClip').show();
        splitAndSendFile(new Uint8Array(e.target.result), file);
      };
      fr.readAsArrayBuffer(file);
    });


    function splitAndSendFile(dataArray, file) {
      var id= $('#id').val();
      var field= $('#field_prev_clip').val();
      var totalSize=file.size;
      var count_chunk=Math.floor(file.size/1000000)+1;
      var file_name='www.clipamooz.ir_'+ $('#filename_prev_clip').val();
      var count=0;
      var finish=1;
      progressHandlerFilePreviewClip1(count,totalSize);
      console.log('A');
      var i = 0, formData, blob;
      for (; i < dataArray.length; i += 1000000) {
        blob = new Blob([dataArray.subarray(i, i + 1000000)]);
        formData = new FormData();
        formData.append("file", blob, ""+(i / 1000000));
        $.ajax({
          url:"/uploader/upload_prev_file/"+count_chunk+"/"+file_name+"/"+id+"/"+field,
          type: 'POST',
          dataType:'text',
          cache:false,
          contentType:false,
          processData:false,
          data:formData,
          success:function(data){
            console.log(data);
            count=count+1000000;
            finish++;
            progressHandlerFilePreviewClip1(count,totalSize);
            if(finish>count_chunk){
              document.getElementById("progressBarFilePreviewClip").innerHTML="100%";
             location.reload();
            }
          }
        });

      }
    }


    function progressHandlerFilePreviewClip1(blob,filesize){
      //  _("loaded_n_totalFilePreviewClip").innerHTML ="آپلود شد "+blob+" بایت ها از "+filesize;
      var percent = (blob / filesize) * 100;
      document.getElementById("progressBarFilePreviewClip").innerHTML=Math.round(percent)+"%";

    }


  });

</script>
