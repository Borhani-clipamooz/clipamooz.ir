<div class="tac content">
  <br>
  <img src="/asset/images/success.png">
  <br>
  <br>
  <div><?=$message?></div>
</div>
