<?php


class MessageController {
  public function __construct() {

  }



  public function Success() {
    $data = array();
    $data['message'] = "welcome moslem";
    View::renderPartial("/message/success.php", $data);
  }
  public function Unsuccessful_login() {
    $data = array();
    $data['message'] = "کاربر عزیز جهت دیدن این صفحه لطفا به clipamooz.ir وارد شوید.";
    View::render("/message/unsuccessful_login.php", $data);
  }
  public function validate_Upload_isFree() {
    $content = $_POST['upload'];
    $NameTable = "category";
    $whichFeild = "image";
    $result = CommonModel::Fetch_by_every($NameTable, $whichFeild, $content);
    $output = array();
    if (count($result) > 0) {
      $output['isFree'] = false;
    } else {
      $output['isFree'] = true;
    }
    echo json_encode($output);
  }

}