<input style="display: none" id="clip_api_key" type="text" value="<?=$clip_api_key?>">
<div id="pageUpdate_final_clip"></div>
<script>

  $(function () {
    final_clip();
  });

  function final_clip() {
    var clip_api_key = $("#clip_api_key").val();
    $.ajax({
      url: '/final_clip_ajax/',
      method: 'POST',
      dataType: 'json',
      data: {
        clip_api_key: clip_api_key
      },
      success: function (output) {
        //console.log(output);
        $("#pageUpdate_final_clip").html(output.html);
      }
    });
  }


</script>









