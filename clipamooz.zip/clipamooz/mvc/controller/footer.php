<?php


class FooterController {
  public function __construct() {

  }


  public function Footer() {
    ob_start();
    View::renderPartial("/footer/footer.php", array());
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }



}