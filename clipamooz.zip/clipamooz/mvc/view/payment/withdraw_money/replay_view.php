<div class="content">
  <div class="all_deposits">
    <div class="row">
      <div class="colx-2 colm-fill cols-fill"><h2>مبلغ</h2></div>
      <div class="colx-3 colm-fill cols-fill"><h2>تاریخ درخواست</h2></div>
      <div class="colx-7 colm-fill cols-fill"><h2>توضیحات</h2></div>
    </div>
    <div class="row">
      <div class="colx-2 colm-fill cols-fill"><h2><?=$amount?></h2></div>
      <div class="colx-2 colm-fill cols-fill"><h2><?=DateTimeCommon($create_at)?></h2></div>
      <div class="colx-7 colm-fill cols-fill"><textarea id="discription"><?=$discription?></textarea></div>
    </div>
    <div class="row">
      <button class="btn_style btn-brown" onclick="update_description(<?= $id ?>,<?= $pageIndex ?>)">بروزرسانی</button>
    </div>
  </div>
  <br>
  <div class="row">
    <button class="btn_style btn-brown" onclick="back(<?= $pageIndex ?>)">برگشت</button>
  </div>

</div>
<script>
  function back(pageIndex){
    SuperAdmin_withdraw_money(pageIndex);
  }
  function update_description(id,PageIndex) {
    var discription=$('#discription').val();
    $.ajax({
      url: '/payment/superAdmin_update_description/',
      type: 'POST',
      dataType: 'json',
      data:{
        id:id,
        discription:discription,
        pageIndex:PageIndex
      },
      success: function (data) {
        back(PageIndex);
      }
    });
  }
</script>


