<input type="text" style="display: none" id="user_id"  value="<?=$id?>" autocomplete="off">
<div id="paginationUpdate"></div>
<script>

  $("#keyword").on('keyup', function () {
    all_message(<?=$pageIndex?>);
  });
  $(function () {
    all_message(<?=$pageIndex?>);
  });

  function all_message(pageIndex) {

    var keyword = $("#keyword").val();
    var SearchFiled = $("#UserFind").val();
    var user_id = $("#user_id").val();
    $.ajax({
      url: '/all_message_ajax/' + pageIndex,
      method: 'POST',
      dataType: 'json',
      data: {
        user_id:user_id,
        keyword: keyword,
        SearchFiled: SearchFiled
      },
      success: function (output) {
       // console.log(output);
        $("#paginationUpdate").html(output.html);
      }
    });
  }


</script>









