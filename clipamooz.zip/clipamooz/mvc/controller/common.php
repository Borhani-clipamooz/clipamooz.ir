<?php


class CommonController {
  public function __construct() {

  }
  public function captcha() {
    $captcha = $_POST['captcha'];
    if($captcha== $_SESSION['captcha_code']){
      echo json_encode(array('status' => true,));
    }else{
      echo json_encode(array('status' => false,));
    }
  }
  public function datepicker() {
    ob_start();
    View::renderDatePicker("/datepicker/datepicker.php", array());
//    include('/datepicker/datepicker.php');
    $output = ob_get_clean();
     echo json_encode(array('status' => true, 'html' => $output,));
  }
  public function Remove_data() {
    $PathFile = $_POST['pathFile'];
  //  CommonModel::DeleteFile_Remote_Host($PathFile);
   if(CommonModel::DeleteFile($PathFile)){
    echo json_encode(array('status' => true, ));
   }
  }
  public function update_spacial_field() {
    $id = $_POST['id'];
    $table_name = $_POST['table_name'];
    $whichfeild = $_POST['whichfeild'];
    $content = $_POST['content'];
    ob_start();
    CommonModel::update_spacial_field($id,$table_name,$whichfeild,$content);
    ob_get_clean();
  }
  public function CommonRemove() {
    $id = $_POST['Id'];
    $table_name = $_POST['table_name'];
    $PathFile = $_POST['pathFile'];
    ob_start();
    CommonModel::DeleteFile($PathFile);
    CommonModel::Remove_item($id,$table_name);
    ob_get_clean();
    echo json_encode(array('status' => true, ));
  }

}