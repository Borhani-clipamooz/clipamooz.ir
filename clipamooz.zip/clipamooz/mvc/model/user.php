<?php
class UserModel {
  public static function Search($keyword)
  {
    $SortType=" ASC";
    $db=Db::getInstance();
    $record=$db->query("select * from info_person where codemelli LIKE '$keyword' ");
    return $record;

  }
  public static function ListUsers($NameTable,$startIndex=0,$count=10,$SearchFiled,$keyword,$SortType)
  {
    //  $keyword="";
    $SortType1=$SortType." DESC";
    $db=Db::getInstance();
    $record=$db->query("select * from $NameTable where ($SearchFiled LIKE '%$keyword%')  ORDER BY $SortType1 LIMIT $startIndex,$count");
    return $record;

  }


  public static function Fun_UploadImagePathInSql($id,$image){
    $db = Db::getInstance();
    $db->modify("UPDATE users SET profile_pic=:profile_pic
     WHERE id=:id",
      array(
        'id' => $id,
        'profile_pic' => $image,

      ));
  }
  public static function insert_users($user_name,$email,$passwordhash,$profile_pic,$status,$cash,$member_date,$api_key,$user_access,$last_entry,$sample_password){
    $db = Db::getInstance();
    $db->query_insert("INSERT INTO users (user_name,email,password_hash,profile_pic,status,cash,member_date,api_key,user_access,last_entry,sample_password)
             VALUES ( :user_name, :email, :password_hash,:profile_pic,:status,:cash,:member_date,:api_key,:user_access,:last_entry,:sample_password)",
      array(
        'user_name'         => $user_name,
        'email'         => $email,
        'password_hash'         => $passwordhash,
        'member_date'         => $member_date,
        'profile_pic'         => $profile_pic,
        'status'         => $status,
        'cash'         => $cash,
        'api_key'         => $api_key,
        'user_access'         => $user_access,
        'last_entry'         => $last_entry,
        'sample_password'         => $sample_password,
      ));


  }


  //**** education_history *******************************************************************************************************
  public static function Insert_all_education_history_ToSql($user_id,$education_level,$field_of_study,$trend,$term_of_study
    ,$name_of_education_unit,$country,$average){
    $db = Db::getInstance();
    $db->query_insert("INSERT INTO education_history (user_id,education_level,field_of_study,trend,term_of_study
,name_of_education_unit,country,average)
             VALUES ( :user_id,:education_level, :field_of_study, :trend,:term_of_study,:name_of_education_unit,:country,:average)",
      array(
        'user_id'         => $user_id,
        'education_level'         => $education_level,
        'field_of_study'         => $field_of_study,
        'trend'         => $trend,
        'term_of_study'         => $term_of_study,
        'name_of_education_unit'         => $name_of_education_unit,
        'country'         => $country,
        'average'         => $average,
      ));


  }
  public static function detail_education_history_update($id,$education_level,$field_of_study,$trend,$term_of_study
    ,$name_of_education_unit,$country,$average){
    $db = Db::getInstance();
    $db->modify("UPDATE education_history SET education_level=:education_level
 , field_of_study=:field_of_study
 , trend=:trend
 , term_of_study=:term_of_study
 , name_of_education_unit=:name_of_education_unit
 , country=:country
 , average=:average
 WHERE id=:id", array(
      'education_level' => $education_level,
      'field_of_study' => $field_of_study,
      'trend' => $trend,
      'term_of_study' => $term_of_study,
      'name_of_education_unit' => $name_of_education_unit,
      'country' => $country,
      'average' => $average,
      'id' => $id,
    ));
  }
  //**** END  education_history *******************************************************************************************************
  //**** professional_history *******************************************************************************************************
  public static function Insert_all_professional_history_ToSql($user_id,$name_company,$start_collaboration,$finish_collaboration
    ,$responsibility,$type_of_activity,$time_activity){
    $db = Db::getInstance();
    $db->query_insert("INSERT INTO professional_history (user_id,name_company,start_collaboration,finish_collaboration,responsibility,type_of_activity
,time_activity)
             VALUES ( :user_id,:name_company, :start_collaboration, :finish_collaboration,:responsibility,:type_of_activity,:time_activity)",
      array(
        'user_id'         => $user_id,
        'name_company'         => $name_company,
        'start_collaboration'         => $start_collaboration,
        'finish_collaboration'         => $finish_collaboration,
        'responsibility'         => $responsibility,
        'type_of_activity'         => $type_of_activity,
        'time_activity'         => $time_activity,
      ));


  }
  public static function detail_professional_history_update($id,$name_company,$start_collaboration,$finish_collaboration,$responsibility
    ,$type_of_activity,$time_activity){
    $db = Db::getInstance();
    $db->modify("UPDATE professional_history SET name_company=:name_company
 , start_collaboration=:start_collaboration
 , finish_collaboration=:finish_collaboration
 , responsibility=:responsibility
 , type_of_activity=:type_of_activity
 , time_activity=:time_activity
 WHERE id=:id", array(
      'name_company' => $name_company,
      'start_collaboration' => $start_collaboration,
      'finish_collaboration' => $finish_collaboration,
      'responsibility' => $responsibility,
      'type_of_activity' => $type_of_activity,
      'time_activity' => $time_activity,
      'id' => $id,
    ));
  }
  //****END professional_history *******************************************************************************************************
  //****  tutorial_history *******************************************************************************************************
  public static function Insert_all_tutorial_history_ToSql($user_id,$course_name,$level_name,$tutorial_place
    ,$tutorial_year,$tutorial_times){
    $db = Db::getInstance();
    $db->query_insert("INSERT INTO tutorial_history (user_id,course_name,level_name,tutorial_place,tutorial_year,tutorial_times)
             VALUES ( :user_id,:course_name, :level_name, :tutorial_place,:tutorial_year,:tutorial_times)",
      array(
        'user_id'         => $user_id,
        'course_name'         => $course_name,
        'level_name'         => $level_name,
        'tutorial_place'         => $tutorial_place,
        'tutorial_year'         => $tutorial_year,
        'tutorial_times'         => $tutorial_times,
      ));


  }
  public static function detail_tutorial_history_update($id,$course_name,$level_name,$tutorial_place,$tutorial_year
    ,$tutorial_times){
    $db = Db::getInstance();
    $db->modify("UPDATE tutorial_history SET course_name=:course_name
 , level_name=:level_name
 , tutorial_place=:tutorial_place
 , tutorial_year=:tutorial_year
 , tutorial_times=:tutorial_times
 WHERE id=:id", array(
      'course_name' => $course_name,
      'level_name' => $level_name,
      'tutorial_place' => $tutorial_place,
      'tutorial_year' => $tutorial_year,
      'tutorial_times' => $tutorial_times,
      'id' => $id,
    ));
  }
  //**** END  tutorial_history *******************************************************************************************************
  //****  article_history *******************************************************************************************************
  public static function Insert_all_article_history_ToSql($user_id,$article_type,$article_name,$release_time,$article_location){
    $db = Db::getInstance();
    $db->query_insert("INSERT INTO article_history (user_id,article_type,article_name,release_time,article_location)
             VALUES ( :user_id,:article_type,:article_name, :release_time, :article_location)",
      array(
        'user_id'         => $user_id,
        'article_type'         => $article_type,
        'article_name'         => $article_name,
        'release_time'         => $release_time,
        'article_location'         => $article_location,
      ));


  }
  public static function detail_article_history_update($id,$article_type,$article_name,$release_time,$article_location)
  {
    $db = Db::getInstance();
    $db->modify("UPDATE article_history SET
   article_type=:article_type
 , article_name=:article_name
 , release_time=:release_time
 , article_location=:article_location
 WHERE id=:id", array(
      'article_type' => $article_type,
      'article_name' => $article_name,
      'release_time' => $release_time,
      'article_location' => $article_location,
      'id' => $id,
    ));
  }
  //**** END  article_history *******************************************************************************************************
  //****  prize_history *******************************************************************************************************
  public static function Insert_all_prize_history_ToSql($user_id,$prize_name,$receive_date,$grantor){
    $db = Db::getInstance();
    $db->query_insert("INSERT INTO prize_history (user_id,prize_name,receive_date,grantor)
             VALUES ( :user_id,:prize_name,:receive_date, :grantor)",
      array(
        'user_id'         => $user_id,
        'prize_name'         => $prize_name,
        'receive_date'         => $receive_date,
        'grantor'         => $grantor,
      ));


  }
  public static function detail_prize_history_update($id,$prize_name,$receive_date,$grantor)
  {
    $db = Db::getInstance();
    $db->modify("UPDATE prize_history SET
   prize_name=:prize_name
 , receive_date=:receive_date
 , grantor=:grantor
 WHERE id=:id", array(
      'prize_name' => $prize_name,
      'receive_date' => $receive_date,
      'grantor' => $grantor,
      'id' => $id,
    ));
  }
  //**** END  prize_history *******************************************************************************************************
  //****  reasearch_pattern *******************************************************************************************************
  public static function Insert_all_research_pattern_ToSql($user_id,$research_name,$responsibility,$employer
    ,$start_date,$finish_date,$schedule_validity){
    $db = Db::getInstance();
    $db->query_insert("INSERT INTO research_pattern (user_id,research_name,responsibility,employer,start_date,finish_date
,schedule_validity
)
             VALUES ( :user_id,:research_name, :responsibility, :employer,:start_date,:finish_date
             ,:schedule_validity)",
      array(
        'user_id'         => $user_id,
        'research_name'         => $research_name,
        'responsibility'         => $responsibility,
        'employer'         => $employer,
        'start_date'         => $start_date,
        'finish_date'         => $finish_date,
        'schedule_validity'         => $schedule_validity,
      ));


  }
  public static function detail_research_pattern_update($id,$research_name,$responsibility,$employer
    ,$start_date,$finish_date,$schedule_validity){
    $db = Db::getInstance();
    $db->modify("UPDATE research_pattern SET research_name=:research_name
 , responsibility=:responsibility
 , employer=:employer
 , start_date=:start_date
 , finish_date=:finish_date
 , schedule_validity=:schedule_validity
 WHERE id=:id", array(
      'research_name' => $research_name,
      'responsibility' => $responsibility,
      'employer' => $employer,
      'start_date' => $start_date,
      'finish_date' => $finish_date,
      'schedule_validity' => $schedule_validity,
      'id' => $id,
    ));
  }
  //**** END  reasearch_pattern *******************************************************************************************************
  public static function detail_info_person_update($id,$first_name,$last_name,$birthday,$country
    ,$province,$codemelli,$telephone,$website){
    $db = Db::getInstance();
    $db->modify("UPDATE info_person SET
 first_name=:first_name
 , last_name=:last_name
 , birthday=:birthday
 , country=:country
 , province=:province
 , codemelli=:codemelli
 , telephone=:telephone
 , website=:website
 WHERE user_id=:user_id", array(
      'first_name' => $first_name,
      'last_name' => $last_name,
      'country' => $country,
      'province' => $province,
      'codemelli' => $codemelli,
      'telephone' => $telephone,
      'website' => $website,
      'birthday' => $birthday,
      'user_id' => $id,
    ));
  }
  public static function detail_info_mystory_person_update($id,$mystory){
    $db = Db::getInstance();
    $db->modify("UPDATE info_person SET mystory=:mystory WHERE user_id=:user_id", array('mystory' => $mystory,'user_id' => $id,
    ));
  }
  public static function insert_info($user_id,$first_name,$last_name,$birthday,$country,$province,$codemelli,$telephone,$website){
    $db = Db::getInstance();
    $db->query_insert("INSERT INTO info_person (user_id,first_name,last_name,birthday,country,province,codemelli,telephone,website)
             VALUES (  :user_id,:first_name,:last_name,:birthday,:country,:province,:codemelli,:telephone,:website)",
      array(
        'user_id'         => $user_id,
        'first_name'         => $first_name,
        'last_name'         => $last_name,
        'birthday'         => $birthday,
        'country'         => $country,
        'province'         => $province,
        'codemelli'         => $codemelli,
        'telephone'         => $telephone,
        'website'         => $website,
      ));
  }
  public static function insert_network($user_id,$name,$create_date,$user_key,$parent_key,$leg,$payment_status,$paid_date,$sponsor_key){
    $db = Db::getInstance();
    $db->query_insert("INSERT INTO network (user_id,name,create_date,user_key,parent_key,leg,payment_status,paid_date,sponsor_key)
             VALUES (  :user_id,:name,:create_date,:user_key,:parent_key,:leg,:payment_status,:paid_date,:sponsor_key)",
      array(
        'user_id'         => $user_id,
        'name'         => $name,
        'create_date'         => $create_date,
        'user_key'         => $user_key,
        'parent_key'         => $parent_key,
        'leg'         => $leg,
        'payment_status'         => $payment_status,
        'paid_date'         => $paid_date,
        'sponsor_key'         => $sponsor_key,
      ));
  }
  //***********************************************************************************************************************************
  public static function update_cash($id,$cash){
    $db = Db::getInstance();
    $db->modify("UPDATE users SET
     cash=:cash
     WHERE id=:id",
      array(
        'id' => $id,
        'cash' => $cash,

      ));
  }
  public static function promote_user($userId, $user_access){
    $db = Db::getInstance();
    $db->modify("UPDATE users SET user_access=:user_access WHERE id=:id", array(
      'user_access' => $user_access,
      'id' => $userId,
    ));
  }
  public static function ChangeStatus($Id, $Status){
    $db = Db::getInstance();
    $db->modify("UPDATE users SET status=:status WHERE id=:id", array(
      'status' => $Status,
      'id' => $Id,
    ));
  }


  public static function delete_user($id)
  {
    $db=Db::getInstance();
    $db->query("DELETE FROM users where id=:id",array('id'=>$id,));

  }
  public static function view_user($id)
  {
    $db=Db::getInstance();
    $record=$db->query("select * from users where id=:id",array('id'=>$id,));
    return $record;

  }

  public static function get_user_access($userId){
    $db = Db::getInstance();
    $record = $db->first("SELECT user_access FROM users WHERE user_id=:user_id", array(
      'user_id' => $userId,
    ));
    return $record['user_access'];
  }


  public static function Save_Send_message($ticket_id,$sender_user_id,$target_user_id,$body,$created_at,$status){
    $db = Db::getInstance();
    $db->query_insert("INSERT INTO message (ticket_id,sender_user_id,target_user_id,body,created_at,status)
             VALUES ( :ticket_id, :sender_user_id,:target_user_id,:body,:created_at,:status)",
      array(
        'ticket_id'         => $ticket_id,
        'sender_user_id'         => $sender_user_id,
        'target_user_id'         => $target_user_id,
        'body'         => $body,
        'created_at'         => $created_at,
        'status'         => $status,
      ));
  }

  public static function message_ConutNotRead($user_id)
  {
    $db=Db::getInstance();
    $record=$db->
  /*  query("
           SELECT MIN(id) AS id, ticket_id,status
           FROM message
           where sender_user_id='$user_id'
           GROUP BY ticket_id
           ORDER BY 'ASC'
          ",array(user_id=>$user_id));*/

    first("select count(*) AS total from message where (sender_user_id=$user_id)AND (status=1)",array(),'total');
    return $record;

  }

}
