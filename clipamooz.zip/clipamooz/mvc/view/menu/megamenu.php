
<? global $config;?>
<div class="responsive-nav">
 <div class="row">
   <div class="colx-3 colm-3 cols-3  tac">
     <div class="nav-bar tac">
       <span class="icon-bar"></span>
       <span class="icon-bar"></span>
       <span class="icon-bar"></span>
     </div>
   </div>
   <div class="colx-3 colm-3 cols-3  tac">
     <a href="/insurance" target="_blank"> <img style="height: 36px" src="/asset/images/insurance/pasargadInsurance.png" alt="بیمه پاسارگاد"></a>
   </div>
   <div class="colx-3 colm-3 cols-3  tac">
     <div class="nav-profile">
     <?
     if($_SESSION['profile_pic']!=''){?>
       <img style="border-radius: 50%;width: 36px;height: 36px" src="<?=$config['upload'].$_SESSION['profile_pic']?>" alt="">
     <?}else{?>
      <img style="border-radius: 50%" src="/asset/images/empty/empty-profile/empty-profile-36.png" alt="پروفایل خالی">
     <?} ?>
     </div>
     <div class="nav-bar3">
       <ul>
         <?
         if(isVip()){?>
           <li style="text-align: center;margin-top: 5px"><span style="color: greenyellow"><?=$_SESSION['user_name']?></span></li>
           <li><a href="/Cpanel/<?=$_SESSION['user_id']?>/1" ><i style="position: relative;top: 5px" class="icon-user large" ></i>&nbsp;&nbsp;<?=_btn_cpanel?> </a></li>
           <li><a href="support_home" class="inline2"><i  class="icon-spinner4 large"></i><?=_support_ticket?></a></li>
           <li><a href="/logout<?=$_SESSION['user_id']?>"><i class="icon-exit large"></i><?=_btn_logout?></a></li>
         <? }else if(isSuperAdmin()){?>
           <li><a style="font-size: large;font-family: traffic" href="/superadmin/CPanel_superAdmin" class="glyphicon home-icon" target="_blank"><span class="lf icon-user-tie" ></span>&nbsp;&nbsp;مدیریت</a></li>
           <li><a href="/logout<?=$_SESSION['user_id']?>"><i class="icon-exit large"></i><?=_btn_logout?></a></li>
         <? }else if(isAdmin()){?>
           <li><a style="font-size: large;font-family: traffic" href="/superadmin/CPanel_Admin" class="glyphicon home-icon" target="_blank"><span class="lf icon-user-tie" ></span>&nbsp;&nbsp;مدیریت</a></li>
           <li><a href="/logout<?=$_SESSION['user_id']?>"><i class="icon-exit large"></i><?=_btn_logout?></a></li>
         <?}else {?>
           <li><a href="/login" ><i class=" icon-enter large"></i><?=_btn_login?></a></li>
           <li><a href="/registerForm"><i  class="icon-user large"></i><?=_btn_register?></a></li>
           <li><a href="/forgot_password" ><i class="icon-key large"></i><?=_btn_forgot_password?></a></li>
           <li><a href="/request_link_active" ><i class="icon-ticket large"></i><?=_btn_request_link_active?></a></li>
         <?}?>
       </ul>
     </div>
   </div>
   <div class="colx-3 colm-3 cols-3 tac">
    <div class="nav-search">
      <i style="color: #fff;" class="icon-search huge"></i>
      <div class="nav-bar4">
          <div class="search-form">
            <div  id="responsive_search"></div>
          </div>
      </div>
    </div>
   </div>
 </div>
  <div class="nav-bar2" style="height: 200px;overflow: scroll;">
  <nav>
    <ul>
      <li><a href="/main"><i class="icon-home large"></i><?=_home?></a></li>
      <li>
        <div id="category">
        <a href="#"><?=_category?>
          <i id="icon_category_ON" style="float: left" class="icon-arrow-down2"></i>
        </a>
        </div>
        <div id="category_panel" style="display: none;">
        <ul>
           <li id="Electricity">
            <a href="#"><?=_Electricity?><i id="icon_Electricity_ON" style="float: left" class="icon-arrow-down2"></i></a>
          </li>
            <li id="Electricity_panel" style="display: none;">
              <ul>
                <li><a href="/compelete_clips_subcategory/19">آموزش LabVIEW</a></li>
              </ul>
            </li>
          <li id="Network">
            <a href="#"><?=_Network?><i id="icon_Network_ON" style="float: left" class="icon-arrow-down2"></i></a>
          </li>
            <li id="Network_panel" style="display: none;">
              <ul>
                <li><a href="/compelete_clips_subcategory/16"><?=_MCSA_2016?></a></li>
              </ul>
            </li>
          <li id="Graphic">
            <a href="#"><?=_Graphic?><i id="icon_Graphic_ON" style="float: left" class="icon-arrow-down2"></i></a>
          </li>
            <li id="Graphic_panel" style="display: none;">
              <ul>
                <li><a href="/compelete_clips_subcategory/21">فتوشاپ</a></li>
                <li><a href="/compelete_clips_subcategory/30">طراحی نقاشی</a></li>
              </ul>
            </li>
          <li id="web_programing">
            <a href="#"><?=_Web_programming?><i id="icon_category_ON2" style="float: left" class="icon-arrow-down2"></i></a>
          </li>
            <li id="web_programing_panel" style="display: none;">
              <ul>
                <li><a href="/compelete_clips_subcategory/22">آموزش JavaScript</a></li>
                <li><a href="/compelete_clips_subcategory/14">آمورش CSS</a></li>
                <li><a href="/compelete_clips_subcategory/15">آموزش HTML</a></li>
              </ul>
            </li>
          <li id="office_supplies">
            <a href="#"><?=_Office_supplies?><i id="icon_office_supplies_ON2" style="float: left" class="icon-arrow-down2"></i></a>
          </li>
          <li id="office_supplies_panel" style="display: none;">
              <ul>
                <li><a href="/compelete_clips_subcategory/29">چاپگر</a></li>
              </ul>
          </li>
        </ul>
        </div>
      </li>
      <li><a href="#" onclick="$('#section-3').animatescroll();"><i class="icon-question large"></i><?=_question?></a></li>
<!--      <li><a href="/rules"><i class="icon-user-tie large"></i>--><?//=_rules?><!--</a></li>-->
      <li><a href="#" onclick="$('#section-2').animatescroll();"><i  class="icon-happy large"></i><?=_about_us?></a></li>
      <li><a href="#" onclick="$('#section-3').animatescroll();"><i  class="icon-phone large"></i><?=_contact_us?></a></li>
      <li style=" background:transparent;"> <a href="https://telegram.me/clipamoozir"><img src="/asset/images/Telegram.svg" alt="تصویر تلگرام" class="image-icon"></a></li>
      <li style=" background:transparent;"> <a href="https://sapp.ir/clipamooz.ir"><img src="/asset/images/sorosh.png" alt="تصویر سروش" class="image-icon2"></a></li>
      <li style=" background:transparent;"> <a href="/insurance"><img src="/asset/images/insurance/pasargadInsurance.png" alt="تصویر سروش" class="image-icon2"></a></li>
      <li style=" background:transparent;"> <a href="/software"><img src="/asset/images/software/software36.png" alt="تصویر نرم افزار" class="image-icon2"></a></li>
    </ul>

  </nav>
  </div>
</div>

<div class="landing-nav">
<nav>
  <ul>
     <li> <a href="/main"><i class="icon-home large"></i><?=_home?></a></li>
    <li> <a href="#"><?=_category?><i class="arrow-down icon-arrow-down2"></i></a>
      <ul>
        <li><a href=""><?=_Electricity?></a>
          <ul class="submenu">
            <li><a href="/compelete_clips_subcategory/19">آموزش LabVIEW</a></li>
          </ul>
        </li>
        <li><a href=""><?=_Network?></a>
          <ul class="submenu">
            <li><a href="/compelete_clips_subcategory/16"><?=_MCSA_2016?></a></li>
          </ul>
        </li>
        <li><a href=""><?=_Graphic?></a>
          <ul class="submenu">
            <li><a href="/compelete_clips_subcategory/21">فتوشاپ</a></li>
            <li><a href="/compelete_clips_subcategory/30">طراحی نقاشی</a></li>
          </ul>
        </li>
        <li><a href=""><?=_Office_supplies?></a>
          <ul class="submenu">
            <li><a href="/compelete_clips_subcategory/29">چاپگر</a></li>
          </ul>
        </li>
        <li><a href=""><?=_Web_programming?></a>
          <ul class="submenu">
            <li><a href="/compelete_clips_subcategory/14">آموزش CSS</a></li>
            <li><a href="/compelete_clips_subcategory/15">آموزش HTML</a></li>
            <li><a href="/compelete_clips_subcategory/22">آموزش JavaScript</a></li>
          </ul>
        </li>
      </ul>
    </li>
   <li><a href="#" onclick="$('#section-3').animatescroll();"><i class="icon-question large"></i><?=_question?></a></li>
    <li><a href="#" onclick="$('#section-2').animatescroll();"><i  class="icon-happy large"></i><?=_about_us?></a></li>
    <li><a href="#" onclick="$('#section-3').animatescroll();"><i  class="icon-phone large"></i><?=_contact_us?></a></li>
<li style="width: 30%">
  <div class="search-form">
    <div  id="search"></div>
  </div>
</li>
    <li>
      <?
      if($_SESSION['profile_pic']!=''){?>
        <a href=""><img class="image-icon" src="<?=$config['upload'].$_SESSION['profile_pic']?>" alt="تصویر پروفایل"></a>
      <?}else{?>
        <a href=""><img class="image-icon" src="/asset/images/empty/empty-profile/empty-profile-36.png" alt="تصویر پروفایل خالی"></a>
      <?} ?>
      <div class="submenu2">
        <ul>
          <?
          if(isVip()){?>
            <li style="text-align: center;margin-top: 5px"><span style="color: greenyellow"><?=$_SESSION['user_name']?></span></li>
            <li><a href="/Cpanel/<?=$_SESSION['user_id']?>/1" target="_blank" ><i style="position: relative;top: 5px" class="icon-user large" ></i>&nbsp;&nbsp;<?=_btn_cpanel?> </a></li>
            <li><a href="/support_home"><i  class="icon-spinner4 large"></i><?=_support_ticket?></a></li>
            <li><a href="/logout<?=$_SESSION['user_id']?>"><i class="icon-exit large"></i><?=_btn_logout?></a></li>
          <? }else if(isSuperAdmin()){?>
            <li><a style="font-size: large;font-family: traffic" href="/superadmin/CPanel_superAdmin" class="glyphicon home-icon" target="_blank"><span class="lf icon-user-tie" ></span>&nbsp;&nbsp;مدیریت</a></li>
            <li><a href="/logout<?=$_SESSION['user_id']?>"><i class="icon-exit large"></i><?=_btn_logout?></a></li>
          <? }else if(isAdmin()){?>
            <li><a style="font-size: large;font-family: traffic" href="/superadmin/CPanel_Admin" class="glyphicon home-icon" target="_blank"><span class="lf icon-user-tie" ></span>&nbsp;&nbsp;مدیریت</a></li>
            <li><a href="/logout<?=$_SESSION['user_id']?>"><i class="icon-exit large"></i><?=_btn_logout?></a></li>
          <?}else {?>
            <li><a href="/login"><i class="icon-enter large"></i><?=_btn_login?></a></li>
            <!--              <li><a href="/--><?//=_btn_register?><!--"><i style="position: relative;top: 5px" class="icon-user large"></i>&nbsp;&nbsp;--><?//=_btn_register?><!--</a></li>-->
            <li><a href="/registerForm"><i  class="icon-user large"></i><?=_btn_register?></a></li>
            <li><a href="/forgot_password" ><i class="icon-key large"></i><?=_btn_forgot_password?></a></li>
            <li><a href="/request_link_active" ><i class="icon-ticket large"></i><?=_btn_request_link_active?></a></li>
          <?}?>
        </ul>
      </div>
    </li>
    <li style=" background:transparent;"> <a href="https://telegram.me/clipamoozir" target="_blank"><img src="/asset/images/Telegram.svg" alt="تصویر تلگرام" class="image-icon"></a></li>
    <li style=" background:transparent;"> <a href="https://sapp.ir/clipamooz.ir" target="_blank"><img src="/asset/images/sorosh.png" alt="تصویر سروش" class="image-icon2"></a></li>
    <li style=" background:transparent;"> <a href="/insurance" target="_blank"><img src="/asset/images/insurance/pasargadInsurance.png" alt="تصویر بیمه پاسارگاد" class="image-icon2"></a></li>
    <li style=" background:transparent;"> <a href="/software" target="_blank"><img src="/asset/images/software/software36.png" alt="تصویر نرم افزار" class="image-icon2"></a></li>
  </ul>
</nav>
</div>
<script>
  $(function(){
    responsive_search();
    Search();
    $(".nav-bar").click(function(){
      $(".responsive-nav .nav-bar2").toggle(function(){
          $(this).animate({height:300});
        }
      );
      $(".responsive-nav .nav-bar3").hide();
      $(".responsive-nav .nav-bar4").hide();
    });
    $(".nav-profile").click(function(){
      $(".responsive-nav .nav-bar3").toggle(200);
      $(".responsive-nav .nav-bar2").hide();
      $(".responsive-nav .nav-bar4").hide();
    });
    $(".nav-search").click(function(){
      $(".responsive-nav .nav-bar4").show(200);
      $(".responsive-nav .nav-bar2").hide();
      $(".responsive-nav .nav-bar3").hide();
    });

    var icon_category_ON = document.getElementById("icon_category_ON");
    var icon_Electricity_ON = document.getElementById("icon_Electricity_ON");
    var icon_Math_ON = document.getElementById("icon_Math_ON");
    var icon_Network_ON = document.getElementById("icon_Network_ON");
    var icon_Graphic_ON = document.getElementById("icon_Graphic_ON");
    var icon_category_ON2 = document.getElementById("icon_category_ON2");
    var icon_office_supplies_ON2 = document.getElementById("icon_category_ON2");
    $("#category").click(function(){
      $("#category_panel").slideToggle("slow");
      icon_category_ON.classList.toggle("arrow");
    });
    $("#web_programing").click(function(){
      $("#web_programing_panel").slideToggle("slow");
      icon_category_ON2.classList.toggle("arrow");
    });
    $("#Math").click(function(){
      $("#Math_panel").slideToggle("slow");
      icon_Math_ON.classList.toggle("arrow");
    });
    $("#Electricity").click(function(){
      $("#Electricity_panel").slideToggle("slow");
      icon_Electricity_ON.classList.toggle("arrow");
    });
    $("#Network").click(function(){
      $("#Network_panel").slideToggle("slow");
      icon_Network_ON.classList.toggle("arrow");
    });
    $("#Graphic").click(function(){
      $("#Graphic_panel").slideToggle("slow");
      icon_Graphic_ON.classList.toggle("arrow");
    });

    $("#office_supplies").click(function(){
      $("#office_supplies_panel").slideToggle("slow");
      icon_office_supplies_ON.classList.toggle("arrow");
    });

  });
</script>


