<div class="rtl">

  <input type="text" style="display: none" id="user_id"  value="<?=$id?>" autocomplete="off">

</div>
<div id="paginationUpdate"></div>
<script>

  $("#keyword").on('keyup', function () {
    list_question(<?=$pageIndex?>);
  });
  $(function () {
    list_question(<?=$pageIndex?>);
  });

  function list_question(pageIndex) {
    var keyword = $("#keyword").val();
    var SearchFiled = $("#UserFind").val();
    var user_id = $("#user_id").val();
    $.ajax({
      url: '/RefreshData_question/' + pageIndex,
      method: 'POST',
      dataType: 'json',
      data: {
        user_id:user_id,
        keyword: keyword,
        SearchFiled: SearchFiled
      },
      success: function (output) {
       // console.log(output);
        $("#paginationUpdate").html(output.html);
      }
    });
  }


</script>









