<div class="content">
<div class="all_notification">
  <div class="row">
    <div class="colx-1"><h2>حذف</h2></div>
    <div class="colx-1"><h2>نمایش</h2></div>
    <div class="colx-1"><h2>پروفایل</h2></div>
    <div class="colx-1"><h2>نام کاربری</h2></div>
    <div class="colx-3"><h2>کلیپ</h2></div>
    <div class="colx-4"><h2>اعلان ها</h2></div>
    <div class="colx-1"><h2>تاریخ</h2></div>
  </div>
  <? foreach ($list as $feild) {?>
        <?$clip=CommonModel::Fetch_by_every('clips','id',$feild['clip_id']);?>
  <div class="row">
    <div class="colx-1"><h3><span onclick="Remove_item(<?= $feild['id']?>,<?=$pageIndex?>,<?=$feild['reciver_id']?>)"><i style="cursor: pointer;margin-top: 5px" class="icon-bin large"></i></span></h3></div>
    <div class="colx-1"><h3>
        <a target="_blank" href="/g/<?=$clip['clip_api_key']?>">
          <i style="color: #fffccc" class="icon-file-video large"></i>
        </a></h3></div>
    <?$data=CommonModel::Fetch_by_every('users','id',$feild['sender_id']);?>
    <? global $config;?>
    <div class="colx-1"><h3>
        <?  if($data['profile_pic'] !=''){?>
          <a  href="/profile/<?=$data['id']?>" style="color: #f88;font-size: 14pt"><img style="width: 40px;height: 40px;border-radius: 50px" src="<?=$config['upload'].$data['profile_pic']?>"></a>
        <?}else{?>
          <a  href="/profile/<?=$data['id']?>" style="color: #f88;font-size: 14pt"><img style="width: 40px;height: 40px;border-radius: 50px" src="/asset/images/empty/empty-profile/empty-profile-24.png"></a>
        <?}?>
      </h3></div>
    <?$data2=CommonModel::Fetch_by_every('users','id',$feild['sender_id']);?>
    <div class="colx-1"><h3><?= $data2['user_name'] ?></h3></div>
    <div class="colx-3"><h3><?= $feild['clip_name'] ?></h3></div>
    <div class="colx-4"><h3><?= $feild['body_notification'] ?></h3></div>
    <div class="colx-1"><h3><?=DateTimeCommon($feild['created_at']) ?></h3></div>
  </div>
  <? } ?>
  <br>
  <!--Buttons Filter-->
  <div class="row">
  <div><?=pagination('',3,'btn_style btn-brown','btn',$pageIndex,$pageCount,'all_notification')?></div>
  </div>
  <br>
</div>
<div class="all_notification_responsive">
  <? foreach ($list as $feild) {?>
  <div class="row">
   <div class="colx-2"><h2>حذف</h2></div>
    <div class="colx-1"><h3><span onclick="Remove_item(<?= $feild['id']?>,<?=$pageIndex?>,<?=$feild['reciver_id']?>)"><i style="cursor: pointer;margin-top: 5px" class="icon-bin large"></i></span></h3></div>
 </div>
  <div class="row">
   <div class="colx-2"><h2>نمایش</h2></div>
   <div class="colx-10">  <h3>
       <?$clip=CommonModel::Fetch_by_every('clips','id',$feild['clip_id']);?>
       <a target="_blank" href="/g<?=$clip['clip_api_key']?>/<?=$clip['subcategory']?>">
         <i style="color: #fffccc" class="icon-file-video large"></i>
       </a></h3>
   </div>
 </div>
  <div class="row">
   <div class="colx-2"><h2>پروفایل</h2></div>
    <?$data=CommonModel::Fetch_by_every('users','id',$feild['sender_id']);?>
   <div class="colx-10">
     <h3>
       <? global $config;?>
       <?  if($data['profile_pic'] !=''){?>
         <a  href="/profile/<?=$data['id']?>" style="color: #f88;font-size: 14pt"><img style="width: 40px;height: 40px;border-radius: 50px" src="<?=$config['upload'].$data['profile_pic']?>"></a>
       <?}else{?>
         <a  href="/profile/<?=$data['id']?>" style="color: #f88;font-size: 14pt"><img style="width: 40px;height: 40px;border-radius: 50px" src="/asset/images/empty/empty-profile/empty-profile-24.png"></a>
       <?}?>
      </h3>
   </div>
 </div>
  <div class="row">
   <div class="colx-2"><h2>نام کاربری</h2></div>
    <?$data2=CommonModel::Fetch_by_every('users','id',$feild['sender_id']);?>
   <div class="colx-10"><h3><?= $data2['user_name'] ?></h3></div>
 </div>
  <div class="row">
   <div class="colx-2"><h2>کلیپ</h2></div>
   <div class="colx-10"><h3><?= $feild['clip_name'] ?></h3></div>
 </div>
  <div class="row">
   <div class="colx-2"><h2>اعلان ها</h2></div>
   <div class="colx-10"><h3><?= $feild['body_notification'] ?></h3></div>
 </div>
  <div class="row">
   <div class="colx-2"><h2>تاریخ</h2></div>
   <div class="colx-10"><h3><?=DateTimeCommon($feild['created_at']) ?></h3></div>
 </div>
  <hr>
  <? } ?>
    <div class="row">
      <div><?=pagination_responsive('',3,'btn_style btn-brown','btn',$pageIndex,$pageCount,'all_notification')?></div>
    </div>
</div>
</div>

<script>
  function notification_detail(ticket_id,PageIndex) {
    $.ajax({
      url: '/notification_detail/' + ticket_id,
      type: 'POST',
      dataType: 'json',
      data:{
        pageIndex:PageIndex
      },
      success: function (data) {
        $("#paginationUpdate").html(data.html);
      }
    });
  }
  function Remove_item(Id,PageIndex,reciver_id) {

    $.ajax({
      url: '/remove_notification_message/' + Id,
      type: 'POST',
      dataType: 'json',
      data:{
        pageIndex:PageIndex,
        reciver_id:reciver_id
      },
      success: function (data) {
        $("#paginationUpdate").html(data.html);
      }
    });
  }
</script>


