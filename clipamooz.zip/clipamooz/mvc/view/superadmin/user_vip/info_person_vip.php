<script>
  $(function () {
    Fun_URL.clear();
    Fun_URL.getURL('/user/Fun_UploadImagePathInSql/');
    //*****************************************************
    $("input").each(function () {
      $(this).on('keyup', function () {
       // info_person();
      });
      $(this).on('change', function () {
        var id=$("#id").val();
        var cash=$("#cash").val();
        $.ajax({
          url:'/user/cash',
          type: 'POST',
          dataType:'json',
          data:{
            id:id,
            cash:cash
          },
          success:function(data){
            console.log(data);
          }
        });
      });
    });
  });
  $(function(){

    $('#level').val($('#defaultLevel').val());
    $('#responsive_level').val($('#responsive_defaultLevel').val());
    var id=$("#responsive_IDAccess").val();
    $('#level').on('change',function(){
      var level=$("#level").val();
      $.ajax({
        url:'/user/changeLevel',
        type: 'POST',
        dataType:'json',
        data:{
          id:id,
          user_access:level

        },
        success:function(data){
          console.log(data);
        }
      });
    });
    $('#responsive_level').on('change',function(){
      var level=$("#responsive_level").val();
      $.ajax({
        url:'/user/changeLevel',
        type: 'POST',
        dataType:'json',
        data:{
          id:id,
          user_access:level

        },
        success:function(data){
          console.log(data);
        }
      });
    });
  });
  $(function(){
      $('#Status').val($('#defaultStatus').val());
      $('#responsive_Status').val($('#responsive_defaultStatus').val());
    var id=$("#id").val();
    $('#Status').on('change',function(){
    var Status=$("#Status").val();
      $.ajax({
         url:'/user/ChangeStatus',
        type: 'POST',
        dataType:'json',
        data:{
          id:id,
          Status:Status

        },
        success:function(data){
          console.log(data);
        }
      });
    });
    $('#responsive_Status').on('change',function(){
    var Status=$("#responsive_Status").val();
      $.ajax({
         url:'/user/ChangeStatus',
        type: 'POST',
        dataType:'json',
        data:{
          id:id,
          Status:Status

        },
        success:function(data){
          console.log(data);
        }
      });
    });
  });
</script>
<div class=" content">
  <input type="text" style="display: none" id="id"value="<?=$id?>">
  <input type="hidden"id="IDAccess"value="<?=$id?>">
  <input type="hidden"id="defaultLevel"value="<?=$user_access?>">
  <input type="hidden"id="defaultStatus"value="<?=$status?>">
  <input type="hidden"id="responsive_IDAccess"value="<?=$id?>">
  <input type="hidden"id="responsive_defaultLevel"value="<?=$user_access?>">
  <input type="hidden"id="responsive_defaultStatus"value="<?=$status?>">
  <div class="info_person">
  <div class="titrbox"><h1>اطلاعات فردی :<span><?=$email?></span></h1> </div>
  <div class="row">
    <div class="colx-2 colm-fill cols-fill">
      <? global $config;?>
      <?  if($profile_pic !=''){
        if($login_status==1){?>
          <img  src="<?= $config['upload'].$profile_pic ?>" style="width: 200px;height: 150px;border-radius: 5px;border:3px solid  greenyellow;">
        <?  }else{?>
          <img  src="<?= $config['upload']. $profile_pic ?>" style="width: 200px;height: 150px;border-radius: 5px;border:3px solid  red;">
        <?} ?>
      <?}else{
        if($login_status==1){ ?>
          <img  src="/asset/images/empty/empty-profile/empty-profile-128.png" style="width: 200px;height: 200px;border-radius: 5px;border:3px solid  greenyellow;">
        <?  }else{?>
          <img  src="/asset/images/empty/empty-profile/empty-profile-128.png" style="width: 200px;height: 200px;border-radius: 5px;border:3px solid  red;">
        <?}}?>
    </div>
    <div class="colx-10 cols-fill">
      <?
      $data=CommonModel::Fetch_by_all('info_person','user_id',$id,'');
      foreach($data as $field)
      {?>
        <div class="row">
          <div class="colx-2 ">
            <h2>نام</h2>
          </div>
          <div class="colx-2">
            <h2>نام خانوادگی</h2>
          </div>
          <div class="colx-2">
            <h2>وضعیت فعالیت</h2>
          </div>
          <div class="colx-2">
            <h2>سطح دسترسی</h2>
          </div>
          <div class="colx-2">
            <h2>استان</h2>
          </div>
          <div class="colx-2">
            <h2>شهر</h2>
          </div>
        </div>
        <div class="row">
          <div class="colx-2">
            <h3><?=$field['first_name']?></h3>
          </div>
          <div class="colx-2">
            <h3><?=$field['last_name']?></h3>
          </div>
          <div class="colx-2">
            <h3>
              <select id="Status" style="background-color:#a97b50 ; border: 1px solid #322010">
                <option value="0">غیر فعال</option>
                <option value="1">فعال</option>
              </select>
            </h3>
          </div>
          <div class="colx-2">
            <h3>
              <select id="level" style="background-color:#a97b50 ; border: 1px solid #322010">
                <option value="|superadmin|">مدیر کل</option>
                <option value="|admin|">مدیر</option>
                <option value="|vip|">کاربر ویژه</option>
                <option value="|author|">نویسنده</option>
                <option value="|vipauthor|">نویسنده ویژه</option>
                <option value="|user|">کاربر عادی</option>
              </select>


            </h3>
          </div>
          <div class="colx-2">
            <h3><?=$field['province']?></h3>
          </div>
          <div class="colx-2">
            <h3><?=$field['codemelli']?></h3>
          </div>
        </div>
        <div class="row">
          <div class="colx-2">
            <h2 >نوع کاربری</h2>
          </div>
          <div class="colx-2">
            <h2 >تاریخ عضویت</h2>
          </div>
          <div class="colx-2">
            <h2>وب سایت</h2>
          </div>
          <div class="colx-2">
            <h2>نام کاربری</h2>
          </div>
          <div class="colx-2">
            <h2>تلفن</h2>
          </div>
          <div class="colx-2">
            <h2>آخرین ورود</h2>
          </div>
        </div>
        <div class="row">
          <div class="colx-2">
            <?
            $access='';
            $access=CommonModel::identification_user($user_access);
            ?>
            <h3><?=$access?></h3>
          </div>
          <div class="colx-2">
            <h3><?=DateTimeCommon($member_date);?></h3>
          </div>
          <div class="colx-2">
            <h3><?=$field['website']?></h3>
          </div>
          <div class="colx-2">
            <h3><?=$user_name?></h3>
          </div>
          <div class="colx-2">
            <h3><?=$field['telephone']?></h3>
          </div>
          <div class="colx-2">
            <h3><?=DateTimeCommon($last_entry);?></h3>
          </div>
        </div>
      <?}?>
    </div>
  </div>
 </div>
  <div class="info_person_responsive">
    <div class="titrbox" style="color: yellow"> <b style="color: white">اطلاعات فردی :</b><?=$email?> </div>
    <div class="row">
      <div class="colx-2 colm-fill cols-fill">
        <?  if($profile_pic !=''){
          if($login_status==1){?>
            <img  src="<?=$config['upload']. $profile_pic ?>" style="width: 200px;height: 150px;border-radius: 5px;border:3px solid  greenyellow;">
          <?  }else{?>
            <img  src="<?=$config['upload']. $profile_pic ?>" style="width: 200px;height: 150px;border-radius: 5px;border:3px solid  red;">
          <?} ?>
        <?}else{
          if($login_status==1){ ?>
            <img  src="/asset/images/empty/empty-profile/empty-profile-128.png" style="width: 200px;height: 200px;border-radius: 5px;border:3px solid  greenyellow;">
          <?  }else{?>
            <img  src="/asset/images/empty/empty-profile/empty-profile-128.png" style="width: 200px;height: 200px;border-radius: 5px;border:3px solid  red;">
          <?}}?>
      </div>
      <div class="colx-10 cols-fill">
        <?
        $data=CommonModel::Fetch_by_all('info_person','user_id',$id,'');
        foreach($data as $field)
        {?>
        <div class="row">
          <div class="colx-2  ">
            <h2>نام</h2>
          </div>
          <div class="colx-2 ">
            <h2>نام خانوادگی</h2>
          </div>
        </div>
        <div class="row">
          <div class="colx-2">
            <span><?=$field['first_name']?></span>
          </div>
          <div class="colx-2 ">
            <span><?=$field['last_name']?></span>
          </div>
        </div>
        <div class="row">
          <div class="colx-2">
            <h2>وضعیت فعالیت</h2>
          </div>
          <div class="colx-2">
            <h2>شهر</h2>
          </div>
        </div>
        <div class="row">
          <div class="colx-2">
            <select id="responsive_Status" style="background-color:#a97b50 ; border: 1px solid #322010">
              <option value="0">غیر فعال</option>
              <option value="1">فعال</option>
            </select>
          </div>
          <div class="colx-2">
            <span><?=$field['codemelli']?></span>
          </div>
        </div>
        <div class="row">
          <div class="colx-2">
            <h2>تاریخ عضویت</h2>
          </div>
          <div class="colx-2">
            <h2>سطح دسترسی</h2>
          </div>
        </div>
        <div class="row">
          <div class="colx-2">
            <span><?=DateTimeCommon($member_date)?></span>
          </div>
          <div class="colx-2">
            <h3>
              <select id="responsive_level" style="background-color:#a97b50 ; border: 1px solid #322010">
                <option value="|superadmin|">مدیر کل</option>
                <option value="|admin|">مدیر</option>
                <option value="|vip|">کاربر ویژه</option>
                <option value="|author|">نویسنده</option>
                <option value="|vipauthor|">نویسنده ویژه</option>
                <option value="|user|">کاربر عادی</option>
              </select>
            </h3>
          </div>
        </div>
        <div class="row">
          <div class="colx-2">
            <h2>نام کاربری</h2>
          </div>
          <div class="colx-2">
            <h2>تلفن</h2>
          </div>
          <div class="colx-2">
            <h2>آخرین ورود</h2>
          </div>
        </div>
        <div class="row">
          <div class="colx-2">
            <span><?=$user_name?></span>
          </div>
          <div class="colx-2">
            <span><?=$field['telephone']?></span>
          </div>
          <div class="colx-2">
            <span><?echo DateTimeCommon($last_entry);?></span>
          </div>
        </div>
      </div>
      <?}?>
    </div>
    </div>
</div>















