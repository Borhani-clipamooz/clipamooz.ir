
<?php
//if (!defined('test')) { echo "Forbidden Request"; exit; }
GLOBAL $config;
$config['db']['host']="localhost";
$config['db']['user']="clipam_db";
$config['db']['pass']="Borhan@8683054";
$config['db']['name']="clipam_db";
$config['lang'] = 'fa';

$config['salt'] = 'suya9s8ydaiu987vqo28bv9q87B87VPq7E98QVB';
$config['route'] = array(
  //**common ***********************************************
  '/captcha' => '/common/captcha',
  //***user ****************************************
  '/loginCheck' => '/user/loginCheck/',
  '/detail_info_person_update' => '/user/detail_info_person_update',
  '/detail_info_mystory_person_update' => '/user/detail_info_mystory_person_update',
  '/login' => '/user/loginForm',
  '/logout' => '/user/logout/',
  '/Cpanel/' => '/user/Cpanel/',
  '/detail/' => '/user/detail/',
  '/network/' => '/user/network/',
  '/vrify/' => '/user/vrify/',
  '/profile' => '/user/profile',
  '/change_password' => '/user/change_password',
  '/Receive_message_email' => '/user/Receive_message_email',
  '/registerForm' => '/user/registerForm',
  '/send_link_forgot_password' => '/user/send_link_forgot_password',
  '/forgot_password' => '/user/forgot_password',
  '/request_link_active' => '/user/request_link_active',
  '/send_link_request_link_active' => '/user/send_link_request_link_active',
  '/registerUser/' => '/user/registerUser/',
  '/registerForm/' => '/user/registerForm/',
  '/Replay_message/' => '/user/Replay_message/',
  '/message_replay_view/' => '/user/message_replay_view/',
  '/all_message/' => '/user/all_message/',
  '/all_message_superadmin/' => '/superadmin/all_message_superadmin/',
  '/all_message_superadmin_ajax/' => '/superadmin/all_message_superadmin_ajax/',
  '/all_message_ajax/' => '/user/all_message_ajax/',
  '/save_message/' => '/user/save_message/',
  '/all_education_history/' => '/user/all_education_history/',
  '/all_professional_history/' => '/user/all_professional_history/',
  '/all_tutorial_history/' => '/user/all_tutorial_history/',
  '/all_article_history/' => '/user/all_article_history/',
  '/all_prize_history/' => '/user/all_prize_history/',
  '/all_research_pattern/' => '/user/all_research_pattern/',
  //***END user ****************************************
  //question**********************************************************
  '/Replay_question/' => '/question/Replay_question/',
  '/view_question/' => '/question/view_question/',
  '/RefreshData_question/' => '/question/RefreshData_question/',
  '/question_all/' => '/question/question_all/',
  '/Save_Questions/' => '/question/Save_Questions/',
  '/Call_DataBase_question/' => '/question/Call_DataBase_question/',
  //***END question ****************************************
  //notifications**********************************************************
  '/remove_notification_message/' => '/notification/remove_notification_message/',
  '/Replay_notification_notice/' => '/notification/Replay_notification_notice/',
  '/Replay_notification/' => '/notification/Replay_notification/',
  '/notification_detail/' => '/notification/notification_detail/',
  '/all_notifications/' => '/notification/all_notifications/',
  '/RefreshData_notification/' => '/notification/RefreshData_notification/',
  //***END notifications ****************************************
  //payment**********************************************************
  '/Update_back' => '/payment/Update_back',
  '/Check_SaleReferenceId' => '/payment/Check_SaleReferenceId',
  '/all_deposits_ajax' => '/payment/all_deposits_ajax',
  '/deposits' => '/payment/deposits',
  '/withdraw_money' => '/payment/withdraw_money',
  '/all_withdraw_money_ajax' => '/payment/all_withdraw_money_ajax',
  '/cash_user' => '/payment/cash_user',
  '/back_payment' => '/payment/back_payment',
  '/shaba' => '/payment/shaba',
  '/cash_user_donate' => '/payment/cash_user_donate',
  '/not_free_pay' => '/payment/not_free_pay/',
  '/donate_pay' => '/payment/donate_pay/',
  '/pay_clipamooz' => '/payment/pay_clipamooz',
  '/smsclipamooz' => '/payment/smsclipamooz/',
  '/back_payment_zarin' => '/payment/back_payment_zarin',
  // END Payment**********************************************************
  //menu**********************************************************
  '/rules' => '/menu/rules',
  '/guide' => '/menu/guide',
  '/contact_us' => '/menu/contact_us',
  '/frequently_questions' => '/menu/frequently_questions',
  '/complete_search/' => '/menu/complete_search/',
  '/serach/' => '/menu/Search/',
  '/search_admins/' => '/admins/search_admins/',
  '/responsive_search/' => '/menu/responsive_search/',
  //end menu************************************************************
  //**Support************************************************************
  '/Replay_user/' => '/support/Replay_user/',
  '/support_user_detail/' => '/support/support_user_detail/',
  '/support_home' => '/support/support_home',
  '/support_all_ticket/' => '/support/support_all_ticket/',
  '/support_all_ticket_superadmin/' => '/support/support_all_ticket_superadmin/',
  '/RefreshData_support_ticket/' => '/support/RefreshData_support_ticket/',
  '/RefreshData_support_ticket_superadmin/' => '/support/RefreshData_support_ticket_superadmin/',
  '/Send_Message_support_first/' => '/support/Send_Message_support_first/',
  //************End Support********************************************************************************
  //************clip********************************************************************************
  '/RefreshData_user_home/' => '/clip/RefreshData_user_home/',
  '/all_clip_upload/' => '/clip/all_clip_upload/',
  '/list_upload/' => '/clip/list_upload/',
  '/all_clip_buy/' => '/clip/all_clip_buy/',
  '/clip_prev_link/' => '/clip/clip_prev_link/',
  '/relation_clip/' => '/clip/relation_clip/',
  '/clip_link/' => '/clip/clip_link/',
  '/final_clip_ajax' => '/clip/final_clip_ajax/',
  '/clip_explain' => '/clip/explain/',
  '/clip_comments' => '/clip/comments/',
  '/clip_like' => '/clip/like/',
  '/notices/' => '/clip/notices/',
  '/Update_checkbox_notices/' => '/clip/Update_checkbox_notices',
  '/clip_questions/' => '/clip/questions/',
  '/compelete_clips_subcategory/' => '/subcategory/compelete_clips_subcategory/',
  '/g/' => '/clip/play/',
  '/h' => '/clip/final_clip_ajax/',
  //************END clip********************************************************************************
  '/main' => '/page/main/',
  '/Unsuccessful_login' => '/message/Unsuccessful_login',
  '/insurance' => '/page/insurance',
  '/software' => '/page/software',
  '/pdf' => '/page/pdf',

);

$config['UploadDir_ftp']="/public_html/uploadfile/";
$config['UploadDir_save_database']="/uploadfile/";
$config['base'] = 'http://mvc.clipamooz.ir';
$config['base_local'] = 'clipamooz.local';
$config['upload'] = 'http://mvc.clipamooz.ir';
$config['empty_play'] = '/asset/images/empty/empty-play/play.png';
