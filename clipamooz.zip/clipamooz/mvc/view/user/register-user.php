<div class="tac content">
  <div class="signin">
    <div class="row">
      <img  style="width: 150px;height: 100px;" src="/asset/images/logo/logo1.jpg">
    </div>
    <div class="row"><h2 style="font-weight: bold"> قوانین وب سایت</h2></div>
    <div class="row">
      <div class="colx-4 colm-5 cols-0"></div>
      <div class="colx-4 colm-1 cols-fill ">
        <p   id="bob"style="text-align: justify;padding: 10px;height: 150px">
          مواردی که در حین بارگذاری ویدیو باید رعایت شوند عبارتند از :
          •	رعایت حقوق ناشر و مولف
          •	دلخراش و آزار دهنده نبودن
          •	مغایرت نداشتن با شئونات اخلاقی و عرف جامعه
          •	اهانت آمیز نبودن به مقامات سیاسی
          •	نداشتن موزیک متن غیر مجاز
          •	عدم ایجاد تنش و التهاب سیاسی در سایت
          •	عدم تمسخر یک شهروند
          •	اهانت آمیز نبودن به اقلیت های قومی و مذهبی
          » با استناد به ماده 74 قانون تجارت الکترونیک مصوب 17/10/1382 مجلس شورای اسلامی و با عنایت به اینکه سایت کلیپ آموز مصداق بستر مبادلات الکترونیکی صوتی و تصویر است ، مسئولیت نقض حقوق تصریح شده مولفان در قانون فوق از قبیل تکثیر ، اجرا و توزیع و یا هر گونه محتوی خلاف قوانین کشور ایران بر عهده کاربران است.
          » پس از بارگذاری ویدیو، حقوق مربوط به انتشار، حذف و ویرایش ویدیوهای بارگذاری شده نزد کلیپ آموز محفوظ خواهد ماند.
          » سایت کلیپ آموز تابع کلیه قوانین موضوعه کشور به خصوص قانون تجارت الکترونیک است لذا نقض هر رفتاری که متضمن نقض هریک از قوانین کشور باشد مجرمانه تلقی میگردد و قابل پیگیری است .

        </p>
      </div>
      <div class="colx-4 colm-5 cols-0"></div>
    </div>
    <div class="row">
      <div class="colx-5 colm-5 cols-0"></div>
      <div class="colx-1 colm-1 cols-fill">      نام کاربری</div>
      <div class="colx-1 colm-1 cols-fill ">
        <input  type="text" style="width: 200px" placeholder="لاتین تایپ شود" data-rule="user_name_is_Free" id="user_name"  name="user_name" >
      </div>
      <div class="colx-5 colm-5  cols-0 "></div>
    </div>
    <div class="row">
      <div class="colx-5 colm-5 cols-0"></div>
      <div class="colx-1 colm-1 cols-fill">        ایمیل</div>
      <div class="colx-1 colm-1 cols-fill ">
        <input  type="text" style="width: 200px" data-rule="email_is_Free" id="email_register"  name="user_name" >
      </div>
      <div class="colx-5 colm-5  cols-0 "></div>
    </div>
    <div class="row">
      <div class="colx-5 colm-5 cols-0"></div>
      <div class="colx-1 colm-1 cols-fill">        رمز عبور</div>
      <div class="colx-1 colm-1 cols-fill ">
        <input style="color: #000;width: 200px"  data-rule="password" type="password" id="password1" name="password1">
      </div>
      <div class="colx-5 colm-5  cols-0 "></div>
    </div>
    <div class="row">
      <div class="colx-5 colm-5 cols-0"></div>
      <div class="colx-1 colm-1 cols-fill">        تکرار رمز عبور</div>
      <div class="colx-1 colm-1 cols-fill ">
        <input style="color: #000;width: 200px"  data-rule="password" type="password" id="password2" name="password2">
        <input  type="hidden"  id="password" name="password">
      </div>
      <div class="colx-5 colm-5  cols-0 "></div>
    </div>
    <div class="row">
      <div class="colx-5 colm-5 cols-0"></div>
      <div class="colx-1 colm-1 cols-fill"><img src="/mvc/view/common/captcha/captcha_image.jpg.php"></div>
      <div class="colx-1 colm-1 cols-fill"><input style="width: 200px" class="tac hf" type="text" id="captcha_SaveRegister"></div>
      <div class="colx-5 colm-5  cols-0 "></div>
    </div>
    <div class="row">
      <div class="colx-5 colm-5 cols-0"></div>
      <div class="colx-1 colm-1 cols-fill">
        <button class="btn_style btn-brown" id="submit">ثبت نام </button>
      </div>
      <div class="colx-1 colm-1 cols-fill">
        <button class="btn_style btn-brown"  id="btn_reset" onclick="Reset();">بازنشانی</button>
      </div>
      <div class="colx-5 colm-5  cols-0 "></div>
    </div>
    <div id="Register_message_1" style="display: none">
      <span id="Register_message"></span>
    </div>


  </div>

    <div style="display: none">
      <span>تاریخ عضویت</span>
      <input type="datetime"  value="<?=getCurrentDateTime()?>" id="member_date"  style="text-align: center">
    </div>

  </div>
<script src="/asset/js/lib/hash/md5.min.js"></script>
<script src="/asset/js/lib/hash/sha1.min.js"></script>
<script>

  $(function () {
    $("#bob").mCustomScrollbar({
      scrollButtons: {
        enable: true
      },
      theme: "dark"
    });
    $("input").each(function () {
      // validateInput($(this));
      $(this).on('keyup', function () {
        validateInput($(this));
      });
    });
    $("#submit").on('click', function () {
      var validation = true;
      $("input").each(function () {
        if ($(this).hasClass("wrong")) {
          validation = false;
          return;
        }
        var user_name=$("#user_name").val();
        var email=$("#email_register").val();
        var password1=$("#password1").val();
        var password2=$("#password2").val();
        if (user_name==''||email==''||password1==''||password2=='') {
          validation = false;
          return;
        }
      })
      if (!validation) {
        swal("اطلاعات وارد شده دارای اشکال می باشد.");
      } else {
        captcha_SaveRegister();
      }
    });
  });
  function Reset(){
    $("#user_name").val('');
    $("#email_register").val('');
    $("#password1").val('');
    $("#password2").val('');
  }
  function captcha_SaveRegister(){
    var captcha=$("#captcha_SaveRegister").val();
    $.ajax({
      url:'/captcha',
      type: 'POST',
      dataType:'json',
      data:{
        captcha:captcha
      },
      success:function(data){
        if(data.status==false){
          swal("کد وارد شده ایراد دارد.");
          return;
        }else{
          SaveRegisterUser();
        }
      }
    });

  }
  function SaveRegisterUser(){
    var user_name=$("#user_name").val();
    var email=$("#email_register").val();
    var password1=$("#password1").val();
    var password=$("#password").val();
    var member_date=$("#member_date").val();
    $("#submit").after('<div id="loader"><span class="icon-spinner9 huge spin "></span></div>');
    $.ajax({
      url:'/registerUser/',
      type: 'POST',
      dataType:'json',
      data:{
        user_name:user_name,
        email:email,
        password:password,
        member_date:member_date,
        password1:password1

      },
      success:function(data){
        $('#loader').slideUp(1000, function() {
          $(this).remove();
        });
        switch (data.status) {
          case 'false':
          {
            swal("کاربر عزیز قبلا ثبت نام کردید.");
            break;
          }
          case 'true':
          {
            swal({
                title: "به کلیپ آموز خوش آمدید.",
                text: "خوش آ مدید لطفا برای فعال کردن حساب کاربری خود به ایمیل خود مراجعه کرده و روی لینک فعالسازی کلیک نمایید. دقت نمایید ممکن است ایمیل تا چند دقیقه دیگر ارسال شود و یا به لیست هرزنامه‌ها (اسپم) برود.  با تشکر              ",
                imageUrl: "/asset/images/logo/logo.png",
                closeOnConfirm: false,
                showLoaderOnConfirm: true
              },
              function () {
                setTimeout(function () {
                  window.location.href = "/page/home";
                }, 2000);
              });
            break;
          }
          default:
          //  window.location.href = "/h"+name_fa+"/"+subcategory;
        }
      }
    });
  }
</script>