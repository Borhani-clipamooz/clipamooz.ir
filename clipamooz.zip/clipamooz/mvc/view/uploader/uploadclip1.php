<div class="content">
  <div class="upload_clip">
    <div class="row">
      <video id="previewClip" style="width: 100%"  controls ></video>
    </div>
    <div class="row">
      <img id="img_previewClip" src="/asset/images/loading.gif" style="display: none" />
      <div id="progressHandlerFileClip"></div>
    </div>
    <div class="row" style="padding-bottom: 15px">
      <label class="btn btn_style" for="FileClip" class="btn btn_style ">آپلود</label>120MG
      <input type="file" style="display:none"   id="FileClip">
      <input type="text"  style="display: none"  id="id" value="<?=$id?>">
      <input type="text" style="display: none"  id="field_name_clip" value="<?=$feild_name?>">
      <input type="text" style="display: none"   id="field_Main_clip" value="<?=generateApiKey()?>">
     <!-- <?/*
      $randomKey_first=generateApiKey();
      $data_clip_prev_link=CommonModel::View_All_onlyFeild('clips','clip_link');
      foreach ($data_clip_prev_link as $feild) {
        $parts = explode('/', $feild['clip_link']);
        $clip_prev_link = $parts[4];
        if($clip_prev_link == $randomKey_first){
          $randomKey_second=generateApiKey();*/?>
          <input type="text" style="display: none"   id="field_Main_clip" value="<?/*=$randomKey_second*/?>">
          <?/*
          break;
        }else{*/?>
          <input type="text" style="display: none"   id="field_Main_clip" value="<?/*=$randomKey_first*/?>">
        --><?/*}
      }
      */?>
    </div>

</div>
</div>
<script>
  $(function(){
    $('#FileClip').on('change',function(){
      $('#previewClip').hide();
      var file =this.files[0];
      var type=file.type;
      var size=file.size;
      if(size >120000000 ) {
        swal("ببخشید حداکثر سایز 120 مگابایت می باشد");
        $('#img_previewClip').hide();
        return;
      }
      if(type != "video/mp4" ) {
        swal("ببخشید فایل انتخابی را با پسوند mp4 انتخاب نمایید . با تشکر");
        $('#img_previewClip').hide();
        return;
      }
      var fr=new FileReader();
      fr.onload = function(e) {
            $('#img_previewClip').show();
        splitAndSendFile(new Uint8Array(e.target.result), file);
      };
      fr.readAsArrayBuffer(file);
    });
    function splitAndSendFile(dataArray, file) {
      var id= $('#id').val();
      var field= $('#field_name_clip').val();
      var totalSize=file.size;
      var count_chunk=Math.floor(file.size/1000000);
//      console.log(count_chunk);return;
      var file_name= $('#field_Main_clip').val();
      var count=0;
      var finish=1;
      progressHandlerFileClip1(count,totalSize);
      var i = 0, formData, blob;
      for (; i < dataArray.length; i += 1000000) {
        blob = new Blob([dataArray.subarray(i, i + 1000000)]);
        formData = new FormData();
        formData.append("file", blob, ""+(i / 1000000));
        $.ajax({
          url:"/uploader/upload_main_file/"+count_chunk+"/"+file_name+"/"+id+"/"+field,
          type: 'POST',
          dataType:'text',
          cache:false,
          contentType:false,
          processData:false,
          data:formData,
          success:function(data){
            console.log(data);
            count=count+1000000;
            finish++;
            progressHandlerFileClip1(count,totalSize);
            if(finish>count_chunk){
             location.reload();
            }
          }
        });
      }



    }


    function progressHandlerFileClip1(blob,filesize){
      //  _("loaded_n_totalFileClip").innerHTML ="آپلود شد "+blob+" بایت ها از "+filesize;
      var percent = (blob / filesize) * 100;
//      console.log( Math.round(percent));
      document.getElementById("progressHandlerFileClip").innerHTML=Math.round(percent)+"%";

    }
  });

</script>