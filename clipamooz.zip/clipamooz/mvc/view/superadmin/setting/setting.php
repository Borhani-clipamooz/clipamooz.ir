<div class="row">بهینه سازی</div>
<div class="row">
  <input type="text"  id="date_withdraw"  value="<?=$id?>" autocomplete="off">
  <button class="btn_style btn-brown" onclick="optimize()" >optimize</button>
  <span>2019-02-11</span>
</div>
<script>
  function optimize() {
    var date_withdraw = $("#date_withdraw").val();
    $.ajax({
      url: '/superadmin/optimize/',
      method: 'POST',
      dataType: 'json',
      data: {
        date_withdraw:date_withdraw
      },
      success: function (output) {
        console.log(output.html);
      }
    });
  }
</script>