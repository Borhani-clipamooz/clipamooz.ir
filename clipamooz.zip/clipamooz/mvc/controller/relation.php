<?php


class RelationController {
  public function all($pageIndex) {
    if (!isSuperAdmin()) {
      header("Location:/");
      return;
    }
    $result = CommonModel::View_All('clips');
    if (count($result) == 0) {
      message("not-found-information", _not_found_information);
      return;
    }
    $NameTable = 'clips';
    $keyword = "";
    $SearchFiled = "name_fa";
    $SortType = "name_fa";
    $data = ListAjax($NameTable, $pageIndex,$SearchFiled,$keyword,$SortType);
    View::renderCPanelSuperAdmin("/relation/all_clip.php", $data);
  }
  public function RefreshData($pageIndex) {
    $NameTable = 'clips';

    if (isset($_POST['SearchFiled'])) {
      $SearchFiled = $_POST['SearchFiled'];
    } else {
      $SearchFiled = "name_fa";
    }
    if (isset($_POST['keyword'])) {
      $keyword = $_POST['keyword'];
    } else {
      $keyword = "";
    }
    $SortType = "name_fa";

    $data = ListAjax($NameTable, $pageIndex,$SearchFiled, $keyword,$SortType);
    ob_start();
    View::renderPartial("/relation/all_clip_ajax.php", $data);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }
  public function Refresh_all_relation_clip($pageIndex) {
    $NameTable = 'relations';
      $WhichClipId = $_POST['WhichClipId'];
    $IFfeild = "clip_id_1";
    $SortType = "clip_id_1 ASC";
    $clip_id_1 = $WhichClipId;
    $nameClip=$_POST['nameClip'];
    if (isset($_POST['SearchFiled'])) {
      $SearchFiled = $_POST['SearchFiled'];
    } else {
      $SearchFiled = "";
    }
    if (isset($_POST['keyword'])) {
      $keyword = $_POST['keyword'];
    } else {
      $keyword = "";
    }
    $count=10;
    $data = ListAjaxPartial($NameTable, $pageIndex,$WhichClipId,$IFfeild,$SortType, $count);
    ob_start();
    $data['clip_id_1']=$clip_id_1;
    $data['nameClip']=$nameClip;
    View::renderPartial("/relation/all_relation_clip.php", $data);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }
  public function Refresh_all_relation_clip_with_ClipId1($pageIndex,$clip_id_1,$nameClip) {
    $NameTable = 'relations';
    $WhichClipId = $clip_id_1;
    $IFfeild = "clip_id_1";
    $SortType = "clip_id_1 ASC";
    ob_start();
    $count=10;
    $data = ListAjaxPartial($NameTable, $pageIndex,$WhichClipId,$IFfeild,$SortType,$count);
    $data['nameClip']=$nameClip;
    View::renderPartial("/relation/all_relation_clip.php", $data);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }
  public function all_clip_want_add_relation_ajax($pageIndex) {
    $NameTable = 'clips';

    if (isset($_POST['SearchFiled'])) {
      $SearchFiled = $_POST['SearchFiled'];
    } else {
      $SearchFiled = "name_fa";
    }
    if (isset($_POST['keyword'])) {
      $keyword = $_POST['keyword'];
    } else {
      $keyword = "";
    }
    $SortType = "name_fa";
    $clip_id_1 = $_POST['clip_id_1'];
    $nameClip = $_POST['nameClip'];
    $data = ListAjax($NameTable, $pageIndex,$SearchFiled, $keyword,$SortType);
    ob_start();
    $data['clip_id_1']=$clip_id_1;
    $data['nameClip']=$nameClip;
    View::renderPartial("/relation/all_clip_add_relation_ajax.php", $data);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));


  }
  public function view($id) {
    if (isset($_POST['pageIndex'])) {
      $pageIndex = $_POST['pageIndex'];
    } else {
      $pageIndex = 1;
    }
    $result =RelationModel::view_single($id);
    $record = $result;
    ob_start();
    $record['list'] = $record;
    $record['pageIndex']=$pageIndex;
    $record['clip_id_1']=$id;
    $record['nameClip']=$_POST['nameClip'];
    View::renderPartial("/relation/detail_clip.php", $record);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }
  public function Remove_sql_data($Id) {
    $clip_id_1 = $_POST['clip_id_1'];
    ob_start();
    $nameClip=$_POST['nameClip'];
   RelationModel::DelSqlRecord($Id);
    ob_get_clean();
    if (isset($_POST['pageIndex'])) {
      $pageIndex = $_POST['pageIndex'];
    } else {
      $pageIndex = 1;
    }
    $this->Refresh_all_relation_clip_with_ClipId1($pageIndex,$clip_id_1,$nameClip);
  }
  public function InserRelationToSql() {
    $clip_id_1 = $_POST['clip_id_1'];
    $clip_id_2 = $_POST['clip_id_2'];
    $nameClip=$_POST['nameClip'];
    ob_start();
    RelationModel::insert($clip_id_1,$clip_id_2);
    ob_get_clean();
    if (isset($_POST['pageIndex'])) {
      $pageIndex = $_POST['pageIndex'];
    } else {
      $pageIndex = 1;
    }
    $this->Refresh_all_relation_clip_with_ClipId1($pageIndex,$clip_id_1,$nameClip);
  }


}