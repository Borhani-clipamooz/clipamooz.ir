<?php


class UserController {
public function __construct() {

}


public function Fun_UploadImagePathInSql() {

  $id = $_POST['id'];
  $UploadImagePath = $_POST['UploadImagePath'];
  UserModel::Fun_UploadImagePathInSql($id,$UploadImagePath);
}


public function welcome() {
  $data = array();
  $data['pageTitle'] = "welcome moslem";
  View::render("/user/welcome.php", $data);

}


//***************** REGISTER USER  *************************************************
public function registerForm() {
  if (isVip()or isSuperAdmin() or isAdmin()) {
    header("Location:/");
    return;
  }
  View::render("/user/register-user.php", array());
}
public function registerUser() {
  $sample_password = $_POST['password1'];
  $user_name = $_POST['user_name'];
  $email = $_POST['email'];
  $api_key = generateApiKey();
  $passwordhash =PassHash::hash($_POST['password']);
  $member_date = $_POST['member_date'];
  $user_access = '|vip|';
  $data=CommonModel::Fetch_by_every('users','email',$email);
  if($data!=null){
    echo json_encode(array('status' => 'false',));
  }else{
    if($user_name!=null){
      UserModel::insert_users($user_name,$email,$passwordhash,'',0,0,$member_date,$api_key,$user_access,'',$sample_password);
      echo json_encode(array('status' => 'true',));
      ob_start();
      $record=CommonModel::last_record('users');
      $api_key=$record['api_key'];
      global $config;
      $link=$config['base']."/vrify/".$api_key;
      $MsgHTML="<a href=$link>لینک فعال سازی</a>";
      $subject='لینک فعال سازی';
      $message='کاربر عزیز خیلی خوش آمدین برروی لینک فعال سازی کلیک نماید.';
      send_message_email($email,$MsgHTML,$subject,$message,'','');
      ob_get_clean();
    }
  }
}

public function Create_lastRecord_sendEmail() {
  $result=CommonModel::last_record('users');
  $user_id = $result['id'];
  $email = $result['email'];
  // UserModel::insert_info($user_id,"","","","","","","","","","");
  $api_key=$result['api_key'];
  global $config;
  $link=$config['base']."/vrify/".$api_key;
  $MsgHTML="<a href=$link>لینک فعال سازی</a>";
  $subject='لینک فعال سازی';
  $message='کاربر عزیز خیلی خوش آمدین برروی لینک فعال سازی کلیک نماید.';
  send_message_email($email,$MsgHTML,$subject,$message);
}
public function vrify($api_key) {
  $data=CommonModel::Fetch_by_every('users','api_key',$api_key);
  CommonModel::update_spacial_field($data['id'],'users','status',1);
  $user_id=$data['id'];
  $user_name=$data['user_name'];
  $member_date=$data['member_date'];
  $data2=CommonModel::Fetch_by_every('notices','user_id',$user_id);
  $data3=CommonModel::Fetch_by_every('info_person','user_id',$user_id);
//  $data4=CommonModel::Fetch_by_every('network','user_id',$user_id);
  if($data2['user_id']==null){
    ClipModel::insert_notices($user_id);
  }
  if($data3['user_id']==null){
    UserModel::insert_info($user_id,'','','','','','','','');
  }
 /* if($data4['user_id']==null){
    UserModel::insert_network($user_id,$user_name,$member_date,$api_key,'','','','','');
  }*/
  $data['message']='سلام ادب و احترام خدمت کاربر عزیز امیدواریم لحظات خوشی را در وب سایت سپری بنمایید.';
  View::render("/message/success_register.php",$data);
}
//***************** END  REGISTER USER  ****************************************************************************************************
//***************** forgot password  ****************************************************************************************************
public function forgot_password() {
  View::render("/user/forgot_password.php",array());
}
public function send_link_forgot_password() {
  $email = $_POST['email'];
  $record = CommonModel::Fetch_by_every('users', 'email', $email);
  if ($record != null) {
    $password=generateRandomString();
    $password_encrypt=encryptPassword($password);
    $password_hash =PassHash::hash($password_encrypt);
    ob_start();
    $MsgHTML=$password;
    $subject=_ph_recovery_password;
    $message=_ph_message_password;
    send_message_email($email,$MsgHTML,$subject,$message,'','');
    CommonModel::update_spacial_field($record['id'],'users','password_hash',$password_hash);
    ob_get_clean();
    echo json_encode(array('status' => true,));
  }else{
    echo json_encode(array('status' => 'NOT_Exist_Email',));
  }
}
//*****************END forgot password  ****************************************************************************************************
//***************** RECECIVE EMAIL USERS  ****************************************************************************************************
public function Receive_message_email() {
  $family = $_POST['family_send_email'];
  $email = $_POST['email_send_email'];
  $subject = $_POST['subject_send_email'];
  $message = $_POST['message_send_email'];
  ob_start();
  Receive_message_email($email,$family,$subject,$message);
  ob_get_clean();
  echo json_encode(array('status' => true,));
}
//***************** request_link_active  ****************************************************************************************************
public function request_link_active() {
  View::render("/user/request_link_active.php",array());
}
public function send_link_request_link_active() {
  $email = $_POST['email'];
  $record = CommonModel::Fetch_by_every('users', 'email', $email);
  if ($record != null) {
    echo json_encode(array('status' => 'SEND_Email',));
    ob_start();
    $api_key=$record['api_key'];
    global $config;
    $link=$config['base']."/vrify/".$api_key;
    $MsgHTML="<a href=$link>Active LINK</a>";
    $subject='لینک فعال سازی';
    $message='کاربر عزیز خیلی خوش آمدین برروی لینک فعال سازی کلیک نماید.';
    $image=$config['base'].'/asset/logo/logo.png';
    $alt='لینک فعال سازی';
    send_message_email($email,$MsgHTML,$subject,$message,$image,'');
    ob_get_clean();
  }else{
    echo json_encode(array('status' => 'NOT_Exist_Email',));
  }
}
//*****************END request_link_active  ****************************************************************************************************

public function Cpanel($id,$pageIndex) {
  Unsuccessful_login();
  $data =CommonModel::Fetch_by_every('users','id',$id);
  $data2 =CommonModel::Fetch_by_every('info_person','user_id',$data['id']);

  $data['pageTitle']=_clipamooz." | ".$data2['first_name'].' '.$data2['last_name'];
  $data['description']=$data2['telephone'].' '.$data2['province'].' '.$data['email'];
  $data['pageIndex']=$pageIndex;
  $data['author']=$data2['first_name'].' '.$data2['last_name'];
  View::renderCPanelUser("/user/home.php", $data);
}
public function profile($id) {
  $data =CommonModel::Fetch_by_every('users','id',$id);
  if($data==''){
    $data['message']='صفحه مورد نظر حذف گردیده است.';
    View::render("/message/limit-access.php", $data);
  }else {
    $data2 = CommonModel::Fetch_by_every('info_person', 'user_id', $data['id']);
    $data3 = CommonModel::Fetch_by_all('clips', 'user_id', $data['id'], '');
    $value = '';
    for ($i = 0; $i < count($data3); $i++) {
      $value = $value . $data3[$i]['name_fa'] . ",";
    }
    $data['pageTitle'] ='رزومه کاری'." | ". $data2['first_name'] . ' ' . $data2['last_name'];
    $data['description'] = $data2['telephone'] . ' ' . $data2['province'] .' ' . $data['email'] ;
    $data['author'] = $data2['first_name'] . ' ' . $data2['last_name'];
    $data['image'] = baseUrl_upload() . $data['profile_pic'];
    $data['canonical'] = baseUrl() . '/profile/' . $data['id'] . '/' . $data['pageTitle'];
    View::render("/user/home.php", $data);
  }
}
//***************** LOGIN  *************************************************
public function login() {
  if (isset($_POST['user_email'])) {
    $this->loginCheck();
  } else {
    $this->loginForm();
  }
}
public function loginCheck() {
  $user_password =$_POST['passwordUserEncrypt'];
  $content = $_POST['emailUser'];
  $NameTable = "users";
  $whichFeild = "email";
  $record = CommonModel::Fetch_by_every($NameTable, $whichFeild, $content);
  $info_person = CommonModel::Fetch_by_every("info_person","user_id", $record['id']);
  if ($record == null) {
    echo json_encode(array('status' => 'NotExistEmail', ));
  } else {
    $hashedPassword=$record['password_hash'];
    if (PassHash::check_password($hashedPassword,$user_password)) {
      $record2 = CommonModel::Detail_Record($NameTable,$record['id'] );
      $result = $record2['status'];
      switch ($result){
        case 0:
        {
          echo json_encode(array('status' => 'banded', ));
          break;
        }
        case 1:
        {
          $_SESSION['user_id'] = $record['id'];
          $_SESSION['first_last_name'] = $info_person['first_name'].' '.$info_person['last_name'];
          $_SESSION['user_name'] = $record['user_name'];
          $_SESSION['api_key'] = $record['api_key'];
          $_SESSION['profile_pic'] = $record['profile_pic'];
          $_SESSION['email'] = $record['email'];
          $_SESSION['user_access'] = $record['user_access'];
          CommonModel::update_spacial_field($record['id'],'users','last_entry',getCurrentDateTime());
          CommonModel::update_spacial_field($record['id'],'users','login_status',1);
          echo json_encode(array('status' =>'successlogin', ));
          break;
        }
      }
    }else{
      echo json_encode(array('status' => 'passwordISwronge', ));
    }

  }
}

public function loginForm() {

  View::render("/user/login.php", array());
}

public function logout($id) {
  session_destroy();
  header("Location:/");
  CommonModel::update_spacial_field($id,'users','login_status',0);
}
public function popupdonate($user_id_buyer,$clip_api_key) {

  $data =CommonModel::Fetch_by_every('users','id',$user_id_buyer);
  $data1=CommonModel::Fetch_by_every('clips','clip_api_key',$clip_api_key);
  $record['clip_id']=$data1['id'];
  //buyer*****************************************************************
  $record['user_id_buyer']=$data['id'];
  $record['cash_buyer']=$data['cash'];
  //Seller*****************************************************************
  $data_seller =CommonModel::Fetch_by_every('users','id',$data1['user_id']);
  $record['user_id_seller']=$data1['user_id'];
  $record['cash_seller']=$data_seller['cash'];
  View::renderPartial("/user/donate.php", $record);
}

//***************  education_history   *********************************************************************************************
public function Refresh_all_education_history($id) {
  $data['list'] =CommonModel::Fetch_by_all('education_history','user_id',$id,'');
  ob_start();
  View::renderPartial("/user/education_history/all_education_history_ajax.php", $data);
  $output = ob_get_clean();
  echo json_encode(array('status' => true, 'html' => $output,));

}
public function all_education_history($id) {
  Unsuccessful_login();
  $data['id']=$id;
  View::renderCPanelUser("/user/education_history/all_education_history.php", $data);

}
public function detail_education_history($id) {
  Unsuccessful_login();
  $record = CommonModel::Detail_Record('education_history',$id);
  ob_start();
  View::renderPartial("/user/education_history/detail_education_history.php", $record);
  $output = ob_get_clean();
  echo json_encode(array('status' => true, 'html' => $output,));
}
public function detail_education_history_update() {
  Unsuccessful_login();
  $id=$_POST['id'];
  $education_level=$_POST['education_level'];
  $field_of_study=$_POST['field_of_study'];
  $trend=$_POST['trend'];
  $term_of_study=$_POST['term_of_study'];
  $name_of_education_unit=$_POST['name_of_education_unit'];
  $country=$_POST['country'];
  $average=$_POST['average'];
  ob_start();
  UserModel::detail_education_history_update($id,$education_level,$field_of_study,$trend,$term_of_study,$name_of_education_unit,$country,$average);
  $output = ob_get_clean();
  echo json_encode(array('status' => true, 'html' => $output,));
}
public function Insert_all_education_history_ToSql($user_id) {
  Unsuccessful_login();
  ob_start();
  UserModel::Insert_all_education_history_ToSql($user_id,"","","","","","","");
  $output = ob_get_clean();
  $this->Refresh_all_education_history($user_id);
  // echo json_encode(array('status' => true, 'html' => $output,));
}
public function Remove_item_education_history($user_id) {
  Unsuccessful_login();
  $id=$_POST['id'];
  $table_name=$_POST['table_name'];
  ob_start();
  CommonModel::Remove_item($id,$table_name);
  $output = ob_get_clean();
  $this->Refresh_all_education_history($user_id);
  // echo json_encode(array('status' => true, 'html' => $output,));
}
//***************END   education_history   *********************************************************************************************
//***************  professional_history   *********************************************************************************************
public function Refresh_all_professional_history($pageIndex) {
  $NameTable = 'professional_history';
  $content=$_POST['user_id'];
  $SortType = "id DESC";
  $count=10;
  $groupby='';
  $data = ListAjaxPartial($NameTable, $pageIndex,'user_id',$content,'','',$SortType,$count,$groupby);
  ob_start();

  View::renderPartial("/user/professional_history/all_professional_history_ajax.php", $data);
  $output = ob_get_clean();
  echo json_encode(array('status' => true, 'html' => $output,));

}
public function all_professional_history($id,$pageIndex) {
  Unsuccessful_login();
  $data['pageIndex']=$pageIndex;
  $data['id']=$id;
  View::renderCPanelUser("/user/professional_history/all_professional_history.php", $data);

}

public function detail_professional_history($id) {
  Unsuccessful_login();
  if (isset($_POST['pageIndex'])) {
    $pageIndex = $_POST['pageIndex'];
  } else {
    $pageIndex = 1;
  }
  $record = CommonModel::Detail_Record('professional_history',$id);
  $record['pageIndex'] = $pageIndex;
  ob_start();
  View::renderPartial("/user/professional_history/detail_professional_history.php", $record);
  $output = ob_get_clean();
  echo json_encode(array('status' => true, 'html' => $output,));
}

public function detail_professional_history_update() {
  Unsuccessful_login();
  $id=$_POST['id'];
  $name_company=$_POST['name_company'];
  $start_collaboration=$_POST['start_collaboration'];
  $finish_collaboration=$_POST['finish_collaboration'];
  $responsibility=$_POST['responsibility'];
  $type_of_activity=$_POST['type_of_activity'];
  $time_activity=$_POST['time_activity'];
  ob_start();
  UserModel::detail_professional_history_update($id,$name_company,$start_collaboration,$finish_collaboration,$responsibility
    ,$type_of_activity,$time_activity);
  $output = ob_get_clean();
  echo json_encode(array('status' => true, 'html' => $output,));
}

public function Insert_all_professional_history_ToSql($pageIndex) {
  Unsuccessful_login();
  $user_id = $_POST['user_id'];
  ob_start();
  UserModel::Insert_all_professional_history_ToSql($user_id,"","","","","","");
  $output = ob_get_clean();
  $this->Refresh_all_professional_history($pageIndex);
}

public function Remove_item_professional_history($pageIndex) {
  Unsuccessful_login();
  $id=$_POST['id'];
  $table_name=$_POST['table_name'];
  ob_start();
  CommonModel::Remove_item($id,$table_name);
  $output = ob_get_clean();
  $this->Refresh_all_professional_history($pageIndex);
}
//***************END   professional_history   *********************************************************************************************
//***************  tutorial_history   *********************************************************************************************
public function Refresh_all_tutorial_history($pageIndex) {
  $NameTable = 'tutorial_history';
  $content=$_POST['user_id'];
  $SortType = "id DESC";
  $count=10;
  $groupby='';
  $data = ListAjaxPartial($NameTable, $pageIndex,'user_id',$content,'','',$SortType,$count,$groupby);
  ob_start();
  View::renderPartial("/user/tutorial_history/all_tutorial_history_ajax.php", $data);
  $output = ob_get_clean();
  echo json_encode(array('status' => true, 'html' => $output,));

}
public function all_tutorial_history($id,$pageIndex) {
  Unsuccessful_login();
  $data['pageIndex']=$pageIndex;
  $data['id']=$id;
  View::renderCPanelUser("/user/tutorial_history/all_tutorial_history.php", $data);

}

public function detail_tutorial_history($id) {
  Unsuccessful_login();
  if (isset($_POST['pageIndex'])) {
    $pageIndex = $_POST['pageIndex'];
  } else {
    $pageIndex = 1;
  }
  $record = CommonModel::Detail_Record('tutorial_history',$id);
  $record['pageIndex'] = $pageIndex;
  ob_start();
  View::renderPartial("/user/tutorial_history/detail_tutorial_history.php", $record);
  $output = ob_get_clean();
  echo json_encode(array('status' => true, 'html' => $output,));
}
public function detail_tutorial_history_update() {
  Unsuccessful_login();
  $id=$_POST['id'];
  $course_name=$_POST['course_name'];
  $level_name=$_POST['level_name'];
  $tutorial_place=$_POST['tutorial_place'];
  $tutorial_year=$_POST['tutorial_year'];
  $tutorial_times=$_POST['tutorial_times'];
  ob_start();
  UserModel::detail_tutorial_history_update($id,$course_name,$level_name,$tutorial_place,$tutorial_year
    ,$tutorial_times);
  $output = ob_get_clean();
  echo json_encode(array('status' => true, 'html' => $output,));
}
public function Insert_all_tutorial_history_ToSql($pageIndex) {
  Unsuccessful_login();
  $user_id = $_POST['user_id'];
  UserModel::Insert_all_tutorial_history_ToSql($user_id,"","","","","");
  $this->Refresh_all_tutorial_history($pageIndex);
}
public function Remove_item_tutorial_history($pageIndex) {
  Unsuccessful_login();
  $id=$_POST['id'];
  $table_name=$_POST['table_name'];
  ob_start();
  CommonModel::Remove_item($id,$table_name);
  $output = ob_get_clean();
  $this->Refresh_all_tutorial_history($pageIndex);
}
//***************END  tutorial_history   *********************************************************************************************
//***************  article_history   *********************************************************************************************
public function Refresh_all_article_history($pageIndex) {
  $NameTable = 'article_history';
  $content=$_POST['user_id'];
  $SortType = "id DESC";
  $count=10;
  $groupby='';
  $data = ListAjaxPartial($NameTable, $pageIndex,'user_id',$content,'','',$SortType,$count,$groupby);
  ob_start();
  View::renderPartial("/user/article_history/all_article_history_ajax.php", $data);
  $output = ob_get_clean();
  echo json_encode(array('status' => true, 'html' => $output,));

}
public function all_article_history($id,$pageIndex) {
  Unsuccessful_login();

  $data['pageIndex']=$pageIndex;
  $data['id']=$id;
  View::renderCPanelUser("/user/article_history/all_article_history.php", $data);

}
public function detail_article_history($id) {
  Unsuccessful_login();
  if (isset($_POST['pageIndex'])) {
    $pageIndex = $_POST['pageIndex'];
  } else {
    $pageIndex = 1;
  }
  $record = CommonModel::Detail_Record('article_history',$id);
  $record['pageIndex'] = $pageIndex;
  ob_start();
  View::renderPartial("/user/article_history/detail_article_history.php", $record);
  $output = ob_get_clean();
  echo json_encode(array('status' => true, 'html' => $output,));
}
public function detail_article_history_update() {
  Unsuccessful_login();
  $id=$_POST['id'];
  $article_type=$_POST['article_type'];
  $article_name=$_POST['article_name'];
  $release_time=$_POST['release_time'];
  $article_location=$_POST['article_location'];
  ob_start();
  UserModel::detail_article_history_update($id,$article_type,$article_name,$release_time,$article_location);
  $output = ob_get_clean();
  echo json_encode(array('status' => true, 'html' => $output,));
}
public function Insert_all_article_history_ToSql($pageIndex) {
  Unsuccessful_login();
  $user_id = $_POST['user_id'];
  UserModel::Insert_all_article_history_ToSql($user_id,"","","","");
  $this->Refresh_all_article_history($pageIndex);
}
public function Remove_item_article_history($pageIndex) {
  Unsuccessful_login();
  $id=$_POST['id'];
  $table_name=$_POST['table_name'];
  CommonModel::Remove_item($id,$table_name);
  $this->Refresh_all_article_history($pageIndex);
}
//***************END  article_history   *********************************************************************************************
//***************  prize_history   *********************************************************************************************
public function Refresh_all_prize_history($pageIndex) {
  $NameTable = 'prize_history';
  $content=$_POST['user_id'];
  $SortType = "id DESC";
  $count=10;
  $groupby='';
  $data = ListAjaxPartial($NameTable, $pageIndex,'user_id',$content,'','',$SortType,$count,$groupby);
  ob_start();
  View::renderPartial("/user/prize_history/all_prize_history_ajax.php", $data);
  $output = ob_get_clean();
  echo json_encode(array('status' => true, 'html' => $output,));

}
public function all_prize_history($id,$pageIndex) {
  if (!isVip()) {
    header("Location:/");
    return;
  }

  $data['pageIndex']=$pageIndex;
  $data['id']=$id;
  View::renderCPanelUser("/user/prize_history/all_prize_history.php", $data);

}
public function detail_prize_history($id) {
  Unsuccessful_login();
  if (isset($_POST['pageIndex'])) {
    $pageIndex = $_POST['pageIndex'];
  } else {
    $pageIndex = 1;
  }
  $record = CommonModel::Detail_Record('prize_history',$id);
  $record['pageIndex'] = $pageIndex;
  ob_start();
  View::renderPartial("/user/prize_history/detail_prize_history.php", $record);
  $output = ob_get_clean();
  echo json_encode(array('status' => true, 'html' => $output,));
}
public function detail_prize_history_update() {
  Unsuccessful_login();
  $id=$_POST['id'];
  $prize_name=$_POST['prize_name'];
  $receive_date=$_POST['receive_date'];
  $grantor=$_POST['grantor'];
  ob_start();
  UserModel::detail_prize_history_update($id,$prize_name,$receive_date,$grantor);
  $output = ob_get_clean();
  echo json_encode(array('status' => true, 'html' => $output,));
}
public function Insert_all_prize_history_ToSql($pageIndex) {
  Unsuccessful_login();
  $user_id = $_POST['user_id'];
  UserModel::Insert_all_prize_history_ToSql($user_id,"","","");
  $this->Refresh_all_prize_history($pageIndex);
}
public function Remove_item_prize_history($pageIndex) {
  Unsuccessful_login();
  $id=$_POST['id'];
  $table_name=$_POST['table_name'];
  CommonModel::Remove_item($id,$table_name);
  $this->Refresh_all_prize_history($pageIndex);
}
//***************END  prize_history   *********************************************************************************************
//***************  research_pattern   *********************************************************************************************
public function Refresh_all_research_pattern($pageIndex) {
  $NameTable = 'research_pattern';
  $content=$_POST['user_id'];
  $SortType = "id DESC";
  $count=10;
  $groupby='';
  $data = ListAjaxPartial($NameTable, $pageIndex,'user_id',$content,'','',$SortType,$count,$groupby);
  ob_start();
  View::renderPartial("/user/research_pattern/all_research_pattern_ajax.php", $data);
  $output = ob_get_clean();
  echo json_encode(array('status' => true, 'html' => $output,));

}
public function all_research_pattern($id,$pageIndex) {
  if (!isVip()) {
    header("Location:/");
    return;
  }
  $data['pageIndex']=$pageIndex;
  $data['id']=$id;
  View::renderCPanelUser("/user/research_pattern/all_research_pattern.php", $data);

}
public function detail_research_pattern($id) {
  Unsuccessful_login();
  if (isset($_POST['pageIndex'])) {
    $pageIndex = $_POST['pageIndex'];
  } else {
    $pageIndex = 1;
  }
  $record = CommonModel::Detail_Record('research_pattern',$id);
  $record['pageIndex'] = $pageIndex;
  ob_start();
  View::renderPartial("/user/research_pattern/detail_research_pattern.php", $record);
  $output = ob_get_clean();
  echo json_encode(array('status' => true, 'html' => $output,));
}
public function detail_research_pattern_update() {
  Unsuccessful_login();
  $id=$_POST['id'];
  $research_name=$_POST['research_name'];
  $responsibility=$_POST['responsibility'];
  $employer=$_POST['employer'];
  $start_date=$_POST['start_date'];
  $finish_date=$_POST['finish_date'];
  $schedule_validity=$_POST['schedule_validity'];
  ob_start();
  UserModel::detail_research_pattern_update($id,$research_name,$responsibility,$employer
    ,$start_date,$finish_date,$schedule_validity);
  $output = ob_get_clean();
  echo json_encode(array('status' => true, 'html' => $output,));
}
public function Insert_all_research_pattern_ToSql($pageIndex) {
  Unsuccessful_login();
  $user_id = $_POST['user_id'];
  ob_start();
  UserModel::Insert_all_research_pattern_ToSql($user_id,"","","","","","");
  $output = ob_get_clean();
  $this->Refresh_all_research_pattern($pageIndex);
}
public function Remove_item_research_pattern($pageIndex) {
  Unsuccessful_login();
  $id=$_POST['id'];
  $table_name=$_POST['table_name'];
  ob_start();
  CommonModel::Remove_item($id,$table_name);
  $output = ob_get_clean();
  $this->Refresh_all_research_pattern($pageIndex);
}
//***************END  reasearch_pattern   *********************************************************************************************
//*************** Information Person  *********************************************************************************************
public function detail($id) {
  Unsuccessful_login();
  $result = CommonModel::Detail_Record('users',$id);
  View::renderCPanelUser("/user/detail.php", $result);

}
public function detail_info_person_update() {
  $id=$_POST['id'];
  $first_name=$_POST['first_name'];
  $last_name=$_POST['last_name'];
  $birthday=$_POST['birthday'];
  $country=$_POST['country'];
  $province=$_POST['province'];
  $codemelli=$_POST['codemelli'];
  $telephone=$_POST['telephone'];
  $website=$_POST['website'];
  ob_start();
  UserModel::detail_info_person_update($id,$first_name,$last_name,$birthday,$country,$province,$codemelli,$telephone,$website);
  $output = ob_get_clean();
  echo json_encode(array('status' => true, 'html' => $output,));
}
public function detail_info_mystory_person_update() {
  $id=$_POST['id'];
  $mystory=$_POST['mystory'];
  ob_start();
  UserModel::detail_info_mystory_person_update($id,$mystory);
  $output = ob_get_clean();
  echo json_encode(array('status' => true, 'html' => $output,));
}


//***************END   Information Person  *********************************************************************************************
public function isEmailRegistered() {
  $content = $_POST['user_email'];
  $NameTable = "users";
  $whichFeild = "email";
  $result = CommonModel::Fetch_by_every($NameTable, $whichFeild, $content);
  $output = array();
  if (count($result) > 0) {
    $output['isFree'] = false;
  } else {
    $output['isFree'] = true;
  }
  echo json_encode($output);
}
public function validatePassword_is_True() {
  $content = $_POST['user_password'];
  $NameTable = "users";
  $whichFeild = "email";
  $result = CommonModel::Fetch_by_every($NameTable, $whichFeild, $content);
  $output = array();
  if (count($result) > 0) {
    $output['isFree'] = false;
  } else {
    $output['isFree'] = true;
  }
  echo json_encode($output);
}
public function user_name_is_Free() {
  $content = $_POST['user_name'];
  $NameTable = "users";
  $whichFeild = "user_name";
  $result = CommonModel::Fetch_by_every($NameTable, $whichFeild, $content);
  $output = array();
  if (count($result) > 0) {
    $output['isFree'] = false;
  } else {
    $output['isFree'] = true;
  }
  echo json_encode($output);
}


public function ChangeStatus() {
  $id = $_POST['id'];
  $Status= $_POST['Status'];
  UserModel::ChangeStatus($id, $Status);
}

public function change_password($id) {
  Unsuccessful_login();
  $data['id']=$id;
  View::renderCPanelUser("/user/change_password.php", $data);

}
public function change_password_update() {
  $user_id=$_POST['user_id'];
  $record = CommonModel::Fetch_by_every('users','id',$user_id);
  $passwordUserEncrypt1=$_POST['passwordUserEncrypt'];
  $hashedPassword=$record['password_hash'];
  if (PassHash::check_password($hashedPassword,$passwordUserEncrypt1)) {
    $password =PassHash::hash($_POST['password']);
    CommonModel::update_spacial_field($record['id'],'users','password_hash',$password);
    echo json_encode(array('status' => 'successchangePassword',));
  }else{
    echo json_encode(array('status' => 'wrong_current_password',));
  }


}
public function cash() {

  $id = $_POST['id'];
  $cash = $_POST['cash'];
  UserModel::update_cash($id,$cash);
}
public function changeLevel() {
  $user_id = $_POST['id'];
  $user_access = $_POST['user_access'];
  UserModel::promote_user($user_id, $user_access);
}

// ***    SEND message ************************************************************************************************
public function save_message() {

  $sender_user_id=$_POST['sender_message_id'];
  $target_user_id=$_POST['receiver_message_id'];
  $body=$_POST['body'];
  $ticket_id=generateRandomString();
  UserModel::Save_Send_message($ticket_id,$sender_user_id,$target_user_id,$body,getCurrentDateTime(),0);
  UserModel::Save_Send_message($ticket_id,$target_user_id,$sender_user_id,$body,getCurrentDateTime(),1);
  ob_start();
  $output = ob_get_clean();
  echo json_encode(array('status' => true, 'html' => $output,));
}
public function Replay_message() {
  $sender_user_id = $_POST['user_id'];
  $ticket_id = $_POST['ticket_id'];
  $target_user_id = $_POST['target_user_id'];
  $body = $_POST['body'];
  ob_start();
  UserModel::Save_Send_message($ticket_id,$sender_user_id,$target_user_id,$body,getCurrentDateTime(),0);
  UserModel::Save_Send_message($ticket_id,$target_user_id,$sender_user_id,$body,getCurrentDateTime(),1);
  $output = ob_get_clean();
  echo json_encode(array('status' => true, 'html' => $output,));
}
public function message_replay_view($ticket_id) {
  if (isset($_POST['pageIndex'])) {
    $pageIndex = $_POST['pageIndex'];
  } else {
    $pageIndex = 1;
  }
  $sender_user_id = $_POST['sender_user_id'];
  $record['list'] = CommonModel::Fetch_by_two_all('message','ticket_id',$ticket_id,'sender_user_id',$sender_user_id,'order by id DESC');
  $record2 = CommonModel::Fetch_by_two_all('message','ticket_id',$ticket_id,'sender_user_id',$sender_user_id,'order by id DESC');
  foreach($record2 as $feild){
    CommonModel::update_spacial_field($feild['id'],'message','status',0);
  }
  $record['target_user_id']=$_POST['target_user_id'];
  $record['ticket_id']=$ticket_id;
  ob_start();
  $record['pageIndex'] = $pageIndex;
  View::renderPartial("/user/message/message_replay_view.php", $record);
  $output = ob_get_clean();
  echo json_encode(array('status' => true, 'html' => $output,));

}

public function all_message($id,$pageIndex) {
  if (isVip()||isSuperAdmin()) {
    $data['pageIndex']=$pageIndex;
    $data['id']=$id;
    View::renderCPanelUser("/user/message/all_message.php", $data);
  }else{
    header("Location:/");
    return;

  }

}
public function all_message_ajax($pageIndex) {
  $NameTable = 'message';
  $user_id = $_POST['user_id'];
  if (isset($_POST['SearchFiled'])) {
    $SearchFiled = $_POST['SearchFiled'];
  } else {
    $SearchFiled = "id";
  }
  if (isset($_POST['keyword'])) {
    $keyword = $_POST['keyword'];
  } else {
    $keyword = "";
  }
  $SortType = "id DESC";
  $count=10;
  $groupby='ticket_id';
  $data = ListAjaxPartial($NameTable, $pageIndex,'sender_user_id',$user_id,$SearchFiled,$keyword,$SortType, $count,$groupby);
  ob_start();
  View::renderPartial("/user/message/all_message_ajax.php", $data);
  $output = ob_get_clean();
  echo json_encode(array('status' => true, 'html' => $output,));

}

public function view_receiver($id) {
  if (isset($_POST['pageIndex'])) {
    $pageIndex = $_POST['pageIndex'];
  } else {
    $pageIndex = 1;
  }
  $receiver_message_id = $_POST['receiver_message_id'];
  $record = CommonModel::Fetch_by_every('receive_message','id',$id);
  ob_start();
  $record['pageIndex'] = $pageIndex;
  $record['receiver_message_id'] = $receiver_message_id;
  View::renderPartial("/user/message/message_replay.php", $record);
  $output = ob_get_clean();
  echo json_encode(array('status' => true, 'html' => $output,));

}
public function remove_sender_message($ticket_id){
  $sender_user_id = $_POST['sender_user_id'];
  $pageIndex = $_POST['pageIndex'];
  CommonModel::Remove_items_two_all('message','ticket_id',$ticket_id,'sender_user_id',$sender_user_id);
  $this-> all_message_ajax($pageIndex);
}
// ***  END  SEND message ************************************************************************************************
// ***  START  NETWORK ************************************************************************************************
public function network() {
//$key = 'z2rydFNxfX';
$key =  $_SESSION['api_key'];
  $family_name=$_SESSION['first_last_name'];
$level = 3;
if (isset($_REQUEST['k']) && $_REQUEST['k'] != '') {
  $userKey = $_REQUEST['k'];
} else {
  $userKey = $key;
}
if (isset($userKey)) {
  require(getcwd() . "/mvc/view/network/classes/network.class.php");
$objMyNetwork = new MyNetwork($userKey, $level);
$listArr = $objMyNetwork->my_network($userKey, $level);

  ?>
<script type='text/javascript' src='https://www.google.com/jsapi'></script>
<script type='text/javascript'>
  google.load('visualization', '1', {packages:['orgchart']});
  google.setOnLoadCallback(drawChart);
  function drawChart() {
    var data = new google.visualization.DataTable();
    data.addColumn('string', 'family_name');
    data.addColumn('string', 'Manager');
    data.addColumn('string', 'ToolTip');
    data.addRows([
      <?
      		$i=1;
		foreach($listArr as $lists=>$rowArr)
		{
			foreach($rowArr as $rows=>$row)
			{
				foreach($row as $rowDetail)
				{
					if(empty($rowDetail['userKey']))
					{
						if($rowDetail['leg'] == 0){
							$userKey = $rowDetail['parentKey'].'_addl';
						}else{
							$userKey = $rowDetail['parentKey'].'_addr';
						}
					}else{
						$userKey = $rowDetail['userKey'];
					}
					?>
      [{v:'<?= $userKey;?>',

        f: '<div class="display">' +
        '<span title="<?=$family_name?>" class="name"><?=$rowDetail['name']?></span><br><span class="userkey"><?=strtolower($rowDetail['userKey'])?></span><br\><span><?=$rowDetail['payment_status']?></span><br\><?php if(count($listArr)-1 == $lists && !empty($rowDetail['userKey']) ){?><span><a href="<?= '?k='.$rowDetail['userKey']?>">More</a></span><?php } ?></div>'},
        '<?=$rowDetail['parentKey']?>', null],

  <?php
  }

}
}
?>
    ]);
    var chart = new google.visualization.OrgChart(document.getElementById('chart_div'));
    chart.draw(data, {allowHtml:true });

  }
</script>
  <style type="text/css">
    .display{
      padding:0px;
      margin:0px;
      width:auto;
      height:auto;
    }
    .display .name{
      font-weight:bold;
      line-height:22px;
    }
    .display .userkey{
      font-weight:bold;
      margin:0 0 5px 0;
      color:#0000FF;
    }


  </style>
  <div id='chart_div'></div>
<?php } else{ ?>
  <div class="geneology error">error while generating the network. </div>
  <?}
}
public function save_network() {
  $leg = $_POST['leg'];
  $sub_codemelli = $_POST['sub_codemelli'];
//***Main user***********************************************************************************************
  $main_codemelli = $_POST['main_codemelli'];
  $record_main_codemelli = CommonModel::Fetch_by_every('info_person','codemelli',$main_codemelli);
  $user_id_record_main_codemelli=$record_main_codemelli['user_id'];
  $record_main_api_key=CommonModel::Fetch_by_every('users','id',$user_id_record_main_codemelli);
  $api_key_main_codemelli=$record_main_api_key['api_key'];
//***END Main user***********************************************************************************************
//*** SUB user***********************************************************************************************
  $record_sub_codemelli = CommonModel::Fetch_by_every('info_person','codemelli',$sub_codemelli);
  $user_id_sub_codemelli=$record_sub_codemelli['user_id'];
  $record_sub_codemelli_cheek_network = CommonModel::Fetch_by_every('network','user_id',$user_id_sub_codemelli);
  $record_api_key_main_cheek_network = CommonModel::Fetch_by_all('network','parent_key',$api_key_main_codemelli,'');
  $record_leg_not_save_this_tree_cheek_network = CommonModel::Fetch_by_every('network','parent_key',$api_key_main_codemelli,'');
  if($record_sub_codemelli_cheek_network['user_id']!=''){
    echo json_encode(array('status' => 'duplicate_sub_user',));
  }else if(count($record_api_key_main_cheek_network) >= 2){
    echo json_encode(array('status' => 'compelete_tree',));
  }else if($record_main_codemelli['codemelli']==''){
    echo json_encode(array('status' => 'main_codemelli_not_exist',));
  }else if($record_sub_codemelli['codemelli']==''){
    echo json_encode(array('status' => 'sub_codemelli_not_exist',));
  }else if($record_leg_not_save_this_tree_cheek_network['leg']==$leg){
    echo json_encode(array('status' => 'not_save_this_tree',));
  }else{
    $record_sub_codemelli_api_key = CommonModel::Fetch_by_every('users','id',$user_id_sub_codemelli);
    $first_last_name_sub_codemelli=$record_sub_codemelli['first_name'].' '.$record_sub_codemelli['last_name'];
    $api_key_sub_codemelli=$record_sub_codemelli_api_key['api_key'];
    UserModel::insert_network($user_id_sub_codemelli,$first_last_name_sub_codemelli,getCurrentDateTime(),$api_key_sub_codemelli,$api_key_main_codemelli,$leg,'','','');
    echo json_encode(array('status' => 'ok',));
  }

}
// ***  END  NETWORK ************************************************************************************************
}?>
