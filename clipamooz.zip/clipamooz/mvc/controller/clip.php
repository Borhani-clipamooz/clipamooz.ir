<?php


class ClipController {
  public function __construct() {

  }
  public function like() {
    $id=$_POST['id'];
    $sum=$_POST['sum'];
    $data_ip=CommonModel::Fetch_by_every('ip_network','ip',$_SESSION['ip']);
    $value="";
    $parts_one = explode(',',  $data_ip['clip_id_like']);
    for ($i = 0; $i < count($parts_one); $i++) {
      $value=$value.$parts_one[$i].",";
    }
    if(!in_array($id,$parts_one)){
      ob_start();
    $sum++;
    CommonModel::update_spacial_field($id,'clips','clip_like',$sum);
      $clip_id='';
      $clip_id=$value.$id;
      if($data_ip['id']!=null){
        CommonModel::update_spacial_field($data_ip['id'],'ip_network','clip_id_like',$clip_id);
      }else{
        Ip_networkModel::insert($_SESSION['ip']);
      }
      $output = ob_get_clean();
    echo json_encode(array('value' => $sum,));
    }
  }
// single clip  /******* like**********************************************
  public function play($clip_api_key) {
    $record=CommonModel::Fetch_by_every('clips','clip_api_key',$clip_api_key);
    if($record==''){
    $data['message']='صفحه مورد نظر حذف گردیده است.';
    View::render("/message/limit-access.php", $data);
    }else{
    $record2=CommonModel::Fetch_by_every('info_person','user_id',$record['user_id']);
    $record['author']=$record2['first_name'].' '.$record2['last_name'];
//    $record['pageTitle']=_clipamooz." | ". $record['name_fa'];
    $record['pageTitle']= $record['name_fa'];
//    $record['keywords']=$record['name_fa'];
    $record['description']=$record['short_desc_fa'];
    $record['image']=baseUrl_upload().$record['img_link'];
    $record['canonical']=baseUrl().'/g/'.$record['clip_api_key'].'/'.$record['name_fa'];
    View::renderSingleClip("/clip/excute/single_ajax.php", $record);
    }
  }
  public function play2($clip_api_key) {
    $record=CommonModel::Fetch_by_every('clips','clip_api_key',$clip_api_key);
    View::renderPartial("/clip/excute/clip_prev_link_playing.php", $record);
  }
//END  single clip  /******* prev_link**********************************************
// final clip  /******* clip_link**********************************************
  public function final_clip_ajax($clip_api_key) {
    if ($_SESSION['ip']=='') {
      header("Location:/");
      return;
    }
    $record=CommonModel::Fetch_by_every('clips','clip_api_key',$clip_api_key);
    $record2=CommonModel::Fetch_by_every('info_person','user_id',$record['user_id']);
    // $record['keyword']=$record[''];
    $record['author']=$record2['first_name'].' '.$record2['last_name'];
    $record['pageTitle']=$record['name_fa'];
    $record['description']=$record['short_desc_fa'];
    View::renderSingleClip("/clip/excute/finalclip_ajax.php", $record);
  }
//end  final clip  /******* clip_link**********************************************
  public function relation_clip($subcategory) {
    $data['list']=ClipModel::relation_clip($subcategory);
    $data['subcategory']=$subcategory;
    View::renderPartial("/clip/relation_clip.php", $data);
  }
  //*****END    Newpopular_clip    *********************************************************************************************************
  public function RegisterClip() {
    $content = $_POST['name_fa'];
    $NameTable = "clips";
    $whichFeild = "name_fa";
    $record = CommonModel::Fetch_by_every($NameTable, $whichFeild, $content);
      if($record == null){
      $name_fa = $_POST['name_fa'];
      $name_en = $_POST['name_en'];
      $short_desc_fa = $_POST['short_desc_fa'] ;
      $short_desc_en = $_POST['short_desc_en'];
      $long_desc_fa =$_POST['long_desc_fa'];
      $long_desc_en =$_POST['long_desc_en'];
      $clip_link =$_POST['clip_link'];
      $clip_prev_link =$_POST['clip_prev_link'];
      $img_link =$_POST['img_link'];
      $clip_long_time =$_POST['clip_long_time'];
      $clip_size =$_POST['clip_size'];
      $price =$_POST['price'];
      $category =$_POST['category'];
      $created_at =$_POST['created_at'];
      ClipModel::insert($name_fa, $name_en, $short_desc_fa,
                        $short_desc_en, $long_desc_fa,$long_desc_en,
                        $clip_link,$clip_prev_link,$img_link,$clip_long_time,
                        $clip_size,$price,$category,$created_at);
    }

  }


  public function validate_Clip_isFree() {
    $content = $_POST['name_fa'];
    $NameTable = "clips";
    $whichFeild = "name_fa";
    $result = CommonModel::Fetch_by_every($NameTable, $whichFeild, $content);
    $output = array();
    if (count($result) > 0) {
      $output['isFree'] = false;
    } else {
      $output['isFree'] = true;
    }
    echo json_encode($output);
  }
////CLIPS MY SUPERADMIN****** tavasote superadmin modiriyat mishe**************************************************************************************************
  public function superadmin_all_clip($pageIndex) {
    $data['pageIndex']=$pageIndex;
    View::renderCPanelSuperAdmin("/clip/superadmin/all_clip.php", $data);
  }
  public function RefreshData_superadmin_all_clip_ajax($pageIndex) {
    $NameTable = 'clips';
    //$content=$_POST['user_id'];
    if (isset($_POST['SearchFiled'])) {
      $SearchFiled = $_POST['SearchFiled'];
    } else {
      $SearchFiled = "name_fa";
    }
    if (isset($_POST['keyword'])) {
      $keyword = $_POST['keyword'];
    } else {
      $keyword = "";
    }
    $SortType = "status ASC";
    $groupby='';
    $data = ListAjax($NameTable,$pageIndex,$SearchFiled,$keyword,$SortType,$groupby);
    ob_start();
    View::renderPartial("/clip/superadmin/all_clip_ajax.php", $data);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));
  }
  public function detail_clip_superadmin($id) {
    if (isset($_POST['pageIndex'])) {
      $pageIndex = $_POST['pageIndex'];
    } else {
      $pageIndex = 1;
    }
    $record =CommonModel::Fetch_by_every('clips','id',$id);
    ob_start();
    $record['pageIndex'] = $pageIndex;
    View::renderPartial("/clip/superadmin/detail_clip.php", $record);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }
  public function superadmin_Change_Status_clip() {
    require_once(getcwd() . "/system/sitemap.php");
    $id = $_POST['id'];
    $Status= $_POST['Status'];
    CommonModel::update_spacial_field($id,'clips','status', $Status);
    $clip_name= $_POST['clip_name'];
    $alt= $_POST['clip_name'];
    $clip_api_key= $_POST['clip_api_key'];
    $address_image_clip= $_POST['address_image_clip'];
    $subcategory= $_POST['subcategory'];
    $link=baseUrl().'/g/'.$clip_api_key;
    $MsgHTML="<a style='color:#603813' href=$link>$clip_name</a>";
    $subject= $clip_name;
    $message=$_POST['long_desc_fa'];
$data= CommonModel::Fetch_by_every('subcategories','id',$subcategory);
    $subcategory_name = mb_convert_encoding($data['subcategory_english'],'HTML-ENTITIES','utf-8');
    $notices=CommonModel::View_All('notices');
    // send_message_email(52,$MsgHTML,$subject,$message,$address_image_clip,$alt);
 foreach ($notices as $feild) {
   if($feild[$subcategory_name]==1){
     $record =CommonModel::Fetch_by_every('users','id',$feild['user_id']);

     send_message_email($record['email'],$MsgHTML,$subject,$message,$address_image_clip,$alt);
     echo json_encode(array('status' => true,));
   }else{
     echo json_encode(array('status' => false,));
   }
     echo json_encode(array('status' => $subcategory_name,));
 }
    //send_message_telegram($clip_name,$clip_api_key,$subcategory);

  }
////  END CLIPS MY SUPERADMIN********************************************************************************************************
////  CLIPS MY USER IS UPLOAD********************************************************************************************************


  public function all_clip_upload($id,$pageIndex) {
    if (!isVip()) {
      header("Location:/");
      return;
    }
    $data['pageIndex']=$pageIndex;
    $data['id']=$id;
    View::renderCPanelUser("/clip/user/all_clip_upload.php", $data);
  }
  public function list_upload($id,$pageIndex) {
    if (!isVip()) {
      header("Location:/");
      return;
    }
    $data['pageIndex']=$pageIndex;
    $data['id']=$id;
    View::renderCPanelUser("/clip/user/list_upload.php", $data);
  }
  public function RefreshData_clip_upload($pageIndex) {
    $NameTable = 'clips';
    $content=$_POST['user_id'];
    if (isset($_POST['SearchFiled'])) {
      $SearchFiled = $_POST['SearchFiled'];
    } else {
      $SearchFiled = "name_fa";
    }
    if (isset($_POST['keyword'])) {
      $keyword = $_POST['keyword'];
    } else {
      $keyword = "";
    }
    $SortType = "id DESC";
    $count=10;
    $groupby='';
    $data = ListAjaxPartial($NameTable, $pageIndex,'user_id',$content,$SearchFiled,$keyword,$SortType,$count,$groupby);
    ob_start();
    View::renderPartial("/clip/user/all_clip_upload_ajax.php", $data);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }
  public function list_upload_RefreshData($pageIndex) {
    $NameTable = 'uploader';
    $content=$_POST['user_id'];
    if (isset($_POST['SearchFiled'])) {
      $SearchFiled = $_POST['SearchFiled'];
    } else {
      $SearchFiled = "upload_name";
    }
    if (isset($_POST['keyword'])) {
      $keyword = $_POST['keyword'];
    } else {
      $keyword = "";
    }
    $SortType = "id DESC";
    $count=10;
    $groupby='';
    $data['user_id']='123';
    $data = ListAjaxPartial($NameTable,$pageIndex,'user_id',$content,$SearchFiled,$keyword,$SortType,$count,$groupby);
    ob_start();
    View::renderPartial("/clip/user/list_upload_ajax.php", $data);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }
  public function detail_clip_upload_user($id) {
    if (isset($_POST['pageIndex'])) {
      $pageIndex = $_POST['pageIndex'];
    } else {
      $pageIndex = 1;
    }
    $record =CommonModel::Fetch_by_every('clips','id',$id);
    ob_start();
    $record['pageIndex'] = $pageIndex;
    View::renderPartial("/clip/user/detail_clip_upload.php", $record);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }
  public function list_detail_upload_user($id) {
    if (isset($_POST['pageIndex'])) {
      $pageIndex = $_POST['pageIndex'];
    } else {
      $pageIndex = 1;
    }
    $record =CommonModel::Fetch_by_every('uploader','id',$id);
    ob_start();
    $record['pageIndex'] = $pageIndex;
    View::renderPartial("/clip/user/list_detail_upload.php", $record);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }
  public function RefreshData_user_home($pageIndex) {
    $NameTable = 'clips';
    $content=$_POST['user_id'];
    if (isset($_POST['SearchFiled'])) {
      $SearchFiled = $_POST['SearchFiled'];
    } else {
      $SearchFiled = "name_fa";
    }
    if (isset($_POST['keyword'])) {
      $keyword = $_POST['keyword'];
    } else {
      $keyword = "";
    }
   /* if (isset($_POST['pageIndex'])) {
      $pageIndex = $_POST['pageIndex'];
    } else {
      $pageIndex = 1;
    }*/
    $SortType = "id DESC";
    $count=10;
    $groupby='';
    $data = ListAjaxPartial($NameTable, $pageIndex,'user_id',$content,$SearchFiled,$keyword,$SortType,$count,$groupby);
    $data['pageIndex'] = $pageIndex;
    ob_start();
    View::renderPartial("/clip/user/all_clip_upload_ajax_user_home.php", $data);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }

//// END CLIPS MY USER  IS UPLOAD********************************************************************************************************
////  CLIPS MY USER IS BUY********************************************************************************************************
  public function all_clip_buy($id,$pageIndex) {
    if (isVip()||isSuperAdmin()) {
    $data['pageIndex']=$pageIndex;
    $data['id']=$id;
    View::renderCPanelUser("/clip/user/all_clip_buy.php", $data);
    }else{
      header("Location:/");
      return;
    }
  }
  public function RefreshData_clip_buy($pageIndex) {
    $NameTable = 'clips_buy';
    $content=$_POST['user_id'];
    if (isset($_POST['SearchFiled'])) {
      $SearchFiled = $_POST['SearchFiled'];
    } else {
      $SearchFiled = "name_fa";
    }
    if (isset($_POST['keyword'])) {
      $keyword = $_POST['keyword'];
    } else {
      $keyword = "";
    }
    $SortType = "id DESC";
    $count=10;
    $groupby='';
    $data = ListAjaxPartial($NameTable, $pageIndex,'user_id',$content,$SearchFiled,$keyword,$SortType,$count,$groupby);
    ob_start();
    View::renderPartial("/clip/user/all_clip_buy_ajax.php", $data);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }
//// END CLIPS MY USER IS BUY********************************************************************************************************
  public function Remove_all_clip_upload_ajax($pageIndex) {
      $img_link = $_POST['img_link'];
      $uploadfile = $_POST['uploadfile'];
      $Id= $_POST['Id'];
    $content=$_POST['user_id'];
    if (($_POST['img_link'])!=null) {
   CommonModel::DeleteFile($img_link);
    }
    if (($_POST['uploadfile'])!=null) {
  CommonModel::DeleteFile($uploadfile);
    }
   $data= CommonModel::Fetch_by_every('rating','clip_id',$Id);
    CommonModel::Remove_item($data['id'],'rating');
    $data2=CommonModel::Fetch_by_all('comments','clip_id',$Id,'');
   if(!empty($data2)){
    foreach ($data2 as $feild) {
      CommonModel::Remove_item($feild['id'],'comments');
    }
   }
    $data3=CommonModel::Fetch_by_all('questions','clip_id',$Id,'');
    if(!empty($data3)){
    foreach ($data3 as $feild) {
      CommonModel::Remove_item($feild['id'],'questions');
    }
    }
    $data4=CommonModel::Fetch_by_all('clips_buy','clip_id',$Id,'');
    if(!empty($data4)){
    foreach ($data4 as $feild) {
      CommonModel::Remove_item($feild['id'],'clips_buy');
    }
    }
    ClipModel::DelSqlRecord($Id);
    echo json_encode(array('status' => true,));
  }

  public function InsertClipToSql($pageIndex) {
      $currentDate = $_POST['currentDate'];
      $user_id = $_POST['user_id'];
    $clip_api_key=generateRandomString();
    ob_start();
    ClipModel::insert($user_id,"","","","","","",0,0,0,0,0,0,0,0,$currentDate,0,0,0,$clip_api_key,'','','','','','');
    $result=CommonModel::last_record('clips');
    $clip_id = $result['id'];
    ClipModel::insert_rating($clip_id,0,0,0,0,0,0,0,'');
    ob_get_clean();
        $this->RefreshData_clip_upload($pageIndex);
  }
  public function Remove_data() {
      $PathFile = $_POST['pathFile'];
    ob_start();
  CommonModel::DeleteFile_Remote_Host($PathFile);
   ob_get_clean();

  }
  public function Update() {

    $id = $_POST['id'];
    $user_id = $_POST['user_id'];
    $name_fa = $_POST['name_fa'];
    $clip_prev_link = $_POST['clip_prev_link'];
    $clip_link = $_POST['clip_link'];
    $short_desc_fa = $_POST['short_desc_fa'];
    $price =$_POST['price'];
    $video_tag1 =$_POST['video_tag1'];
    $video_tag2 =$_POST['video_tag2'];
    $video_tag3 =$_POST['video_tag3'];
    $video_tag4 =$_POST['video_tag4'];
    $video_tag5 =$_POST['video_tag5'];
    ClipModel::update($id,$user_id,$name_fa,$short_desc_fa,$clip_prev_link,$clip_link,$price,$video_tag1,$video_tag2,$video_tag3,$video_tag4,$video_tag5);
  }
  public function update_long_desc() {

    $id = $_POST['id'];
    $long_desc_fa = $_POST['long_desc_fa'];
    ClipModel::update_long_desc($id,$long_desc_fa);
    echo json_encode(array('status' => true, ));
  }
  public function ChangeSelectCategory_SubCategory() {
    $id = $_POST['id'];
    $parent_cat = $_POST['parent_cat'];
    if($_POST['sub_cat']==''){
      $sub_cat=0;
    }else{
    $sub_cat = $_POST['sub_cat'];
    }
    ClipModel::ChangeSelectCategory_SubCategory($id,$parent_cat, $sub_cat);
  }
  public function Change_Select_SubCategory() {
    $id = $_POST['id'];
    $sub_cat = $_POST['sub_cat'];
   CommonModel::update_spacial_field($id,'clips','subcategory',$sub_cat);
  }
  public function ChangeSelectSubCategory() {
    $id = $_POST['parent_cat'];
    $record=ClipModel::ViewSubCategoryID($id);
    ob_start();
            foreach($record as $row){
           echo "<option value='$row[id]'>$row[subcategory_name]</option>";
            }
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));
  }
  public function explain() {
    $id = $_POST['id'];
    $record =CommonModel::Fetch_by_every('clips','id',$id);
    ob_start();
    View::renderPartial("/clip/explain.php", $record);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }
  public function clip_link() {
    $id = $_POST['id'];
    $record =CommonModel::Fetch_by_every('clips','id',$id);
   // $result['clip_link']=$record['clip_link'];
    ob_start();
    View::renderPartial("/clip/excute/clip_link_playing.php", $record);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }
  public function comments($pageIndex) {
    $NameTable = 'comments';
    $content=$_POST['id'];
    if (isset($_POST['SearchFiled'])) {
      $SearchFiled = $_POST['SearchFiled'];
    } else {
      $SearchFiled = "id";
    }
    if (isset($_POST['keyword'])) {
      $keyword = $_POST['keyword'];
    } else {
      $keyword = "";
    }
    $SortType = "id DESC";
    $count=10;
    $groupby='';
    $data = ListAjaxPartial($NameTable, $pageIndex,'clip_id',$content,$SearchFiled,$keyword,$SortType,$count,$groupby);
    ob_start();
    View::renderPartial("/clip/comments.php", $data);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));
  }
  // ********   Questions    *********************************************************************************************************
  public function questions($pageIndex) {
    $NameTable = 'questions';
    $content=$_POST['id'];
    $user_id=$_POST['user_id'];
    $clip_name=$_POST['clip_name'];
    if (isset($_POST['SearchFiled'])) {
      $SearchFiled = $_POST['SearchFiled'];
    } else {
      $SearchFiled = "id";
    }
    if (isset($_POST['keyword'])) {
      $keyword = $_POST['keyword'];
    } else {
      $keyword = "";
    }
    $SortType = "id DESC";
    $count=10;
    $groupby='ticket_id';
    $data = ListAjaxPartial($NameTable, $pageIndex,'clip_id',$content,$SearchFiled,$keyword,$SortType, $count,$groupby);
    $data['user_id']=$user_id;
    $data['clip_name']=$clip_name;
    $data['id']=$content;
    ob_start();
    View::renderPartial("/question/questions_clip.php", $data);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));
  }
  //*********   *  NOTICES    ******************************************************************************************************************
  public function notices($user_id) {
    Unsuccessful_login();
    $record =CommonModel::Fetch_by_every('notices','user_id',$user_id);
    View::renderCPanelUser("/clip/notices.php", $record);
  }
  public function Update_checkbox_notices() {
    $id = $_POST['id'];
    $check_card = $_POST['check_card'];
    $whichFeild = $_POST['whichFeild'];
    CommonModel::update_spacial_field($id,'notices',$whichFeild,$check_card);
  }
  public function update_duration() {
    $id = $_POST['id'];
    $video_duration = $_POST['video_duration'];
    CommonModel::update_spacial_field($id,'clips','clip_long_time',$video_duration);
    echo json_encode(array('status' => true,));
  }



}
