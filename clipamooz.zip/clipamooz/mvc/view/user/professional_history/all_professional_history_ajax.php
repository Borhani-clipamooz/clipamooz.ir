<div class="content">
  <div class="all_professional_history_panel_ajax">
  <div id="professional_history" class="titrbox "> <h1>&nbsp;&nbsp;سوابق حرفه ای :<i id="icon_professional_history_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
    <div class="row">
      <div class="colx-1 ">
        <h2 >جزئیات</h2>
      </div>
      <div class="colx-1">
        <h2>حذف</h2>
      </div>
      <div class="colx-2 ">
        <h2 >نام سازمان / شرکت</h2>
      </div>
      <div class="colx-1">
        <h2>شروع همکاری</h2>
      </div>
      <div class="colx-1">
        <h2>پایان همکاری</h2>
      </div>
      <div class="colx-2">
        <h2>سمت</h2>
      </div>
      <div class="colx-2">
        <h2>نوع فعالیت (قراردادی، پیمانی، رسمی و ...) </h2>
      </div>
      <div class="colx-2">
        <h2>پاره وقت/ تمام وقت/ مشاوره</h2>
      </div>
    </div>
    <? foreach ($list as $field) {?>
      <div class="row">
        <div class="colx-1">
          <h3 style="cursor: pointer" onclick="View_Detail(<?= $field['id']?>)"><i class="icon-folder-open large"></i></h3>
        </div>
        <div class="colx-1">
          <h3 style="cursor: pointer" onclick="Remove_item(<?= $field['id']?>,<?=$pageIndex?>,'professional_history',<?=$field['user_id']?>)"><i class="icon-bin"></i></h3>
        </div>
        <div class="colx-2">
          <h3><?=$field['name_company']?></h3>
        </div>
        <div class="colx-1">
          <h3><?=$field['start_collaboration']?></h3>
        </div>
        <div class="colx-1">
          <h3><?=$field['finish_collaboration']?></h3>
        </div>
        <div class="colx-2">
          <h3><?=$field['responsibility']?></h3>
        </div>
        <div class="colx-2">
          <h3><?=$field['type_of_activity']?></h3>
        </div>
        <div class="colx-2">
          <h3><?=$field['time_activity']?></h3>
        </div>
      </div>
        <?$user_id= $field['user_id']?>
    <?}?>
    <br>
  <div class="row tac">
    <?=pagination('',3,'btn_style btn-brown','btn',$pageIndex,$pageCount,'professional_history')?>
  </div>
    <br>
  </div>
  <div class="all_professional_history_panel_ajax_responsive">
  <div id="professional_history" class="titrbox "> <h1>&nbsp;&nbsp;سوابق حرفه ای :<i id="icon_professional_history_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
    <? foreach ($list as $field) {?>
    <div class="row">
      <div class="colx-6 ">
        <h2 >جزئیات</h2>
      </div>
      <div class="colx-6">
        <h3 onclick="View_Detail(<?= $field['id']?>)"><i class="icon-folder-open large"></i></h3>
      </div>
    </div>
    <div class="row">
      <div class="colx-6 ">
        <h2 >حذف</h2>
      </div>
      <div class="colx-6">
        <h3 onclick="Remove_item(<?= $field['id']?>,<?=$pageIndex?>,'professional_history',<?=$field['user_id']?>)"><i class="icon-bin"></i></h3>
      </div>
    </div>
    <div class="row">
      <div class="colx-6 ">
        <h2 >نام سازمان / شرکت</h2>
      </div>
      <div class="colx-6">
        <h3><?=$field['name_company']?></h3>
      </div>
    </div>
    <div class="row">
      <div class="colx-6">
        <h2>شروع همکاری</h2>
      </div>
      <div class="colx-6">
        <h3><?=$field['start_collaboration']?></h3>
      </div>
    </div>
    <div class="row">
      <div class="colx-6">
        <h2>پایان همکاری</h2>
      </div>
      <div class="colx-6">
        <h3><?=$field['finish_collaboration']?></h3>
      </div>
    </div>
      <div class="row">
        <div class="colx-6">
          <h2>سمت</h2>
        </div>
        <div class="colx-6">
          <h3><?=$field['responsibility']?></h3>
        </div>
      </div>
    <div class="row">
      <div class="colx-6">
        <h2>نوع فعالیت (قراردادی، پیمانی، رسمی و ...) </h2>
      </div>
      <div class="colx-6">
        <h3><?=$field['type_of_activity']?></h3>
      </div>
    </div>
      <div class="row">
        <div class="colx-6">
          <h2>پاره وقت/ تمام وقت/ مشاوره</h2>
        </div>
        <div class="colx-6">
          <h3><?=$field['time_activity']?></h3>
        </div>
      </div>
        <?$user_id= $field['user_id']?>
    <hr>
    <?}?>
    <div class="row">
      <?=pagination_responsive('',3,'btn_style btn-brown','btn',$pageIndex,$pageCount,'professional_history')?>
    </div>
  </div>
  <div class="row tac">
  <button class="btn_style btn-brown" onclick="Insert_all_professional_history_ToSql(<?=$pageIndex?>,<?=$_SESSION['user_id']?>)" >سابقه جدید را اضافه بفرمایید</button>
  </div>

</div>

<script>

  function View_Detail(id){
    $.ajax({
      url: '/user/detail_professional_history/' + id,
      method: 'POST',
      dataType: 'json',
      data: {
      },
      success: function (output) {
        //console.log(output);
        $("#paginationUpdate").html(output.html);
      }
    });
  }
  function Insert_all_professional_history_ToSql(pageIndex,user_id) {
    $.ajax({
      url: '/user/Insert_all_professional_history_ToSql/'+pageIndex,
      type: 'POST',
      dataType: 'json',
      data:{
        user_id:user_id
      },
      success: function (data) {
        $("#paginationUpdate").html(data.html);
      }
    });
  }
  function Remove_item(id,pageIndex,table_name,user_id) {
    swal({
        title: "آیا مطمئن هستید؟",
        text: "شما دیگر قادر به بازیابی این فایل نخواهید بود.",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#5d4126",
        confirmButtonText: "آره، آن را حذف کنید.",
        cancelButtonText: "لغو",
        closeOnConfirm: false
      },
      function(){
        $.ajax({
          url: '/user/Remove_item_professional_history/'+pageIndex,
          type: 'POST',
          dataType: 'json',
          data:{
            id:id,
            user_id:user_id,
            table_name:table_name
          },
          success: function (data) {
            $("#paginationUpdate").html(data.html);
          }
        });
        swal("حذف گردید.");
      });

  }
</script>


