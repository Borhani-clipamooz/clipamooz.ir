<?php
class Ip_networkModel {

  public static function insert($ip){
    $db = Db::getInstance();
    $db->query_insert("INSERT INTO ip_network (ip,clip_id_opens,clip_id_views,clip_id_like)
                       VALUES (:ip,:clip_id_opens,:clip_id_views,:clip_id_like)", array(
      'ip'            => $ip,
      'clip_id_opens'            => '',
      'clip_id_views'            => '',
      'clip_id_like'            => '',
    ));
  }

}