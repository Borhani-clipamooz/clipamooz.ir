<div class="tac content">
  <img src="/asset/images/logo/logo250.png">
    <table style="position: relative;border: 2px solid #603813;border-radius: 5px;">
        <colgroup>
        </colgroup>
        <tr>
          <td>
            این وب سایت تابع قوانین جمهوری اسلامی ایران می باشد.
          </td>
        </tr>
      <tr>
        <td>
          هرگونه کپی برداری از وب سایت و همچنین کلیپ های موجود غیرمجاز،شرعاً حرام و غیرقانونی میباشد.در صورت مشاهده پیگیرد قانونی خواهد داشت.
        </td>
      </tr>

    </table>



</div>
38554945
