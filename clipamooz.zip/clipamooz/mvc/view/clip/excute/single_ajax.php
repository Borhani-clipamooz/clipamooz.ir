<section>
  <div class="single_clip">
  <?global $config;?>
  <input type="text" style="display: none" id="id"   value="<?=$id?>">
  <input type="text" style="display: none" id="clip_api_key" value="<?=$clip_api_key?>">
  <input type="text"  style="display: none" id="subcategory" value="<?=$subcategory?>">
  <input type="text"  style="display: none" id="user_id" value="<?=$user_id?>">
  <input type="text"  style="display: none" id="clip_name" value="<?=$name_fa?>">
  <input  type="text" style="display: none" id="user_id_buyer" value="<?=$_SESSION['user_id']?>">
  <input  type="text" style="display: none" id="vote" value="<?=$clip_like?>">
  <div class="row">
    <div class="colx-8 colm-fill cols-fill" style="vertical-align: top;">
      <div class="row">
            <?require(getcwd() . "/mvc/view/clip/excute/clip_prev_link_playing.php")?>
      </div>
      <div class="row"><!-- video-grid-->
        <?
        $data=CommonModel::Fetch_by_every('users','id',$user_id);
        $user_name="";
        $user_img="";
        $user_name=$data['user_name'];
        $user_img=$data['profile_pic'];
        $login_status=$data['login_status'];
        ?>

        <div class="row tac">
          <?
          function check_pay($id,$user_id){
            $data_user_clip=CommonModel::Fetch_by_all('clips_buy','user_id',$_SESSION['user_id'],'');
            foreach($data_user_clip as $field){
              if($field['clip_id']==$id){
                return true;
              }
            }
            if($_SESSION['user_id']==$user_id){
              return true;
            }
          }
          if($clip_link !=''){
            if($_SESSION['user_id']==''){?>
              <h3>برای دیدن کلیپ اصلی به کلیپ آموز وارد شوید.</h3>
            <? }elseif(check_pay($id,$user_id)!=true){?>
              <button onclick="not_free_pay()" title="<?=$name_fa?>" class="tooltip btn_style btn-brown icon-lock large">&nbsp;<span style="margin-bottom: 5px;" >تماشا</span></button>
            <? }else{?>
              <a href="/h<?=$clip_api_key?>/<?=$subcategory?>">  <button style="color: greenyellow !important;" class=" btn_style btn-brown icon-unlocked large">&nbsp;<span style="margin-bottom: 5px;" >تماشا</span></button></a>
            <?}} ?>
        </div>
        <div class="row">
          <div class="colx-3 tac">
            <div class="dropdown">
              <span  class="icon-share2 huge"></span>
              <div class="dropdown_panel" style="display: none">
                <ul>
                  <li>
                    <a target="_blank" href="https://t.me/share/url?url=<?=baseUrl()?>/g/<?=$clip_api_key?>&text=<?=$name_fa?>"> <span style="color: #2e87ca " class="icon-telegram huge"></span></a>
                  </li>
                  <li>
                    <a target="_blank" href="https://plus.google.com/share?url=<?=baseUrl()?>/g/<?=$clip_api_key?>&text=<?=$name_fa?>"> <span style="color:#d34836" class="icon-google-plus huge" ></span></a>
                  </li>
                  <li>
                    <a target="_blank" href="https://www.facebook.com/share.php?u=<?=baseUrl()?>/g/<?=$clip_api_key?>&t=<?=$name_fa?>"> <span style="color:#3b5998" class="icon-facebook2 huge"></span></a>
                  </li>
                  <li>
                    <?$link=baseUrl().'/g/'.$clip_api_key?>
                    <a target="_blank" href="https://www.linkedin.com/shareArticle?mini=true&url=<?=$link?>&title=<?=$name_fa?>"> <span style="color:#0077B5" class="icon-linkedin huge"></span></a>
                  </li>
                  <li>
                    <a target="_blank" href="https://twitter.com/intent/tweet?url=<?=baseUrl()?>/g/<?=$clip_api_key?>&text=<?=$name_fa?>"> <span style="color:#55acee" class="icon-twitter huge"></span></a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div class="colx-3 tac">
            <?
            //********************************mizane opens ra ba hesab ip va clip_id hesab kard ***************************************
            $count=0;
            $ip="";
            $parts_one=array();
            $data_ip=CommonModel::Fetch_by_every('ip_network','ip',$_SESSION['ip']);
            $value="";
            $parts_one = explode(',',  $data_ip['clip_id_opens']);
            for ($i = 0; $i < count($parts_one); $i++) {
              $value=$value.$parts_one[$i].",";
            }
            if(!in_array($id,$parts_one))
            {
              $count= $opens+1;
              CommonModel::update_spacial_field($id,'clips','opens',$count);
              $clip_id='';
              $clip_id=$value.$id;
              if($data_ip['id']!=null){
                CommonModel::update_spacial_field($data_ip['id'],'ip_network','clip_id_opens',$clip_id);
              }else{
                Ip_networkModel::insert($_SESSION['ip']);
              }
            }
            //**********mizane like dadae shode      *************************************************************************************************************
            $value="";
            $parts_one = explode(',',  $data_ip['clip_id_like']);
            for ($i = 0; $i < count($parts_one); $i++) {
              $value=$value.$parts_one[$i].",";
            }
            if(!in_array($id,$parts_one))
            {?>
            <i id="like" style="cursor: pointer" class="icon-heart" onclick="like()">
              <i id="show_like" style="font-family:Sahel-FD;" ><?=number_format($clip_like);?></i>
              <?}else{?>
              <i id="vote" style="cursor: pointer;color: pink" class="icon-heart" >
                <i id="show_like" style="font-family:Sahel-FD;" ><?=number_format($clip_like);?></i>
                <?  }
                //*********************   END   ***********************************************************************************************
                ?>
              </i>

          </div>
          <div  class="colx-3 tac" style="line-height: 20px">
            <b>قیمت (ریال)</b>
            <br>
            <span ><?=number_format($price,0);?></span>
          </div>
          <div class="colx-3 tac cols-0">
            <span><?=DateTimeCommon_without_time($created_at)?></span>
          </div>
        </div>
      </div>
      <div class="row"><!--Deatail-->
        <div class="colx-4 tar">
          <div class="time">
            <i style="font-family: traffic">
              <?
              $x=$clip_long_time;
              if($x>=3600){
                echo gmdate("H:i:s", $clip_long_time);
              }else{
                echo gmdate("i:s", $clip_long_time);
              }?>
            </i>
            <span class="icon-clock"></span>
          </div>
        </div>
        <div class="colx-4 tac">
          <div class="opens">
            <span class=" icon-eye" aria-hidden="true"><span style="font-family: traffic">&nbsp;<?=number_format($opens)?></span></span>
          </div>
        </div>
        <div class="colx-4 tal">
          <div class="views">
            <span class="icon-play" aria-hidden="true"><span style="font-family: traffic">&nbsp;<?=number_format($views)?></span></span>
          </div>
        </div>
      </div>
      <div class="row tac pd5">
        <div  style="font-size:14pt;line-height: 25px;"><h1><p><?=$name_fa?></p></h1></div>
      </div>
      <div class="row pd5"><!--Category-->
        <?
        $data=CommonModel::Fetch_by_every('category','id',$category);
        $namecategory="";
        $namecategory=$data['name_fa'];
        $data=CommonModel::Fetch_by_every('subcategories','id',$subcategory);
        $name_sub_category="";
        $name_sub_category=$data['subcategory_name'];
        ?>
        <h2 class="">دسته بندی : &nbsp;<span style="color:#322010"><?= $namecategory?>:<?=$name_sub_category?></span></h2>
      </div>
      <div class="row profile"><!-- Rating USER_name Profile-->
        <div class="colx-1 cols-2">
          <? global $config;?>
          <?  if($user_img !=''){
            if($login_status==1){?>
              <a href="/profile/<?=$user_id?>"> <img style="border:2px solid  greenyellow;" src="<?=$config['upload'].$user_img?>"></a>
            <?  }else{?>
              <a href="/profile/<?=$user_id?>"> <img style="border:2px solid  red;" src="<?=$config['upload'].$user_img?>"></a>
            <?} ?>
          <?}else{
            if($login_status==1){ ?>
              <a  href="/profile/<?=$user_id?>"><img style="border:2px solid  greenyellow;" src="/asset/images/empty/empty-profile/empty-profile-24.png"></a>
            <?  }else{?>
              <a  href="/profile/<?=$user_id?>"><img style="border:2px solid  red;"
               src="/asset/images/empty/empty-profile/empty-profile-24.png"></a>
            <?}}?>
        </div>
        <div class="colx-3 cols-fill tar">
          <h3 style="color: #322010;font-size: 14pt;"><?=$user_name?></h3>
        </div>
        <div class="colx-8 colm-fill cols-fill tal">
          <?
          if (strpos($rating, '.5') !== false) {
            $R_rating=$rating;
          }else{
            $R_rating=round($rating);
          }
          ?>
          <span id="rating" class="rating"><?=rating($R_rating,'30px','30px');?></span>
        </div>
      </div>
      <div class="row">
        <div class="colx-2 colm-fill cols-fill tac">
          <h2 id="explain" class="tac read-more">توضیحات</h2>
        </div>
        <div class="colx-3 colm-fill cols-fill tac">
          <h2  id="explain" onclick="Comments(1)" class="tac read-more">نظرات کاربران</h2>
        </div>
        <div class="colx-2 colm-fill cols-fill tac" >
          <h2 onclick="Questions(1)" class="tac read-more">پرسش و پاسخ</h2>
        </div>
        <div class="colx-2 colm-fill cols-fill tac" >
          <h2 ><a class="tac read-more" href="<?=baseUrl().'/profile/'.$user_id?>">پروفایل کاربر</a></h2>
        </div>
        <? if ($uploadfile !='') {?>
          <div class="colx-3 colm-fill cols-fill tac" >
            <?global $config;?>
            <h2 ><a class="tac read-more" href="<?=$config['upload'].$uploadfile ?>" download>دانلود پیوست فایل</a></h2>
          </div>
        <? }?>
      </div>
    </div>
    <div class="colx-4 colm-fill cols-fill" style="vertical-align: top;">
      <?
        $_SESSION[$subcategory]=$subcategory;
      require(getcwd() ."/mvc/view/clip/relation_clip.php");?>
    </div>
  </div>
</div>
<div id="page"></div>
</section>
<section>
<div  id="explain_panel">
  <p><?=$long_desc_fa?></p>
</div>
</section>
<!-- ****Rating ****************************************************************************************-->
  <div id="show_rating" style="display:none">
    <?
    $_SESSION[$clipid]=$id;
    require(getcwd() ."/mvc/view/rating/detail_rating.php");?>
  </div>
<script>
  $(function(){
    $("#explain").click(function(){
      $("#explain_panel").toggle(200);
      $("#page").hide();
      $("#show_rating").hide();
    });
    $("#rating").click(function(){
      $("#show_rating").toggle(200);
      $("#page").hide();
    });
    clips_panel(<?=$pageIndex?>);
    $("#keyword_home").on('keyup', function () {
      clips_panel(<?=$pageIndex?>);
    });
  });
  $('.tooltip').tooltipster({
    animation: 'fade',
    delay: 200,
    theme: 'tooltipster-punk',
    trigger: 'click'
  });
  function clips_panel(pageIndex) {
    var keyword = $("#keyword_home").val();
    var SearchFiled = $("#UserFind").val();
    var user_id = $("#user_id").val();
    $.ajax({
      url: '/RefreshData_user_home/'+pageIndex,
      method: 'POST',
      dataType: 'json',
      data: {
        user_id:user_id,
        keyword: keyword,
        SearchFiled: SearchFiled
      },
      success: function (output) {
        // console.log(output);
        $("#paginationUpdate").html(output.html);
      }
    });
  }
  function not_free_pay(){
    var clip_api_key = $("#clip_api_key").val();
    var subcategory = $("#subcategory").val();

    $.ajax({
      url: '/not_free_pay/',
      method: 'POST',
      dataType: 'json',
      data: {
        clip_api_key: clip_api_key,
        subcategory: subcategory
      },
      success: function (data) {
        //console.log(data.status);
        switch (data.status) {
          case 'cash':
          {
            $(".tooltip").tooltipster('content', 'موجودی کافی نمی باشد.');
            break;
          }
          case 'free':
          {
            window.location.href = "/h" + clip_api_key;
            break;
          }
          case 'ok':
          {
            window.location.href = "/h" + clip_api_key;
            break;
          }
          default:
          //  window.location.href = "/h"+name_fa+"/"+subcategory;
        }
      }
    });
  }
  function like(){
    var id = $("#id").val();
    var sum = $("#vote").val();
    $.ajax({
      url:'/clip_like/',
      method: 'POST',
      dataType: 'json',
      data: {
        id:id,
        sum:sum
      },
      success: function (output) {
        document.getElementById("show_like").innerHTML  = output.value;
        document.getElementById("like").style.color = "pink";
      }
    });
  }
  function expalin(id){
    var id = $("#id").val();
    $.ajax({
      url: '/clip_explain',
      method: 'POST',
      dataType: 'json',
      context:document.body,
      cache:false,
      data: {
        id: id
      },
      success: function (output) {
        //console.log(output.html);
        $("#page").html(output.html);
      }
    });
  }
  function Comments(pageIndex){

    var id = $("#id").val();
    $.ajax({
      url: '/clip_comments'+pageIndex,
      method: 'POST',
      dataType: 'json',
      data: {
        id: id
      },
      success: function (output) {
        $("#explain_panel").hide();
        $("#show_rating").hide();
        $("#page").html(output.html);
        $("#page").show();
      }
    });
  }
  function Questions(pageIndex){

    var id = $("#id").val();
    var user_id = $("#user_id").val();
    var clip_name = $("#clip_name").val();
    $.ajax({
      url:'/clip_questions/'+pageIndex,
      method: 'POST',
      dataType: 'json',
      data: {
        id: id,
        user_id: user_id,
        clip_name: clip_name
      },
      success: function (output) {
        $("#explain_panel").hide();
        $("#show_rating").hide();
        $("#page").html(output.html);
        $("#page").show();
      }
    });
  }
  $(function(){
    $(".dropdown").click(function(){
      $(".dropdown_panel").slideToggle("slow");
    });
  });
</script>

