<?
date_default_timezone_set("Asia/Tehran");
session_start();

if(isset($_SESSION['lastTime'])){
  //  if(time()-$_SESSION['lastTime']>24*60*60)
    if(time()-$_SESSION['lastTime']>3600*24*15)
    {
        session_unset();
        session_destroy();
      CommonModel::update_spacial_field($_SESSION['user_id'],'users','login_status',0);
      header("Location:/");
    }
}
$_SESSION['lastTime']=time();
 $_SESSION['ali']='123';

require_once(getcwd() . "/config.php");
require_once(getcwd() ."/system/core.php");
require_once(getcwd() . "/system/common.php");
require_once(getcwd() . "/system/access.php");
require_once(getcwd() . '/local/' . $config['lang'].'.php');
require_once(getcwd() . "/system/db.php");
require_once(getcwd() . "/system/render.php");
require_once(getcwd() . "/system/PassHash.php");
?>

