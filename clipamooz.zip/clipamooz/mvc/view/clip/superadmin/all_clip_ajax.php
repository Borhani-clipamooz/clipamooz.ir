<div class="content">
  <div class="all_clip_upload">
    <div class="row">
      <div class="colx-1"><h2>جزئیات</h2>  </div>
      <div class="colx-1"><h2>حذف  </h2></div>
      <div class="colx-1">  <h2>وضعیت</h2></div>
      <div class="colx-5"><h2>  نام کلیپ </h2></div>
      <!--  <div class="colx-1"> <h2>سایز</h2></div>-->
      <div class="colx-2"> <h2>دسته بندی</h2></div>
      <div class="colx-1"><h2>تاریخ بارگزاری</h2></div>
    </div>
    <? foreach ($list as $feild) {?>
      <div class="row">
        <div class="colx-1"><h3 onclick="View(<?= $feild['id']?>,<?=$pageIndex?>)" class="icon-file-video large"></h3>  </div>
        <div class="colx-1"><h3 onclick="Remove_sql_data(<?= $feild['id']?>,<?=$pageIndex?>,'<?= $feild['clip_link'] ?>','<?= $feild['clip_prev_link'] ?>','<?= $feild['img_link'] ?>','<?=$feild['user_id']?>')" class="icon-bin large" ></h3></div>
        <div class="colx-1">
          <?if($feild['status']==0){?>
            <span  class="icon-checkmark2 large"></span>
          <?}else{?>
            <span  class="icon-checkmark large"></span>
          <?}?>
        </div>
        <div class="colx-5"><?= $feild['name_fa'] ?></div>
        <!--  <div class="colx-1"> --><?//= $feild['clip_size'] ?><!--</div>-->
        <?
        $data=CommonModel::Fetch_by_every('category','id',$feild['category']);
        $data2=CommonModel::Fetch_by_every('subcategories','id',$feild['subcategory']);
        ?>
        <div class="colx-2"><?= $data['name_fa'] ?>/<?=$data2['subcategory_name']?></div>
        <div class="colx-1"><?=DateTimeCommon_without_time( $feild['created_at'] )?></div>
      </div>
    <? } ?>
    <br>
    <div class="row">
      <?=pagination('',3,'btn_style btn-brown','btn',$pageIndex,$pageCount,'superadmin_all_clip')?>
    </div>
    <br>
  </div>
  <div class="all_clip_upload_responsive">
    <? foreach ($list as $feild) {?>
      <div class="row">
        <div class="colx-2">
          <h2>جزئیات</h2>
        </div>
        <div class="colx-10">
          <h3 onclick="View(<?= $feild['id']?>,<?=$pageIndex?>)" class="icon-file-video large"></h3>
        </div>
      </div>
      <div class="row">
        <div class="colx-2">
          <h2>حذف</h2>
        </div>
        <div class="colx-10">
          <h3 onclick="Remove_sql_data(<?= $feild['id']?>,<?=$pageIndex?>,'<?= $feild['clip_link'] ?>','<?= $feild['clip_prev_link'] ?>','<?= $feild['img_link'] ?>','<?=$feild['user_id']?>')" class="icon-bin large" ></h3>
        </div>
      </div>
      <div class="row">
        <div class="colx-2">
          <h2>وضعیت</h2>
        </div>
        <div class="colx-10">
          <?if($feild['status']==0){?>
            <span  class="icon-checkmark2 large"></span>
          <?}else{?>
            <span  class="icon-checkmark large"></span>
          <?}?>
        </div>
      </div>
      <div class="row">
        <div class="colx-2">
          <h2>  نام کلیپ </h2>
        </div>
        <div class="colx-10"><?= $feild['name_fa'] ?></div>
      </div>
      <!-- <div class="row">-->
      <!--   <div class="colx-2">-->
      <!--     <h2>سایز</h2>-->
      <!--   </div>-->
      <!--   <div class="colx-10">--><?//= $feild['clip_size'] ?><!--</div>-->
      <!-- </div>-->
      <div class="row">
        <div class="colx-2">
          <h2>دسته بندی</h2>
        </div>
        <?
        $data=CommonModel::Fetch_by_every('category','id',$feild['category']);
        $data2=CommonModel::Fetch_by_every('subcategories','id',$feild['subcategory']);
        ?>
        <div class="colx-10"><?= $data['name_fa'] ?>/<?=$data2['subcategory_name']?></div>
      </div>
      <div class="row">
        <div class="colx-2">
          <h2>تاریخ بارگزاری</h2>
        </div>
        <div class="colx-10"><?=DateTimeCommon_without_time( $feild['created_at'] )?></div>
      </div>
      <hr>
    <? } ?>
    <div class="row">
      <?=pagination_responsive('',3,'btn_style btn-brown','btn',$pageIndex,$pageCount,'superadmin_all_clip')?>
    </div>
  </div>
</div>


<script>
  function View(Id,PageIndex) {

    $.ajax({
      url: '/clip/detail_clip_superadmin/' + Id,
      type: 'POST',
      dataType: 'json',
      data:{
        pageIndex:PageIndex
      },
      success: function (data) {
        $("#pageUpdate_superadmin_all_clip").html(data.html);
      }
    });
  }

  function Remove_sql_data(Id,PageIndex,clip_link,clip_prev_link,img_link,user_id) {
    swal({
        title: "آیا مطمئن هستید؟",
        text: "شما دیگر قادر به بازیابی این فایل نخواهید بود.",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#5d4126",
        confirmButtonText: "آره، آن را حذف کنید.",
        closeOnConfirm: false
      },
      function(){
        $.ajax({
          url: '/clip/Remove_all_clip_upload_ajax/' + PageIndex,
          type: 'POST',
          dataType: 'json',
          data:{
            Id:Id,
            clip_link:clip_link,
            clip_prev_link:clip_prev_link,
            img_link:img_link,
            user_id:user_id
          },
          success: function (data) {
            $("#pageUpdate_superadmin_all_clip").html(data.html);
          }
        });
        swal("حذف گردید.");
      });


  }


</script>


