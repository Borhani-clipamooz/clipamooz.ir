<div id="paginationUpdate"></div>
<input type="text" style="display: none" id="user_id"  value="<?=$id?>" autocomplete="off">
<script>

   $(function () {
     research_pattern(<?=$pageIndex?>);
  });

  function research_pattern(pageIndex) {
    var user_id = $("#user_id").val();
    $.ajax({
      url: '/user/Refresh_all_research_pattern/'+pageIndex,
      method: 'POST',
      dataType: 'json',
      data: {
        user_id:user_id
      },
      success: function (output) {
        //console.log(output);
        $("#paginationUpdate").html(output.html);
      }
    });
  }


</script>









