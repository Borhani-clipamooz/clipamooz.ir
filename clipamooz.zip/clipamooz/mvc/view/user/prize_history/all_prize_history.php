<div id="paginationUpdate"></div>
<input type="text" style="display: none" id="user_id"  value="<?=$id?>" autocomplete="off">
<script>

   $(function () {
     prize_history(<?=$pageIndex?>);
  });

  function prize_history(pageIndex) {
    var user_id = $("#user_id").val();
    $.ajax({
      url: '/user/Refresh_all_prize_history/'+pageIndex,
      method: 'POST',
      dataType: 'json',
      data: {
        user_id:user_id
      },
      success: function (output) {
        //console.log(output);
        $("#paginationUpdate").html(output.html);
      }
    });
  }


</script>









