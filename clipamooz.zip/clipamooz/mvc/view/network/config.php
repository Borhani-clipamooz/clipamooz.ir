<?php
/************************************************************
	Author			: Chandan Kumar 
	Project			: Binary Network
*****************************************************************/
// DISPLAY ERROR SETTING FOR SITE 

error_reporting(E_ALL);
error_reporting(E_ALL && ~E_NOTICE);

$link = mysql_connect('localhost', 'root', '');
@mysql_select_db('network',$link); 



?>