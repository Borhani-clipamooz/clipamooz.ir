<div class=" content">
  <div class="detail_tutorial_history_panel">
  <div id="tutorial_history" class="titrbox "> <h1>&nbsp;&nbsp;دوره آموزشی( زبان خارجی ،کامپيوتر و... ) :<i id="icon_tutorial_history_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
    <input type="hidden"id="id"value="<?=$id?>">
    <div class="row">
      <div class="colx-4">
        <h2 >نام دوره</h2>
      </div>
      <div class="colx-4">
        <h2>سطح</h2>
      </div>
      <div class="colx-4">
        <h2>محل آموزش</h2>
      </div>
    </div>
    <div class="row">
      <div class="colx-4">
        <h3><input  type="text"  id="course_name"  name="" value="<?=$course_name  ?>"></h3>
      </div>
      <div class="colx-4">
        <h3><input  type="text"  id="level_name"  name="" value="<?= $level_name ?>"></h3>
      </div>
      <div class="colx-4">
        <h3><input  type="text"  id="tutorial_place"  name="" value="<?= $tutorial_place ?>"></h3>
      </div>
    </div>
    <div class="row">
      <div class="colx-6">
        <h2>سال</h2>
      </div>
      <div class="colx-6">
        <h2>میزان ساعت دوره</h2>
      </div>
    </div>
      <div class="row">
        <div class="colx-6">
          <h3><input  type="text"  id="tutorial_year"  name="" value="<?= $tutorial_year ?>"></h3>
        </div>
        <div class="colx-6">
          <h3><input  type="text"  id="tutorial_times"  name="" value="<?= $tutorial_times ?>"></h3>
        </div>
      </div>
  </div>
  <div class="row tac">
    <button  class="btn_style btn-brown" onclick="back(<?=$pageIndex?>)">بازگشت</button>
    </div>
</div>
<script>
$(function(){
  $("input").each(function () {
    $(this).on('keyup', function () {
      var id=$("#id").val();
      var course_name=$("#course_name").val();
      var level_name=$("#level_name").val();
      var tutorial_place=$("#tutorial_place").val();
      var tutorial_year=$("#tutorial_year").val();
      var tutorial_times=$("#tutorial_times").val();
      $.ajax({
        url:'/user/detail_tutorial_history_update',
        type: 'POST',
        dataType:'json',
        data:{
          id:id,
          course_name:course_name,
          level_name:level_name,
          tutorial_place:tutorial_place,
          tutorial_year:tutorial_year,
          tutorial_times:tutorial_times
        },
        success:function(data){
          //console.log(data);
        }
      });


    });
  });
});
  function back(id){
    tutorial_history(id);
  }
</script>















