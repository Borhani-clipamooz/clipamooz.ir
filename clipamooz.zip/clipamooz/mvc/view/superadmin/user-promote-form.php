<div class="tal content">
<form action="<?=baseUrl()?>/admin/promote" method="post">
  <input name="user_ID" type="text" placeholder="USER_ID" id="userId"><BR>
  <input name="access" type="text" placeholder="ACCESS" id="access"><br>
  <button type="submit">PROMOTE</button>
</form>
</div>

<script>

  $(function(){
    $('#userId').on('keyup',function(){
      var value=$(this).val();
      $.ajax('<?=baseUrl()?>/admin/getUserAccess/'+value,{
        dataType:'json',
        success:function(data){
          var access=data.access.replaceAll(/\|/g,',',data.access);
          access=access.substring(1,data.access.length-1);
          $('#access').val(access);
          console.log(data.access);
        }
      });
  });
  });
</script>