<html>
  <head>
    <title>تست</title>
    <meta charset="utf-8" />
    <link rel="stylesheet"          type="text/css" href="/mvc/view/uploader/public/style.css" />
    <?  header("Access-Control-Allow-Origin: *");?>
  </head>
  <body>
    <div id="frame">

      <h1>توجه</h1>
      <p>این صفحه صرفا برای تست ایجاد شده است</p>

      <hr/>
      <script src="/mvc/view/uploader/public/jquery1.7.1.js"></script>
      <script src="/mvc/view/uploader/public/resumable.js"></script>
      <div class="resumable-error">
        مرورگر شما متاسفانه این ویژگی رو پشتیبانی نمیکنه  بیشتر بدانید <a href="http://www.w3.org/TR/FileAPI/#normalization-of-params"></a>.
      </div>

      <div class="resumable-drop">
        ویدئو رو در این کادر بکشید و یا از  <a class="resumable-browse"><u>اینجا انتخاب کنید</u></a>
      </div>
      
      <div class="resumable-progress">
        <table>
          <tr>
            <td class="progress-pause" nowrap="nowrap">
              <a href="#" onclick="r.upload(); return(false);" class="progress-resume-link"><img src="/mvc/view/uploader/public/resume.png" title="Resume upload" /></a>
              <a href="#" onclick="r.pause(); return(false);" class="progress-pause-link"><img src="/mvc/view/uploader/public/pause.png" title="Pause upload" /></a>
              <a href="#" onclick="r.cancel(); return(false);" class="progress-cancel-link"><img src="/mvc/view/uploader/public/cancel.png" title="Cancel upload" /></a>
            </td>
            <td width="100%"><div class="progress-container"><div class="progress-bar"></div></div></td>
            <td class="progress-text" nowrap="nowrap"></td>
          </tr>
        </table>
      </div>
      
      <ul class="resumable-list"></ul>

    <script>
        var intervalId = '';
        progressCount = 0;
        var r = new Resumable({
          target:'https://clipamooz.ir/happyweb/',
         // target:'http://clipamooz.ir:4000/upload',
            fileType:['mp4'],
            fileTypeErrorCallback: function(file,errorCount){
              swal("ببخشید حداکثر سایز 120 مگابایت می باشد");
            },
            chunkSize:1*1024*1024,
            simultaneousUploads:4,
            testChunks:false,
            throttleProgressCallbacks:1
          });
        // Resumable.js isn't supported, fall back on a different method
        if(!r.support) {
          $('.resumable-error').show();
        } else {
          // Show a place for dropping/selecting files
          $('.resumable-drop').show();
          r.assignDrop($('.resumable-drop')[0]);
          r.assignBrowse($('.resumable-browse')[0]);
          // Handle file add event
          r.on('fileAdded', function(file){
              // Show progress pabr
              $('.resumable-progress, .resumable-list').show();
              // Show pause, hide resume
              $('.resumable-progress .progress-resume-link').hide();
              $('.resumable-progress .progress-pause-link').show();
              // Add the file to the list
              $('.resumable-list').append('<li class="resumable-file-'+file.uniqueIdentifier+'">Uploading <span class="resumable-file-name"></span> <span class="resumable-file-progress"></span>');
              $('.resumable-file-'+file.uniqueIdentifier+' .resumable-file-name').html(file.fileName);
              // Actually start the upload
              r.upload();
            });
          r.on('pause', function(){
              // Show resume, hide pause
              clearInterval(intervalId);
              $('.resumable-progress .progress-resume-link').show();
              $('.resumable-progress .progress-pause-link').hide();
            });
          r.on('complete', function(){
              clearInterval(intervalId);
              console.log("complete")
              // Hide pause/resume when the upload has completed
              $('.resumable-progress .progress-resume-link, .resumable-progress .progress-pause-link').hide();
            });
          r.on('fileSuccess', function(file,message){
              // Reflect that the file upload has completed
              $('.resumable-file-'+file.uniqueIdentifier+' .resumable-file-progress').html('(completed) ('+message+')');
            });
          r.on('fileError', function(file, message){
            console.log("fileError")
              // Reflect that the file upload has resulted in error
              $('.resumable-file-'+file.uniqueIdentifier+' .resumable-file-progress').html('(file could not be uploaded: '+message+')');
            });
            r.on('error', function(message, file){
              // Reflect that the file upload has resulted in error
              console.log("error")
            });
          r.on('fileProgress', function(file){
              // Handle progress for both the file and the overall upload
              $('.resumable-file-'+file.uniqueIdentifier+' .resumable-file-progress').html(Math.floor(file.progress()*100) + '%');
              $('.progress-bar').css({width:Math.floor(r.progress()*100) + '%'});
            });
          r.on('cancel', function(){
            clearInterval(intervalId);
            $('.resumable-file-progress').html('canceled');
          });
          r.on('uploadStart', function(){
              // Show pause, hide resume
              console.log("uploadStart")
              $('.resumable-progress .progress-resume-link').hide();
              $('.resumable-progress .progress-pause-link').show();

	intervalId = setInterval(function()  {
                console.log("progress", r.progress());
                if(r.progress() > progressCount)
                {
                  progressCount = r.progress();

                } else {
                  alert("ارتباط شما قطع شد لطفا بعد از بررسی اتصال خود ادامه آپلود را انجام دهید");
                  clearInterval(intervalId);
                }
              }, 10000)});
        }
      </script>

    </div>
  </body>
</html>

