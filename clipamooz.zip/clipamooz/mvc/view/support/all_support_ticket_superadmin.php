<div class="rtl">
  <strong style="color: #fff">نوع نمایش</strong>
  <select id="UserFind">
    <option value="subject">نام دسته</option>
  </select>
  <input type="text" style="width:100px;height: 20px" id="keyword" placeholder="جستجو" value="" autocomplete="off">
  <input type="text"  id="user_id"  value="<?=$id?>" autocomplete="off">
</div>
<div id="paginationUpdate444"></div>
<script>

  $("#keyword").on('keyup', function () {
    getPage(<?=$pageIndex?>);
  });
  $(function () {
     getPage(<?=$pageIndex?>);
  });

  function getPage(pageIndex) {
    var keyword = $("#keyword").val();
    var SearchFiled = $("#UserFind").val();
    var user_id = $("#user_id").val();
    $.ajax({
      url: '/RefreshData_support_ticket_superadmin/' + pageIndex,
      method: 'POST',
      dataType: 'json',
      data: {
        user_id:user_id,
        keyword: keyword,
        SearchFiled: SearchFiled
      },
      success: function (output) {
     console.log(output);
        $("#paginationUpdate444").html(output.html);
      }
    });
  }


</script>









