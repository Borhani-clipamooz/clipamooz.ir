<div class=" content">

<table>
    <colgroup>
        <col style="width: 100px">
        <col style="width: auto">
    </colgroup>
     <tr>
        <td class="comlmn">نام فارسی</td>
       <td><input  type="text"  id="title"   ></td>
    </tr>

    <tr>
        <td class="comlmn">توضیحات فارسی</td>
      <td> <textarea id="text"  style="height: 150px;width:700px"></textarea></td>
    </tr>
    <tr>
        <td class="comlmn">توضیحات فارسی</td>
      <td> <input class="tac" id="date" value="<?=jdate(getCurrentDateTime())?>"></td>
    </tr>

</table>


  <button class="btn_style btn-brown" onclick="Save(),back(<?= $pageIndex ?>)">برگشت و ذخیره</button>
</div>
<script>
  function Save(){
    var title=$("#title").val();
    var text=$("#text").val();
    var date=$("#date").val();

    $.ajax({
      url:'/notification/InsertNotificationToSql/',
      type: 'POST',
      dataType:'json',
      data:{
        title:title,
        text:text,
        date:date

      },
      success:function(data){
        //console.log(data);
      }
    });

  }
  function back(pageIndex){
    getPage(pageIndex);
  }
</script>
