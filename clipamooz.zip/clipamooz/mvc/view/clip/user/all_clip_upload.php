<div class="rtl">
  <div style="position: relative;margin-top: 5px;">
  <strong style="color: #fff">نوع نمایش</strong>
  <select id="UserFind">
    <option value="name_fa">نام کلیپ</option>
  </select>
    <span class="icon-search large" style="position: absolute;top: 5px;color: #fff"></span> &nbsp;&nbsp;&nbsp;&nbsp; <input type="text" style="width:40%;height: 30px;" id="keyword" placeholder="جستجو" autocomplete="off">
  </div>
  <input type="text" style="display: none" id="user_id"  value="<?=$id?>" autocomplete="off">

</div>
<div id="paginationUpdate"></div>
<script>

  $("#keyword").on('keyup', function () {
    all_clip_upload(<?=$pageIndex?>);
  });
  $(function () {
    all_clip_upload(<?=$pageIndex?>);
  });

  function all_clip_upload(pageIndex) {
    var keyword = $("#keyword").val();
    var SearchFiled = $("#UserFind").val();
    var user_id = $("#user_id").val();
    $.ajax({
      url: '/clip/RefreshData_clip_upload/' + pageIndex,
      method: 'POST',
      dataType: 'json',
      data: {
        user_id:user_id,
        keyword: keyword,
        SearchFiled: SearchFiled
      },
      success: function (output) {
       // console.log(output);
        $("#paginationUpdate").html(output.html);
      }
    });
  }


</script>









