<body>
<section>
  <div class="row">
    <div class="box-new">
      <div class="colx-2 colm-fill">
      </div>
      <div class="colx-5 colm-fill tac">
        <img src="/asset/images/468-60.gif">
      </div>
      <div class="colx-5 colm-fill tac">
        <img src="/asset/images/468-60.gif">
      </div>
    </div>
  </div>
<input type="text" style="display: none;width:100px;height: 50px" class="keyword" placeholder="جستجو" value="<?=$keyword?>" autocomplete="off">
</section>
<div class="wrapper" style=" margin-top: 0px;">
  <div id="paginationUpdate"></div>
</div>
<div id="noMoreQuestion" style="display: none;text-align: center;">
  <div style="color: #ffcc80;font-size: 14pt !important;line-height: 28pt !important;">کلیپ بیشتری برای نمایش نمی باشد.</div>
</div>
<div id="lazyloading-logo" style="display: none;text-align: center;">
  <span class="icon-spinner9 huge spin "></span>
</div>
</body>
<script>
  var count=15;
  var startIndex = 0;
  var canLoadMore = true;
  var loaderInprogress = false;
  $(function () {
    var keyword = $(".keyword").val();
    //console.log(keyword);
    compelete_search(keyword);

  });
  var inProgress = false;

  $(window).scroll(function () {
    if ($(window).scrollTop() + $(window).height() > $('#paginationUpdate').height()) {
      if (!inProgress) {
        startIndex += 15;

        var keyword = $(".keyword").val();
        //console.log(keyword);
        compelete_search(keyword);
      }
      inProgress = true;
      setTimeout(function () {
        inProgress = false;
      }, 300);
    }
  });
  function compelete_search(keyword) {
    var keyword = $(".keyword").val();
    if (!canLoadMore) {
      return;
    }

    if (loaderInprogress) {
      return;
    }

    loaderInprogress = true;
    $("#lazyloading-logo").show();
    $.ajax({
      url: '/menu/Complete_Search_ajax/',
      method: 'POST',
      dataType: 'json',
      data: {
        keyword:keyword,
        startIndex: startIndex,
        count: count
      },
      success: function (data) {
        loaderInprogress = false;
        if (data.status == true) {
      // $("#paginationUpdate").html(output.html);
          var $questionList = $("#paginationUpdate");
          var $questions = $(data.html);
          $questionList.append($questions);
          $("#lazyloading-logo").hide();
        } else {
          canLoadMore = false;
          $("#noMoreQuestion").show();
          $("#lazyloading-logo").hide();
        }
      }
    });
  }

</script>