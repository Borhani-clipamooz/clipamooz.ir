<div class="content">
  <div class="all_clip_buy">
    <div class="row">
      <div class="colx-1"><h2>نمایش</h2></div>
      <div class="colx-4"><h2>نام کلیپ</h2></div>
      <div class="colx-1"><h2>قیمت</h2></div>
      <div class="colx-2"><h2>دسته بندی</h2></div>
      <div class="colx-2"><h2>تاریخ خرید</h2></div>
      <div class="colx-2"><h2>امتیاز و نظرتون</h2></div>
    </div>
    <? foreach ($list as $feild) {?>
    <div class="row">
      <div class="colx-1"><h3>
          <?
          $data=CommonModel::Fetch_by_every('clips','id',$feild['clip_id']);
          $clip_name=$data['name_fa'];
          $name_price=$data['price'];
          $clip_api_key=$data['clip_api_key'];
          $subcategory=$data['subcategory'];
          $clip_id=$feild['clip_id'];
          $user_id=$feild['user_id'];
          ?>
          <input  style="display: none" id="clip_name" value="<?=$clip_name?>">
          <input  style="display: none" id="user_id" value="<?=$user_id?>">
          <a href="/g/<?=$clip_api_key?>"><i style="color: #fffccc" class="icon-play huge"></i></a>
        </h3></div>
      <div class="colx-4"><h3><?= $clip_name ?></h3></div>
      <div class="colx-1"><h3><?= number_format($name_price,0); ?></h3></div>
      <?
      $data2=CommonModel::Fetch_by_every('category','id',$data['category']);
      $data3=CommonModel::Fetch_by_every('subcategories','id',$data['subcategory']);
      ?>
      <div class="colx-2"><h3><?= $data2['name_fa'] ?>/<?=$data3['subcategory_name']?></h3></div>
      <div class="colx-2"><h3><?=DateTimeCommon_without_time( $feild['created_at'] )?></h3></div>

      <div class="colx-2"><h3>
          <?
          //***********************************************************************
          $checkComment='true';
          $data_comments=CommonModel::Fetch_by_all('comments','user_id',$user_id,'');
          sort($data_comments);
          $clength = count($data_comments);
          if (empty($data_comments)) {
            $checkComment='true';
          }else{
            foreach ($data_comments as $key => $val) {// array chand boedy
              if ($val['clip_id'] === $clip_id) {
                $checkComment='false';
              }
            }
          }
          $parts_one=array();
          $data_rating=CommonModel::Fetch_by_every('rating','clip_id',$clip_id);
          $value="";
          $parts_one = explode(',',  $data_rating['voters']);

          if((!in_array($user_id,$parts_one))|| ($checkComment=='true')){?>
            <td>
              <button onclick="rating(<?= $clip_id?>,'<?= $clip_name?>',<?=$pageIndex?>);" class="btn_style btn-brown"><span>منتظریم</span></button>
            </td>
          <?} ?>
        </h3></div>
    </div>
    <? } ?>
  <br>
  <!--Buttons Filter-->
  <div class="row">
  <?=pagination('',3,'btn_style btn-brown','btn',$pageIndex,$pageCount-1,'all_clip_buy')?>
  </div>
  <br>
  </div>
  <div class="all_clip_buy_responsive">
    <? foreach ($list as $feild) {?>
    <div class="row">
      <div class="colx-2"><h2>نمایش</h2></div>
      <div class="colx-10"><h3>
          <?
          $data=CommonModel::Fetch_by_every('clips','id',$feild['clip_id']);
          $clip_name=$data['name_fa'];
          $name_price=$data['price'];
          $clip_api_key=$data['clip_api_key'];
          $subcategory=$data['subcategory'];
          $clip_id=$feild['clip_id'];
          $user_id=$feild['user_id'];
          ?>
          <input  style="display: none" id="clip_name" value="<?=$clip_name?>">
          <input  style="display: none" id="user_id" value="<?=$user_id?>">
          <a href="/g<?=$clip_api_key?>/<?=$subcategory?>"><i style="color: #fffccc" class="icon-play huge"></i></a>
        </h3></div>
    </div>
    <div class="row">
      <div class="colx-2"><h2>نام کلیپ</h2></div>
      <div class="colx-10"><h3><?= $clip_name ?></h3></div>
    </div>
    <div class="row">
      <div class="colx-2"><h2>قیمت</h2></div>
      <div class="colx-10"><h3><?= $name_price ?></h3></div>
    </div>
    <div class="row">
      <div class="colx-2"><h2>دسته بندی</h2></div>
      <?
      $data2=CommonModel::Fetch_by_every('category','id',$data['category']);
      $data3=CommonModel::Fetch_by_every('subcategories','id',$data['subcategory']);
      ?>
      <div class="colx-10"><h3><?= $data2['name_fa'] ?>/<?=$data3['subcategory_name']?></h3></div>
    </div>
      <div class="row">
        <div class="colx-2"><h2>تاریخ خرید</h2></div>
        <div class="colx-10"><h3><?=DateTimeCommon_without_time( $feild['created_at'] )?></h3></div>
      </div>
      <div class="row">
        <div class="colx-2"><h2>امتیاز و نظرتون</h2></div>
        <div class="colx-10"><h3>
            <?
            //***********************************************************************
            $checkComment='true';
            $data_comments=CommonModel::Fetch_by_all('comments','user_id',$user_id,'');
            //  dump_unco($data_comments);
            sort($data_comments);
            $clength = count($data_comments);
            //  echo $clength;

            if (empty($data_comments)) {
              $checkComment='true';
            }else{
              foreach ($data_comments as $key => $val) {// array chand boedy
                if ($val['clip_id'] === $clip_id) {
                  //return $key;
                  $checkComment='false';
                  // echo $key;
                }
              }

            }
            $parts_one=array();
            $data_rating=CommonModel::Fetch_by_every('rating','clip_id',$clip_id);
            $value="";
            $parts_one = explode(',',  $data_rating['voters']);
            if((!in_array($user_id,$parts_one))|| ($checkComment=='true')){?>
                <button onclick="rating(<?= $clip_id?>,'<?= $clip_name?>',<?=$pageIndex?>);" class="btn_style btn-brown"><span>منتظریم</span></button>
            <?} ?>
          </h3></div>
      </div>
      <hr>
    <? } ?>
    <div class="row">
      <?=pagination_responsive('',3,'btn_style btn-brown','btn',$pageIndex,$pageCount,'all_clip_buy')?>
    </div>
  </div>
</div>
<script>
  function rating(Id,clip_name,pageIndex) {
   // var clip_name=$('#clip_name').val();
    var user_id=$('#user_id').val();

    $.ajax({
      url: '/rating/AddRating/' + Id,
      type: 'POST',
      dataType: 'json',
      data:{
        clip_name:clip_name,
        user_id:user_id,
        pageIndex:pageIndex
      },
      success: function (data) {
        $("#paginationUpdate").html(data.html);
      }
    });
  }

  $(function(){
    //rating();
  });
</script>

