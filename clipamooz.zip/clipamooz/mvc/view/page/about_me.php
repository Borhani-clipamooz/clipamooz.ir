<div class="row">
  <section id="section-2">
    <div class="about-landing">
      <div class="container">
        <div class="about-text">
          <h2 style="color: #fffccc;">درباره من بیشتر بدانید :</h2>
          <p style="font-size: 12pt;text-align: justify">
مسلم برهانی
          </p>
          <p style="font-size: 12pt;text-align: justify">
            طراح وب سایت
          </p>
          <p style="font-size: 12pt;text-align: justify">
            مشاوره  رایگان و مدرس طراحی وب سایت عمومی و خصوصی
          </p>
          <p style="font-size: 12pt;text-align: justify">
            کارشناس و نماینده فروش بیمه پاسارگاد کد : 87743
          </p>
          <p style="font-size: 12pt;text-align: left">
            09153018177&nbsp;&nbsp; <i class="icon-mobile2 large"></i>
          </p>
          <p style="font-size: 12pt;text-align: left">
            <i class="icon-coin-euro  large"></i>&nbsp;&nbsp;clipamooz.ir@gmail.com
          </p>
          <p style="font-size: 12pt;text-align: left">
            مشاوره : 14 الی 21   &nbsp;&nbsp;   <i class="icon-clock  large"></i>
          </p>
          <p style="font-size: 12pt;text-align: left">
            مشهد بلوار بعثت ، نبش بعثت 10 &nbsp;&nbsp;   <i class="icon-location  large"></i>
          </p>
        </div>
        <div class="thumb wow animated zoomIn"><img style="border-radius: 5px;width: 100%;height: 250px" src="/asset/images/insurance/pasargad.jpg" alt="پاسارگاد"></div>
      </div>
    </div>
  </section>

</div>