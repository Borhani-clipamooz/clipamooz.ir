<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="google-site-verification" content="_m5zKjcjgM1z18io5WZAXuNOSiLq5aR9mqkm6Hosj_g" />
<meta name="msvalidate.01" content="7A7BC75D35A352F6A48EE41FA1571169" />
<link rel="icon" href="/asset/images/favicon/clipamooz.ico">
<meta name="enamad" content="230654314"/>
<meta charset="utf-8">
<title><?= $pageTitle ?></title>
<!-- LINKEEDIN-->
<meta name="title" property="og:title" content="<?= $pageTitle ?>">
<meta name="image" property="og:image" content="<?= $image ?>">
<meta property="og:image:secure_url" content="<?= $image ?>">
<meta property="og:image:width" content="640">
<meta property="og:image:height" content="360">
<meta property="og:image:type" content="image/jpg">
<meta property="og:site_name" content="<?=_site_name?>">
<meta  property="og:description" content="<?=$description?>">
<meta name="author" content="<?= $author?>">
<!-- LINKEEDIN-->
<link rel="canonical" href="<?= $canonical?>" />
<meta property="article:tag" content="<?= $video_tag1?>"/>
<meta property="article:tag" content="<?= $video_tag2?>"/>
<meta property="article:tag" content="<?= $video_tag3?>"/>
<meta property="article:tag" content="<?= $video_tag4?>"/>
<meta property="article:tag" content="<?= $video_tag5?>"/>
<meta name="generator" content="Clipamooz.ir" />

<!--  CSS ******************************************************************************************************-->
<link rel="stylesheet" href="/asset/owlcarousel/assets/owl.carousel.css">
<link rel="stylesheet" href="/asset/owlcarousel/assets/owl.theme.default.min.css">
<link rel=stylesheet href="/asset/css/style.min.css">
<!--<link rel=stylesheet href="/asset/css/colorbox.min.css">-->
<link rel=stylesheet href="/asset/css/responsive.min.css">
<link rel="stylesheet" type="text/css" href="/asset/tooltipster/dist/css/tooltipster.bundle.min.css" />
<link rel=stylesheet type="text/css" href="/asset/css/jquery.mCustomScrollbar.min.css">
<!--  js   .......................................................................  -->
<script src="/asset/js/jquery.min.js"></script>
<script src="/asset/js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="/asset/owlcarousel/owl.carousel.min.js"></script>
<script src="/asset/js/animatescroll.min.js"></script>
<script src="/asset/js/sweetalert.min.js"></script>
<script src="/asset/js/lib/tinymce/tinymce.min.js"></script>
<script src="/asset/tooltipster/dist/js/tooltipster.bundle.min.js"></script>
<script src="/asset/js/index.min.js"></script>
<script  src="/asset/js/google_analytics.js?id=UA-127037559-1"></script>
</head>
<iframe src="https://www.googletagmanager.com/ns.html?id=GTM-TT7K54S" height="0" width="0" style="display:none;visibility:hidden"></iframe>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'UA-127037559-1');
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-127037559-1');
</script>



