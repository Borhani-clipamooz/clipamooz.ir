<div class="tac content">
  <div class="signin">
    <div class="row">
      <img  style="width: 150px;height: 100px;" src="/asset/images/logo/logo.png">
    </div>
    <div class="row" style="padding: 5px">
      کاربر عزیز تیکت خود را ارسال نمایید.
    </div>
    <div class="row">
      <div class="colx-5 colm-5 cols-0"></div>
      <div class="colx-1 colm-1 cols-fill">   ارسال کننده      </div>
      <div class="colx-1 colm-1 cols-fill ">
        <input  class="tac" style="width: 200px"  type="text"  value="<?=$_SESSION['user_name']?>">
        <input style="display: none"  class="tac"  type="text" id="sender_message_id" value="<?=$_SESSION['user_id']?>">
      </div>
      <div class="colx-5 colm-5  cols-0 "></div>
    </div>
    <div class="row">
      <div class="colx-5 colm-5 cols-0"></div>
      <div class="colx-1 colm-1 cols-fill">        موضوع</div>
      <div class="colx-1 colm-1 cols-fill ">
        <input type="text" style="width: 200px" class="tac"   id="subject_Support_message">
      </div>
      <div class="colx-5 colm-5  cols-0 "></div>
    </div>
    <div class="row">
      <div class="colx-5 colm-5 cols-0"></div>
      <div class="colx-1 colm-1 cols-fill">متن پیام </div>
      <div class="colx-1 colm-1 cols-fill ">
        <textarea style="height: 100px" class="tar" type="text"   id="body_Support_message" ></textarea>
      </div>
      <div class="colx-5 colm-5  cols-0 "></div>
    </div>
    <div class="row">
      <div class="colx-5 colm-5 cols-0"></div>
      <div class="colx-1 colm-1 cols-fill"></div>
      <div class="colx-1 colm-1 cols-fill ">
        <button id="btn_Send_Message_support_first"  class="btn_style btn-brown" onclick="Send_Message_support_first();">ارسال تیکت</button>
      </div>
      <div class="colx-5 colm-5  cols-0 "></div>
    </div>
    <div class="row">
      <div id="Support_message_1" style="display: none">
        <p id="Support_message"></p>
      </div>
    </div>
  </div>
  <input type="text"  style="display: none" id="date_question" value="<?=getCurrentDateTime()?>">
</div>
<script>
  function Send_Message_support_first(){
    $("#btn_Send_Message_support_first").after('<div id="loader_Send_Message_support_first"><span class="icon-spinner9 huge spin "></span></div>');
    var sender_message_id=$('#sender_message_id').val();
    var subject=$('#subject_Support_message').val();
    //   var receiver_message_id=$('#receiver_message_id').val();
  //  var receiver_message_id=53;
      var body=$('#body_Support_message').val();
      if(body==''){
       swal('پیامی نوشته نشده است.') ;
        $('#loader').slideUp(1000, function() {
          $(this).remove();
      });
        return;
      }else{
      $.ajax({
        url: '/Send_Message_support_first/',
        method: 'POST',
        dataType: 'json',
        data: {
          sender_message_id: sender_message_id,
          subject: subject,
          body: body
        },
        success: function (output) {
          $('#loader_Send_Message_support_first').slideUp(1000, function() {
            $(this).remove();
          });
            window.location.reload();
        if(output.status==false){
          swal("وارد سیستم شوید.");
        }
        }
      });
      }
    }

</script>