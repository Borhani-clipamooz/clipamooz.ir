<div class="row">
  <section id="section-2">
    <div class="about-landing">
      <div class="container">
        <div class="about-text">
          <h2 style="color: #fffccc;">بیمه مسئولیت مدیر یا هیئت مدیره ساختمان</h2>
          <p style="margin-top: 50px">
            اگر مدیر ساختمان هستید حتما گاهی اوقات با خود اندیشیده اید که اگر برای نظافت چی یا سرایدار اتفاقی بیفتد تکلیف چیست ؟ اگر سنگ یا آجری از نمای ساختمان رها شود و بر سر یک عابر بیفتد تکلیف چیست ؟ اگر برای تعمیرکار تاسیسات یا آسانسور یا باغبان حادثه ای پیش بیاید چه باید کرد ؟ اگر مهمانی در حین استفاده از آسانسور دچار حادثه شود مسئول کیست ؟
          </p>
        </div>
        <div class="thumb wow animated zoomIn"><img style="border-radius: 10px" src="/asset/images/insurance/residentialcomplex.jpg" alt="مجتمع مسکونی"></div>
      </div>
    </div>
  </section>
  </div>
<div class="row">
  <section>
    <div class="container">
    <!--***********  INFO ---   Person   --   Responsive   ********************************************************************************-->
    <div class="info_person_responsive">
      <div id="panel1_residentialcomplex_responsive" class="titrbox"> <h1>&nbsp;&nbsp;موضوع بیمه مسئولیت مدیر ساختمان :<i id="icon_panel1_residentialcomplex_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="panel1_residentialcomplex_panel_responsive" style="display: none">
        <p style="font-size: 12pt;text-align: justify">
          عبارت است از بیمه مسئولیت مدیر ساختمان در قبال ساکنین ، اشخاص ثالث و مشاعات ساختمان ، بدین معنی که چنانچه در نتیجه قصور و سهل انگاری  مدیر ساختمان خسارت جانی و مالی به ساکنین ، اشخاص ثالث و مشاعات وارد شود و منشاء این خسارت ناشی از مشاعات ساختمان باشد ، شرکت بیمه پس از احراز مسئولیت مدیر ساختمان و در صورت لزوم مطابق رای محاکم قضایی نسبت به پرداخت خسارت اقدام می نماید.        </p>
        </p>
      </div>    <!-- END panel1_responsive ******************-->
      <div id="panel2_residentialcomplex_responsive" class="titrbox "> <h1>&nbsp;&nbsp;خطرات تحت پوشش بیمه مسئولیت مدیر ساختمان:<i id="icon_panel2_residentialcomplex_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="panel2_residentialcomplex_panel_responsive" style="display: none">
        <p style="font-size: 12pt;text-align: justify">
          مسئولیت بیمه گذار در قبال اشخاص ثالث، ساکنین و مشاعات ساختمان مطابق شرایط و تعهدات بیمه نامه

          صدمات جانی و مالی وارده به شخص بیمه گذار در اثر خطرات موضوع بیمه نامه و در محل مورد بیمه ، بر اساس شرایط بیمه نامه (حوادث)
        </p>
        <p style="font-size: 12pt;text-align: justify">
          خسارت جانی وارده به شخص سرایدار ، نظافتچی ، سرویس کار ، تعمیرکار و باغبان برای همه موارد در بخش های مشاعات ساختمان و در اثر خطرات موضوع مورد بیمه  نامه
        </p>
        <p style="font-size: 12pt;text-align: justify">
          خسارت جانی وارده به ساکنین و اشخاص ثالث ناشی از استفاده از آسانسور و یا پله برقی
        </p>
      </div><!--  END panel2_responsive  ******************-->
      <div id="panel3_residentialcomplex_responsive" class="titrbox "> <h1>&nbsp;&nbsp;خسارت های غیر قابل پرداخت : <i id="icon_panel3_residentialcomplex_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="panel3_residentialcomplex_panel_responsive" style="display: none">
        <p style="font-size: 12pt;text-align: justify">
          1- خسارت وارده ناشی از فعالیت های نماکاری ، نقاشی ، احداث و یا اضافه بنا ، و هرگونه تعمیرات اساسی و کلی ساختمان در کلیه ساختمانهای مورد بیمه
        </p>
        <p style="font-size: 12pt;text-align: justify">
          2- خسارت وارده به وسایل نقلیه مستقر در پارکینگ های عمومی ، تجاری ، اداری
        </p>
        <p style="font-size: 12pt;text-align: justify">
          3- خسارت های ناشی از تصادم ، تصادف ، برخورد با اجسام ثابت و ... که در نتیجه عمل راننده وسیله نقلیه حادث شود
        </p>
        <p style="font-size: 12pt;text-align: justify">
          4- خسارت های ناشی از عمد و تقلب بیمه گذار
        </p>
        <p style="font-size: 12pt;text-align: justify">
          5- خسارت های ناشی از انفجار هسته ای و تشعشعات رادیو اکتیو
        </p>
        <p style="font-size: 12pt;text-align: justify">
          6- خسارت های ناشی از جنگ و انقلاب و شورش و اعتصاب و عوامل دیگری از این قبیل
        </p>
        <p style="font-size: 12pt;text-align: justify">
          6- خسارت های ناشی از جنگ و انقلاب و شورش و اعتصاب و عوامل دیگری از این قبیل
        </p>
        <p style="font-size: 12pt;text-align: justify">
          7- خسارت هایی که منشا آن خارج از اختیار بیمه گذار می باشد از قبیل حوادث و بلایای طبیعی ( سیل ، زلزله ، رانش زمین ) مگر آنکه مسئولیت بیمه گذار در مراجع قضایی در بروز حادثه محرز گردد
        </p>
        <p style="font-size: 12pt;text-align: justify">
          8- جرایم ، تخلفات و مطالبات شهرداری و سایر سازمانها و جزای نقدی
        </p>
        <p style="font-size: 12pt;text-align: justify">
          9- کلیه حوادثی که طبق نظر مراجع ذیصلاح بیمه گذار مسئول آن شناخته نمی شود
        </p>
        <p style="font-size: 12pt;text-align: justify">
          10- خسارت ناشی از حوادث ورزشی در سالن ورزشی محل مورد بیمه (یک بیمه نامه مستقل باید خریداری شود)
        </p>
        <p style="font-size: 12pt;text-align: justify">
          11- خسارت وارده به وسیله نقلیه موتوری بر اثر برخورد ، تصادم ، تصادف ، سرقت کلی ، سرقت جزیی ، و خط کشی روی بدنه
        </p>
        <p style="font-size: 12pt;text-align: justify">
          12- خسارت وارده ناشی از مسئولیت غیر از بیمه گذار ( مانند مسئولیت پیمانکار )
        </p>
        <p style="font-size: 12pt;text-align: justify">
          13- هرگونه خسارتی که خارج از شرایط و آیین نامه مسئولیت قانون تملک آپارتمانها باشد
        </p>
        <p style="font-size: 12pt;text-align: justify">
          14- خسارت وارده به کارکنان و نگهبانان بیمه گذار در مراکز تجاری و اداری
        </p>
        <p style="font-size: 12pt;text-align: justify">
          تبصره : خسارت های مالی وارده به اتومبیل های مستقر درپارکینگ ساختمان های مسکونی که منشا حادثه مشاعات ساختمان باشد مطابق شرایط بیمه نامه قابل پرداخت است
        </p>
      </div><!--  END panel3_responsive ******************-->
    </div><!--  END info person Responsive  ******************-->
    </div>
  </section>
  <section style="padding:0 10px 0 10px">
  <p style="font-size: 12pt;color: #fffccc;text-align: right">
            <span>
              <strong>خرید بیمه نامه :</strong>
            </span>
  </p>
  <p style="font-size: 12pt;text-align: justify">
    جهت خرید بیمه نامه لطفا فرم زیر را  دانلود و پس از تکمیل به یکی از روشها شبکه های اجتماعی (سروش ، تلگرام ، واتس آپ ) و یا ایمیل برای اینجانب ارسال نمایید تا فرم اعلام حق بیمه و متعاقب آن صدور بیمه نامه صورت پذیرد .
  </p>
  </section>
  <div class="row">
  <button class="btn btn-brown" onclick="window.location.href='/pdf/residentialcomplex'">دانلود فرم بیمه مسئولیت هیات مدیره مجتمع مسکونی</button>
  </div>
</div>