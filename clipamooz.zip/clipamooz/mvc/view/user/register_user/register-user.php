<script src="/asset/js/lib/hash/md5.min.js"></script>
<script src="/asset/js/lib/hash/sha1.min.js"></script>
<script>

    $(function () {
      $("input").each(function () {
        // validateInput($(this));
        $(this).on('keyup', function () {
          validateInput($(this));
        });
      });
        $("#submit").on('click', function () {
            var validation = true;
          $("input").each(function () {
                if ($(this).hasClass("wrong")) {
                    validation = false;
                    return;
                }
            var user_name=$("#user_name").val();
            var email=$("#email_register").val();
            var password1=$("#password1").val();
            var password2=$("#password2").val();
                if (user_name==''||email==''||password1==''||password2=='') {
                    validation = false;
                    return;
                }
            })
            if (!validation) {
           swal("اطلاعات وارد شده دارای اشکال می باشد.");
             } else {
              captcha_SaveRegister();
            }
        });
    });
</script>

<div class="tac content">
  <div class="border">
 <div class="row">
   <div class="colx-2 colm-4 cols-0"></div>
    <div class="colx-3 colm-1 cols-fill">
      نام کاربری
    </div>
    <div class="colx-2 colm-2 cols-fill ">
      <input  type="text"  data-rule="user_name_is_Free" id="user_name"  name="user_name" >
    </div>
    <div class="colx-5 colm-5  cols-0 "></div>
 </div>
    <div class="row">
      <div class="colx-3 colm-4 cols-0"></div>
      <div class="colx-2 colm-1 cols-fill">
        ایمیل
      </div>
      <div class="colx-2 colm-2 cols-fill ">
        <input style="color: #000"  data-rule="email_is_Free" type="text" id="email_register" name="user_email">
      </div>
      <div class="colx-5 colm-5  cols-0 "></div>
    </div>
    <div class="row">
      <div class="colx-2 colm-4 cols-0"></div>
      <div class="colx-3 colm-1 cols-fill">
        رمز عبور
      </div>
      <div class="colx-2 colm-2 cols-fill ">
        <input style="color: #000"  data-rule="password" type="password" id="password1" name="password1">
      </div>
      <div class="colx-5 colm-5  cols-0 "></div>
    </div>

    <div class="row">
      <div class="colx-1 colm-4 cols-0"></div>
      <div class="colx-4 colm-1 cols-fill">
        تکرار رمز عبور
      </div>
      <div class="colx-2 colm-2 cols-fill ">
        <input style="color: #000"   data-rule="password" type="password" id="password2" name="password2">
        <input  type="hidden"  id="password" name="password">
      </div>
      <div class="colx-5 colm-5  cols-0 "></div>
    </div>
  <div class="row">
    <div class="colx-3 colm-3 cols-fill"> <button class="btn_style btn-brown"  id="reset" onclick="Reset()">بازنشانی</button></div>
    <div class="colx-3 colm-3 cols-fill"><input style="width: 100%" class="tac hf" type="text" id="captcha_SaveRegister"></div>
    <div class="colx-3 colm-3 cols-fill"><img src="/mvc/view/common/captcha/captcha_image.jpg.php"></div>
    <div class="colx-3 colm-3 cols-fill"> <button class="btn_style btn-brown" id="submit">ثبت نام </button></div>
    </div>
    <div id="Register_message_1" style="display: none">
      <span id="Register_message"></span>
    </div>
  </div>

    <div style="display: none">
      <td>تاریخ عضویت</td>
      <td><input type="datetime"  value="<?=getCurrentDateTime()?>" id="member_date"  style="text-align: center"></td>
    </div>

  </div>
</div>
<script>
  function Reset(){
    $("#user_name").val('');
    $("#email_register").val('');
    $("#password1").val('');
    $("#password2").val('');
  }
  function captcha_SaveRegister(){
    var captcha=$("#captcha_SaveRegister").val();
    $.ajax({
      url:'/captcha',
      type: 'POST',
      dataType:'json',
      data:{
        captcha:captcha
      },
      success:function(data){
        if(data.status==false){
          swal("کد وارد شده ایراد دارد.");
          return;
        }else{
          SaveRegisterUser();
        }
      }
    });

  }
  function SaveRegisterUser(){
    var user_name=$("#user_name").val();
    var email=$("#email_register").val();
    var password1=$("#password1").val();
    var password=$("#password").val();
    var member_date=$("#member_date").val();
    $("#submit").after('<div id="loader"><span class="icon-spinner9 huge spin "></span></div>');
    $.ajax({
      url:'/registerUser/',
      type: 'POST',
      dataType:'json',
      data:{
        user_name:user_name,
        email:email,
        password:password,
        member_date:member_date
      },
      success:function(data){
        $('#loader').slideUp(1000, function() {
          $(this).remove();
        });
        switch (data.status) {
          case 'false':
          {
            swal("کاربر عزیز قبلا ثبت نام کردید.");
            break;
          }
          case 'true':
          {
            swal({
                title: "به کلیپ آموز خوش آمدید.",
                text: "لینک فعال سازی به ایمیلتون ارسال گردید.",
                imageUrl: "/asset/images/logo/logo.png",
                closeOnConfirm: false,
                showLoaderOnConfirm: true
              },
              function () {
                setTimeout(function () {
                  window.location.href = "/page/home";
                }, 2000);
              });
            break;
          }
          default:
          //  window.location.href = "/h"+name_fa+"/"+subcategory;
        }
      }
    });
  }
</script>