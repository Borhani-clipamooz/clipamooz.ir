/**
 * Created by mbm125 on 5/16/2018.
 */


  function validateInput(element) {

    var rule = element.data('rule');
    if (rule == undefined) {
      return
    }
    if (rule == "email_is_Free") {
      validateEmail_isFree(element);
    }
    if (rule == "email_is_Free_responsive") {
      validateEmail_isFree_responsive(element);
    }
    if (rule == "user_name_is_Free") {
      user_name_is_Free(element);
    }
    if (rule == "user_name_is_Free_responsive") {
      user_name_is_Free_responsive(element);
    }
    if (rule == "password") {
      isPasswordValid();
    }
    if (rule == "password_responsive") {
      isPasswordValid_responsive();
    }


  }
  function validateEmail_isFree(element) {
    if(regexEmail(element)){return;}
    $.ajax('/user/isEmailRegistered', {
      type: 'post',
      dataType: 'json',
      data:  {user_email: element.val()},
      success: function (data) {

        if (data.isFree) {
          element.removeClass("wrong");
          element.addClass("correct");
        } else {
          element.removeClass("correct");
          element.addClass("wrong");
        }
      }
    });
  }
  function validateEmail_isFree_responsive(element) {
    if(regexEmail(element)){return;}
    $.ajax('/user/isEmailRegistered', {
      type: 'post',
      dataType: 'json',
      data:  {user_email: element.val()},
      success: function (data) {

        if (data.isFree) {
          element.removeClass("wrong");
          element.addClass("correct");
        } else {
          element.removeClass("correct");
          element.addClass("wrong");
        }
      }
    });
  }
  function user_name_is_Free(element) {
    $.ajax('/user/user_name_is_Free', {
      type: 'post',
      dataType: 'json',
      data:  {user_name: element.val()},
      success: function (data) {

        if (data.isFree) {
          element.removeClass("wrong");
          element.addClass("correct");
        } else {
          element.removeClass("correct");
          element.addClass("wrong");
        }
      }
    });
  }
  function user_name_is_Free_responsive(element) {
    $.ajax('/user/user_name_is_Free', {
      type: 'post',
      dataType: 'json',
      data:  {user_name: element.val()},
      success: function (data) {

        if (data.isFree) {
          element.removeClass("wrong");
          element.addClass("correct");
        } else {
          element.removeClass("correct");
          element.addClass("wrong");
        }
      }
    });
  }
function isPasswordValid() {
  var element1=$("#password1");
  var element2=$("#password2");
  var hiddenElement=$("#password");
  var mustReturn = false;
  if (element1.val().length < 4) {
    element1.removeClass("correct");
    element1.addClass("wrong");
    mustReturn = true;
  }
  if (element2.val().length < 4) {
    element2.removeClass("correct");
    element2.addClass("wrong");
    mustReturn = true;
  }
  if (mustReturn) {
    return;
  }
  if (element1.val() !== element2.val()) {
    element1.removeClass("correct");
    element1.addClass("wrong");
    element2.removeClass("correct");
    element2.addClass("wrong");
  }else
  {
    element1.removeClass("wrong");
    element1.addClass("correct");
    element2.removeClass("wrong");
    element2.addClass("correct");
    hiddenElement.val(js_encryptPassword(element1.val()));
  }
}
function isPasswordValid_responsive() {
  var element1=$("#password1_responsive");
  var element2=$("#password2_responsive");
  var hiddenElement=$("#password_responsive");
  var mustReturn = false;
  if (element1.val().length < 4) {
    element1.removeClass("correct");
    element1.addClass("wrong");
    mustReturn = true;
  }
  if (element2.val().length < 4) {
    element2.removeClass("correct");
    element2.addClass("wrong");
    mustReturn = true;
  }
  if (mustReturn) {
    return;
  }
  if (element1.val() !== element2.val()) {
    element1.removeClass("correct");
    element1.addClass("wrong");
    element2.removeClass("correct");
    element2.addClass("wrong");
  }else
  {
    element1.removeClass("wrong");
    element1.addClass("correct");
    element2.removeClass("wrong");
    element2.addClass("correct");
    hiddenElement.val(js_encryptPassword(element1.val()));
  }
}
  function makeRandomText() {
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    for (var i = 0; i < 20; i++)
      text += possible.charAt(Math.floor(Math.random() * possible.length));

    return text;
  }

//........URL...................
  var Fun_URL=(function(){
    var url="";
    return{
      getURL:function(dd){
        url=url+dd;
        return url;
      },
      clear:function(){
        url="";
        return url;
      }
    }
  })();

//..........................................................................
  function ShowUploaderImage(id,table_name,feild_name,width,height){
    $.ajax({
      url:'/uploader/ShowUploaderImage/',
      type: 'POST',
      dataType:'json',
      data:{
        id:id,
        table_name:table_name,
        feild_name:feild_name,
        width:width,
        height:height
      },
      success:function(data){
        //    console.log(data);
        $("#ShowUploaderImage").html(data.html);
      }
    });
  }
//..........................................................................
  function ShowUploaderFile(id,table_name,feild_name){
    $.ajax({
      url:'/uploader/ShowUploaderFile/',
      type: 'POST',
      dataType:'json',
      data:{
        id:id,
        table_name:table_name,
        feild_name:feild_name
      },
      success:function(data){
        //    console.log(data);
        $("#ShowUploaderFile").html(data.html);
      }
    });
  }
//..........................................................................
  function  update_spacial_field(id,table_name,whichfeild,content){
    $.ajax({
      url:'/common/update_spacial_field/',
      type: 'POST',
      dataType:'json',
      data:{
        id:id,
        table_name:table_name,
        whichfeild:whichfeild,
        content:content
      },
      success:function(data){
        //  console.log(data);
      }
    });
  }
//.......Remove_data........................................................................................
function Remove_data(PathFile,select,id,table_name,whichfeild,content) {
  swal({
      title: "آیا مطمئن هستید؟",
      text: "شما دیگر قادر به بازیابی این فایل نخواهید بود.",
      type: "warning",
      showCancelButton: true,
      confirmButtonColor: "#5d4126",
      confirmButtonText: "آره، آن را حذف کنید.",
      cancelButtonText: "لغو",
      closeOnConfirm: false
    },
    function(){
      $.ajax({
        url: '/common/Remove_data/',
        type: 'POST',
        dataType: 'json',
        data:{
          pathFile: PathFile
        },
        success: function (data) {
          update_spacial_field(id,table_name,whichfeild,content);
        }
      });
      swal("حذف گردید.");
      switch(select){
        case 0:
          $("#deleteImage").html("");
          document.getElementById("messageiImage").innerHTML="تصویر حذف گردید صفحه نیاز به لود مجدد دارد.";
          $("#ShowUploaderImage").show();
          break;
        case 1:
          document.getElementById("messagePrevClip").innerHTML="پیش نمایش کلیپ حذف گردید صفحه نیاز به لود مجدد دارد.";
          $("#delete_clip_prev_link").html("");
          $("#ShowUploaderPrevClip").show();
          break;
        case 2://   کلیپ اصلی
          update_spacial_field(id,table_name,'clip_long_time',content);
          update_spacial_field(id,table_name,'clip_size',content);
          $("#delete_clip_link").html("");
          $("#ShowUploaderClip").show();
          break;
        case 3:
          $("#deleteFile").html("");
          document.getElementById("messageFile").innerHTML="پیوست کلیپ حذف گردید صفحه را مجدد لود کنید.";
          $("#ShowUploaderFile").show();
          break;
        default :
          break;
      }

    });

}
function Remove_Clip(PathFile,id) {
  swal({
      title: "آیا مطمئن هستید؟",
      text: "شما دیگر قادر به بازیابی این فایل نخواهید بود.",
      type: "warning",
      showCancelButton: true,
      confirmButtonColor: "#5d4126",
      confirmButtonText: "آره، آن را حذف کنید.",
      cancelButtonText: "لغو",
      closeOnConfirm: false
    },
    function(){
      $.ajax({
        url: '/common/Remove_data/',
        type: 'POST',
        dataType: 'json',
        data:{
          pathFile: PathFile
        },
        success: function (data) {
          update_spacial_field(id,table_name,whichfeild,content);
        }
      });
      swal("حذف گردید.");
    });

}

//.....PopUp Windows...............................................................................................................
  function popup(){
    $('.popup-with-zoom-anim').magnificPopup({
      type: 'inline',
      fixedContentPos: false,
      fixedBgPos: true,
      overflowY: 'auto',
      closeBtnInside: true,
      preloader: false,
      midClick: true,
      removalDelay: 300,
      mainClass: 'my-mfp-zoom-in'
    });
  }
  function popupClose(){
    $.magnificPopup.proto.close.call(this);
  }
  function PopupHelp() {
    $.ajax({
      url: '/page/Help/',
      method: 'POST',
      dataType: 'json',
      data: {

      },
      success: function (output) {
        // console.log(output);
        $("#Help").html(output.html);
      }
    });
  }
  function Search() {
    $.ajax({
      url: '/serach/',
      method: 'POST',
      dataType: 'json',
      data: {

      },
      success: function (output) {
        // console.log(output);
        $("#search").html(output.html);
      }
    });
  }
  function responsive_search() {
    $.ajax({
      url: '/responsive_search/',
      method: 'POST',
      dataType: 'json',
      data: {
      },
      success: function (output) {
     //  console.log(output);
        $("#responsive_search").html(output.html);
      }
    });
  }


  function popupRating(id) {

    $.ajax({
      url: '/rating/ShowRating/'+id,
      method: 'POST',
      dataType: 'json',
      data: {

      },
      success: function (output) {
        //  console.log(output);
        $("#popupRating").html(output.html);
      }
    });
  }



  function js_baseUrl(){
    var config='';
    return config;
  }

  function js_encryptPassword(password){
    var salt = 'suya9s8ydaiu987vqo28bv9q87B87VPq7E98QVB';
    return hex_sha1(hex_md5(password+salt));
    //return (password+salt);
  }
  function js_encryptPasswordWithoutSalt(password){
    return hex_md5(password);
  }
  function regexEmail(element){
    var email = element.val();
    var regex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if (!regex.test(email)) {
      element.removeClass("correct");
      element.addClass("wrong");
      return true;
    }

  }


  function Rating(){
    $.ajax({
      url: '/rating/ShowRating/',
      method: 'POST',
      dataType: 'json',
      data: {

      },
      success: function (output) {
        // console.log(output);
        $("#Rating").html(output.html);
      }
    });
  }

