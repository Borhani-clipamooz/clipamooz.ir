<div class="tac">
  <br>
  <img src="/asset/images/fail.png">
  <br>
  <br>
  <div style="color:#fff"><?=$message?></div>
</div>
