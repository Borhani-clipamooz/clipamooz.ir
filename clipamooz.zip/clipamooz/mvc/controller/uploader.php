<?php

class UploaderController {
  public function upload_prev_file($count_chunk,$file_name,$id,$field) {
    if(isset($_FILES['file']) && $_FILES['file']['error'] == 0){
      $filesize = $count_chunk;
      $chunksFolder = 'uploadfile/chunks/'.$file_name.'/';
     $address_Save_to_DataBase='/uploadfile/clip_prev/'.$file_name.'.mp4';
      if (!file_exists($chunksFolder)) {
        mkdir($chunksFolder, 0777, true);
      }
      if(isset($_FILES['file']["tmp_name"])) {
        // $num_chunks = $_POST['num_chunks'];
          echo $chunksFolder.$_FILES["file"]["name"];
        if (move_uploaded_file($_FILES["file"]["tmp_name"],$chunksFolder. $_FILES["file"]["name"])){
          // count ammount of uploaded chunks
          $chunksUploaded = 0;
          for ( $i = 0; $i < $filesize; $i++ ) {
            if ( file_exists( $chunksFolder.$i ) ) {
              ++$chunksUploaded;
            }
          }
          if ($chunksUploaded == $filesize) {
            $DIRECTORY_SEPARATOR='/';
            $targetPath = join($DIRECTORY_SEPARATOR, array( "uploadfile/", 'clip_prev', $file_name.'.mp4'));
            if (!file_exists($targetPath)){
              mkdir(dirname($targetPath), 0777, true);
            }
            $target = fopen($targetPath, 'wb');

            for ($i=0; $i<$filesize; $i++){
              $chunk = fopen($chunksFolder.$i, "rb");
              stream_copy_to_stream($chunk, $target);
              fclose($chunk);
            }
            // Success
            fclose($target);
            CommonModel::update_spacial_field($id,'clips',$field,$address_Save_to_DataBase);
            for ($i=0; $i<$filesize; $i++){
              unlink($chunksFolder.$DIRECTORY_SEPARATOR.$i);
            }
            rmdir($chunksFolder);
          }
        }else{
          echo 'NO';
        }
      }
    }
  }


  public function UploadImage($id,$table,$field,$resizeWidth,$resizeHeight) {
    //$resizeWidth=100;
  //  $resizeHeight=100;
    function resizeImage($resourceType,$image_width,$image_height,$resizeWidth,$resizeHeight) {

      $imageLayer = imagecreatetruecolor($resizeWidth,$resizeHeight);
      imagecopyresampled($imageLayer,$resourceType,0,0,0,0,$resizeWidth,$resizeHeight, $image_width,$image_height);
      return $imageLayer;
    }

      $fileName = $_FILES['file1']['tmp_name'];
      $sourceProperties = getimagesize($fileName);
      $resizeFileName = time().md5(uniqid(rand(), true));
      $uploadPath ="uploadfile/image/";
      $fileExt = pathinfo(@$_FILES['file1']['name'], PATHINFO_EXTENSION);
      $uploadImageType = $sourceProperties[2];
      $sourceImageWidth = $sourceProperties[0];
      $sourceImageHeight = $sourceProperties[1];
      switch ($uploadImageType) {
        case IMAGETYPE_JPEG:
          $resourceType = imagecreatefromjpeg($fileName);
          $imageLayer = resizeImage($resourceType, $sourceImageWidth, $sourceImageHeight, $resizeWidth, $resizeHeight);
          imagejpeg($imageLayer, $uploadPath . "www.clipamooz.ir" . $resizeFileName . '.' . $fileExt);
          $address_Save_to_DataBase = $uploadPath.'www.clipamooz.ir' . $resizeFileName . '.' . $fileExt;
          CommonModel::update_spacial_field($id,$table,$field,'/'.$address_Save_to_DataBase);
          break;

        case IMAGETYPE_GIF:
          $resourceType = imagecreatefromgif($fileName);
          $imageLayer = resizeImage($resourceType, $sourceImageWidth, $sourceImageHeight, $resizeWidth, $resizeHeight);
          imagegif($imageLayer, $uploadPath . "www.clipamooz.ir" . $resizeFileName . '.' . $fileExt);
          $address_Save_to_DataBase = $uploadPath.'www.clipamooz.ir' . $resizeFileName . '.' . $fileExt;
          CommonModel::update_spacial_field($id,$table,$field,'/'.$address_Save_to_DataBase);
          break;

        case IMAGETYPE_PNG:
          $resourceType = imagecreatefrompng($fileName);
          $imageLayer = resizeImage($resourceType, $sourceImageWidth, $sourceImageHeight, $resizeWidth, $resizeHeight);
          imagepng($imageLayer, $uploadPath . "www.clipamooz.ir" . $resizeFileName . '.' . $fileExt);
          $address_Save_to_DataBase = $uploadPath.'www.clipamooz.ir' . $resizeFileName . '.' . $fileExt;
          CommonModel::update_spacial_field($id,$table,$field,'/'.$address_Save_to_DataBase);
          break;
        default:
          break;
      }
  }
  public function UploadImage1($id,$table,$field) {
    header("Content-Type: text/html; charset=utf-8");
    $target_dir = 'uploadfile/image/';
    $ID = $id;
    $Table_name = $table;
    $Feild_name = $field;
    global $config;
    $target_file = $target_dir . basename($_FILES["file1"]["name"]);
    if(isset($_FILES['file1']) && $_FILES['file1']['error'] == 0){
      $imageFileType = pathinfo($target_file, PATHINFO_EXTENSION);
      if($imageFileType != "jpg" && $imageFileType != "png")
      {
        echo "File Format Not Suppoted";
      }else{
        $temp = explode(".", $_FILES["file1"]["name"]);
        $newfilename ='www.clipamooz.ir'.generateRandomString(). round(microtime(true)) . '.' . end($temp);
        move_uploaded_file($_FILES["file1"]["tmp_name"], $target_dir . $newfilename);
        CommonModel::update_spacial_field($ID,$Table_name,$Feild_name,'/'.$target_dir . $newfilename);
      }
    }
  }
  public function Uploadzipfile($id,$table,$field) {
    header("Content-Type: text/html; charset=utf-8");
    $target_dir = 'uploadfile/zipfile/';
    $ID = $id;
    $Table_name = $table;
    $Feild_name = $field;
    global $config;
    $target_file = $target_dir . basename($_FILES["file1"]["name"]);
    if(isset($_FILES['file1']) && $_FILES['file1']['error'] == 0){
      $imageFileType = pathinfo($target_file, PATHINFO_EXTENSION);
      if($imageFileType != "zip")
      {
        echo "File Format Not Suppoted";
      }else{
        $temp = explode(".", $_FILES["file1"]["name"]);
        $newfilename ='www.clipamooz.ir:'.generateRandomString(). round(microtime(true)) . '.' . end($temp);
        move_uploaded_file($_FILES["file1"]["tmp_name"], $target_dir . $newfilename);
        CommonModel::update_spacial_field($ID,$Table_name,$Feild_name,'/'.$target_dir . $newfilename);
      }
    }
  }
  public function FilePreviewClip($id,$table,$field) {
    header("Content-Type: text/html; charset=utf-8");
    $target_dir = 'uploadfile/clip_prev/';
    $ID = $id;
    $Table_name = $table;
    $Feild_name = $field;
    global $config;
    $target_file = $target_dir . basename($_FILES["file1"]["name"]);
    if(isset($_FILES['file1']) && $_FILES['file1']['error'] == 0){
      $imageFileType = pathinfo($target_file, PATHINFO_EXTENSION);
      if($imageFileType != "mp4")
      {
        echo "File Format Not Suppoted";
      }else{
        $temp = explode(".", $_FILES["file1"]["name"]);
        $newfilename =generateRandomString(). round(microtime(true)) . '.' . end($temp);
        move_uploaded_file($_FILES["file1"]["tmp_name"], $target_dir . $newfilename);
        CommonModel::update_spacial_field($ID,$Table_name,$Feild_name,'/'.$target_dir . $newfilename);
      }
    }
  }
  public function cropimage($id,$field,$table,$width,$height) {

    if(isset($_FILES['user-file']) && $_FILES['user-file']['error'] == 0){

      $ch = curl_init();
      $cfile=new CURLFile($_FILES["user-file"]["tmp_name"],$_FILES["user-file"]["type"],$_FILES['user-file']['name']);
      $data=array("user-file"=>$cfile ,"id"=>$id,"field"=>$field,"table"=>$table,"width"=>$width,"height"=>$height);
      $target_url = 'http://stg.pz10251.parspack.net/cropimage/uploader.php';
      curl_setopt($ch, CURLOPT_URL,$target_url);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
      curl_setopt($ch, CURLOPT_POST,true);
      curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
      $result=curl_exec ($ch);
      echo $result;
    }else{
      echo 'فایلی انتخاب نشده است';
    }

  }

  public function zipfile($id,$field,$table) {

if(isset($_FILES['user-file']["tmp_name"])) {
  //تعیین فرمت یا اندازه مجاز و سایر پارامترها
  $fileExt = pathinfo(@$_FILES['user-file']['name'], PATHINFO_EXTENSION);
  if ($fileExt == 'zip' && $_FILES["user-file"]["size"] <= 10000000) {
    //بررسی سایر خطاهای سرور
    if ($_FILES["user-file"]["error"] > 0){
      echo "<div class=\"server\">خطا: " . $_FILES["user-file"]["error"] . "</div><br />";
      $check_result = 0;
    }
    //بررسی وجود یا عدم وجود فایل با نام مشابه در سرور
    else{
      if (file_exists("user-upload/" . $_FILES["user-file"]["name"])){
        echo "<div class=\"server\">این فایل در حال حاضر وجود دارد! <br /><br />".$_FILES["user-file"]["name"]. "</div><br />";
        $check_result = 0;
      }
      //انتقال و ذخیره فایل در سرور
      else{
        if( @$_FILES['user-file']['name'] != "" )
        {
          $fileName = $_FILES['user-file']['tmp_name'];
          $resizeFileName = time().md5(uniqid(rand(), true));
          $uploadPath ="/uploadfile/zipfile/files/";

          $address_Save_to_DataBase='/uploadfile/zipfile/files/www.clipamooz.ir'.$resizeFileName.'.'. $fileExt;
          move_uploaded_file($_FILES["user-file"]["tmp_name"],$uploadPath . 'www.clipamooz.ir'.$resizeFileName.'.'. $fileExt);
          image_finish($address_Save_to_DataBase,$id,$field,$table);
        }

        else
        {
          die("No file specified!");
        }
        $check_result = 1;
      }
    }
  }
//خطای تعیین فرمت یا اندازه مجاز و سایر پارامترها
  else{
    if($_FILES["user-file"]["size"] > 1000000){
      echo "<div class=\"server\">حجم فایل خیلی زیاد است!</div>";
    }
    else{
      echo "<div class=\"server\">فرمت فایل مجاز نیست!</div>";
    }
    $check_result = 0;
  }
}


    echo "<script type='text/javascript'>";
    echo " window.top.window.upload_end1(<?php echo $check_result; ?>);";
    echo "</script>";

   /*
    if(isset($_FILES['user-file']) && $_FILES['user-file']['error'] == 0){
      $ch = curl_init();
      $cfile=new CURLFile($_FILES["user-file"]["tmp_name"],$_FILES["user-file"]["type"],$_FILES['user-file']['name']);
      $data=array("user-file"=>$cfile ,"id"=>$id,"field"=>$field,"table"=>$table);
      $target_url = 'http://stg.pz10251.parspack.net/zipfile.php';
      curl_setopt($ch, CURLOPT_URL,$target_url);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
      curl_setopt($ch, CURLOPT_POST,true);
      curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
      $result=curl_exec ($ch);
      echo $result;
    }else{
      echo 'فایلی انتخاب نشده است';
    }*/
  }

  public function image_finish($address_Save_to_DataBase,$id,$field,$table) {
    CommonModel::update_spacial_field($id,$table,$field,$address_Save_to_DataBase);
  }
  public function SaveAddressClipUpload() {
    $user_id=$_POST['user_id'];
    $address_Save_to_DataBase=$_POST['Save_Adress'];
    ClipModel::insert_uploader($user_id,'',$address_Save_to_DataBase);
    echo json_encode(array('status' => true, ));
  }
  public function UpdateNameClipUpload() {
    $id=$_POST['id'];
    $upload_name=$_POST['name_fa'];
    CommonModel::update_spacial_field($id,'uploader','upload_name',$upload_name);
    echo json_encode(array('status' => true, ));
  }
//******************************************************************************
  public function ShowUploaderImage() {
    $data=array();
    $data['id']=$_POST['id'];
    $data['table_name']=$_POST['table_name'];
    $data['feild_name']=$_POST['feild_name'];
    $data['width']=$_POST['width'];
    $data['height']=$_POST['height'];
    ob_start();
    View::renderPartial("/uploader/image_uploader_ajax.php", $data);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }
  public function ShowUploaderFile() {
    $data=array();
    $data['id']=$_POST['id'];
    $data['table_name']=$_POST['table_name'];
    $data['feild_name']=$_POST['feild_name'];
    ob_start();
    View::renderPartial("/uploader/uploadfile.php", $data);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }
  public function ShowUploaderclipFile() {
    ob_start();
    View::renderPartial("/uploader/public/index.php", array());
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }

  public function validate_Upload_isFree() {
    $content = $_POST['upload'];
    $NameTable = "category";
    $whichFeild = "image";
    $result = CommonModel::Fetch_by_every($NameTable, $whichFeild, $content);

    $output = array();
    if (count($result) > 0) {
      $output['isFree'] = false;
    } else {
      $output['isFree'] = true;
    }
    echo json_encode($output);
  }

}