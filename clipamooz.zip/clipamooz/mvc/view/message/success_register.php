<div class="tac content">
  <br>
  <img src="/asset/images/logo/logo250.png">
  <br>
  <br>
  <div><?=$message?></div>
  <br>
  <br>
  <img style="border-radius: 5px" src="/asset/images/tabrik.jpg">
</div>
