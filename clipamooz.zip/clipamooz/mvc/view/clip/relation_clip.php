<div class="row">
      <img src="/asset/images/468-60.gif">
</div>
<div class="row">
      <img src="/asset/images/468-60.gif">
</div>
<? global $config;?>
<div style="height: 501px"  id="bob" class="relation_clip" >
  <?  $list=CommonModel::Fetch_by_all_limit('clips','subcategory',$_SESSION[$subcategory],'opens',0,12);
  foreach ($list as $feild) {?>
      <a href="/g/<?=$feild['clip_api_key']?>" title="<?= $feild['name_fa']?>">
        <div class="row pd0">
            <div class="colx-4">
              <?if($feild['img_link']!=''){?>
                <img style="height: 85px;width: 100%;border-radius: 5px" src="<?= $config['upload'].$feild['img_link'] ?>">
                <? } else{ ?>
                  <img style="height: 85px;width: 100%;border-radius: 5px" src="<?= $config['empty_play']?>" >
                <?}?>
                <?
                if (strpos($feild['rating'], '.5') !== false) {
                  $R_rating=$feild['rating'];
                }else{
                  $R_rating=round($feild['rating']);
                }
                rating($R_rating,'15px','15px');?>
            </div>

          <div class="colx-8">
            <div class="row">
              <span class="video_title" ><?= $feild['name_fa'] ?></span>
            </div>
            <div class="row">
              <div class="colx-2">
                <?
                $data=CommonModel::Fetch_by_every('users','id',$feild['user_id']);
                $user_name="";
                $user_img="";
                $user_name=$data['user_name'];
                $user_img=$data['profile_pic'];
                ?>
                <?  if($user_img !=''){?>
                  <img style="width: 35px;height: 35px;border-radius: 2px" src="<?= $config['upload'].$user_img?>">
                <?}else{?>
                  <img style="width: 35px;height: 35px;border-radius: 2px" src="/asset/images/empty/empty-profile/empty-profile-24.png">
                <?}?>
              </div>
              <div class="colx-10">
                <div class="row tal">
                  <div><span style="font-size: 12px;font-weight: bold;" ><?=$user_name?></span></div>
                </div>
                <div class="row tal">
                  <?
                  $data=CommonModel::Fetch_by_every('category','id',$feild['category']);
                  $name_category=$data['name_fa'];

                  $data=CommonModel::Fetch_by_every('subcategories','id',$feild['subcategory']);
                  $name_sub_category=$data['subcategory_name'];
                  ?>
                  <div><span style="font-size: 12px;font-weight: bold;"><?= $name_category?>:<?= $name_sub_category?></span></div>
                </div>
              </div>
            </div>
          </div>
          </div>
        <div class="row" >
          <div class="colx-4"style="text-align: right !important;">
            <?
            if($feild['clip_long_time']>=3600){
              echo gmdate("H:i:s", $feild['clip_long_time']);
            }else{
              echo gmdate("i:s", $feild['clip_long_time']);
            }
            ?>
            </i>
            <span class="icon-clock"></span>
          </div>
          <div class="colx-4 tac">
                <span class=" icon-eye" aria-hidden="true"><span style="font-family: traffic">&nbsp;<?
                    $number =  number_format( $feild['opens']);
                    echo $number;?></span>
                </span>
          </div>
          <div class="colx-4" style="text-align: left !important;">
            <span class="icon-play" aria-hidden="true"><span style="font-family: traffic">&nbsp;<?= $feild['views']?></span></span>
          </div>
      </div>
      </a>
  <? }?>

  <?
  if(count($list)>11){?>
    <div style="text-align: center"><a href="/compelete_clips_subcategory/<?=$subcategory?>"><button onclick="" class="btn_style btn-brown"><?=_btn_more?></button></a></div>
  <?}?>
</div>
<script>
  $(function(){
    $("#bob").mCustomScrollbar({
      scrollButtons: {
        enable: true
      },
      theme: "dark"
    });
  });
</script>



