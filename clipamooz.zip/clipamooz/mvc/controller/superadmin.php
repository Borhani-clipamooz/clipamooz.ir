<?php
class SuperAdminController {
   public function optimize() {
     $date = $_POST['date_withdraw'];
     //$date='2019-02-11';
     $whichFeild='create_at';
     $table='withdraw_money';
     $data=CommonModel::Fetch_by_all_Date($table,$whichFeild,$date);
     foreach($data as $feild){
       CommonModel::Remove_item($feild['id'],$table);
     }
     $date = $_POST['date_withdraw'];
     //$date='2019-02-11';
     $whichFeild='create_at';
     $table='pay';
     $data=CommonModel::Fetch_by_all_Date($table,$whichFeild,$date);
     foreach($data as $feild){
       CommonModel::Remove_item($feild['id'],$table);
     }
     echo json_encode(array('status' => true, 'html' => $data,));
  }
   public function Setting() {
    if (!isSuperAdmin()) {
      header("Location:/");
      return;
    }
    $data = array();
    $data['pageTitle'] = "Panel ADMIN";
    View::renderCPanelSuperAdmin("/superadmin/setting/setting.php",$data);
  }
   public function CPanel_superAdmin() {
    if (!isSuperAdmin()) {
      header("Location:/");
      return;
    }
    $data = array();
    $data['pageTitle'] = "Panel Super ADMIN";
    View::renderCPanelSuperAdmin("/superadmin/home.php",$data);
  }
   public function CPanel_Admin() {
    if (!isAdmin()) {
      header("Location:/");
      return;
    }
    $data = array();
    $data['pageTitle'] = "Panel ADMIN";
    View::renderCPanelAdmins("/admins/home.php",$data);
  }
  public function promote_user_form(){
    View::render("/superadmin/user-promote-form.php");
  }
// USER VIP ****************************************************************************************************************************
  public function all_user_vip($pageIndex) {
    if (!isSuperAdmin()) {
      header("Location:/");
      return;
    }
    $data['pageIndex']=$pageIndex;
    View::renderCPanelSuperAdmin("/superadmin/user_vip/all_user_vip.php", $data);
  }
  public function Refresh_all_user_vip($pageIndex) {
    $NameTable = 'users';
    if (isset($_POST['SearchFiled'])) {
      $SearchFiled = $_POST['SearchFiled'];
    } else {
      $SearchFiled = "email";
    }
    if (isset($_POST['keyword'])) {
      $keyword = $_POST['keyword'];
    } else {
      $keyword = "";
    }
    $SortType="member_date";

    $data=$this->ListUsers($NameTable, $pageIndex,$SearchFiled, $keyword,$SortType);
    ob_start();
    View::renderPartial("/superadmin/user_vip/all_user_vip_ajax.php", $data);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }
  private function ListUsers($NameTable,$pageIndex,$SearchFiled,$keyword,$SortType)
  {
    $count=10;
    $startIndex=($pageIndex-1)* $count;
    $data['list']=UserModel::ListUsers($NameTable,$startIndex,$count,$SearchFiled,$keyword,$SortType);
    $recordcount=CommonModel::CatalogConutPage($NameTable);
    $data['pageCount']=ceil($recordcount/10);
    $data['pageIndex']=$pageIndex;
    return $data;
  }
  public function detail_user_vip($id) {
    if (isset($_POST['pageIndex'])) {
      $pageIndex = $_POST['pageIndex'];
    } else {
      $pageIndex = 1;
    }
    $result = CommonModel::Detail_Record('users',$id);
    ob_start();
    $record['pageIndex'] = $pageIndex;
    $record['user_id'] = $result['id'];
    View::renderPartial("/superadmin/user_vip/detail_user_vip.php", $record);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }
  public function info_person_vip($id) {
    $result = UserModel::view_user($id);
    $record = $result[0];
    ob_start();
    View::renderPartial("/superadmin/user_vip/info_person_vip.php", $record);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }

//END  USER VIP ****************************************************************************************************************************
  public function info_all_clip($pageIndex) {
    $NameTable = 'clips';
    $content=$_POST['user_id'];
    if (isset($_POST['SearchFiled'])) {
      $SearchFiled = $_POST['SearchFiled'];
    } else {
      $SearchFiled = "name_fa";
    }
    if (isset($_POST['keyword'])) {
      $keyword = $_POST['keyword'];
    } else {
      $keyword = "";
    }
    $SortType = "id DESC";
    $count=10;
    $groupby='';
    $data = ListAjaxPartial($NameTable, $pageIndex,'user_id',$content,$SearchFiled,$keyword,$SortType,$count, $groupby);
    ob_start();
    View::renderPartial("/superadmin/clips/all_clip.php", $data);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }
// USER ADMIN ****************************************************************************************************************************
  public function all_user_admin($pageIndex) {
    if (!isSuperAdmin()) {
      header("Location:/");
      return;
    }
    $NameTable = 'users';
    $keyword = "";
    $SearchFiled = "user_name";
    $SortType="user_name";
    $data =$this->ListAdmin($NameTable, $pageIndex,$SearchFiled,$keyword,$SortType);
    View::renderCPanelSuperAdmin("/superadmin/user_admin/all_user_admin.php", $data);
  }
  public function Refresh_all_user_admin($pageIndex) {
    $NameTable = 'users';
    if (isset($_POST['SearchFiled'])) {
      $SearchFiled = $_POST['SearchFiled'];
    } else {
      $SearchFiled = "email";
    }
    if (isset($_POST['keyword'])) {
      $keyword = $_POST['keyword'];
    } else {
      $keyword = "";
    }
    $SortType="email";
    $data =$this->ListAdmin($NameTable, $pageIndex,$SearchFiled, $keyword,$SortType);
    ob_start();
    View::renderPartial("/superadmin/user_admin/all_user_admin_ajax.php", $data);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));
  }
   private function ListAdmin($NameTable,$pageIndex,$SearchFiled,$keyword,$SortType)
  {
    $count=10;
    $startIndex=($pageIndex-1)* $count;
    $data['list']=AdminUsersModel::ListAdmin($NameTable,$startIndex,$count,$SearchFiled,$keyword,$SortType);
    $recordcount=CommonModel::CatalogConutPage($NameTable);
    $data['pageCount']=ceil($recordcount/10);
    $data['pageIndex']=$pageIndex;
    return $data;
  }
  public function detail_user_admin($id) {
    if (isset($_POST['pageIndex'])) {
      $pageIndex = $_POST['pageIndex'];
    } else {
      $pageIndex = 1;
    }
    $result = AdminUsersModel::view_user($id);
    $record = $result[0];
    ob_start();
    $record['pageIndex'] = $pageIndex;
    View::renderPartial("/superadmin/detail_user_admin.php", $record);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }
// END USER ADMIN ****************************************************************************************************************************
  public function Remove($Id) {
    ob_start();
    AdminUsersModel::delete_user($Id);
    ob_get_clean();
    if (isset($_POST['pageIndex'])) {
      $pageIndex = $_POST['pageIndex'];
    } else {
      $pageIndex = 1;
    }
    $this->RefreshData($pageIndex);
  }
  public function remove_users($Id) {
    ob_start();
    /*CommonModel::Remove_items('users','id',$Id);
    CommonModel::Remove_items('article_history','user_id',$Id);
    CommonModel::Remove_items('comments','user_id',$Id);
    CommonModel::Remove_items('contact_us','user_id',$Id);
    CommonModel::Remove_items('education_history','user_id',$Id);
    CommonModel::Remove_items('info_person','user_id',$Id);*/
    ob_get_clean();
    if (isset($_POST['pageIndex'])) {
      $pageIndex = $_POST['pageIndex'];
    } else {
      $pageIndex = 1;
    }
    $this->RefreshData($pageIndex);
  }
  public function promote(){
    $userId=$_POST["user_ID"];
    $access=$_POST["access"];
     /* $AccessArray=explode(",",$access);
    $NewAccess=implode("|",$AccessArray);*/

    $access=str_replace(" ","",$access);
    $access="|".str_replace(",","|",$access)."|";
    UserModel::promote_user($userId,$access);
    header("Location:".baseUrl()."/user/welcome");

  }

  public function getUserAccess($userId){

    $output['access']= UserModel::get_user_access($userId);
    echo  json_encode($output);
  }
  public function InsertSuperAdminToSql() {

    ob_start();
    CategoryModel::insert("","","","","");
    ob_get_clean();
    if (isset($_POST['pageIndex'])) {
      $pageIndex = $_POST['pageIndex'];
    } else {
      $pageIndex = 1;
    }
    $this->RefreshData($pageIndex);
  }




  // ***    SEND message ************************************************************************************************
  public function Send_message() {

    $sender_message_id=$_POST['sender_message_id'];
    $receiver_message_id=$_POST['receiver_message_id'];
    $body=$_POST['body'];
    UserModel::Save_Send_message($sender_message_id,$receiver_message_id,$body,getCurrentDateTime(),0);
    UserModel::Save_Receive_message($receiver_message_id,$sender_message_id,$body,getCurrentDateTime(),0);
    ob_start();
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));
  }
  public function all_message_superadmin($id,$pageIndex) {
    if (isVip()||isSuperAdmin()) {
      $data['pageIndex']=$pageIndex;
      $data['id']=$id;
      View::renderCPanelSuperAdmin("/superadmin/message/all_message.php", $data);
    }else{
      header("Location:/");
      return;

    }

  }
  public function all_message_superadmin_ajax($pageIndex) {
    $NameTable = 'message';
    $user_id = $_POST['user_id'];
    if (isset($_POST['SearchFiled'])) {
      $SearchFiled = $_POST['SearchFiled'];
    } else {
      $SearchFiled = "id";
    }
    if (isset($_POST['keyword'])) {
      $keyword = $_POST['keyword'];
    } else {
      $keyword = "";
    }
    $SortType = "id DESC";
    $count=10;
    $groupby='ticket_id';
    $data = ListAjaxPartial($NameTable, $pageIndex,'sender_user_id',$user_id,$SearchFiled,$keyword,$SortType, $count,$groupby);
    ob_start();
    View::renderPartial("/superadmin/message/all_message_ajax.php", $data);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }
  public function all_receiver_message_ajax($pageIndex) {
    $NameTable = 'receive_message';

    if (isset($_POST['SearchFiled'])) {
      $SearchFiled = $_POST['SearchFiled'];
    } else {
      $SearchFiled = "id";
    }
    if (isset($_POST['keyword'])) {
      $keyword = $_POST['keyword'];
    } else {
      $keyword = "";
    }
    $SortType = "id DESC";
    $count=10;
    $data = ListAjaxPartial($NameTable, $pageIndex,'receiver_message_id',$_SESSION['user_id'],$SearchFiled,$keyword,$SortType, $count);
    ob_start();
    View::renderPartial("/superadmin/message/all_message_receiver_ajax.php", $data);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }
  public function all_sender_message($pageIndex) {
    if (isVip()||isSuperAdmin()) {
      $NameTable = 'send_message';
      $keyword = "";
      $SearchFiled = "id";
      $SortType = "id DESC";
      $count=10;
      $data = ListAjaxPartial($NameTable, $pageIndex,'sender_message_id',$_SESSION['user_id'],$SearchFiled,$keyword,$SortType,$count);
      View::renderCPanelSuperAdmin("/superadmin/message/all_message_sender.php", $data);
    }else{
      header("Location:/");
      return;

    }

  }
  public function all_sender_message_ajax($pageIndex) {
    $NameTable = 'send_message';

    if (isset($_POST['SearchFiled'])) {
      $SearchFiled = $_POST['SearchFiled'];
    } else {
      $SearchFiled = "id";
    }
    if (isset($_POST['keyword'])) {
      $keyword = $_POST['keyword'];
    } else {
      $keyword = "";
    }
    $SortType = "id DESC";
    $count=10;
    $data = ListAjaxPartial($NameTable, $pageIndex,'sender_message_id',$_SESSION['user_id'],$SearchFiled,$keyword,$SortType, $count);
    ob_start();
    View::renderPartial("/superadmin/message/all_message_sender_ajax.php", $data);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }

  public function view_receiver($id) {
    if (isset($_POST['pageIndex'])) {
      $pageIndex = $_POST['pageIndex'];
    } else {
      $pageIndex = 1;
    }
    $receiver_message_id = $_POST['receiver_message_id'];
    $record = CommonModel::Fetch_by_every('receive_message','id',$id);
    ob_start();
    $record['pageIndex'] = $pageIndex;
    $record['receiver_message_id'] = $receiver_message_id;
    View::renderPartial("/superadmin/message/message_replay.php", $record);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }
  public function remove_sender_message($id){
    $pageIndex = $_POST['pageIndex'];
    ob_start();
    CommonModel::Remove_item($id,'send_message');
    $output = ob_get_clean();
    $this-> all_sender_message_ajax($pageIndex);
  }
  public function remove_Receiver_message($id){
    $pageIndex = $_POST['pageIndex'];
    ob_start();
    CommonModel::Remove_item($id,'receive_message');
    $output = ob_get_clean();
    $this-> all_receiver_message_ajax($pageIndex);
  }

// ***  END  SEND message ************************************************************************************************

}