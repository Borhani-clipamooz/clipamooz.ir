<footer>
  <div class="footer-landing">
    <div class="container">
      <div class="social">
        <div class="row">
          <div class="colx-2 colm-fill cols-fill tac">
            <img src="https://trustseal.enamad.ir/logo.aspx?id=74578&amp;p=F3y64zfnr8xbgji6" alt="" onclick="window.open(&quot;https://trustseal.enamad.ir/Verify.aspx?id=74578&amp;p=F3y64zfnr8xbgji6&quot;, &quot;Popup&quot;,&quot;toolbar=no, location=no, statusbar=no, menubar=no, scrollbars=1, resizable=0, width=580, height=600, top=30&quot;)" style="cursor:pointer" id="F3y64zfnr8xbgji6">
          </div>
          <div class="colx-2 colm-fill cols-fill tac">
            <img id='jxlzesgtnbqewlaoesgtwlaofukz' style='cursor:pointer' onclick='window.open("https://logo.samandehi.ir/Verify.aspx?id=1024046&p=rfthobpduiwkaodsobpdaodsgvka", "Popup","toolbar=no, scrollbars=no, location=no, statusbar=no, menubar=no, resizable=0, width=450, height=630, top=30")' alt='logo-samandehi' src='https://logo.samandehi.ir/logo.aspx?id=1024046&p=nbpdlymaodrfshwllymashwlwlbq'/>
          </div>
          <div class="colx-7 colm-fill cols-fill tac  lf">
            مسئولیت محتوای ویدئوها و هرگونه پاسخگویی به ادعاهای مطروحه توسط اشخاص حقیقی و حقوقی با منتشر کننده است و کلیپ آموز هیچگونه مسئولیتی نسبت به آن ندارد.
          </div>
          <div class="colx-1 colm-fill cols-fill tac">
            <div class="row tac">
              <div class="colx-3 tac facebook">
                <a href="https://sapp.ir/clipamooz.ir" class="top"><span class="tooltip">سروش</span><img src="/asset/images/sorosh.png" alt="تصویر سروش" class="image-icon"></a>
              </div>
              <div class="colx-3 tac google-plus">
                <a href="https://plus.google.com/116033109133340159908" class="top" target="_blank"><span class="tooltip">google-plus</span><i class="icon-google-plus"></i></a>
              </div>
              <div class="colx-3 tac twitter">
           <a href="https://telegram.me/clipamoozir" class="top" target="_blank"><span class="tooltip">telegram</span><i class="icon-telegram"></i></a>
              </div>
              <div class="colx-3 tac instagram">
                <a href="https://www.instagram.com/clipamooz.page/" class="top" target="_blank"><span class="tooltip">instagram</span><i class="icon-instagram"></i></a>
              </div>
            </div>

          </div>
        </div>

      </div>
      <!--      <p>طراحی توسط کلیپ آموز</p>-->
    </div>
  </div>
</footer>
<!--<a href="http://sapp.ir/clipamooz.ir"><img src="/asset/images/sorosh.png" width="150px"height="150px"></a>-->
