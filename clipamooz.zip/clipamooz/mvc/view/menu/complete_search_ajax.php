  <ul class="clip-items" >
    <?
    foreach ($list as $feild) {
      ?>
      <li class="clip-items" >
        <div class="box_items_complete_search">
          <div class="row">
            <div class="box-image">
              <?
              if($feild['img_link']!=''){?>
                <? global $config;?>
                <a href="/g/<?=$feild['clip_api_key']?>"  title="<?= $feild['name_fa']?>" title="<?= $feild['name_fa']?>"><img  src="<?=$config['upload'].$feild['img_link']?>" alt="" /></a>
              <? } else{ ?>
                <a href="/g/<?=$feild['clip_api_key']?>"  title="<?= $feild['name_fa']?>"><img  src="/asset/images/empty/empty-play/play.png" alt="" /></a>
              <?}?>
            </div>
          </div>
          <div class="row box-one">
            <div class="colx-4 tar">
              <?
              if($x>=3600){
                echo gmdate("H:i:s", $feild['clip_long_time']);
              }else{
                echo gmdate("i:s", $feild['clip_long_time']);
              }
              ?>
              </i>
              <span class="icon-clock"></span>
            </div>
            <div class="colx-4 tac">
                <span class=" icon-eye" aria-hidden="true"><span style="font-family: traffic">&nbsp;<?
                    $number =  number_format( $feild['opens']);
                    echo $number;?></span>
                </span>
            </div>
            <div class="colx-4 tal">
              <span class="icon-play" aria-hidden="true"><span style="font-family: traffic">&nbsp;<?= $feild['views']?></span></span>
            </div>
          </div>
          <div class="row tac box-two">
            <span class="tac"><?= $feild['name_fa']?></span>
          </div>
          <div class="row box-three">
            <div class="colx-2">
              <?
              $data=CommonModel::Fetch_by_every('users','id',$feild['user_id']);
              if($data['profile_pic'] !=''){?>
                <img style="width: 30px;height: 30px;border-radius: 2px" src="<?=$config['upload'].$data['profile_pic']?>">
              <?}else{?>
                <img style="width: 30px;height: 30px;border-radius: 2px" src="/asset/images/empty/empty-profile/empty-profile-24.png">
              <?}?>
            </div>
            <div class="colx-10">
              <div class="row">
                <?
                $data2=CommonModel::Fetch_by_every('category','id',$feild['category']);
                $name_category="";
                $name_category=$data2['name_fa'];
                $data3=CommonModel::Fetch_by_every('subcategories','id',$feild['subcategory']);
                $name_sub_category="";
                $name_sub_category=$data3['subcategory_name'];
                ?>
                <h2><span style="color:#3f250e"><?= $name_category?>:<?= $name_sub_category?></span></h2>
              </div>
              <div class="row">
                <h3><?=$data['user_name']?></h3>
              </div>
              <div class="row">
                <div class="rating">
                  <?
                  if (strpos($feild['rating'], '.5') !== false) {
                    $R_rating=$feild['rating'];
                  }else{
                    $R_rating=round($feild['rating']);
                  }
                  ?>
                  <?=rating($R_rating,'20px','20px');?>
                </div>
              </div>
            </div>
          </div>
        </div>
      </li>
    <?}?>
  </ul>

