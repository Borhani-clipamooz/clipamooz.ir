<script>

  $(function () {
    Fun_URL.clear();
    Fun_URL.getURL('/category/Fun_UploadImagePathInSql/');
    $("input").each(function () {
      $(this).on('change', function () {
        var id=$("#id").val();
        var name_fa=$("#name_fa").val();
        var name_en=$("#name_en").val();
        var description_fa=$("#description_fa").val();
        var description_en=$("#description_en").val();
        $.ajax({
          url:'/category/update',
          type: 'POST',
          dataType:'json',
          data:{
            id:id,
            name_fa:name_fa,
            name_en:name_en,
            description_fa:description_fa,
            description_en:description_en
          },
          success:function(data){
            //console.log(data);
          }
        });


      });






    });
    $("textarea").each(function () {
      $(this).on('change', function () {
        var id=$("#id").val();
        var name_fa=$("#name_fa").val();
        var name_en=$("#name_en").val();
        var description_fa=$("#description_fa").val();
        var description_en=$("#description_en").val();
        $.ajax({
          url:'/category/update',
          type: 'POST',
          dataType:'json',
          data:{
            id:id,
            name_fa:name_fa,
            name_en:name_en,
            description_fa:description_fa,
            description_en:description_en

          },
          success:function(data){
            //console.log(data);
          }
        });


      });


    });



  });

 /* function  Fun_UploadImagePathInSql(){
    var id=$("#id").val();
    var UploadImagePath=$("#UploadImagePath").text();
    $.ajax({
      url:'/category/Fun_UploadImagePathInSql',
      type: 'POST',
      dataType:'json',
      data:{
        id:id,
        UploadImagePath:UploadImagePath

      },
      success:function(data){
        console.log(data);
      }
    });
  }*/
</script>
<div class=" content">

<table>
    <colgroup>
        <col style="width: 100px">
        <col style="width: 550px">
    </colgroup>
     <tr>
       <input type="hidden"id="id" value="<?=$id?>">
        <td class="comlmn">نام فارسی</td>
       <td><input  type="text"  id="name_fa"  name="name_fa" value="<?= $name_fa ?>"></td>
    </tr>
    <tr>
        <td class="comlmn">نام انگلیسی</td>
       <td><input class="tal" type="text"  id="name_en"  name="name_fa" value="<?= $name_en ?>"></td>
    </tr>
    <tr>
        <td class="comlmn">توضیحات فارسی</td>
      <td> <textarea id="description_fa" name="description_fa" style="height: 150px;width: 500px"><?= $description_fa ?></textarea></td>
    </tr>
    <tr>
        <td class="comlmn">توضیحات انگلیسی</td>
      <td> <textarea class="tal" id="description_en" name="description_fa" style="height: 150px;width: 500px"><?= $description_en ?></textarea></td>

    </tr>

    <tr>
        <td class="comlmn">عکس </td>

     <td>

       <? if (CommonModel::SearchFile($image)) {?>

         <img  src="<?= $image ?>" alt="محل قرار گرفتن تصویر"style=" padding-top:5px;width: 150px;height: 150px"><br>
         <span style="color: #a2120a" id="messageiImage"></span>
         <button class="btn_style btn-brown" onclick="Remove_data('<?= $image ?>',0,'<?=$id?>','category','image','')"><?=_btn_delete?></button>
       <?}else{?>
         <script>ShowUploaderImage('<?=$id?>','category','image');</script>
         <div id="ShowUploaderImage"></div>
      <? }?>
     </td>
    </tr>

</table>

  <button class="btn_style btn-brown" onclick="back(<?= $pageIndex ?>)">برگشت و ذخیره</button>
</div>
<script>
  function back(pageIndex){
    getPage(pageIndex);
  }
</script>
