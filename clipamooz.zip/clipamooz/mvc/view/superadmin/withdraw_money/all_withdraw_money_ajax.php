<div class="content">
<div class="all_deposits">
<div class="row">
  <div class="colx-1 colm-fill cols-fill"><h2>جزئیات</h2></div>
  <div class="colx-1 colm-fill cols-fill"><h2>کاربر</h2></div>
  <div class="colx-2 colm-fill cols-fill"><h2>مبلغ</h2></div>
  <div class="colx-3 colm-fill cols-fill"><h2>تاریخ درخواست</h2></div>
  <div class="colx-7 colm-fill cols-fill"><h2>توضیحات</h2></div>
</div>
    <? foreach ($list as $feild) {?>
<div class="row">
  <div class="colx-1"><h3> <span onclick="replay_view(<?= $feild['id']?>,<?=$pageIndex?>)"><i class="icon-eye large"></i></span></h3></div>
  <? global $config;?>
  <?$data2=CommonModel::Fetch_by_every('users','id',$feild['user_id']);?>
  <div class="colx-1"><h3>
      <?  if($data2['profile_pic'] !=''){?>
        <a  href="/profile/<?=$data2['id']?>" style="color: #f88;font-size: 14pt"><img style="width: 40px;height: 40px;border-radius: 50px" src="<?=$config['upload'].$data2['profile_pic']?>"></a>
      <?}else{?>
        <a  href="/profile/<?=$data2['id']?>" style="color: #f88;font-size: 14pt"><img style="width: 40px;height: 40px;border-radius: 50px" src="/asset/images/empty/empty-profile/empty-profile-24.png"></a>
      <?}?>
    </h3></div>
  <div class="colx-2 colm-fill cols-fill"><h3><?= $feild['amount'] ?></h3></div>
  <div class="colx-3 colm-fill cols-fill"><h3><?=DateTimeCommon( $feild['create_at']) ?></h3></div>
  <div class="colx-7 colm-fill cols-fill"><h3><?= $feild['discription'] ?></h3></div>
</div>
  <? } ?>
</div>
  <br>
  <!--Buttons Filter-->
  <div class="pagination_comment" >
    <?=pagination('',3,'btn_style btn-brown','btn',$pageIndex,$pageCount,'all_withdraw_money')?>
  </div>
  <br>
  <div class="pagination_comment_responsive tac" >
    <?=pagination_responsive('',3,'btn_style btn-brown','btn',$pageIndex,$pageCount,'all_withdraw_money')?>
  </div>

</div>
<script>
  function replay_view(id,PageIndex) {
    $.ajax({
      url: '/payment/superAdmin_replay_view/',
      type: 'POST',
      dataType: 'json',
      data:{
        id:id,
        pageIndex:PageIndex
      },
      success: function (data) {
        $("#paginationUpdate").html(data.html);
      }
    });
  }
</script>


