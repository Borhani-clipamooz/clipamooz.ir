<?php


class SupportController {
  public function __construct() {

  }
  public function support_home() {
Unsuccessful_login();
    View::render("/support/support_home.php", array());
  }
  //****superAdmin*******************************
  public function support_all_ticket_superadmin($id,$pageIndex) {
    $data['id']=$id;
    $data['pageIndex']=$pageIndex;
    View::renderCPanelSuperAdmin("/support/all_support_ticket_superadmin.php", $data);
  }
  public function RefreshData_support_ticket_superadmin($pageIndex) {
    $NameTable = 'support';
    $user_id=$_POST['user_id'];
    if (isset($_POST['SearchFiled'])) {
      $SearchFiled = $_POST['SearchFiled'];
    } else {
      $SearchFiled = "subject";
    }
    if (isset($_POST['keyword'])) {
      $keyword = $_POST['keyword'];
    } else {
      $keyword = "";
    }
    $SortType = "id DESC";
    $count=10;
    $groupby='ticket_id';
    $data = ListAjaxPartial($NameTable, $pageIndex,'sender_user_id',$user_id,$SearchFiled,$keyword,$SortType, $count,$groupby);
    ob_start();
    View::renderPartial("/support/all_support_ticket_superadmin_ajax.php", $data);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }
  //****END superAdmin*******************************
  public function support_all_ticket($id,$pageIndex) {
    Unsuccessful_login();

    $data['pageIndex']=$pageIndex;
    $data['id']=$id;
    View::renderCPanelUser("/support/all_support_ticket.php", $data);
  }
  public function RefreshData_support_ticket($pageIndex) {

    $NameTable = 'support';
    $user_id=$_POST['user_id'];
    if (isset($_POST['SearchFiled'])) {
      $SearchFiled = $_POST['SearchFiled'];
    } else {
      $SearchFiled = "subject";
    }
    if (isset($_POST['keyword'])) {
      $keyword = $_POST['keyword'];
    } else {
      $keyword = "";
    }
    $SortType = "id DESC";
    $count=10;
    $groupby='ticket_id';
    $data = ListAjaxPartial($NameTable, $pageIndex,'sender_user_id',$user_id,$SearchFiled,$keyword,$SortType,$count,$groupby);
    ob_start();
    View::renderPartial("/support/all_support_ticket_ajax.php", $data);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }

  public function support_user_detail($ticket_id) {
    if (isset($_POST['pageIndex'])) {
      $pageIndex = $_POST['pageIndex'];
    } else {
      $pageIndex = 1;
    }
    $sender_user_id = $_POST['sender_user_id'];
    $record['list'] = CommonModel::Fetch_by_two_all('support','ticket_id',$ticket_id,'sender_user_id',$sender_user_id,'order by id DESC');
    $record2 = CommonModel::Fetch_by_two_all('support','ticket_id',$ticket_id,'sender_user_id',$sender_user_id,'order by id DESC');
    foreach($record2 as $feild){
      CommonModel::update_spacial_field($feild['id'],'support','status',0);
    }
    $record['subject']=$_POST['subject'];
    $record['ticket_id']=$ticket_id;
    $record['target_user_id']= $_POST['target_user_id'];
    ob_start();
    $record['pageIndex'] = $pageIndex;
    View::renderPartial("/support/detail_support_user.php", $record);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }
  public function detail_support_superadmin($ticket_id) {
    if (isset($_POST['pageIndex'])) {
      $pageIndex = $_POST['pageIndex'];
    } else {
      $pageIndex = 1;
    }
   $sender_user_id = $_POST['sender_user_id'];
    $record['list'] = CommonModel::Fetch_by_two_all('support','ticket_id',$ticket_id,'sender_user_id',$sender_user_id,'order by id DESC');
    $record2 = CommonModel::Fetch_by_two_all('support','ticket_id',$ticket_id,'sender_user_id',$sender_user_id,'order by id DESC');
    foreach($record2 as $feild){
      CommonModel::update_spacial_field($feild['id'],'support','status',0);
    }
    $record['subject']=$_POST['subject'];
    $record['ticket_id']=$ticket_id;
    $record['target_user_id']=$_POST['target_user_id'];
    ob_start();
    $record['pageIndex'] = $pageIndex;
    View::renderPartial("/support/detail_support_superadmin.php", $record);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }
  public function Remove_sql_data($ticket_id) {
    ob_start();
   CommonModel::Remove_items('support','ticket_id',$ticket_id);
    ob_get_clean();
    if (isset($_POST['pageIndex'])) {
      $pageIndex = $_POST['pageIndex'];
    } else {
      $pageIndex = 1;
    }
    $this->RefreshData_support_ticket($pageIndex);
  }

  public function Replay_user() {
    $sender_user_id = $_POST['user_id'];
    $target_user_id = $_POST['target_user_id'];
    $ticket_id = $_POST['ticket_id'];
    $subject = $_POST['subject'];
    $body = $_POST['body'];
    ob_start();
    SupportModel::Save_Send_message_first($ticket_id,$sender_user_id,$target_user_id,$subject,$body,getCurrentDateTime(),0);
    SupportModel::Save_Send_message_first($ticket_id,$target_user_id,$sender_user_id,$subject,$body,getCurrentDateTime(),1);

    /*$data2=CommonModel::Fetch_by_every('users','id',$data['user_id']);
    $email=$data2['email'];
    ob_start();
    global $config;
    $link=$config['base']."/support_all_ticket/1";
    $MsgHTML="<a href=$link>'جهت دیدن پاسخ پیامتون کلیک نمایید'</a>";
    $subject='پاسخ به پیام شما کاربر عزیز';
    $message='کاربر عزیز از اینکه ابهام خود را بیان نمودید تشکر میکنیم . در صورت برطرف نشدن ابهام ادامه به ارسال پیام فرمایید.';
    send_message_email($email,$MsgHTML,$subject,$message);*/
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));
  }
  public function Replay_Superadmin() {
    $sender_user_id = $_POST['user_id'];
    $target_user_id = $_POST['target_user_id'];
    $ticket_id = $_POST['ticket_id'];
    $subject = $_POST['subject'];
    $body = $_POST['body'];
    ob_start();
    SupportModel::Save_Send_message_first($ticket_id,$sender_user_id,$target_user_id,$subject,$body,getCurrentDateTime(),0);
    SupportModel::Save_Send_message_first($ticket_id,$target_user_id,$sender_user_id,$subject,$body,getCurrentDateTime(),1);

    /*$data2=CommonModel::Fetch_by_every('users','id',$data['user_id']);
    $email=$data2['email'];
    ob_start();
    global $config;
    $link=$config['base']."/support_all_ticket/1";
    $MsgHTML="<a href=$link>'جهت دیدن پاسخ پیامتون کلیک نمایید'</a>";
    $subject='پاسخ به پیام شما کاربر عزیز';
    $message='کاربر عزیز از اینکه ابهام خود را بیان نمودید تشکر میکنیم . در صورت برطرف نشدن ابهام ادامه به ارسال پیام فرمایید.';
    send_message_email($email,$MsgHTML,$subject,$message);*/
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));
  }
  public function Send_Message_support_first() {
    $sender_user_id=$_POST['sender_message_id'];
   // $receiver_message_id=$_POST['receiver_message_id'];
    $target_user_id=53;
    $subject=$_POST['subject'];
    $body=$_POST['body'];
    $ticket_id=generateRandomString();
    if($sender_user_id !=null){
      ob_start();
      SupportModel::Save_Send_message_first($ticket_id,$sender_user_id,$target_user_id,$subject,$body,getCurrentDateTime(),0);
      SupportModel::Save_Send_message_first($ticket_id,$target_user_id,$sender_user_id,$subject,$body,getCurrentDateTime(),1);
      send_message_email('info@clipamooz.ir','','support_request','cheek your suppoet Home');
      $output = ob_get_clean();
      echo json_encode(array('status' => true, 'html' => $output, 'ticket_id' => $ticket_id));
    }else{
      echo json_encode(array('status' => false,));
    }

  }

}