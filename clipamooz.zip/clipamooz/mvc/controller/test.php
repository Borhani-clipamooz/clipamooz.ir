<?php
class TestController{

  public function test1(){

    for($i=0;$i<159;$i++){
      $title="moslem";
      $description="Borhani";
      TestModel::insert_test($title,$description);
    }

  }

  public function test2(){
    $result=TestModel::catalogByPage();
    $data['users']=$result;
    View::render("/page/test.php",$data);
     }

  public function testupload(){
    View::render("/fileuploadphp/index.php",array());
     }
  public function testuploadpersial(){
    View::render("/fileuploadphp/upload.php",array());
     }


  public function catalog($pageIndex)
   {
     $NameTable='test';
     $data= ListAjax($NameTable,$pageIndex);
     View::render("/page/test.php",$data);
    }
  public function ajaxCatalog($pageIndex)
   {
     $NameTable='test';
     $data= ListAjax($NameTable,$pageIndex);
      ob_start();
     View::renderPartial("/page/ajaxcatalog.php",$data);
     $output=ob_get_clean();

     echo json_encode(array(
       'status'=> true,
       'html'=> $output,
     ));
    }

}