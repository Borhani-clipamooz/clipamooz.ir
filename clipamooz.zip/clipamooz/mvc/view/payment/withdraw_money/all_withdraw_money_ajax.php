<div class="content">
<div class="all_deposits">
<div class="row">
  <div class="colx-2 colm-fill cols-fill"><h2>مبلغ</h2></div>
  <div class="colx-3 colm-fill cols-fill"><h2>تاریخ درخواست</h2></div>
  <div class="colx-7 colm-fill cols-fill"><h2>توضیحات</h2></div>
</div>
    <? foreach ($list as $feild) {?>
<div class="row">
  <div class="colx-2 colm-fill cols-fill"><h3><?= $feild['amount'] ?></h3></div>
  <div class="colx-3 colm-fill cols-fill"><h3><?=DateTimeCommon( $feild['create_at']) ?></h3></div>
  <div class="colx-7 colm-fill cols-fill"><h3><?= $feild['discription'] ?></h3></div>
</div>
  <? } ?>
</div>
  <br>
  <!--Buttons Filter-->
  <div class="pagination_comment" >
    <?=pagination('',3,'btn_style btn-brown','btn',$pageIndex,$pageCount,'all_withdraw_money')?>
  </div>
  <br>
  <div class="pagination_comment_responsive tac" >
    <?=pagination_responsive('',3,'btn_style btn-brown','btn',$pageIndex,$pageCount,'all_withdraw_money')?>
  </div>

</div>


