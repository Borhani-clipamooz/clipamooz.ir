<div class=" content">
  <div id="reasearch_pattern" class="titrbox "> <h1>&nbsp;&nbsp;سوابق طرح‌های پژوهشی و تحقيقاتی :<i id="icon_reasearch_pattern_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
  <div class="detail_reasearch_pattern_panel">
    <input type="hidden"id="id"value="<?=$id?>">
    <div class="row">
      <div class="colx-2">
        <h2 >عنوان طرح</h2>
      </div>
      <div class="colx-2">
        <h2>سمت</h2>
      </div>
      <div class="colx-2">
        <h2>کارفرما</h2>
      </div>
    </div>
    <div class="row">
      <div class="colx-2">
        <h3><input  type="text"  id="research_name"  value="<?=$research_name?>"></h3>
      </div>
      <div class="colx-2">
        <h3><input  type="text"  id="responsibility"  value="<?=$responsibility?>"></h3>
      </div>
      <div class="colx-2">
        <h3><input  type="text"  id="employer"  value="<?= $employer ?>"></h3>
      </div>
    </div>
  <div class="row">
    <div class="colx-2">
      <h2 >تاريخ شروع</h2>
    </div>
    <div class="colx-2">
      <h2 >تاریخ پايان</h2>
    </div>
    <div class="colx-2">
      <h2 >اعتبار طرح (ریال)</h2>
    </div>
  </div>
  <div class="row">
    <div class="colx-2">
      <h3><input  type="text"  id="start_date"   value="<?= $start_date?>"></h3>
    </div>
    <div class="colx-2">
      <h3><input  type="text"  id="finish_date"  value="<?= $finish_date?>"></h3>
    </div>
    <div class="colx-2">
      <h3><input  type="text"  id="schedule_validity"   value="<?= $schedule_validity?>"></h3>
    </div>
  </div>
</div>
  <div class="row tac">
    <button  class="btn_style btn-brown" onclick="back(<?= $pageIndex ?>)">بازگشت</button>
  </div>
</div>
<script>
$(function(){
  $("input").each(function () {
    $(this).on('keyup', function () {
      var id=$("#id").val();
      var research_name=$("#research_name").val();
      var responsibility=$("#responsibility").val();
      var employer=$("#employer").val();
      var start_date=$("#start_date").val();
      var finish_date=$("#finish_date").val();
      var schedule_validity=$("#schedule_validity").val();
      $.ajax({
        url:'/user/detail_research_pattern_update',
        type: 'POST',
        dataType:'json',
        data:{
          id:id,
          research_name:research_name,
          responsibility:responsibility,
          employer:employer,
          start_date:start_date,
          finish_date:finish_date,
          schedule_validity:schedule_validity
        },
        success:function(data){
          //console.log(data);
        }
      });


    });
  });
});
  function back(pageIndex){
    research_pattern(pageIndex);
  }
</script>















