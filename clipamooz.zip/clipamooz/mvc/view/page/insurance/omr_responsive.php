<div class="row">
  <section id="section-2">
    <div class="about-landing">
      <div class="container">
        <div class="about-text">
          <h2 style="color: #fffccc;">تعریف بیمه عمر و تامین آتیه : </h2>
          <p style="margin-top: 50px">
            دراین بیمه نامه بیمه گذاران با پرداخت مبلغی تحت عنوان حق بیمه علاوه برتامین منابع لازم برای تشکیل سرمایه ای در آتیه امکان برخورداری از پوشش بیمه عمر در مقابل خطر فوت را نیز درصورتی که بیمه شده هم باشند، خواهند داشت .
            بیمه های عمر همراه با تشکیل سرمایه که اکنون در بسیاری از کشورهای جهان ارائه می شود ،طرفداران زیادی داشته و با توجه به انواع آن می تواند مورداستقبال اقشار مختلف جامعه قرار گیرد .
            بیمه پاسارگاد با دریافت مبالغ حق بیمه ،اولا”بیمه شده را در مقابل خطر فوت بیمه می کند و ثانیا” مازاد مبالغ دریافتی را سرمایه گذاری می نماید و نرخ سود آن سرمایه گذاری را تا حد نرخ بهره فنی تضمین می نمایدو چنانچه سودبیشتری از محل سرمایه گذاری بدست آورد بخش عمده از آن را به عنوان مشارکت در منافع به بیمه گذار می دهد .
          </p>
        </div>
        <div class="thumb wow animated zoomIn"><img style="border-radius: 50%" src="/asset/images/insurance/Babyfuss-533x533.jpg" alt=""></div>
      </div>
    </div>
  </section>
  </div>
<div class="row">
  <section>
    <div class="container">
    <!--***********  INFO ---   Person   --   Responsive   ********************************************************************************-->
    <div class="info_person_responsive">
      <div id="panel1_responsive" class="titrbox"> <h1 style="color: yellow">&nbsp;&nbsp;شرایط ویژه بیمه عمر و تامین آتیه بیمه پاسارگاد<i id="icon_panel1_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="panel1_panel_responsive" style="display: none">
        <p style="font-size: 12pt;text-align: justify">
          بررسی وضعیت مالی اکثر صندوق های بازنشستگی نشان دهنده این واقعیت است که میزان پرداختی این نوع صندوق ها در دوران بازنشستگی ،حتی کفایت لازم برای یک زندگی متوسط را نیز ندارد .با توجه به اینکه عده کثیری از افراد جامعه بااین مشکل مواجه هستند طراحی بیمه نامه ای با تشکیل سرمایه در صورت حیات میتواند تامین کننده سرمایه ای یکجا در سنین بالا بوده و تاثیر مهمی درافزایش قدرت خرید افراد در دوران بازنشستگی خواهد داشت .
        </p>
      </div>    <!-- END panel1_responsive ******************-->
      <div id="panel2_responsive" class="titrbox "> <h1>&nbsp;&nbsp;یک<i id="icon_panel2_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="panel2_panel_responsive" style="display: none">
        <p style="font-size: 12pt;text-align: justify">
          در این بیمه نامه سرمایه بیمه عمر ضریبی از میزان قدرت پرداخت حق بیمه،بیمه گذار در ماه خواهد بود . این ضریب می تواند ۲۱۰،۱۸۰،۱۵۰،۱۲۰ ، ۲۴۰ ، ۲۷۰ ، ۳۰۰ ،۳۳۰ و ۳۶۰ برابرانتخاب گردد .
        </p>
      </div><!--  END panel2_responsive  ******************-->
      <div id="panel3_responsive" class="titrbox "> <h1>&nbsp;&nbsp;دو<i id="icon_panel3_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="panel3_panel_responsive" style="display: none">
        <p style="font-size: 12pt;text-align: justify">
          در نحوه پرداخت حق بیمه، پیش بینی شده است که بیمه گذار بتواند حق بیمه را به صورت تلفیقی از روش یکجا (به صورت سپرده گذاری نزد بیمه گر) و اقساطی پرداخت نماید.
        </p>
      </div><!--  END panel3_responsive ******************-->
      <div id="panel4_responsive" class="titrbox "> <h1>&nbsp;&nbsp;سه<i id="icon_panel4_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="panel4_panel_responsive" style="display: none">
        <p style="font-size: 12pt;text-align: justify">
          مدت بیمه نامه می تواند از ۵ سال تا ۳۰ سال درخواست گردد .
        </p>
      </div><!--  END panel3_responsive ******************-->
      <div id="panel5_responsive" class="titrbox "> <h1>&nbsp;&nbsp;چهار<i id="icon_panel5_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="panel5_panel_responsive" style="display: none">
        <p style="font-size: 12pt;text-align: justify">
          رای مقابله با تورم فرضی با درخواست بیمه گذار مبلغ حق بیمه می تواند به میزان  ۳ تا ۲۵ درصد در هر سال نسبت به سال قبل افزایش یابد.
        </p>
      </div><!--  END academic_responsive_responsive ******************-->
      <div id="panel6_responsive" class="titrbox "> <h1>&nbsp;&nbsp;پنج<i id="icon_panel6_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="panel6_panel_responsive" style="display: none">
        <p style="font-size: 12pt;text-align: justify">
          اندوخته حاصل شده از محل بیمه نامه متعلق به بیمه گذار است و در طول مدت بیمه نامه وی حق دارد این اندوخته را به طور کامل برداشت (بازخرید) و یا به صورت وام دریافت نماید.( پس از سپری شدن ۶ ماه از زمان صدور و پرداخت حداقل ۶ ماه حق بیمه )
        </p>
      </div><!--  END academic_responsive_responsive ******************-->
      <div id="panel7_responsive" class="titrbox "> <h1>&nbsp;&nbsp;شش<i id="icon_panel7_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="panel7_panel_responsive" style="display: none">
        <p style="font-size: 12pt;text-align: justify">
          اندوخته حاصل شده از محل بیمه نامه متعلق به بیمه گذار است و در طول مدت بیمه نامه وی حق دارد این اندوخته را به طور کامل برداشت (بازخرید) و یا به صورت وام دریافت نماید.( پس از سپری شدن ۶ ماه از زمان صدور و پرداخت حداقل ۶ ماه حق بیمه )
        </p>
      </div><!--  END  panel7 Panle Responsive ******************-->
      <div id="panel8_responsive" class="titrbox "> <h1>&nbsp;&nbsp;هفت<i id="icon_panel8_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="panel8_panel_responsive" style="display: none">
        <p style="font-size: 12pt;text-align: justify">
          چنانچه بیمه گذار درخواست افزایش پرداخت حق بیمه را در سالهای بعد نماید می تواند به میزان افزایش حق بیمه درخواستی (حداکثر ۱۰ درصد ) سرمایه بیمه عمر خود را افزایش دهد.لازم به ذکر است که می توان افزایش حق بیمه را درخواست کرد ولی سرمایه بیمه عمررا ثابت نگه داشت و افزایش سرمایه درخواست نگردد .
        </p>
      </div><!--  END SEND Message Responsive  ******************-->
      <div id="panel9_responsive" class="titrbox "> <h1>&nbsp;&nbsp;هشت<i id="icon_panel9_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="panel9_panel_responsive" style="display: none">
        <p style="font-size: 12pt;text-align: justify">
          حق بیمه این قرارداد می تواند به روش ماهانه ،سه ماهه ،شش ماهه و یا سالانه پرداخت گردد.
        </p>
      </div>
      <div id="panel10_responsive" class="titrbox "> <h1>&nbsp;&nbsp; پوشش های تکمیلی بیمه نامه عمر و تامین آتیه :<i id="icon_panel10_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="panel10_panel_responsive" style="display: none">
        <p style="font-size: 12pt;color: #fffccc;text-align: right">
            <span>
              <strong>فوت در اثر حادثه</strong>
            </span>
        </p>
        <p style="font-size: 12pt;text-align: justify">
          چنانچه بیمه شده طی مدت بیمه­ نامه به­ علت حادثه فوت نماید معادل ۲،۳ و یا ۴ برابر سرمایه بیمه عمر، به استفاده کنندگان از قرارداد پرداخت می شود.
        </p>
        <p style="font-size: 12pt;color: #fffccc;text-align: right">
            <span>
              <strong>نقص عضو و از کارافتادگی در اثر حادثه</strong>
            </span>
        </p>
        <p style="font-size: 12pt;text-align: justify">
          در صورتی که بیمه شده در زمان اعتبار بیمه­ نامه به علت حادثه دچار نقص عضو یا ازکارافتادگی دائم و قطعی شود بیمه­ گر متعهد است غرامت مربوط را براساس جداول نقص عضو بیمه حوادث شخصی و سرمایه بیمه ازکارافتادگی به میزان ۲،۱و ۳ برابر سرمایه عمر پرداخت نماید.
        </p>
        <p style="font-size: 12pt;color: #fffccc;text-align: right">
            <span>
              <strong>هزینه پزشکی در اثر حادثه</strong>
            </span>
        </p>
        <p style="font-size: 12pt;text-align: justify">
          در این پوشش صورتحساب درمانی که در اثر حادثه هزینه شده باشد تا سقف تعهدات مندرج در بیمه ­نامه به میزان ۱۰،۵ درصد سرمایه فوت در اثر حادثه در هر سال بیمه ­ای قابل پرداخت است.
        </p>
        <p style="font-size: 12pt;color: #fffccc;text-align: right">
            <span>
              <strong>معافیت از پرداخت حق بیمه</strong>
            </span>
        </p>
        <p style="font-size: 12pt;text-align: justify">
          با دریافت این پوشش چنانچه بیمه شده به علت بیماری یا حادثه از کارافتاده کلی و دائم گردد و قادر به انجام هیچ­گونه فعالیتی نباشد بیمه­ گر از دریافت حق بیمه صرف نظر نموده و بیمه نامه را به اعتبار خود باقی نگه می­ دارد.میزان معافیت از پرداخت حق بیمه ۵۰ یا ۱۰۰ درصد می باشد.
        </p>
        <p style="font-size: 12pt;color: #fffccc;text-align: right">
            <span>
              <strong>پرداخت سرمایه از کارافتادگی دائم و کلی</strong>
            </span>
        </p>
        <p style="font-size: 12pt;text-align: justify">
          بیمه شده درصورت ازکارافتادگی کلی و دائم به هرعلت، علاوه بر معافیت از پرداخت حق بیمه فوق غرامتی معادل سرمایه مندرج در قرارداد حداکثر تا سقف ۶۰۰,۰۰۰,۰۰۰ ریال از بیمه پاسارگاد دریافت می­ نماید.
        </p>
        <p style="font-size: 12pt;color: #fffccc;text-align: right">
            <span>
              <strong>بیماری های خاص</strong>
            </span>
        </p>
        <p style="font-size: 12pt;text-align: justify">
          درصورتی که بیمه شده در طول مدت بیمه نامه به هر یک از بیماری­های سرطانCancer))، سکته قلبی (Myocardial Infarction) ، سکته مغزی (Stroke)، جراحی عروق قلب ( Surgery Coronary Artery)  و پیوند اعضای بدن (Main- Organ-Graft) برطبق تشخیص پزشک معتمد شرکت مبتلا گردد، بیمه پاسارگاد معادل سرمایه بیمه تحت پوشش و حداکثر تا مبلغ ۴۰۰,۰۰۰,۰۰۰ ریال به ازای هر یک از بیماریها به بیمه شده پرداخت می­نماید.
        </p>
        <p style="font-size: 12pt;color: #fffccc;text-align: right">
            <span>
              <strong>بیماری های خاص</strong>
            </span>
        </p>
        <p style="font-size: 12pt;text-align: justify">
          درصورتی که بیمه شده در طول مدت بیمه نامه به هر یک از بیماری­های سرطانCancer))، سکته قلبی (Myocardial Infarction) ، سکته مغزی (Stroke)، جراحی عروق قلب ( Surgery Coronary Artery)  و پیوند اعضای بدن (Main- Organ-Graft) برطبق تشخیص پزشک معتمد شرکت مبتلا گردد، بیمه پاسارگاد معادل سرمایه بیمه تحت پوشش و حداکثر تا مبلغ ۴۰۰,۰۰۰,۰۰۰ ریال به ازای هر یک از بیماریها به بیمه شده پرداخت می­نماید.
        </p>
        <p style="font-size: 12pt;color: #fffccc;text-align: right">
            <span>
              <strong>بیمه آتش­ سوزی منزل مسکونی</strong>
            </span>
        </p>
        <p style="font-size: 12pt;text-align: justify">
          بیمه­ شده می­ تواند به همراه این بیمه­ نامه پوشش بیمه آتش­ سوزی برای منزل مسکونی خود تهیه نماید. بیمه­ گذار/ بیمه­ شده می­ تواند مالک ساختمان مورد بیمه بوده و یا ملک موردنظر به صورت استیجاری در اختیار وی باشد. سرمایه آتش ­سوزی بیمه­ نامه ضریبی به میزان ۵۰۰، ۷۵۰، ۱۰۰۰ و یا ۱۵۰۰ برابر حق بیمه ماهانه خواهد بود.
          سقف تعهد جهت پوشش بیمه آتش ­سوزی در سال اول ۱,۰۰۰,۰۰۰,۰۰۰ریال می­باشد و در سال­ها ی بعد با افزایش ۵% و یا ۱۰% تا ۵,۰۰۰,۰۰۰,۰۰۰ ریال قابل افزایش می­باشد.
        </p>
      </div>
      <div id="panel11_responsive" class="titrbox "> <h1>&nbsp;&nbsp;تخفیف های ویژه برای بیمه گذاران بیمه عمروتأمین آتیه<i id="icon_panel11_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="panel11_panel_responsive" style="display: none">
        <p style="font-size: 12pt;text-align: justify">
          شرکت بیمه پاسارگاد در پاسخ به اعتماد میلیونی هموطنان گرامی و تأمین رفاه حال بیمه گذاران عمر و تأمین آتیه اقدام به ارائه ۱۰تا ۴۰ درصد تخفیف ویژه با توجه به میزان ذخیره ریاضی دارندگان این بیمه نامه نموده است.
          دارندگان بیمه نامه عمر و تأمین آتیه می توانند در زمان خرید بیمه نامه های  بدنه اتومبیل، آتش سوزی منزل مسکونی، بیمه حوادث انفرادی و بیمه درمان مسافرتی از تخفیف های ویژه برخوردار شوند.
          گفـتنی است خریداران این بیمه نامه ها می توانند با مراجعه به شـعبه ها و نمـایندگی های سـراسـر کشور، از این فرصـت مناسب بهره مند شوند.
        </p>
      </div>
    </div><!--  END info person Responsive  ******************-->
    </div>
  </section>
  <section>
  <p style="font-size: 12pt;color: #fffccc;text-align: right">
            <span>
              <strong>خرید بیمه نامه :</strong>
            </span>
  </p>
  <p style="font-size: 12pt;text-align: justify">
    جهت خرید بیمه نامه لطفا فرم زیر را  دانلود و پس از تکمیل به یکی از روشها شبکه های اجتماعی (سروش ، تلگرام ، واتس آپ ) و یا ایمیل برای اینجانب ارسال نمایید تا فرم اعلام حق بیمه و متعاقب آن صدور بیمه نامه صورت پذیرد .
  </p>
  </section>
  <button class="btn btn-brown" onclick="window.location.href='/pdf/omr1'">فرم شماره 1</button>
  <button class="btn btn-brown" onclick="window.location.href='/pdf/omr2'">فرم شماره 2</button>
</div>