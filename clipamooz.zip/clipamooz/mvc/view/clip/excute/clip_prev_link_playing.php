<?php
global $config;
?>
<div style="position: relative">
<video id="myplayer_clip_prev_link" style="width: 100%;" controls autoplay>
<!--  <source src="--><?//=$config['upload'].$clip_prev_link?><!--" type="video/mp4">-->
  <source  src="/asset/images/adv/clip/adv1.mp4" type="video/mp4">
</video>
  <div  id="advertisment_image" class="advimage">
    <div  id="close"  class="icon-cancel-circle large" style="color: red;cursor: pointer;display: none"  ></div>
  </div>

</div>

<!--  <input   type="hidden" id="img_link" value="--><?//=$config['upload'].$img_link?><!--">-->
<!--  <input   type="hidden" id="img_link" value="/asset/images/tabrik.jpg">-->
  <input   type="hidden" id="play" value="<?=$config['upload'].$clip_prev_link?>">
<!--  <input   type="hidden" id="play" value="/uploadfile/clip_final/clipamooz.mp4">-->
<script type="text/javascript">
  var clip=$("#play").val();
  $(function() {

    $("#close").click(function(){
      $("#advertisment_image").fadeOut();
    });
 $('#myplayer_clip_prev_link').on('ended',function(){
      $(this).attr('src',clip);
      $(this)[0].autoplay=true;
    });
 $('#myplayer_clip_prev_link').on('pause',function(){
   var number=Math.floor(Math.random() * 10);
   $('#close').fadeIn();
      $('#advertisment_image').fadeIn();
      $('#advertisment_image').css('background-image','url("/asset/images/adv/image/adv'+number+'.jpg")');
    });
 $('#myplayer_clip_prev_link').on('play',function(){
      $('#advertisment_image').fadeOut();
    });
    });
</script>
<!--<script type="text/javascript" src="/jwplayer-7.12.2/jwplayer.js"></script>-->
<!--<script type="text/javascript">jwplayer.key="e+FEhSmQKBoyj9D2dsPFaySjoz51O3VrlthwSg==";</script>-->
<!--<script type="text/javascript">

  var play=$('#play').val();
  var img_link=$('#img_link').val();
  var playerinstance=jwplayer('myplayer_clip_prev_link');
  playerinstance.setup({
    file:play,
    image:img_link,
    height:"250",
    width:"100%",
    logo:{
      file:'/asset/images/logo/logo3.png',
      link:'http://clipamooz.ir'
    }
  });
</script>
-->