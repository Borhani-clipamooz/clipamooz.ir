<div id="paginationUpdate"></div>
<script>

  $("#keyword").on('keyup', function () {
    all_receiver_message(<?=$pageIndex?>);
  });
  $(function () {
    all_receiver_message(<?=$pageIndex?>);
  });

  function all_receiver_message(pageIndex) {

    var keyword = $("#keyword").val();
    var SearchFiled = $("#UserFind").val();
    $.ajax({
      url: '/user/all_receiver_message_ajax/' + pageIndex,
      method: 'POST',
      dataType: 'json',
      data: {
        keyword: keyword,
        SearchFiled: SearchFiled
      },
      success: function (output) {
       // console.log(output);
        $("#paginationUpdate").html(output.html);
      }
    });
  }


</script>









