
<div class="rtl">
  <input type="text" style="display: none" id="user_id"  value="<?=$id?>" autocomplete="off">
</div>
<div id="paginationUpdate"></div>
<script>
  $(function () {
    all_withdraw_money(<?=$pageIndex?>);
  });
  function all_withdraw_money(pageIndex) {
    var user_id = $("#user_id").val();
    $.ajax({
      url: '/all_withdraw_money_ajax/'+pageIndex,
      method: 'POST',
      dataType: 'json',
      data: {
        user_id:user_id
      },
      success: function (output) {
        $("#paginationUpdate").html(output.html);
      }
    });
  }


</script>









