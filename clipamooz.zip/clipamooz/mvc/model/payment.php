<?php
class PaymentModel {
  public static function open_transaction($fee, $user_id, $authority){
    $db = Db::getInstance();
    $time = date("Y-m-d H:m:s");
    $db->insert("INSERT INTO x_transaction (fee, user_id, authority, creationTime, payed) VALUES ($fee, $user_id, '$authority', '$time', 0)");
  }

  public static function close_transaction($authority, $reference){
    $db = Db::getInstance();
    $time = date("Y-m-d H:m:s");
    $db->modify("UPDATE x_transaction SET reference='$reference', payed=1, paymentTime='$time' WHERE authority='$authority'");
  }
  public static function Update_back($SaleOrderId, $RefId,$SaleReferenceId,$ResCode){
    $db = Db::getInstance();
    $db->modify("UPDATE pay SET
 refid='$RefId'
 , salerefid=$SaleReferenceId
 , rescode=$ResCode
  WHERE id='$SaleOrderId'");
  }
  public static function pay_buy_clip_insert($user_id,$clip_id,$date_buy,$status_vote,$status_comment){
    $db = Db::getInstance();
    $db->query("INSERT INTO clips_buy (user_id,clip_id,created_at,status_vote,status_comment)
             VALUES ( :user_id, :clip_id,:created_at,:status_vote,:status_comment)",
      array(
        'user_id'         => $user_id,
        'clip_id'         => $clip_id,
        'created_at'         => $date_buy,
        'status_vote'         => $status_vote,
        'status_comment'         => $status_comment,
      ));
  }
  public static function pay_mony_insert($user_id,$amount,$refid,$salerefid,$ResCode,$create_at){
    $db = Db::getInstance();
    $db->query("INSERT INTO pay (user_id,amount,refid,salerefid,rescode,create_at)
             VALUES ( :user_id, :amount,:refid,:salerefid,:rescode,:create_at)",
      array(
        'user_id'         => $user_id,
        'amount'         => $amount,
        'refid'         => $refid,
        'salerefid'         => $salerefid,
        'rescode'         => $ResCode,
        'create_at'         => $create_at,
      ));
  }
  public static function withdraw_money($user_id,$amount,$create_at,$discription){
    $db = Db::getInstance();
    $db->query("INSERT INTO withdraw_money (user_id,amount,create_at,discription)
             VALUES ( :user_id, :amount,:create_at,:discription)",
      array(
        'user_id'         => $user_id,
        'amount'         => $amount,
        'create_at'         => $create_at,
        'discription'         => $discription,
      ));
  }
  public static function withdraw_money_ConutNotRead()
  {
    $db=Db::getInstance();
    $record=$db->first("select count(*) AS total from withdraw_money where discription='' ",array(),'total');
    return $record;

  }


}