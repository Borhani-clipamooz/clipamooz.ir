<div class="row">
  <section id="section-2">
    <div class="about-landing">
      <div class="container">
        <div class="about-text">
          <h2 style="color: #fffccc;">نرم افزارهای مورد نیاز در توسعه وب سایت </h2>
          <p style="margin-top: 50px">
            برای پیاده سازی سریعتر و ساده تر HTML / CSS نیاز به ابزار بهتری داریم، همینطور برای توسعه PHP نیز محیط برنامه نویسی و ابزاری که بتواند فضای اجرایی یک سرور LAMP را برای ما ایجاد نماید، نیاز است.

            در این بخش فایلهای مربوطه و طریقه نصب ابزارها ، تشریح شده اند.
          </p>
        </div>
        <div class="thumb wow animated zoomIn"><img style="border-radius: 50%" src="/asset/images/software/website.jpg" alt=""></div>
      </div>
    </div>
  </section>
  </div>
<div class="row">
  <section>
    <div class="container">
    <!--***********  INFO ---   Person   --   Responsive   ********************************************************************************-->
    <div class="info_person_responsive">
      <div id="panel1_responsive" class="titrbox"><h1 style="color: yellow">&nbsp;&nbsp;          محیط کد نویسی JetBrain IntelliJ Idea Version 14.1.2
          <i id="icon_panel1_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="panel1_panel_responsive" style="display: none">
        <p class="software">
          ابزاری که به عنوان محیط کد نویسی در قسمت «آماده سازی محیط برنامه نویسی» مورد صحبت قرار می گیرد، از سایت اصلی دانلود شده و در اختیار شما قرار دارد. می توانید بجای این لینک از سایت اصلی jetbrain نیز دانلود نمایید.
        </p>
        <p class="software">
          <a  href="/asset/images/software/source/ideaIU-14.1.2.rar" download style="background: #9b62315e;border-radius: 5px;padding:5px" >دانلود فایل</a>
        </p>
      </div>    <!-- END panel1_responsive ******************-->
      <div id="panel2_responsive" class="titrbox "> <h1>&nbsp;&nbsp;          تنظیمات کلیپ آموز برای IntelliJ Idea<i id="icon_panel2_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="panel2_panel_responsive" style="display: none">
        <p class="software">
          برای اینکه ابزار IntelliJ Idea شبیه محیطی شود که در آموزشها می بینید، نیاز است این فایل را که اختصاصاً از طرف این سایت به شما عرضه شده، دانلود و طبق آموزش مربوطه نصب نمایید.
        </p>
        <p class="software">
          <a  href="/asset/images/software/source/settings.rar" download style="background: #9b62315e;border-radius: 5px;padding:5px" >دانلود فایل</a>
        </p>
      </div><!--  END panel2_responsive  ******************-->
      <div id="panel3_responsive" class="titrbox "> <h1>&nbsp;&nbsp;          پلاگینهای PHP،Apachi،Filewatcher   برای IntelliJ Idea<i id="icon_panel3_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="panel3_panel_responsive" style="display: none">
        <p class="software">
          برای اینکه IntelliJ Idea امکان ویرایش و نمایش فایلهای PHP ، Apachi  ، FileWatcher   را داشته باشد، نیاز است که Plugin خاصی در آن نصب شود. این موضوع در آموزش با جزئیات بیان شده، چنانچه دانلود از سایت اصلی ( در قسمت Plugins - در آموزش ) مقدور نبود، می توانید از نسخه زیر استفاده نمایید.
        </p>
        <p class="software">
          <a  href="/asset/images/software/source/plugin.rar" download style="background: #9b62315e;border-radius: 5px;padding:5px" >دانلود فایل</a>
        </p>
      </div><!--  END panel3_responsive ******************-->
      <div id="panel4_responsive" class="titrbox "> <h1>&nbsp;&nbsp;          ابزار Wamp Server نسخه 32 بیتی برای راه اندازی محیط LAMP
          <i id="icon_panel4_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="panel4_panel_responsive" style="display: none">
        <p class="software">
          برای ایجاد یک محیط توسعه LAMP در ویندوز نیاز به یک Apache HTTP Server و یک MySQL Database Server و یک PHP Interpreter داریم که همگی در ابزاری به اسم WAMP Server موجود است. این ابزار رایگان و هم از لینک زیر و هم از سایت اصلی قابل دانلود می باشد.
          طریقه دانلود از سایت اصلی یا نصب این ابزار در آموزش تشریح شده است.
        </p>
        <p class="software">
          <a  href="/asset/images/software/source/WampServer.v3.0.6.x86.rar" download style="background: #9b62315e;border-radius: 5px;padding:5px" >دانلود فایل</a>
        </p>
      </div><!--  END panel3_responsive ******************-->
      <div id="panel5_responsive" class="titrbox "> <h1>&nbsp;&nbsp;          پیش نیاز Visual C++ Redistributable x86 برای اجرای Wamp Server
          <i id="icon_panel5_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="panel5_panel_responsive" style="display: none">
        <p class="software">
          برای اجرا کردن WAMP Server نیاز به Visual C++ Redistributable می باشد که نسخه 32 بیتی آن در زیر قرار دارد. توجه داشته باشید که باید از نسخه 32 بیتی در ویندوز 64 بیتی یا 32 بیتی استفاده کنید چرا که WAMP Server ما نسخه 32 بیتی ( که سازگارتر است ) می باشد.
          همینطور می توانید این فایل را از سایت مایکروسافت دانلود نمایید.
        </p>
        <p class="software">
          <a  href="/asset/images/software/source/vcredist_x86.rar" download style="background: #9b62315e;border-radius: 5px;padding:5px" >دانلود فایل</a>
        </p>
      </div><!--  END academic_responsive_responsive ******************-->

</div>