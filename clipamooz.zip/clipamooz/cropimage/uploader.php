  <?php
  $id = $_POST['id'];
  $field = $_POST['field'];
  $table = $_POST['table'];
  $resizeWidth = $_POST['width'];
  $resizeHeight = $_POST['height'];
  if(isset($_FILES['user-file']["tmp_name"])) {
  //تعیین فرمت یا اندازه مجاز و سایر پارامترها
  if ($_FILES["user-file"]["type"] == "image/jpeg"||$_FILES["user-file"]["type"] == "image/png"||$_FILES["user-file"]["type"] == "image/gif" && $_FILES["user-file"]["size"] <= 1000000) {
    //بررسی سایر خطاهای سرور
    if ($_FILES["user-file"]["error"] > 0){
      echo "<div class=\"server\">خطا: " . $_FILES["user-file"]["error"] . "</div><br />";
      $check_result = 0;
    }
    //بررسی وجود یا عدم وجود فایل با نام مشابه در سرور
    else{
      if (file_exists("user-upload/" . $_FILES["user-file"]["name"])){
        echo "<div class=\"server\">این فایل در حال حاضر وجود دارد! <br /><br />".$_FILES["user-file"]["name"]. "</div><br />";
        $check_result = 0;
      }
      //انتقال و ذخیره فایل در سرور
      else{

        function resizeImage($resourceType,$image_width,$image_height,$resizeWidth,$resizeHeight) {

          $imageLayer = imagecreatetruecolor($resizeWidth,$resizeHeight);
          imagecopyresampled($imageLayer,$resourceType,0,0,0,0,$resizeWidth,$resizeHeight, $image_width,$image_height);
          return $imageLayer;
        }
        if( @$_FILES['user-file']['name'] != "" )
        {
          $fileName = $_FILES['user-file']['tmp_name'];
          $sourceProperties = getimagesize($fileName);
          $resizeFileName = time().md5(uniqid(rand(), true));
          $uploadPath =$_SERVER['DOCUMENT_ROOT'] ."/cropimage/uploads/image/";
          $fileExt = pathinfo(@$_FILES['user-file']['name'], PATHINFO_EXTENSION);
          $uploadImageType = $sourceProperties[2];
          $sourceImageWidth = $sourceProperties[0];
          $sourceImageHeight = $sourceProperties[1];
          switch ($uploadImageType) {
            case IMAGETYPE_JPEG:
              $resourceType = imagecreatefromjpeg($fileName);
              $imageLayer = resizeImage($resourceType,$sourceImageWidth,$sourceImageHeight,$resizeWidth,$resizeHeight);
              imagejpeg($imageLayer,$uploadPath."www.clipamooz.ir".$resizeFileName.'.'. $fileExt);
              $address_Save_to_DataBase='/cropimage/uploads/image/www.clipamooz.ir'.$resizeFileName.'.'. $fileExt;
              $url='https://www.clipamooz.ir/uploader/image_finish/';
              get_web_page($url,$address_Save_to_DataBase,$id,$field,$table);
              break;

            case IMAGETYPE_GIF:
              $resourceType = imagecreatefromgif($fileName);
              $imageLayer = resizeImage($resourceType,$sourceImageWidth,$sourceImageHeight,$resizeWidth,$resizeHeight);
              imagegif($imageLayer,$uploadPath."www.clipamooz.ir".$resizeFileName.'.'. $fileExt);
              $address_Save_to_DataBase='/cropimage/uploads/image/www.clipamooz.ir'.$resizeFileName.'.'. $fileExt;
              $url='https://www.clipamooz.ir/uploader/image_finish/';
              get_web_page($url,$address_Save_to_DataBase,$id,$field,$table);
              break;

            case IMAGETYPE_PNG:
              $resourceType = imagecreatefrompng($fileName);
              $imageLayer = resizeImage($resourceType,$sourceImageWidth,$sourceImageHeight,$resizeWidth,$resizeHeight);
              imagepng($imageLayer,$uploadPath."www.clipamooz.ir".$resizeFileName.'.'. $fileExt);
              $address_Save_to_DataBase='/cropimage/uploads/image/www.clipamooz.ir'.$resizeFileName.'.'. $fileExt;
              $url='https://www.clipamooz.ir/uploader/image_finish/';
              get_web_page($url,$address_Save_to_DataBase,$id,$field,$table);
              break;

            default:
              $imageProcess = 0;
              break;
          }

        }
        else
        {
          die("No file specified!");
        }
        $check_result = 1;
      }
    }
  }
//خطای تعیین فرمت یا اندازه مجاز و سایر پارامترها
  else{
    if($_FILES["user-file"]["size"] > 1000000){
      echo "<div class=\"server\">حجم فایل خیلی زیاد است!</div>";
    }
    else{
      echo "<div class=\"server\">فرمت فایل مجاز نیست!</div>";
    }
    $check_result = 0;
  }
  }
  function get_web_page( $target_url,$address_Save_to_DataBase,$id,$field,$table)
  {
    $ch = curl_init();
    $data=array('address_Save_to_DataBase'=>$address_Save_to_DataBase,'id'=>$id,'field'=>$field,'table'=>$table);
    curl_setopt($ch, CURLOPT_URL,$target_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
    curl_setopt($ch, CURLOPT_POST,true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $content = curl_exec( $ch );
    curl_close( $ch );
    return $content;
  }
  ?>
  <script type="text/javascript">
    window.top.window.upload_end(<?php echo $check_result; ?>);
  </script>
