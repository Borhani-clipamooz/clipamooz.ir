<!DOCTYPE html>
<?
if (!isset($pageTitle)) {
  $pageTitle = "clipAmooz.ir";
}
?>
<html lang="FA">
      <?require(getcwd() . "/mvc/view/theme/theme.php");?>
      <?require(getcwd() ."/mvc/view/menu/megamenu.php");?>
  <br><br><br>
  <div class="row">
   <div class="colx-12 colm-fill cols-fill" style="vertical-align: top;">
     <?= $content ?>
   </div>
  </div>
<!--</div>-->
  <div id="Footer"></div>
</html>
