<div class="content">

      <table>
        <colgroup>
          <col width="40px">
          <col width="40px">
          <col width="500px">
          <col width="500px">
        </colgroup>
        <thead>
        <tr>

          <th class="tac">جزئیات</th>
          <th class="tac">حذف</th>
          <th class="tac">نام فارسی</th>
          <th class="tac">نام انگلیسی</th>
        </tr>
        </thead>
        <tbody>

        <? foreach ($list as $feild) {?>
        <tr>
            <td ><span onclick="View(<?= $feild['id']?>,<?=$pageIndex?>)"><i class="icon-eye large"></i></span></td>

            <td><span onclick=window["Remove_sql_data"](<?= $feild['id']?>,<?=$pageIndex?>,'<?= $feild['image'] ?>')<i class="icon-bin large"></i> </span></td>

        <td ><?= $feild['name_fa'] ?></td>
        <td ><?= $feild['name_en'] ?></td>
        </tr>

        <? } ?>
        </tbody>
      </table>
    <br>
    <!--Buttons Filter-->
    <?=pagination(baseUrl().'/category/all',3,'btn_style btn-brown','btn',$pageIndex,$pageCount,'getPage')?>
  <button class="btn_style btn-brown" onclick="InsertCategoryToSql(<?=$pageIndex?>)" >اضافه کردن دسته بندی جدید</button>

</div>

<script>
  function InsertCategoryToSql(PageIndex,currentDate) {
    $.ajax({
      url: '/category/InsertCategoryToSql/',
      type: 'POST',
      dataType: 'json',
      data:{
        PageIndex:PageIndex
      },
      success: function (data) {
        $("#paginationUpdate").html(data.html);
      }
    });
  }
  function View(Id,PageIndex) {

    $.ajax({
      url: '/category/view/' + Id,
      type: 'POST',
      dataType: 'json',
      data:{
        pageIndex:PageIndex
      },
      success: function (data) {
        $("#paginationUpdate").html(data.html);
      }
    });
  }
  function Remove_sql_data(Id,PageIndex,PathFile) {
    swal({
        title: "آیا مطمئن هستید؟",
        text: "شما دیگر قادر به بازیابی این فایل نخواهید بود.",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#5d4126",
        confirmButtonText: "آره، آن را حذف کنید.",
        closeOnConfirm: false
      },
      function(){
        $.ajax({
          url: '/category/Remove_sql_data/' + Id,
          type: 'POST',
          dataType: 'json',
          data:{
            pathFile:PathFile,
            pageIndex:PageIndex

          },
          success: function (data) {
            $("#paginationUpdate").html(data.html);
          }
        });
      swal("حذف گردید.");
      });


  }

</script>


