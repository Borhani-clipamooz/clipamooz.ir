<?php
class Contact_usModel {



  public static function Save_Receive_message($sender_message_id,$family,$email,$cellphone,$subject,$body_question,$body_replay,$status,$date_receive_message){
    $db = Db::getInstance();
    $db->query_insert("INSERT INTO contact_us (user_id,family,email,cellphone,subject,body_question,body_replay,status,date_receive_message)
             VALUES (  :user_id,:family,:email,:cellphone,:subject,:body_question,:body_replay,:status,:date_receive_message)",
      array(
        'user_id'         => $sender_message_id,
        'family'         => $family,
        'email'         => $email,
        'cellphone'         => $cellphone,
        'subject'         => $subject,
        'body_question'         => $body_question,
        'body_replay'         => $body_replay,
        'status'         => $status,
        'date_receive_message'         => $date_receive_message,
      ));
  }

  public static function DelSqlRecord($id)
  {
    $db=Db::getInstance();
    $db->query("DELETE FROM contact_us where id=:id",array('id'=>$id,));

  }
  public static function Replay($id,$body_replay,$status){

    $db = Db::getInstance();
    $db->modify("UPDATE contact_us SET body_replay=:body_replay,
     status=:status

     WHERE id=:id",
      array(
        'id' => $id,
        'status' => $status,
        'body_replay' => $body_replay,

      ));


  }
  public static function Contact_us_ConutNotRead()
  {
    $db=Db::getInstance();
    $record=$db->first("select count(*) AS total from contact_us where (status like '0')",array(),'total');
    return $record;

  }
}