<?php
class SupportModel {



  public static function Save_Send_message_first($ticket_id,$sender_user_id,$target_user_id,$subject,$body,$created_at,$status){
    $db = Db::getInstance();
    $db->query_insert("INSERT INTO support (ticket_id,sender_user_id,target_user_id,subject,body,created_at,status)
             VALUES (:ticket_id,:sender_user_id,:target_user_id,:subject,:body,:created_at,:status)",
      array(
        'ticket_id'         => $ticket_id,
        'sender_user_id'         => $sender_user_id,
        'target_user_id'         => $target_user_id,
        'subject'         => $subject,
        'body'         => $body,
        'created_at'         => $created_at,
        'status'         => $status,
      ));
  }


  public static function Replay($id,$body_replay,$status){

    $db = Db::getInstance();
    $db->modify("UPDATE support SET body_replay=:body_replay,
     status=:status

     WHERE id=:id",
      array(
        'id' => $id,
        'status' => $status,
        'body_replay' => $body_replay,

      ));


  }
  public static function support_ConutNotRead($user_id)
  {
    $db=Db::getInstance();
    $record=$db->first("select count(*) AS total from support where (sender_user_id=$user_id)AND (status=1)",array(),'total');
    return $record;

  }



}