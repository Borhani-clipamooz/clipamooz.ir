<?
$price = 100 ;
?>

<div class="tac">
  <span>مبلغ سبد خرید شما عبارتست از:</span><br>
  <span><?=$price?> تومان </span>
  <br>
  <br>
  <br>

  <a class="btn_style" href="/payment/request">پرداخت</a>
</div>

<div>
  <img src="/asset/images/safiran_logo_101.png" style="width:50px;height:50px" />
</div>

<div style="position: fixed; bottom: 10px; left: 10px; ">
  <img id='nbpehwlawmcsnbpedrft' style='cursor:pointer' onclick='window.open("https://trustseal.enamad.ir/Verify.aspx?id=24821&p=wkynodshaqgwwkynnbpd", "Popup","toolbar=no, location=no, statusbar=no, menubar=no, scrollbars=1, resizable=0, width=580, height=600, top=30")' alt='' src='https://trustseal.enamad.ir/logo.aspx?id=24821&p=qesgaodsukaqqesglznb'/>
</div>