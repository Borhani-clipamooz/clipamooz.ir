<div class="content">
  <div id="paginationUpdate"></div>
  <hr>
  <?if(isVip()){?>
  <div class="content">
      <input type="text"  style="display: none" id="clip_id" value="<?=$id?>">
      <input type="text"  style="display: none" id="owner_clip_id" value="<?=$user_id?>">
      <input type="text"  style="display: none" id="date_question" value="<?=getCurrentDateTime()?>">
    <div class="question_clip">
    <div class="row">
      کاربر دوست داشتنی سوال خود را مطرح نمایید:
    </div>
    <div class="row">
      <div class="colx-2 cols-fill">
<h2>        نام کاربری</h2>
      </div>
      <div class="colx-10 cols-fill">
        <input  style="display: none" class="tac"  type="text" id="user_id_question" value="<?=$_SESSION['user_id']?>">
        <?$data=CommonModel::Fetch_by_every('users','id',$_SESSION['user_id']);?>
        <?=$data['user_name']?>
      </div>
    </div>
    <div class="row">
      <div class="colx-2 cols-fill">
        <h2>        نام کلیپ        </h2>
      </div>
      <div class="colx-10 cols-fill">
        <?=$clip_name?>
        <input style="display: none" class="tac" type="text"   id="clip_name"  value="<?=$clip_name?>" >
      </div>
    </div>
    <div class="row ">
      <div class="colx-2 cols-fill">
        <h2>        موضوع
        </h2>
     </div>
      <div class="colx-10 cols-fill">
        <input type="text"   id="subject" >
      </div>
    </div>
    <div class="row">
      <div class="colx-2 cols-fill">
        <h2>        متن سوال
        </h2>
     </div>
      <div class="colx-10 cols-fill">
        <textarea class="tar" type="text"   id="body_question" ></textarea>
      </div>
    </div>
   <div class="row">
    <button id="btn_save_Question" class="btn_style btn-brown" onclick="save_Question()">ثبت سوال</button>&nbsp;
   </div>
    <div class="row">
        <h3 id="message_qusetion"></h3>
    </div>
  <?}else{?>
    <span>برای پرسیدن سوال به کلیپ آموز وارد شوید.</span>
  <?}?>
</div>
  </div>
<script>
  $(function () {
    list_question(<?=$pageIndex?>);
  });
  function list_question(pageIndex) {
    var keyword = $("#keyword").val();
    var SearchFiled = $("#UserFind").val();
    var clip_id=$('#clip_id').val();
    $.ajax({
      url: '/RefreshData_question/' + pageIndex,
      method: 'POST',
      dataType: 'json',
      data: {
        keyword: keyword,
        clip_id: clip_id,
        SearchFiled: SearchFiled
      },
      success: function (output) {
        // console.log(output);
        $("#paginationUpdate").html(output.html);
      }
    });
  }
  function save_Question(){
var user_id_question=$('#user_id_question').val();
var subject=$('#subject').val();
var body_question=$('#body_question').val();
    if(body_question=='' || subject=='' ){
      document.getElementById("message_qusetion").innerHTML="سوالی مطرح نشده است.";
      return;
    }
    $("#btn_save_Question").after('<div id="loader"><span class="icon-spinner9 huge spin "></span></div>');

var clip_id=$('#clip_id').val();
var owner_clip_id=$('#owner_clip_id').val();
var clip_name=$('#clip_name').val();
var date_question=$('#date_question').val();
    $.ajax({
      url: '/Save_Questions/',
      method: 'POST',
      dataType: 'json',
      data: {
        subject: subject,
        clip_id: clip_id,
        owner_clip_id: owner_clip_id,
        clip_name: clip_name,
        user_id_question: user_id_question,
        body_question: body_question,
        date_question: date_question
      },
      success: function (output) {
        //console.log(output.html);
        $('#loader').slideUp(1000, function() {
          $(this).remove();
          window.location.reload();
        });
      }
    });
  }
</script>

