<ul>
  <li>
    <table >

      <tr>
        <td>
          <label class="btn-brown" for="FileZip" class="btn ">انتخاب فایل </label>
          <input  id="FileZip" type="file" name="file1"style="width:1%;visibility: hidden" >
        </td>
      </tr>
      <tr>
        <td>
          <input class="btn-brown" type="button" value="عملیات آپلود" name="" onclick=uploadNEWFile('Uploadzipfile',3,<?=$id?>,'<?=$table_name?>','<?=$feild_name?>')>
          <progress id="progressBarFileZip" value="0" max="100" style="width:100px;"></progress>
        </td>
      </tr>
      <tr>
        <td>
          <h3 id="statusFileZip"></h3>
          <p id="loaded_n_totalFileZip"></p>
          <p id="FileZip"></p>
        </td>
      </tr>
    </table>
  </li>
</ul>
<script>
  $(function(){
    $('#FileZip').on('change',function(){
      var file =this.files[0];
      var type=file.type;
      if(type !='application/x-zip-compressed')
      {
        swal("ببخشید پسوند فایل zip می باشد");
        return;
      }
    var reader=new FileReader();
    reader.onload=viewer.load;
    reader.readAsDataURL(file);
    viewer.setProperties(file);
  });
  var viewer={
    load:function(e){
      $('#FileZip').attr('src', e.target.result);

    },
    setProperties:function(file){
      $('#filenameZip').text(file.name);
      $('#filetypeZipe').text(file.type);
      $('#filesizeZip').text(Math.round(file.size/1024));
    }
  });
  });
</script>