<meta charset="utf-8">
<script type="text/javascript" src="/mvc/view/rating/src/rating.js"></script>
<link rel="stylesheet" href="/mvc/view/rating/src/rating.css" type="text/css" media="screen" title="Rating CSS">
<div class="content">
       <input type="text" style="display: none" id="clip_id" value="<?=$id?>">
       <input type="text" style="display: none" id="user_id" value="<?=$user_id?>">
<div class="add_rating">
  <div class="row">
    <div class="colx-2 colm-fill cols-fill">
      <h2>نام کلیپ</h2>
    </div>
    <div class="colx-10 colm-fill cols-fill"><?=$clip_name?></div>
  </div>
  <div class="row">
    <?
    //********************************mizane opens ra ba hesab ip va clip_id hesab kard ***************************************
    $parts_one=array();
    $data_rating=CommonModel::Fetch_by_every('rating','clip_id',$id);
    $last_count="";
    $parts_one = explode(',',  $data_rating['voters']);
    for ($i = 0; $i < count($parts_one); $i++) {

      $last_count=$last_count.$parts_one[$i].",";
    }?>
    <input type="text" style="display: none" id="last_count" value="<?=$last_count?>">
    <?    if(!in_array($user_id,$parts_one)){?>
      <div id="Vote_td">
        <section class="container1">
          <input type="radio" name="example" class="rating" value="1" />
          <input type="radio" name="example" class="rating" value="2" />
          <input type="radio" name="example" class="rating" value="3" />
          <input type="radio" name="example" class="rating" value="4" />
          <input type="radio" name="example" class="rating" value="5" />
        </section>
        <script>
          $('.container1').rating(function(vote, event){
            var clip_id=$('#clip_id').val();
            var user_id=$('#user_id').val();
            var last_count=$('#last_count').val();
            var x = document.getElementById('Vote_td');
            $.ajax({
              url: '/rating/Save_Rating/',
              method: 'POST',
              dataType: 'json',
              data: {
                vote: vote,
                clip_id: clip_id,
                user_id: user_id,
                last_count: last_count
              },
              success: function (data) {
                //console.log(data.status);
                x.style.display = 'none';
              }
            });
          });

        </script>
      </div>
    <?}?>
  </div>
  <?
  $data_comments=CommonModel::Fetch_by_all('comments','user_id',$user_id,'');
  $checkComment='true';
  sort($data_comments);
  $clength = count($data_comments);
  if (empty($data_comments)) {?>

  <?}else{
    foreach ($data_comments as $key => $val) {// array chand boedy
      if ($val['clip_id'] === $id) {
        $checkComment='false';
        //  echo $checkComment;
        ?>

      <?}}}?>
  <?if ($checkComment=='true'){?>
    <div class="row">
      <div class="colx-2 colm-fill cols-fill"><h2>نظر شما</h2></div>
      <div class="colx-10 colm-fill cols-fill"><textarea id="Comment"  style="height: 80px;"></textarea></div>
    </div>
 <? }?>
<div class="row"><div id="popupRating"></div></div>
  <div class="row"><button  id="btn_SaveComment" class="btn_style btn-brown" onclick="SaveComment(<?= $pageIndex ?>)">ثبت</button></div>
  <div class="row"> <button class="btn_style btn-brown" onclick="back(<?= $pageIndex ?>)">برگشت</button></div>
</div>
</div>

<script>
  function back(pageIndex){
    all_clip_buy(pageIndex);
  }
  function SaveComment(pageIndex){
    $("#btn_SaveComment").after('<div id="loader"><span class="icon-spinner9 huge spin "></span></div>');
    var clip_id=$('#clip_id').val();
    var user_id=$('#user_id').val();
    var comment=$('#Comment').val();
    var comment_td = document.getElementById('comment_td');
    $.ajax({
      url: '/comment/Save_Comment/',
      method: 'POST',
      dataType: 'json',
      data: {
        clip_id: clip_id,
        user_id: user_id,
        comment: comment
      },
      success: function (data) {
        $('#loader').slideUp(1000, function() {
          $(this).remove();
        all_clip_buy(pageIndex);
        });
        comment_td.style.display = 'none';
      }
    });
  }
  $(function(){
    var id = $("#clip_id").val();
    popupRating(id);
  });
</script>

