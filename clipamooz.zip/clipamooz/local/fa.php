<?
define('_email_not_registered', "ورود ناموفق است. لطفاً صحت ایمیل خود را بررسی نمایید");
define('_invalid_password', "رمز عبور شما اشتباه است");
define('_login_welcome', 'ورود شما را به سایت خودتون تبریک می گوییم.');
//define('_login_welcome', 'ورود شما را تبریک می گوییم <a href="' . baseUrl() . '/page/home">ورود به صفحه اصلی</a>');
define('_already_registered', "شما پیشتر ثبت نام کرده اید، کافیست وارد سایت شوید");
define('_already_logged_in', 'شما هم اکنون وارد شده اید <a href="' . baseUrl() . '/page/home">ورود به صفحه اصلی</a> یا <a href="' . baseUrl() . '/user/logout">خروج از حساب</a><br><br>ایمیل شما: ');
define('_weak_password', "پسورد به اندازه کافی قوی نمی باشد");
define('_password_not_match', "پسورد ها با هم مطابقت ندارند");
define('_successfully_registered',    'شما با موفقیت ثبت نام شدید،<a href="' . baseUrl() . '/user/login">ورود به سایت</a>');
//define('_limit_access', 'با عرض پوزش شما برای دیدن این صفحه دارای محدودیت می باشید.<a href="'.baseUrl().'/user/login">ورود</a>');
define('_limit_access', 'fff');

define('_header_welcome', "خوش آمدید");
define('_header_guest', "کاربر مهمان");

define('_btn_register', "عضو جدید");
define('_btn_login', "ورود");
define('_btn_save', "ثبت");
define('_btn_logout', "خروج از حساب کاربری");
define('_btn_signup', "ساخت حساب جدید");
define('_btn_delete', "حذف کردن");
define('_btn_cpanel', "پنل کاربری");
define('_btn_buy', "خریدها");
define('_btn_marked', "کلیپ های نشان شده");
define('_btn_Displayed', "کلیپ های دیده شده");
define('_btn_forgot_password', "رمز عبور فراموش شده");
define('_btn_request_link_active', "درخواست لینک فعال سازی");
define('_btn_print_cv', "چاپ رزومه");
define('_btn_more', "بیشتر");
define('_btn_copy', "کپی");


define('_ph_recovery_password', "بازیابی پسورد");
define('_ph_message_password', "کاربر عزیز پسورد جدید شما برابر است با");
define('_ph_email', "ایمیل");
define('_ph_password', "رمز عبور");
define('_ph_confirm_password', "تکرار رمز عبور");
define('_ph_name', "نام کامل");
define('_ph_nickname', "نام مستعار");

define('_not_found_information', "اطلاعاتی پیدا نشد");
define('_duplicate_information', "اطلاعات ورودی تکراری می باشد");

define('_site_name', "کلیپ آموز - سرویس اشتراک و فروش  کلیپ های آموزشی");
define('_clipamooz', "کلیپ آموز");
define('_banner', "آموزش شما،علاقه ما");
define('_description', "فقط کلیپ های آموزشی");
define('_category', "دسته بندی");
define('_home', "خانه اصلی");
define('_user_home', "خانه کاربر");
define('_question', "سوالات متداول");
define('_contact_us', "تماس با ما");
define('_about_us', "درباره ما");
define('_support_ticket', "پشتیبانی");
define('_rules', "قوانین");
define('_guide', "راهنما");
define('_exit', "خروج");
define('_setting', "تنظیمات");
define('_radio_reial', "ریال");
define('_CV', "رزومه کاری اینجانب :");
define('_linkedin_decription', "برای اینکه بتوانم سابقه خودم را بهتر به شما معرفی نمایم در اینجا رزومه کاری اینجانب را مطالعه بفرمایید . ");

define('_Web_programming', "برنامه نویسی وب");
define('_Office_supplies', "لوازم اداری");
define('_Electricity', "برق");
define('_Math', "ریاضی");
define('_Network', "شبکه");
define('_Graphic', "گرافیک");
define('_MCSA_2016', "آموزش MCSA 2016");

//define ('DIRECTORY_SEPARATOR', "/");
?>