<?php


class MenuController {
  public function __construct() {

  }
  public function guide() {

    View::render("/menu/guide.php", array());
  }
  public function contact_us() {

    View::render("/menu/contact_us.php", array());
  }

  public function frequently_questions() {

    View::render("/menu/frequently_questions.php", array());
  }
  public function rules() {

    View::render("/menu/rules.php", array());
  }

  public function MegaMenu() {
    View::renderPartial("/menu/megamenu.php", array());
  }

  public function ShowSearch() {
    if (isset($_POST['keyword'])) {
      $keyword = $_POST['keyword'];
    } else {
      $keyword = "";
    }

    $records['list'] = ClipModel::Search($keyword);

    ob_start();
    $records['keyword']=$keyword;
    View::renderPartial("/menu/showsearch.php", $records);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));
  }
  public function ShowSearch_responsive() {
    if (isset($_POST['keyword_responsive'])) {
      $keyword = $_POST['keyword_responsive'];
    } else {
      $keyword = "";
    }

    $records['list'] = ClipModel::Search($keyword);

    ob_start();
    $records['keyword_responsive']=$keyword;
    View::renderPartial("/menu/showsearch_responsive.php", $records);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));
  }

  public function Search() {
      ob_start();
    View::renderPartial("/menu/search.php", array());
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));
  }
  public function responsive_search() {
      ob_start();
    View::renderPartial("/menu/search_responsive.php", array());
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));
  }
  public function Complete_Search($keyword) {
    $data['pageTitle']='جستجوی کامل';
    $data['keyword']=$keyword;
    View::render("/menu/complete_search.php", $data);

  }
  public function Complete_Search_ajax() {
    if (isset($_POST['count'])) {
      $count = $_POST['count'];
    } else {
      $count =15;
    }
    if (isset($_POST['startIndex'])) {
      $startIndex = $_POST['startIndex'];
    } else {
      $startIndex = 0;
    }

    if (isset($_POST['keyword'])) {
      $keyword = $_POST['keyword'];
    } else {
      $keyword = "";
    }
    ob_start();
    $data['list']=ClipModel::Complete_Search($startIndex,$count,$keyword);
    View::renderPartial("/menu/complete_search_ajax.php", $data);
    $output = ob_get_clean();
    if(!empty($data['list'])){
    echo json_encode(array('status' => true, 'html' => $output,));
    }else{
    echo json_encode(array('status' =>false, 'html' => $output,));
    }

  }
  public function ShowSearch1() {
    if (isset($_POST['keyword'])) {
      $keyword = $_POST['keyword'];
    } else {
      $keyword = "";
    }
    $out=array();
    $records = ClipModel::Search($keyword);
    $out['html'] = '';
    $out['raw'] = array();
    foreach($records as $record){
      $out['html'] .= '<strong>' . $record['name_fa'] . '</strong><br><span>' . $record['img_link'] . '</span><hr>';
      $out['raw'][] = $record;
    }

    echo json_encode($out);
   // View::renderPartial("/menu/search.php", $data);
  //  echo json_encode(array('status' => true, 'html' =>  $data,));
  }




}