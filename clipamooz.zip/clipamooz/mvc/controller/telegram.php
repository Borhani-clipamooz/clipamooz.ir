<?php
class TelegramController{

  public function send_message4(){
 $token='FJCNiznahjslCUChg2p_yFB8AKu2ddhC2beHroXC_ycb_BK3XEgdc0w3WUxU_KS1U_aLn6YIydG0LMzbTDCTN5v4_npMwmEbZ8Bk_YF5fgC4tqz1moSDAuH81yvvfMmxmbHmkhJP-EHQwbYY';
    $url= Common_CURL('https://bot.sapp.ir/'.$token.'/getMessage');
$getupdates=file_get_contents($url);
  //  $getUpdates= file_get_contents($url.'sendMessage?chat_id='.'@clipamoozir');// payame roye kanal

    echo json_encode(array('status' => var_dump(json_decode($getupdates)), 'html' => $getupdates,));
  }
  public function send_message3(){
//$token='441404292:AAFPfcorBdH0c_KVPB6nPZJEdP3i0eA7Px4';
   /// $token='736951299:AAGHgW-6ZpK4ZgB506LS1Kmmj6xwUSChwmY';
   // $url='https://api.telegram.org/bot'.$token.'/getUpdates';
    $url='https://api.telegram.org/bot736951299:AAGHgW-6ZpK4ZgB506LS1Kmmj6xwUSChwmY/getUpdates';
$getupdates=file_get_contents($url);
  //  $getUpdates= file_get_contents($url.'sendMessage?chat_id='.'@clipamoozir');// payame roye kanal

    echo json_encode(array('status' => var_dump(json_decode($getupdates)), 'html' => $getupdates,));
  }
  public function send_message2(){
    echo 'a';
//$token='441404292:AAFPfcorBdH0c_KVPB6nPZJEdP3i0eA7Px4';
    $token='736951299:AAGHgW-6ZpK4ZgB506LS1Kmmj6xwUSChwmY';
    $url='https://api.telegram.org/'.$token.'/';
$getUpdates=file_get_contents($url.'getUpdates');
    file_get_contents($url.'sendMessage?chat_id='.'9153018177'.'&text=javab2');// payame roye kanal

  }
  public function send_message(){
//$token='441404292:AAFPfcorBdH0c_KVPB6nPZJEdP3i0eA7Px4';
$token='736951299:AAGHgW-6ZpK4ZgB506LS1Kmmj6xwUSChwmY';
    $url='https://api.telegram.org/bot'.$token.'/';
   // file_get_contents($url.'sendMessage?chat_id='.'@clipamooz_ir'.'&text=aa');// payame roye kanal
//$getUpdates=file_get_contents($url.'getUpdates');
//$getUpdates=file_get_contents($url.'getMe');
    //$param=json_decode($getUpdates,true);
  // file_get_contents($url.'sendMessage?chat_id='.'9153018177'.'&text=javab1');// payame roye kanal
 //   var_dump($param['result'][1]['message']['chat']['id']);
   // var_dump($param['result'][1]['message']['text']);
   // dump_unco($param);
  //  file_get_contents($url.'sendMessage?chat_id='.$param['result'][0]['message']['chat']['id'].'&text=javab'); //roye id khas
   // file_get_contents($url.'sendPhoto?chat_id='.'@clipamoozbot'.'&photo=javab1');// payame roye kanal
    $img = 'http://clipamooz.local/uploadfile/image/22.jpg';
    file_get_contents($url.'SendPhoto?chat_id='.'@clipamooz_ir'.$img);
    var_dump($img);
    $request=curl_init($url.'SendPhoto?chat_id=@clipamooz_ir');
    curl_setopt($request,CURLOPT_POST,true);
   curl_setopt($request,CURLOPT_SSL_VERIFYPEER,false);
    curl_setopt($request,CURLOPT_POSTFIELDS,array('photo'=>'@'.$img));
   $result= curl_exec($request);
var_dump($result);
  }

}