<div class=" content">
  <div class="detail_professional_history_panel_ajax">
    <div id="professional_history" class="titrbox "> <h1>&nbsp;&nbsp;سوابق حرفه ای :<i id="icon_professional_history_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
    <input type="hidden"id="id"value="<?=$id?>">
    <div class="row">
      <div class="colx-4 ">
        <h2 >نام سازمان / شرکت</h2>
      </div>
      <div class="colx-4">
        <h2>شروع همکاری</h2>
      </div>
      <div class="colx-4">
        <h2>پایان همکاری</h2>
      </div>
    </div>
    <div class="row">

      <div class="colx-4">
        <h3><input  type="text"  id="name_company"  name="" value="<?=$name_company  ?>"></h3>
      </div>
      <div class="colx-4">
        <h3><input  type="text"  id="start_collaboration"  name="" value="<?= $start_collaboration ?>"></h3>
      </div>
      <div class="colx-4">
        <h3><input  type="text"  id="finish_collaboration"  name="" value="<?= $finish_collaboration ?>"></h3>
      </div>
    </div>
    <div class="row">
      <div class="colx-4">
        <h2>سمت</h2>
      </div>
      <div class="colx-4">
        <h2>نوع فعالیت (قراردادی، پیمانی، رسمی و ...) </h2>
      </div>
      <div class="colx-4">
        <h2>پاره وقت/ تمام وقت/ مشاوره</h2>
      </div>
    </div>
      <div class="row">
        <div class="colx-4">
          <h3><input  type="text"  id="responsibility"  name="" value="<?= $responsibility ?>"></h3>
        </div>
        <div class="colx-4">
          <h3><input  type="text"  id="type_of_activity"  name="" value="<?= $type_of_activity ?>"></h3>
        </div>
        <div class="colx-4">
          <h3><input  type="text"  id="time_activity"  name="" value="<?= $time_activity ?>"></h3>
        </div>
      </div>
  </div>
  <div class="row tac">
    <button  class="btn_style btn-brown" onclick="back(<?=$pageIndex?>)">بازگشت</button>
  </div>
</div>
<script>
$(function(){
  $("input").each(function () {
    $(this).on('keyup', function () {
      var id=$("#id").val();
      var name_company=$("#name_company").val();
      var start_collaboration=$("#start_collaboration").val();
      var finish_collaboration=$("#finish_collaboration").val();
      var responsibility=$("#responsibility").val();
      var type_of_activity=$("#type_of_activity").val();
      var time_activity=$("#time_activity").val();
      $.ajax({
        url:'/user/detail_professional_history_update',
        type: 'POST',
        dataType:'json',
        data:{
          id:id,
          name_company:name_company,
          start_collaboration:start_collaboration,
          finish_collaboration:finish_collaboration,
          responsibility:responsibility,
          type_of_activity:type_of_activity,
          time_activity:time_activity
        },
        success:function(data){
          //console.log(data);
        }
      });


    });
  });
});
  function back(id){
    professional_history(id);
  }
</script>















