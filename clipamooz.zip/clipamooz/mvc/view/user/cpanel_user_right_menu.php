    <div class="titrbox ">
      <div class="row tac" style="background-color: transparent">
      <a style="color: #cccfff" href="/main">
        <i  class="icon-home large"></i>&nbsp;&nbsp;خانه اصلی
      </a>
      </div>
      <br>
      <div class="row tac" style="background-color:transparent">
      <a style="color: #fffccc" href="/Cpanel/<?=$_SESSION['user_id']?>/1">
        <i  class="icon-home large"></i>&nbsp;&nbsp;&nbsp;<?=_user_home?>
      </a>
      </div>
    </div>
<div class="title">اطلاعات پایه</div>
<div class="titrbox">
  <ul>
    <a href="/detail/<?=$_SESSION['user_id']?>">  <li>اطلاعات فردی</li></a>
    <a href="/all_education_history/<?=$_SESSION['user_id']?>"><li>سوابق تحصیلی</li></a>
    <a href="/all_professional_history/<?=$_SESSION['user_id']?>/1"><li>سوابق حرفه ای</li></a>
    <a href="/all_tutorial_history/<?=$_SESSION['user_id']?>/1"><li>دوره های آموزشی</li></a>
    <a href="/all_research_pattern/<?=$_SESSION['user_id']?>/1"><li>طرح های پژوهشی</li></a>
    <a href="/all_article_history/<?=$_SESSION['user_id']?>/1"><li>کتاب ها و مقالات </li></a>
    <a href="/all_prize_history/<?=$_SESSION['user_id']?>/1"><li>جایزه ها و تقدیر نامه ها</li></a>
  </ul>
</div>
<div class="title"> <a target="_blank" href="http://sms.clipamooz.ir/">پنل پیامک</a></div>
<div class="title">مدیریت کلیپ</div>
<div class="titrbox" >
  <ul>
    <a href="/all_clip_upload/<?=$_SESSION['user_id']?>/1">
      <li>کلیپ ها</li>
    </a>
    <a href="/list_upload/<?=$_SESSION['user_id']?>/1">
      <li>آپلود ها</li>
    </a>
    <a href="/all_clip_buy/<?=$_SESSION['user_id']?>/1">
      <li>خرید ها
     <?
     $RecordCount=CommentModel::Comment_Vote_ConutNotRead($_SESSION['user_id']);
     ?>
     <span id="comment-items"><?=$RecordCount?></span>
    </li>
    </a>
    <a href="/notices/<?=$_SESSION['user_id']?>">
      <li>اطلاع رسانی</li>
    </a>
  </ul>
</div>
<div class="title">مدیریت پیام</div>
<div class="titrbox">
  <ul>
        <a href="/question_all/<?=$_SESSION['user_id']?>/1">
  <!--  <li>سوالات
        <?/*
        $RecordCount=QuestionModel::Question_ConutNotRead($id);
          foreach ($record as $feild) {
            if($feild['status']==1){$counter++;}
          }
        */?>
        <span id="comment-items" style=" " ><?/*=$counter*/?></span>
    </li>-->
    </a>
      <a href="/all_notifications/<?=$_SESSION['user_id']?>/1">
    <li>اعلان ها
        <?
       $RecordCount=NotificationModel::notification_ConutNotRead($_SESSION['user_id']);
        ?>
        <span id="comment-items" style=" " ><?=$RecordCount?></span>
    </li>
    </a>
    <a href="/all_message/<?=$_SESSION['user_id']?>/1">
    <li>پیام ها
        <?
      $record=UserModel::message_ConutNotRead($_SESSION['user_id']);
      ?>
      <span id="comment-items"  ><?=$record?></span>
    </li>
    </a>
      <a href="/support_all_ticket/<?=$_SESSION['user_id']?>/1">
    <li>پشتیبانی
        <?
       $RecordCount=SupportModel::support_ConutNotRead($_SESSION['user_id']);
      ?>
        <span id="comment-items" style=" " ><?=$RecordCount?></span>
    </li>
    </a>
  </ul>
</div>
<div class="title">مدیریت مالی</div>
<div class="titrbox">
  <ul>
    <a href="/cash_user/<?=$_SESSION['user_id']?>"><li>حساب مالی</li></a>
    <a href="/deposits/<?=$_SESSION['user_id']?>/1"><li>واریزی ها</li></a>
    <a href="/withdraw_money/<?=$_SESSION['user_id']?>/1"><li> برداشت ها</li></a>
  </ul>
</div>
<div class="title">تنظیمات</div>
<div class="titrbox">
  <ul>
    <a href="/change_password/<?=$_SESSION['user_id']?>"><li>تغییر پسورد</li></a>
  </ul>
</div>
<div class="titrbox">
  <ul>
    <a href="/user/logout/<?=$_SESSION['user_id']?>"><li><?=_exit?></li></a>
  </ul>
</div>


