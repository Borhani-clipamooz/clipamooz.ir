<?php
class ClipModel {

  public static function insert($user_id,$name_fa,$short_desc_fa,$long_desc_fa,
                                $clip_link,$clip_prev_link,$img_link,$clip_long_time,$clip_size,$price,$category
                                ,$subcategory,$views,$opens,$buy_num,$created_at,$sumscore,$rating,$status
                                ,$clip_api_key,$uploadfile,$video_tag1,$video_tag2,$video_tag3,$video_tag4,$video_tag5){
    $db = Db::getInstance();
    $db->query("INSERT INTO clips (user_id,name_fa,short_desc_fa,long_desc_fa,
                                   clip_link,clip_prev_link,img_link,clip_long_time,clip_size,price
                                   ,category,subcategory,views,opens,buy_num
                                   ,created_at,sumscore,rating,status,clip_api_key,uploadfile,video_tag1,video_tag2
                                   ,video_tag3,video_tag4,video_tag5)
             VALUES (:user_id, :name_fa, :short_desc_fa,:long_desc_fa,
                       :clip_link,:clip_prev_link,:img_link,:clip_long_time,:clip_size,:price
                       ,:category,:subcategory,:views,:opens,:buy_num
                       ,:created_at,:sumscore
                       ,:rating,:status,:clip_api_key,:uploadfile,:video_tag1,:video_tag2,:video_tag3
                       ,:video_tag4,:video_tag5)",
      array(
        'user_id'         => $user_id,
        'name_fa'         => $name_fa,
        'short_desc_fa'         => $short_desc_fa,
        'long_desc_fa'         => $long_desc_fa,
        'clip_link'         => $clip_link,
        'clip_prev_link'         => $clip_prev_link,
        'img_link'         => $img_link,
        'clip_long_time'         => $clip_long_time,
        'clip_size'         => $clip_size,
        'price'         => $price,
        'category'         => $category,
        'subcategory'         => $subcategory,
        'views'         => $views,
        'opens'         => $opens,
        'buy_num'         => $buy_num,
        'created_at'         => $created_at,
        'sumscore'         => $sumscore,
        'rating'         => $rating,
        'status'         => $status,
        'clip_api_key'         => $clip_api_key,
        'uploadfile'         => $uploadfile,
        'video_tag1'         => $video_tag1,
        'video_tag2'         => $video_tag2,
        'video_tag3'         => $video_tag3,
        'video_tag4'         => $video_tag4,
        'video_tag5'         => $video_tag5,
      ));


  }

  public static function update($id,$user_id,$name_fa,$short_desc_fa,$clip_prev_link,$clip_link,$price,$video_tag1,$video_tag2,$video_tag3
                                ,$video_tag4,$video_tag5){
    $db = Db::getInstance();
    $db->modify("UPDATE clips SET  user_id=:user_id,name_fa=:name_fa
                                   ,short_desc_fa=:short_desc_fa
                                   ,clip_prev_link=:clip_prev_link
                                   ,clip_link=:clip_link
                                   ,price=:price,video_tag1=:video_tag1
                                   ,video_tag2=:video_tag2,video_tag3=:video_tag3,video_tag4=:video_tag4
                                   ,video_tag5=:video_tag5

     WHERE id=:id",
      array(
      'id' => $id,
        'user_id'         => $user_id,
        'name_fa'         => $name_fa,
        'short_desc_fa'         => $short_desc_fa,
        'clip_prev_link'         => $clip_prev_link,
        'clip_link'         => $clip_link,
        'price'         => $price,
        'video_tag1'         => $video_tag1,
        'video_tag2'         => $video_tag2,
        'video_tag3'         => $video_tag3,
        'video_tag4'         => $video_tag4,
        'video_tag5'         => $video_tag5,

    ));
  }
  public static function update_long_desc($id,$long_desc_fa){
    $db = Db::getInstance();
    $db->modify("UPDATE clips SET  long_desc_fa=:long_desc_fa
     WHERE id=:id",
      array(
      'id' => $id,
        'long_desc_fa'         => $long_desc_fa,
    ));
  }
  public static function relation_clip($subcategory)
  {
    $db = Db::getInstance();
    $record = $db->query("SELECT * FROM clips WHERE (subcategory=$subcategory)AND (status=1) ORDER BY opens DESC LIMIT 4 OFFSET 0");
    return $record;

  }

  public static function Complete_Search($startIndex,$count,$keyword)
  {
    $db=Db::getInstance();
     $record=$db->query("select * from clips where (name_fa LIKE '%$keyword%')AND (status=1) LIMIT $startIndex,$count");
    return $record;
  }
  public static function Search($keyword)
  {
    $SortType=" ASC";
    $db=Db::getInstance();
    $record=$db->query("select * from clips where name_fa LIKE '%{$keyword}%'AND (status=1) LIMIT 0,4");
    return $record;

  }


  //*********popular_clip********************************************************************************************************************
  public static function popular_clip2()
  {
    $startIndex=0;
    $count=4;
    $SortType="ASC";
    $db=Db::getInstance();
    $record=$db->query("select * from clips ORDER BY sumscore DESC LIMIT 4 OFFSET 4");
    return $record;

  }
  public static function popular_clip3()
  {
    $startIndex=5;
    $count=8;
    $SortType="ASC";
    $db=Db::getInstance();
    $record=$db->query("select * from clips ORDER BY sumscore DESC LIMIT 4 OFFSET 8");
    return $record;

  }
  public static function popular_clip4()
  {
    $startIndex=12;
    $count=16;
    $SortType="ASC";
    $db=Db::getInstance();
    $record=$db->query("select * from clips ORDER BY sumscore DESC LIMIT 4 OFFSET 12");
    return $record;

  }
// END popular_clip **************************************************************************************************************************

  public static function HighScoreClip()
  {
    $startIndex=0;
    $count=8;
    $SortType="ASC";
    $db=Db::getInstance();
    $record=$db->query("select * from clips ORDER BY sumscore DESC LIMIT $startIndex,$count");
    return $record;

  }
  public static function ChangeSelectCategory_SubCategory($id,$parent_cat, $sub_cat){
    $db = Db::getInstance();
    $db->modify("UPDATE clips SET  category=:category,subcategory=:subcategory
     WHERE id=:id",
      array(
        'id' => $id,
        'category'         => $parent_cat,
        'subcategory'         => $sub_cat,

    ));
  }
  public static function ViewSubCategoryID($parent_cat)
  {
    $db=Db::getInstance();
    $record=$db->query("select * from subcategories WHERE categoryID = {$parent_cat} ");
    return $record;

  }

  public static function SumScore($id, $sumscore){
    $db = Db::getInstance();
    $db->modify("UPDATE clips SET  sumscore=:sumscore
     WHERE id=:id",
      array(
        'id' => $id,
        'sumscore'         => $sumscore,

    ));
  }



  public static function insert_rating($clip_id,$count_rate,$average
    ,$rate1,$rate2,$rate3,$rate4,$rate5,$voters){
    $db = Db::getInstance();
    $db->query("INSERT INTO rating (clip_id,count_rate,average,rate1,rate2,rate3,rate4,rate5,voters)
             VALUES ( :clip_id, :count_rate, :average,:rate1,:rate2,:rate3,:rate4,:rate5,:voters)",
      array(
        'clip_id'         => $clip_id,
        'count_rate'         => $count_rate,
        'average'         => $average,
        'rate1'         => $rate1,
        'rate2'         => $rate2,
        'rate3'         => $rate3,
        'rate4'         => $rate4,
        'rate5'         => $rate5,
        'voters'         => $voters,
      ));


  }

  public static function view_SumScore($id)
  {
    $db=Db::getInstance();
    $record=$db->query("select * from clips where id=:id",array('id'=>$id,));
    return $record;

  }
  public static function DelSqlRecord($id)
  {
    $db=Db::getInstance();
    $db->query_insert("DELETE FROM clips where id=:id",array('id'=>$id,));

  }
  public static function Clip_ConutNotRead()
  {
    $db=Db::getInstance();
    $record=$db->first("select count(*) AS total from clips where (status like '0')",array(),'total');
    return $record;

  }

  public static function insert_notices($user_id){
    $db = Db::getInstance();
    $db->query("INSERT INTO notices (user_id)
             VALUES ( :user_id)",
      array(
        'user_id'         => $user_id,
      ));
  }
  public static function insert_uploader($user_id,$upload_name,$address){
    $db = Db::getInstance();
    $db->query("INSERT INTO uploader (user_id,upload_name,address)
             VALUES ( :user_id,:upload_name,:address)",
      array(
        'user_id'         => $user_id,
        'upload_name'         => $upload_name,
        'address'         => $address,
      ));
  }


}