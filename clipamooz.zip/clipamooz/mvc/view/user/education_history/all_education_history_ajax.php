<div class="content">
  <div class="all_education_history_ajax_panel">
  <div id="education_history" class="titrbox "> <h1>&nbsp;&nbsp;سوابق تحصیلی :<i id="icon_education_history_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
    <div class="row tac">
      <div class="colx-1 ">
        <h2 >جزئیات</h2>
      </div>
      <div class="colx-1 ">
        <h2 >حذف</h2>
      </div>
      <div class="colx-1 ">
        <h2 >مقطع تحصیلی</h2>
      </div>
      <div class="colx-2">
        <h2>رشته تحصیلی</h2>
      </div>
      <div class="colx-1">
        <h2>گرایش</h2>
      </div>
      <div class="colx-1">
        <h2>زمان تحصیل</h2>
      </div>
      <div class="colx-1">
        <h2>کشور- شهر</h2>
      </div>
      <div class="colx-2">
        <h2>نام واحد آموزشی</h2>
      </div>
      <div class="colx-1">
        <h2>معدل</h2>
      </div>
    </div>
    <?
     foreach ($list as $field)
    {?>
      <div class="row tac">
        <div class="colx-1">
          <h3 style="cursor: pointer" onclick="View_Detail(<?= $field['id']?>)"><i class="icon-folder-open large"></i></h3>
        </div>
        <div class="colx-1">
          <h3  style="cursor: pointer" onclick="Remove_item(<?= $field['id']?>,'education_history',<?=$field['user_id']?>)"><i class="icon-bin"></i></h3>
        </div>
        <div class="colx-1">
          <h3><?=$field['education_level']?></h3>
        </div>
        <div class="colx-2">
          <h3><?=$field['field_of_study']?></h3>
        </div>
        <div class="colx-1">
          <h3><?=$field['trend']?></h3>
        </div>
        <div class="colx-1">
          <h3><?=$field['term_of_study']?></h3>
        </div>
        <div class="colx-1">
          <h3><?=$field['country']?></h3>
        </div>
        <div class="colx-2">
          <h3><?=$field['name_of_education_unit']?></h3>
        </div>
        <div class="colx-1">
          <h3><?=$field['average']?></h3>
        </div>
      </div>
    <?}?>
  </div><!--     END  education_history ****************-->

<!--        --><?//$user_id= $feild['user_id']?>
  <div class="education_history_panel_responsive">
  <div id="education_history_responsive" class="titrbox "> <h1>&nbsp;&nbsp;سوابق تحصیلی :<i id="icon_education_history_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
    <?
    foreach ($list as $field)
    {?>
      <div class="row">
        <div class="colx-2 ">
          <h2 >جزئیات</h2>
        </div>
        <div class="colx-2">
          <h3 style="cursor: pointer" onclick="View_Detail(<?= $field['id']?>)"><i class="icon-folder-open large"></i></h3>
        </div>
      </div>
      <div class="row">
        <div class="colx-2 ">
          <h2 >حذف</h2>
        </div>
        <div class="colx-2">
          <h3  style="cursor: pointer" onclick="Remove_item(<?= $field['id']?>,'education_history',<?=$field['user_id']?>)"><i class="icon-bin"></i></h3>
        </div>
      </div>
      <div class="row">
        <div class="colx-2 ">
          <h2 >مقطع تحصیلی</h2>
        </div>
        <div class="colx-2">
          <h3><?=$field['education_level']?></h3>
        </div>
      </div>
      <div class="row">
        <div class="colx-2">
          <h2>رشته تحصیلی</h2>
        </div>
        <div class="colx-2">
          <h3><?=$field['field_of_study']?></h3>
        </div>
      </div>
      <div class="row">
        <div class="colx-2">
          <h2>گرایش</h2>
        </div>
        <div class="colx-2">
          <h3><?=$field['trend']?></h3>
        </div>
      </div>
      <div class="row">
        <div class="colx-2">
          <h2>زمان تحصیل</h2>
        </div>
        <div class="colx-2">
          <h3><?=$field['term_of_study']?></h3>
        </div>
      </div>
      <div class="row">
        <div class="colx-2">
          <h2>نام واحد آموزشی</h2>
        </div>
        <div class="colx-2">
          <h3><?=$field['name_of_education_unit']?></h3>
        </div>

      </div>
      <div class="row">
        <div class="colx-2">
          <h2>معدل</h2>
        </div>
        <div class="colx-2">
          <h3><?=$field['average']?></h3>
        </div>
      </div>
      <hr>
    <?}?>
  </div>
  <div class="row tac">
  <button class="btn_style btn-brown" onclick="Insert_all_education_history_ToSql(<?=$_SESSION['user_id']?>)" >مقطع جدید را اضافه بفرمایید</button>
  </div>
  <!-- END education_history_responsive ******************-->
</div>

<script>

  function View_Detail(id){
    $.ajax({
      url: '/user/detail_education_history/' + id,
      method: 'POST',
      dataType: 'json',
      data: {
      },
      success: function (output) {
        //console.log(output);
        $("#paginationUpdate").html(output.html);
      }
    });
  }
  function Insert_all_education_history_ToSql(user_id) {
    $.ajax({
      url: '/user/Insert_all_education_history_ToSql/'+user_id,
      type: 'POST',
      dataType: 'json',
      data:{
      },
      success: function (data) {
        $("#paginationUpdate").html(data.html);
      }
    });
  }
  function Remove_item(id,table_name,user_id) {
    swal({
        title: "آیا مطمئن هستید؟",
        text: "شما دیگر قادر به بازیابی این فایل نخواهید بود.",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#5d4126",
        confirmButtonText: "آره، آن را حذف کنید.",
        cancelButtonText: "لغو",
        closeOnConfirm: false
      },
      function(){
        $.ajax({
          url: '/user/Remove_item_education_history/'+user_id,
          type: 'POST',
          dataType: 'json',
          data:{
            id:id,
            table_name:table_name
          },
          success: function (data) {
            $("#paginationUpdate").html(data.html);
          }
        });
        swal("حذف گردید.");
      });

  }
</script>


