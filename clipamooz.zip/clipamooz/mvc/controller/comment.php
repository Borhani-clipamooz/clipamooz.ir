<?php


class CommentController {
  public function __construct() {

  }


  public function Save_Comment() {
    $clip_id = $_POST['clip_id'];
    $user_id = $_POST['user_id'];
    $comment = $_POST['comment'] ;
    CommentModel::insert($clip_id,$user_id,$comment,getCurrentDateTime());
    $data=CommonModel::Fetch_by_two('clips_buy','user_id',$user_id,'clip_id',$clip_id);
    CommonModel::update_spacial_field($data['id'],'clips_buy','status_comment',1);

    echo json_encode(array('status' => true, ));
  }
  public function all($pageIndex) {
    if (!isSuperAdmin()) {
      header("Location:/");
      return;
    }
    $result = CommonModel::View_All('comments');
    if (count($result) == 0) {
      message("not-found-information", _not_found_information);
      return;
    }
    $NameTable = 'comments';
    $keyword = "";
    $SearchFiled = "comment";
    $SortType = "id";
    $groupby='';
    $data = ListAjax($NameTable, $pageIndex,$SearchFiled,$keyword,$SortType,$groupby);
    View::renderCPanelSuperAdmin("/superadmin/comment/all_comment.php", $data);


  }
  public function RefreshData($pageIndex) {
    $NameTable = 'comments';

    if (isset($_POST['SearchFiled'])) {
      $SearchFiled = $_POST['SearchFiled'];
    } else {
      $SearchFiled = "comment";
    }
    if (isset($_POST['keyword'])) {
      $keyword = $_POST['keyword'];
    } else {
      $keyword = "";
    }
    $SortType = "id";
    $groupby='';
    $data = ListAjax($NameTable, $pageIndex,$SearchFiled, $keyword,$SortType,$groupby);
    ob_start();
    View::renderPartial("/superadmin/comment/all_comment_ajax.php", $data);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output));

  }



  public function view($id) {
    if (isset($_POST['pageIndex'])) {
      $pageIndex = $_POST['pageIndex'];
    } else {
      $pageIndex = 1;
    }
    $result =CommentModel::view_single($id);
    $record = $result[0];
    ob_start();
    $record['pageIndex'] = $pageIndex;
    View::renderPartial("/comment/detail_comment.php", $record);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }
  public function Remove_sql_data($Id) {
    ob_start();
    CommentModel::DelSqlRecord($Id);
    ob_get_clean();
    if (isset($_POST['pageIndex'])) {
      $pageIndex = $_POST['pageIndex'];
    } else {
      $pageIndex = 1;
    }
    $this->RefreshData($pageIndex);
  }
}