<script>
  $(document).ready(function(){
    $("#replay").click(function(){
      $("#replay_panel").slideToggle("slow");
    });
  });
</script>
<div class=" content">

<table id="replay">
  <colgroup>
    <col width="10%">
    <col width="90%">
  </colgroup>
     <tr>
        <td  class="read-more"><span><?= $subject ?></span></td>
    </tr>
     <tr>
       <td style="cursor: pointer"><i class="icon-reply large"></i>پاسخ: <i class="icon-arrow-down large"></i></td>
    </tr>
</table>
<!--  <div id="replay" class="titrbox " style="border: 1px solid #000;border-radius: 5px;background:#5f4126;color: #ffe;" > <td class="read-more">--><?//= $subject ?><!--</td> <b style="top: -6px;position: relative;"> <i class="icon-reply huge"></i></b></div>-->
  <div id="replay_panel" style="display: none">
    <textarea id="body"  style="height: 150px;width: 99%"></textarea>
    <div><button class="btn_style btn-brown"  id="send" onclick="Replay_notification()">ارسال</button></div>
  </div>

       <input style="display: none"  id="user_id" value="<?=$_SESSION['user_id']?>">
       <input style="display: none" id="subject" value="<?=$subject?>">
       <input style="display: none" id="ticket_id" value="<?=$ticket_id?>">
       <input style="display: none" id="clip_id" value="<?=$clip_id?>">
       <input style="display: none" id="clip_name" value="<?=$clip_name?>">
       <input style="display: none" id="reciver_id" value="<?=$sender_id?>">
       <input style="display: none" id="pageIndex" value="<?=$pageIndex?>">
<table>
  <colgroup>
    <col width="5%">
    <col width="10%">
    <col width="70%">
    <col width="15%">
  </colgroup>
  <thead>
  <tr>
    <th class="tac">پروفایل</th>
    <th class="tac">نام کاربری</th>
    <th class="tac">پیام</th>
    <th class="tac">تاریخ</th>
  </tr>
  </thead>
  <? foreach ($list as $feild) {?>
    <?$data=CommonModel::Fetch_by_every('users','id',$feild['sender_id']);?>
    <tr>
    <td>
      <?  if($data['profile_pic'] !=''){?>
        <a  href="/profile/<?=$data['id']?>" style="color: #f88;font-size: 14pt"><img style="width: 40px;height: 40px;border-radius: 50px" src="<?=$data['profile_pic']?>"></a>
      <?}else{?>
        <a  href="/profile/<?=$data['id']?>" style="color: #f88;font-size: 14pt"><img style="width: 40px;height: 40px;border-radius: 50px" src="/asset/images/empty/empty-profile/empty-profile-24.png"></a>
      <?}?>
    </td>
    <td ><?= $data['user_name'] ?></td>
       <td><?= $feild['body_notification'] ?></td>
      <td ><?=DateTimeCommon( $feild['created_at'] )?></td>
    </tr>
    <?}?>




</table>

  <button class="btn_style btn-brown" onclick="back(<?= $pageIndex ?>)">برگشت</button>
</div>
<script>
  function Replay_notification(){
    var subject=$("#subject").val();
    var user_id=$("#user_id").val();
    var ticket_id=$("#ticket_id").val();
    var reciver_id=$("#reciver_id").val();
    var clip_id=$("#clip_id").val();
    var clip_name=$("#clip_name").val();
    var body=$("#body").val();
    var pageIndex=$("#pageIndex").val();

    $.ajax({
      url:'/Replay_notification/',
      type: 'POST',
      dataType:'json',
      data:{
        user_id:user_id,
        ticket_id:ticket_id,
        reciver_id:reciver_id,
        clip_id:clip_id,
        clip_name:clip_name,
        subject:subject,
        body:body
      },
      success:function(data){
        back(pageIndex)
      }
    });

  }
  function back(pageIndex){
    all_notification(pageIndex);
  }
</script>
