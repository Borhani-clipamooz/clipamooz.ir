  <div class="recommended-grids">
    <div class="recommended-info">
      <h3>محبوب ترین ها</h3>
    </div>
    <? foreach ($list as $feild) {?>
      <div class="col-md-3 resent-grid  ">
        <div class="resent-grid-img">
          <a href="single.html"><img src="<?= $feild['img_link']?>" alt="" /></a>
          <div class="boxImg">&nbsp;
            <div class="time">
              <span class=" icon-clock" aria-hidden="true"><span style="font-family: traffic">&nbsp;<?= gmdate("H:i:s", $feild['clip_long_time'])?></span></span>
            </div>
            <div class="time1">
              <span class=" icon-eye" aria-hidden="true"><span style="font-family: traffic">&nbsp;<?= $feild['opens']?></span></span>
            </div>
            <div class="time2">
              <span class="glyphicon icon-play" aria-hidden="true"><span style="font-family: traffic">&nbsp;<?= $feild['views']?></span></span>
            </div>

          </div>
        </div>
        <div class="resent-grid-info recommended-grid-info">
          <h3><a href="single.html" class="title title-info"><?= $feild['short_desc_fa']?></a></h3>
          <ul>
            <li><p class="author author-info"><a href="#" class="author"><?= $feild['name_fa']?></a></p></li>
            <?$data=ClipModel::View_Category();
            $namecategory="";
            foreach($data as $filed1){
              if ($filed1['id']== $feild['category'])
              {$namecategory=$filed1['name_fa'];
              }
            }
            ?>
            <li class="right-list"><p>دسته بندی : &nbsp;<?= $namecategory?></p></li>
          </ul>
        </div>
      </div>
    <?}?>
    <div class="clearfix"> </div>
  </div>