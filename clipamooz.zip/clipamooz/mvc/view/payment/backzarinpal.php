<?php
$MerchantID = '2ba6aa08-94ad-48c1-b46e-651c4958fc16'; //Required
$Amount =  $_SESSION['Amount'];
$Authority = $_GET['Authority'];
$clientId = $_SESSION['clientId'];
$orderKind = $_SESSION['orderKind'];
$userId = $_SESSION['userId'];
if ($_GET['Status'] == 'OK') {
  $client = new SoapClient('https://www.zarinpal.com/pg/services/WebGate/wsdl', ['encoding' => 'UTF-8']);
  $result = $client->PaymentVerification(
    [
      'MerchantID' => $MerchantID,
      'Authority' => $Authority,
      'Amount' => $Amount,
    ]
  );

  if ($result->Status == 100) {
    ?>

    <div class="row">
      <img  style="width: 150px;height: 100px;" src="/asset/images/logo/logo.png">
    </div>
    <div class="row">
      <div class="colx-4 colm-fill cols-fill"></div>
      <div class="colx-4 colm-fill cols-fill"><h5>  رسید دیجیتال شما</h5></div>
      <div class="colx-4 colm-fill cols-fill"></div>
    </div>

    <div class="row message_payment">
      <div class="colx-4 colm-fill cols-fill"></div>
      <div class="colx-4 colm-fill cols-fill"><h6><?=$result->RefID?></h6>شماره ارجاع : </div>
      <div class="colx-4 colm-fill cols-fill"></div>
    </div>
    <?finish();?>
    <div class="row message_payment">
      <div class="colx-4 colm-fill cols-fill"></div>
      <div class="colx-4 colm-fill cols-fill"><a class="btn_pay" href="http://sms.clipamooz.ir">بازگشت به پنل پیامک</a></div>
      <div class="colx-4 colm-fill cols-fill"></div>
    </div>
  <?
  } else {
    ?>
    <div class="row message_payment">
      <div class="colx-4 colm-fill cols-fill"></div>
      <div class="colx-4 colm-fill cols-fill"><h6>سیستم دارای خطا :<?=$result->Status?> </h6></div>
      <div class="colx-4 colm-fill cols-fill"></div>
    </div>
    <div class="row message_payment">
      <div class="colx-4 colm-fill cols-fill"></div>
      <div class="colx-4 colm-fill cols-fill">
        <a class="btn_pay" href="http://sms.clipamooz.ir">بازگشت به پنل پیامک</a>
      </div>
      <div class="colx-4 colm-fill cols-fill"></div>
    </div>
    <?
  }
} else {?>
  <div class="row message_payment">
   <div class="colx-4 colm-fill cols-fill"></div>
   <div class="colx-4 colm-fill cols-fill"><h6>توسط کاربر انصراف گردید.</h6></div>
   <div class="colx-4 colm-fill cols-fill"></div>
  </div>
  <div class="row message_payment">
   <div class="colx-4 colm-fill cols-fill"></div>
   <div class="colx-4 colm-fill cols-fill"><a class="btn_pay" href="http://sms.clipamooz.ir">بازگشت به پنل پیامک</a></div>
   <div class="colx-4 colm-fill cols-fill"></div>
  </div>
<?

}

function finish(){
$master_apikey='663141746538386975324C79394C547158424D4C39396C7249766B364D464652592B496D3354484B68704D3D';
$master_url='http://api.kavenegar.com/v1/'.$master_apikey.'/client/fetchbylocalid.json?Localid=1000';
// ***************************************************************************************************************************
$ch = curl_init();
$master='http://api.kavenegar.com/v1/'.$master_apikey.'/client/fetchbylocalid.json?Localid='.$_SESSION['clientId'];
// set url
curl_setopt($ch, CURLOPT_URL, $master);
//return the transfer as a string
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
// $output contains the output string
$output = curl_exec($ch);
$parsed_json = json_decode($output);
$apikey_sub_customer= $parsed_json->entries->apikey;
curl_close( $ch );
$price= $_SESSION['Amount'].'0';
//*********************************************************************************************************************************
$charge_url='http://api.kavenegar.com/v1/'.$master_apikey.'/client/chargecredit.json?apikey='.$apikey_sub_customer.'&Credit='.$price;
$ch_charge = curl_init();
curl_setopt($ch_charge, CURLOPT_URL, $charge_url);
//return the transfer as a string
curl_setopt($ch_charge, CURLOPT_RETURNTRANSFER, 1);
//curl_setopt($ch_charge, CURLOPT_POST,true);
curl_exec($ch_charge);
curl_close( $ch_charge );
}