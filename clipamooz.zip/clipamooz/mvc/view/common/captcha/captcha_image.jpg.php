<?php
//captcha();
header("Content-Type: image/png");
session_start();
 $_SESSION['captcha_code']=null;
  $image=imagecreate(80,40);
  imagecolorallocate($image,196,153,98);
  $text_color= imagecolorallocate($image,255,5,100);
  $code=array();
  for($j=0;$j<20;$j++){
    $line_color= imagecolorallocate($image,rand(0,200),rand(0,200),rand(0,200));
    imageline($image,rand(1,250),rand(1,50),rand(1,250),rand(1,50),$line_color);
  }
  for($i=0;$i<4;$i++){
    $g_code=rand(1,9);
    $code[$i]=$g_code;
    $text_color= imagecolorallocate($image,rand(0,90),rand(0,90),rand(0,90));
    imagettftext($image,rand(19,22),rand(1,5),$i*15,rand(25,30),$text_color,'Sahel-FD.ttf',$g_code);
  }
  imagejpeg($image);
foreach ($code as $item) {
  echo $item;
}

 $_SESSION['captcha_code']=join( $code);
  return $image;

?>
