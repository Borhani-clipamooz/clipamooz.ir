<div class="rtl">
  <strong style="color: #fff">نوع نمایش</strong>
  <select id="UserFind">
    <option value="comment">نظرات</option>
  </select>
  <input type="text" style="width:100px;height: 20px" id="keyword" placeholder="جستجو" value="" autocomplete="off">

</div>
<div id="paginationUpdate"></div>
<script>


  $(function () {
     getPage(<?=$pageIndex?>);
  });

  function getPage(pageIndex) {
    var keyword = $("#keyword").val();
    var SearchFiled = $("#UserFind").val();
    $.ajax({
      url: '/comment/RefreshData/' + pageIndex,
      method: 'POST',
      dataType: 'json',
      data: {
        keyword: keyword,
        SearchFiled: SearchFiled
      },
      success: function (output) {
       // console.log(output);
        $("#paginationUpdate").html(output.html);
      }
    });
  }


</script>









