<div class="content">
      <table>
        <colgroup>
          <col width="40px">
          <col width="40px">
          <col width="500px">
          <col width="500px">
          <col width="500px">
          <col width="500px">
        </colgroup>
        <thead>
        <tr>
          <th class="tac">جزئیات</th>
          <th class="tac">حذف</th>
          <th class="tac">نام فارسی دسته</th>
          <th class="tac">نام انگلیسی دسته</th>
          <th class="tac">نام فارسی زیردسته</th>
          <th class="tac">نام انگلیسی زیردسته</th>
        </tr>
        </thead>
        <tbody>

        <? foreach ($list as $feild) {?>
        <tr>
            <td ><span onclick="View(<?= $feild['id']?>,<?=$pageIndex?>)"><i class="icon-eye large"></i></span></td>

            <td><span onclick=window["Remove_sql_data"](<?= $feild['id']?>,<?=$pageIndex?>)<i class="icon-bin large"></i> </span></td>
          <?$data=CommonModel::View_All('category');
          $name_fa="";
          $name_en="";
          foreach($data as $filed1){
            if ($filed1['id']==$feild['categoryID'])
            {
              $name_fa=$filed1['name_fa'];
              $name_en=$filed1['name_en'];
            }
          }
          ?>
        <td ><?= $name_fa?></td>
        <td ><?= $name_en?></td>
        <td ><?= $feild['subcategory_name'] ?></td>
        <td ><?= $feild['subcategory_english'] ?></td>
        </tr>

        <? } ?>
        </tbody>
      </table>
    <br>
    <!--Buttons Filter-->
    <?=pagination(baseUrl().'/category/all',3,'btn_style btn-brown','btn',$pageIndex,$pageCount,'getPage')?>
  <button class="btn_style btn-brown" onclick="InsertSubCategoryToSql(<?=$pageIndex?>)" >اضافه کردن زیردسته جدید</button>

</div>

<script>
  function InsertSubCategoryToSql(PageIndex) {
    $.ajax({
      url: '/subcategory/InsertSubCategoryToSql/',
      type: 'POST',
      dataType: 'json',
      data:{
        PageIndex:PageIndex
      },
      success: function (data) {
        $("#paginationUpdate").html(data.html);
      }
    });
  }
  function View(Id,PageIndex) {

    $.ajax({
      url: '/subcategory/view/' + Id,
      type: 'POST',
      dataType: 'json',
      data:{
        pageIndex:PageIndex
      },
      success: function (data) {
        $("#paginationUpdate").html(data.html);
      }
    });
  }
  function Remove_sql_data(Id,PageIndex) {
    swal({
        title: "آیا مطمئن هستید؟",
        text: "شما دیگر قادر به بازیابی این فایل نخواهید بود.",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#5d4126",
        confirmButtonText: "آره، آن را حذف کنید.",
        closeOnConfirm: false
      },
      function(){
        $.ajax({
          url: '/subcategory/Remove_sql_data/' + Id,
          type: 'POST',
          dataType: 'json',
          data:{
            pageIndex:PageIndex

          },
          success: function (data) {
            $("#paginationUpdate").html(data.html);
          }
        });
      swal("حذف گردید.");
      });


  }

</script>


