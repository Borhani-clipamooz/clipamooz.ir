<script>
  $(document).ready(function(){
    $("#replay").click(function(){
      $("#replay_panel").slideToggle("slow");
    });
  });
</script>
<div class="content">
  <div class="message_replay_view">
    <div  id="replay" style="cursor: pointer" class="row">
      <i class="icon-reply huge">پاسخ : </i>
      <div class="row read-more"><?= $subject ?></div>
    </div>
    <div id="replay_panel" style="display: none">
      <div class="row"><textarea id="body"  style="height: 150px;width: 100%"></textarea></div>
      <div class="row"><button class="btn_style btn-brown"  id="send" onclick="Replay_Superadmin()">ارسال</button></div>
    </div>
    <div class="row">
      <div class="colx-9"><h2>پیام</h2></div>
      <div class="colx-3"><h2>تاریخ</h2></div>
    </div>
    <? foreach ($list as $feild) {?>
      <?$data=CommonModel::Fetch_by_every('users','id',$feild['sender_user_id']);?>
      <div class="row">
        <div class="colx-9"><?= $feild['body'] ?></div>
        <div class="colx-3"><?=DateTimeCommon( $feild['created_at'] )?></div>
      </div>
    <?}?>
  </div>
  <input style="display: none"  id="user_id" value="<?=$_SESSION['user_id']?>">
  <input style="display: none" id="target_user_id" value="<?=$target_user_id?>">
  <input style="display: none" id="ticket_id" value="<?=$ticket_id?>">
  <input style="display: none" id="subject" value="<?=$subject?>">
  <button class="btn_style btn-brown" onclick="back(<?= $pageIndex ?>)">برگشت</button>
</div>
<script>
  function Replay_Superadmin(){
    var user_id=$("#user_id").val();
    var target_user_id=$("#target_user_id").val();
    var ticket_id=$("#ticket_id").val();
    var body=$("#body").val();
    var subject=$("#subject").val();
    $.ajax({
      url:'/support/Replay_Superadmin/'+user_id,
      type: 'POST',
      dataType:'json',
      data:{
        user_id:user_id,
        target_user_id:target_user_id,
        ticket_id:ticket_id,
        subject:subject,
        body:body
      },
      success:function(data){
        location.reload();
      }
    });

  }
  function back(pageIndex){
    getPage(pageIndex);
  }
</script>
