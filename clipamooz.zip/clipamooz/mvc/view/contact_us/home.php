<div class="content">
  <table style="position: relative;border: 2px solid #603813;border-radius: 5px;">
    <colgroup>
    </colgroup>
    <input type="text"  style="display: none" id="date_question" value="<?=getCurrentDateTime()?>">
    <tr>
      <td colspan="4">کاربر عزیز پیام خود را ارسال نمایید.</td>
    </tr>
   <?if($_SESSION['user_name']!=''){   ?>
    <tr>
      <td rowspan="3" style="width: 30px"></td>
      <td>ارسال کننده</td>
      <td><input  class="tac"  type="text"  value="<?=$_SESSION['user_name']?>"></td>
      <td  style="display: none"><input  class="tac"  type="text" id="sender_message_id" value="<?=$_SESSION['user_id']?>"></td>
      <td rowspan="3" style="width: 30px"></td>
    </tr>
    <?}else{?>
      <tr>
        <td rowspan="5" style="width: 30px"></td>
        <td>نام و نام خانوادگی</td>
        <td><input  class="tac"  type="text"  id="family"></td>
        <td  style="display: none"><input  class="tac"  type="text" id="sender_message_id" value="<?=$_SESSION['user_id']?>"></td>
        <td rowspan="5" style="width: 30px"></td>
      </tr>
      <tr>
        <td>ایمیل</td>
        <td><input  class="tac"  type="text"  value="<?=$_SESSION['user_name']?>"></td>
        <td  style="display: none"><input  class="tac"  type="text" id="sender_message_id" value="<?=$_SESSION['user_id']?>"></td>
      </tr>

      <tr>
        <td>همراه</td>
        <td><input  class="tac"  type="text"  value="<?=$_SESSION['user_name']?>"></td>
      </tr>
    <?}?>
    <!--<tr>

      <td>دریافت کننده</td>
      <input style="display: none" type="text" id="receiver_message_id" value="<?/*=$id*/?>">
      <?/*$data=CommonModel::Fetch_by_every('users','id',$id)*/?>
      <td> <input type="text" class="tac"   value="<?/*=$data['user_name']*/?>"></td>
    </tr>-->
    <tr>

      <td>موضوع</td>
      <td> <input type="text" class="tac"   id="subject"></td>
    </tr>
    <tr>
      <td>متن پیام</td>
      <td><textarea style="width:750px" class="tar" type="text"   id="body_question" ></textarea></td>

    </tr>
    <tr id="message1" style="display: none">
      <td colspan="4"> <span id="message"></span></td>

    </tr>
  </table>
  <button class="btn_style btn-brown" onclick="Send_Message_Contact_us()">ارسال پیام</button>&nbsp;

</div>
<script>
  function Send_Message_Contact_us(){
    var sender_message_id=$('#sender_message_id').val();
    var subject=$('#subject').val();
    //   var receiver_message_id=$('#receiver_message_id').val();
    var receiver_message_id=53;
    if(sender_message_id !=''){
      var body_question=$('#body_question').val();
      if(body_question==''){
        $("#message1").show();
        document.getElementById("message").innerHTML="پیامی نوشته نشده است.";
        return;
      }

      $.ajax({
        url: '/Send_Message_Contact_us/',
        method: 'POST',
        dataType: 'json',
        data: {
          sender_message_id: sender_message_id,
          receiver_message_id: receiver_message_id,
          subject: subject,
          body_question: body_question
        },
        success: function (output) {
          //console.log(output.html);
          $("#message1").show();
          document.getElementById("message").innerHTML="پیام شما با موفقیت ارسال گردید.";
        }
      });
    }else
    {
      var email=$('#email').val();
      if(email==''){
        $("#message1").show();
        document.getElementById("message").innerHTML="ایمیل وارد نشده است.";
        return;
      }
      $.ajax({
        url: '/user/Send_message/',
        method: 'POST',
        dataType: 'json',
        data: {
          sender_message_id: sender_message_id,
          receiver_message_id: receiver_message_id,
          body: body
        },
        success: function (output) {
          //console.log(output.html);
          $("#message1").show();
          document.getElementById("message").innerHTML="پیام شما با موفقیت ارسال گردید.";
        }
      });
    }


  }
</script>