<div class="content">
  <input type="hidden"id="id" value="<?=$id?>">
  <input type="hidden"id="user_id" value="<?=$user_id?>">
<div class="detail_clip_upload">
  <div class="row">
    <div class="colx-2 colm-fill cols-fill"><h2>عنوان</h2></div>
    <div class="colx-10 colm-fill cols-fill"><h3><input style="width: 100%" type="text"  id="name_fa"  name="name_fa" value="<?= $name_fa ?>"></h3></div>
  </div>
  <div class="row">
    <div class="colx-2 colm-fill cols-fill"><h2>توضیحات بلند</h2></div>
    <div class="colx-10 colm-fill cols-fill"><h3><textarea id="long_desc_fa" name="long_desc_fa" style="height: 80px;width: 100%"><?= $long_desc_fa ?></textarea></h3></div>
    <button id="btn_text" class="btn_style btn-brown" onclick="texttiny()"><?=_btn_save?></button>

  </div>
  <div class="row">
    <div class="colx-2 colm-fill cols-fill"><h2>توضیحات کوتاه</h2></div>
    <div class="colx-10 colm-fill cols-fill"><h3>
        <input style="width: 100%" type="text"  id="short_desc_fa" placeholder="165 کاراکتر" name="short_desc_fa" value="<?= $short_desc_fa ?>">
      </h3></div>
  </div>
  <div class="row">
    <div class="colx-2 colm-fill cols-fill"><h2>برچسب ها</h2></div>
    <div class="colx-2 colm-fill cols-fill"><h3><input style="width: 100%" type="text"  id="video_tag1"  value="<?= $video_tag1 ?>"></h3></div>
    <div class="colx-2 colm-fill cols-fill"><h3><input style="width: 100%" type="text"  id="video_tag2"  value="<?= $video_tag2 ?>"></h3></div>
    <div class="colx-2 colm-fill cols-fill"><h3><input style="width: 100%" type="text"  id="video_tag3"  value="<?= $video_tag3 ?>"></h3></div>
    <div class="colx-2 colm-fill cols-fill"><h3><input style="width: 100%" type="text"  id="video_tag4"  value="<?= $video_tag4 ?>"></h3></div>
    <div class="colx-2 colm-fill cols-fill"><h3><input style="width: 100%" type="text"  id="video_tag5"  value="<?= $video_tag5 ?>"></h3></div>
  </div>
  <div class="row">
    <div class="colx-2 colm-fill cols-fill"><h2>قیمت</h2></div>
    <div class="colx-4 colm-fill cols-fill"><h3>
          <input class="tac" id="price" name="price" value="<?= $price ?>" >
      </h3></div>
    <div class="colx-2 colm-fill cols-fill"><h2>دسته بندی</h2></div>
    <div class="colx-4 colm-fill cols-fill"><h3>
        <?
        if($category==0){
          $category=9;
        }
        ?>
        <input type="hidden"id="defaultCategory"value="<?=$category?>">
        <?
        $dataCategory=CommonModel::View_All('category');
        ?>
        <label>&nbsp;&nbsp;&nbsp;&nbsp;دسته</label>
        <select  name="parent_cat" id="parent_cat" style="width:150px;background-color:#a97b50 ; border: 1px solid #322010">
          <?
          foreach($dataCategory as $row){?>
            <option value="<?php echo $row['id']; ?>"><?php echo $row['name_fa']; ?></option>
          <?} ?>
        </select>
        <br/>

        <label>زیردسته</label>

        <input type="hidden" id="defaultSubCategory" value="<?=$subcategory?>">
        <select name="sub_cat" id="sub_cat" style="width:150px;background-color:#a97b50 ; border: 1px solid #322010">
          <?
          $dataSubCategoryID=ClipModel::ViewSubCategoryID($category);
          foreach($dataSubCategoryID as $row){?>
            <option value="<?php echo $row['id']; ?>"><?php echo $row['subcategory_name']; ?></option>
          <?} ?>
        </select>
      </h3></div>
  </div>
  <div class="row">
    <div class="colx-2 colm-fill cols-fill"><h2>عکس</h2></div>
    <div class="colx-4 colm-fill cols-fill"><h3>
        <?
        global $config;
        ?>
        <? if ($img_link !='') {?>
          <div id="deleteImage">
            <img  src="<?=  $config['upload'].$img_link ?>" alt="<?= $name_fa ?>" style=" padding-top:5px;width: 380px;height: 180px"><br>
            <button class="btn_style btn-brown" onclick="Remove_data('<?=$img_link ?>',0,'<?=$id?>','clips','img_link','')"><?=_btn_delete?></button>
          </div>
            <span style="color: #a2120a" id="messageiImage"></span>
        <?}else{?>
         <script>ShowUploaderImage('<?=$id?>','clips','img_link','380','180');</script>
          <div id="ShowUploaderImage"></div>
        <?}?>
      </h3></div>
    <div class="colx-2 colm-fill cols-fill"><h2>آپلود فایل</h2></div>
    <div class="colx-4 colm-fill cols-fill"><h3>
        <?global $config;?>
        <? if ($uploadfile !='') {?>
          <div id="deleteFile">
            <a href="<?=$config['upload'].$uploadfile ?>" download>پیوست کلیپ</a>
            <br>
            <button class="btn_style btn-brown" onclick="Remove_data('<?=$uploadfile ?>',3,'<?=$id?>','clips','uploadfile','')"><?=_btn_delete?></button>
          </div>
            <span style="color: #a2120a" id="messageFile"></span>
        <?}else{?>
          <script>ShowUploaderFile('<?=$id?>','clips','uploadfile');</script>
          <div id="ShowUploaderFile"></div>
        <?}?>
      </h3></div>
  </div>
  <?
  global $config;
  ?>
  <div class="row">
    <div class="colx-2 colm-fill cols-fill"><h2>پیش نمایش</h2></div>
    <div class="colx-4 colm-fill cols-fill">
        <?require(getcwd() . "/mvc/view/clip/excute/clip_prev_link_playing.php")?>
       <input style="width: 100%;" type="text"  id="clip_prev_link" placeholder="ctrl+V بزنید" value="<?= $clip_prev_link ?>">
      </div>
    <div class="colx-2 colm-fill cols-fill"><h2>کلیپ اصلی</h2></div>
    <div class="colx-4 colm-fill cols-fill">
      <?require(getcwd() . "/mvc/view/clip/excute/clip_link_playing.php")?>
      <input style="width: 100%" type="text"  id="clip_link"  value="<?= $clip_link ?>">
     </div>
  </div>
</div>
</div>
<script>

  function texttiny(){
    var content= tinyMCE.activeEditor.getContent();
    $('#btn_text').after('<div id="loader_save"><span class="icon-spinner9 huge spin "></span></div>');
    SaveTextArea(content);
  }
  $(function () {
    tinymce.init({
      selector: 'textarea#long_desc_fa',
      plugins : 'advlist autolink link image lists charmap print preview',
      toolbar: 'insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify  | link image | print',
      menubar: false,
      content_css: '/asset/css/style.min.css'
    });
    var id = $("#id").val();
    $("input").each(function () {
      $(this).on('keyup', function () {
        SaveInput();
      });
      $(this).on('change', function () {
        SaveInput();
      });
    });
    $("textarea").each(function () {
      $(this).on('keyup', function () {
       SaveTextArea();
      });
    });
    $('#parent_cat').val($('#defaultCategory').val());
    $('#sub_cat').val($('#defaultSubCategory').val());
    $("#parent_cat").change(function() {
      var parent_cat=$("#parent_cat").val();
      $('#defaultCategory').val($('#parent_cat').val());
      $(this).after('<div id="loader"><span class="icon-spinner9 huge spin "></span></div>');
      $.ajax({
        url:'/clip/ChangeSelectSubCategory',
        type: 'POST',
        dataType:'json',
        data:{
          parent_cat:parent_cat
        },
        success:function(data){
          $("#sub_cat").html(data.html);
          $('#defaultSubCategory').val($('#sub_cat').val());
          $('#loader').slideUp(200, function() {
            $(this).remove();
          });
          ///console.log(data);
          SaveCategory_Subcategory();
          Save_Subcategory();
        }
      });
    });
    $("#sub_cat").change(function() {
      $('#defaultSubCategory').val($('#sub_cat').val());
      SaveCategory_Subcategory();
      Save_Subcategory();
    });
  });
  function back(pageIndex){
    all_clip_upload(pageIndex);
  }
  function SaveInput(){
    var id=$("#id").val();
    var user_id=$("#user_id").val();
    var name_fa=$("#name_fa").val();
    var price=$("#price").val();
    var video_tag1=$("#video_tag1").val();
    var video_tag2=$("#video_tag2").val();
    var video_tag3=$("#video_tag3").val();
    var video_tag4=$("#video_tag4").val();
    var video_tag5=$("#video_tag5").val();
    var short_desc_fa=$("#short_desc_fa").val();
    var clip_link=$("#clip_link").val();
    var clip_prev_link=$("#clip_prev_link").val();
    $.ajax({
      url:'/clip/update',
      type: 'POST',
      dataType:'json',
      data:{
        id:id,
        user_id:user_id,
        name_fa:name_fa,
        short_desc_fa:short_desc_fa,
        price:price,
        clip_prev_link:clip_prev_link,
        clip_link:clip_link,
        video_tag1:video_tag1,
        video_tag2:video_tag2,
        video_tag3:video_tag3,
        video_tag4:video_tag4,
        video_tag5:video_tag5

      },
      success:function(data){
        //console.log(data);
      }
    });
  }
  function SaveTextArea(content){
    var id=$("#id").val();
    var long_desc_fa=$("#long_desc_fa").val();
    $.ajax({
      url:'/clip/update_long_desc',
      type: 'POST',
      dataType:'json',
      data:{
        id:id,
        long_desc_fa:content
      },
      success:function(data){
        $('#loader_save').slideUp(200, function() {
          $(this).remove();
        });
        //console.log(data);
      }
    });
  }
  function SaveCategory_Subcategory(){
    var id=$("#id").val();
    var parent_cat=$("#defaultCategory").val();
    var sub_cat=$("#defaultSubCategory").val();
//    $('#img_SaveCategory').show();
    $.ajax({
      url:'/clip/ChangeSelectCategory_SubCategory',
      type: 'POST',
      dataType:'json',
      data:{
        id:id,
        parent_cat:parent_cat,
        sub_cat:sub_cat
      },
      success:function(data){
        $("#sub_cat").html(data.html);
//        $('#img_SaveCategory').hide();
      }
    });
  }
  function Save_Subcategory(){
    var id=$("#id").val();
    var sub_cat=$("#defaultSubCategory").val();
    $.ajax({
      url:'/clip/Change_Select_SubCategory',
      type: 'POST',
      dataType:'json',
      data:{
        id:id,
        sub_cat:sub_cat
      },
      success:function(data){
      }
    });
  }
</script>
