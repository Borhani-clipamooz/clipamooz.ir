<?php
class PageController {
    public function Home() {
      $data['canonical']="https://www.clipamooz.ir/";
      $data['description']=_site_name." | "._banner." | "._description;
      $data['pageTitle']=_clipamooz." | "._banner;
      $data['video_tag1']="آموزش نرم افزار";
      $data['video_tag2']="تعریف آموزش";
      $data['video_tag3']="فیلم آموزشی رایگان";
      $data['video_tag4']="آموزش رقص";
      $data['video_tag5']="آموزش کامپیوتر";
      View::render("/page/home.php",$data);
    }
    public function insurance() {
      $data['canonical']="https://www.clipamooz.ir/";
      $data['description']='بیمه عمر و آتیه فرزندان ، بیمه مسئولیت مسئول فنی بیمارستان ، داروخانه ، درمانگاه ، کلینیک ،  بیمه نامه مسئولیت مدنی مدیران مهد کودک ،  بیمه نامه مسئولیت مدنی دارندگان ماشین آلات ،  بیمه مسئولیت مدیر یا هیئت مدیره ساختمان ، بیمه نامه مدیران آژانس های مسافرتی ،  بیمه نامه مسئولیت ﻭﻳﮋه ﻓﻌﺎﻟﯿﺖ ﻫﺎی عمرانی ، بیمه نامه دارندگان و سرویس کاران آسانسور';
      $data['pageTitle']=_clipamooz.' '.'بیمه پاسارگاد';
      $data['video_tag1']="بیمه عمر و آتیه فرزندان";
      $data['video_tag2']="بیمه مسئولیت مسئول فنی بیمارستان ، داروخانه ، درمانگاه ، کلینیک";
      $data['video_tag3']=" بیمه نامه مسئولیت مدنی مدیران مهد کودک";
      $data['video_tag4']=" بیمه نامه مسئولیت مدنی دارندگان ماشین آلات";
      $data['video_tag5']=" بیمه مسئولیت مدیر یا هیئت مدیره ساختمان";
      $data['canonical']="https://www.clipamooz.ir/insurance/بیمه پاسارگاد";
        View::render("/page/insurance.php",$data);
    }
    public function software() {
      $data['canonical']="https://www.clipamooz.ir/";
      $data['description']=_site_name." | "._banner." | "._description;
      $data['pageTitle']=_clipamooz." | "._banner;
      $data['video_tag1']="آموزش نرم افزار";
      $data['video_tag2']="تعریف آموزش";
      $data['video_tag3']="فیلم آموزشی رایگان";
      $data['video_tag4']="آموزش رقص";
      $data['video_tag5']="آموزش کامپیوتر";
      $data['canonical']="https://www.clipamooz.ir/software/نرم افزارهای کاربردی";
        View::render("/page/software.php",$data);
    }
    public function pdf($value) {
      $data['value']=$value;
        View::render("/page/pdf.php",$data);
    }
    public function Main() {
      header("Location:/");
      return;
    }
  public function SideBar() {
    ob_start();
    View::renderPartial("/theme/sidebar.php", array());
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));
  }
  public function Cpanel_user_right_menu($id) {
    $data['id']=$id;
    View::renderPartial("/user/cpanel_user_right_menu.php", $data);
  }
  public function Cpanel_superadmin_user_right_menu() {

    ob_start();
    View::renderPartial("/superadmin/Cpanel_superadmin_user_right_menu.php", array());
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }
  public function Help() {

    ob_start();
    View::renderPartial("/page/help.php", array());
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }
    public function Test() {
        View::render("/page/test.php",array());
    }
    public function UploadFile() {
        View::render("/page/uploadfile.php",array());
    }
    public function ReadFile() {
        View::render("/page/readfile.php",array());
    }
    public function UnzipFile() {
        View::render("/page/unzipfile.php",array());
    }
    public function DeleteFile() {
        View::render("/page/deletefile.php",array());
    }
    public function gettag() {
        View::render("/page/gettag.php",array());
    }

    public function links() {
        $renderer = new Render();
        $renderer->viewFile("/page/links.php", null);
    }
}