<div class=" content">
<table>
    <colgroup>
        <col style="width: 120px">
        <col style="width: 550px">
    </colgroup>

     <tr>
        <td class="comlmn">نام دسته</td>
       <td>
       <input type="hidden"id="id" value="<?=$id?>">
         <input type="hidden"id="defaultCategory"value="<?=$categoryID?>">
<!--        --><?// $dataCategory=ClipModel::View_Category();?>
        <? $dataCategory=CommonModel::View_All('category');?>
       <select  name="parent_cat" id="parent_cat" style="width:150px;background-color:#a97b50 ; border: 1px solid #322010">

         <?
         foreach($dataCategory as $row){?>
           <option value="<?php echo $row['id']; ?>"><?php echo $row['name_fa']; ?></option>
         <?} ?>
       </select>
       </td>
    </tr>
    <tr>
        <td class="comlmn">نام فارسی زیردسته</td>
       <td><input class="tar" type="text"  id="name_fa"  name="name_fa" value="<?= $subcategory_name ?>"></td>
    </tr>
    <tr>
        <td class="comlmn">نام انگلیسی زیردسته</td>
       <td><input class="tal" type="text"  id="name_en"  name="name_en" value="<?= $subcategory_english ?>"></td>
    </tr>
      </ul>
     </td>
    </tr>

</table>

  <button class="btn_style btn-brown" onclick="SaveSubCategory(),back(<?= $pageIndex ?>)">برگشت و ذخیره</button>
  <img id="img" src="/asset/images/loading.gif" style="display: none" />
</div>

<script>
  $(function () {
    $("input").each(function () {
      $(this).on('change', function () {
        var id=$("#id").val();
        var name_fa=$("#name_fa").val();
        var name_en=$("#name_en").val();
        var description_fa=$("#description_fa").val();
        var description_en=$("#description_en").val();
        $.ajax({
          url:'/category/update',
          type: 'POST',
          dataType:'json',
          data:{
            id:id,
            name_fa:name_fa,
            name_en:name_en,
            description_fa:description_fa,
            description_en:description_en
          },
          success:function(data){
            //console.log(data);
          }
        });
      });
    });
    $("textarea").each(function () {
      $(this).on('change', function () {
        var id=$("#id").val();
        var name_fa=$("#name_fa").val();
        var name_en=$("#name_en").val();
        var description_fa=$("#description_fa").val();
        var description_en=$("#description_en").val();
        $.ajax({
          url:'/category/update',
          type: 'POST',
          dataType:'json',
          data:{
            id:id,
            name_fa:name_fa,
            name_en:name_en,
            description_fa:description_fa,
            description_en:description_en
          },
          success:function(data){
            //console.log(data);
          }
        });
      });
    });
    $('#parent_cat').val($('#defaultCategory').val());
    $("#parent_cat").change(function() {
      $('#defaultCategory').val($('#parent_cat').val());
    });
  });
  function back(pageIndex){
    getPage(pageIndex);
  }
  function SaveSubCategory(){
     var id=$("#id").val();
    var parent_cat=$("#defaultCategory").val();
    var name_fa=$("#name_fa").val();
    var name_en=$("#name_en").val();
    $('#img').show();
    $.ajax({
      url:'/subcategory/SaveSubCategory',
      type: 'POST',
      dataType:'json',
      data:{
        id:id,
        parent_cat:parent_cat,
        name_fa:name_fa,
        name_en:name_en
      },
      success:function(data){
        $('#img').hide();
        //console.log(data);
      }
    });
  }
</script>
