<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <script type="text/javascript" src="/mvc/view/rating/src/rating.js"></script>
    <link rel="stylesheet" href="/mvc/view/rating/src/rating.css" type="text/css" media="screen" title="Rating CSS">
</head>

<body>
        <section class="container1">
          <input type="radio" name="example" class="rating" value="1" />
          <input type="radio" name="example" class="rating" value="2" />
          <input type="radio" name="example" class="rating" value="3" />
          <input type="radio" name="example" class="rating" value="4" />
          <input type="radio" name="example" class="rating" value="5" />
        </section>
   <script>
       $('.container1').rating(function(vote, event){
         alert(vote);
         return;
         // we have vote and event variables now, lets send vote to server.
         $.ajax({
           url: '/payment/pay/',
           method: 'POST',
           dataType: 'json',
           data: {
             name_fa: name_fa,
             subcategory: subcategory
           },
           success: function (data) {
             console.log(data.status);

           }
         });
       });

   </script>
</body>
</html>
