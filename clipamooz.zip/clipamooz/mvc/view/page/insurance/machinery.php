<div class="row">
  <section id="section-2">
    <div class="about-landing">
      <div class="container">
        <div class="about-text">
          <h2 style="color: #fffccc;">بیمه نامه مسئولیت مدنی دارندگان ماشین آلات:</h2>
          <p style="margin-top: 50px">
            بيمه ماشین آلات و تجهیزات پیمانکاران کلیه خسارت‌های با منشأ بيرونی وارد بر انواع ماشين آلات و تجهيزات متحرک و یا ثابت مانند:
            لودر، گريدر، بولدوزر، غلتک، سايدبوم، جرثقيل ، تاورکرین ، سنگ شکن ، کارخانه تولید بتن ،لیفتراک ،تسمه های نقاله و... را كه به عنوان ابزار كار پيمانكاران میباشد جبران می نماید .
          </p>
        </div>
        <div class="thumb wow animated zoomIn"><img style="border-radius: 10px" src="/asset/images/insurance/machinery.jpg" alt="ماشین آلات"></div>
      </div>
    </div>
  </section>
  </div>
<div class="row">
  <section>
    <div class="container">
    <div class="info_person">
      <div id="panel1_machinery" class="titrbox "> <h1>&nbsp;&nbsp;خطرات تحت پوشش در بیمه ماشین‌آلات<i id="icon_panel1_machinery_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="panel1_machinery_panel" style="display: none">
        <p style="font-size: 12pt;text-align: justify">
          1- آتش سوزی ،صاعقه ، انفجار
        </p>
        <p style="font-size: 12pt;text-align: justify">
          2- زلزله ، زلزله دریائی ، آتشفشان
        </p>
        <p style="font-size: 12pt;text-align: justify">
          3- رانش زمین ، نشست زمین ، لغزش زمین ، ریزش کوه یا صخره
        </p>
        <p style="font-size: 12pt;text-align: justify">
          4- تگرگ ، یخ زدگی ، یخ شناور
        </p>
        <p style="font-size: 12pt;text-align: justify">
          5- سیل ، آب گرفتگی ، امواج دریا یا آب
        </p>
        <p style="font-size: 12pt;text-align: justify">
          6- طوفان ، گردباد ، تندباد
        </p>
        <p style="font-size: 12pt;text-align: justify">
          7- عدم مهارت ، اجرا با کیفیت نازل
        </p>
        <p style="font-size: 12pt;text-align: justify">
          8- غفلت ، سهل انگاری ، خطای غیر عمد
        </p>
        <p style="font-size: 12pt;text-align: justify">
          9- دزدی
        </p>
        <p style="font-size: 12pt;text-align: justify">
          10- باران ، برف ، بهمن
        </p>
        <p style="font-size: 12pt;text-align: justify">
          11- خسارت‌های ناشی از کاربرد آب یا سایر اقدامات جهت اطفای حریق
        </p>
        <p style="font-size: 12pt;text-align: justify">
          12- سقوط ، تصادم ، واژگونی
        </p>
        <p style="font-size: 12pt;text-align: justify">
          13- خرابکاری غیر گروهی
        </p>
        <p style="font-size: 12pt;text-align: justify">
          14- سایر حوادث به جز آنچه صراحتاً در بیمه‌نامه مستثنی شده است.
        </p>
        <p style="font-size: 12pt;text-align: justify">
          بیمه‌گذار می‌تواند با پرداخت حق بیمه اضافی خسارت وارد به اموال مجاور یا خسارت‌های جانی یا مالی وارد به اشخاص ثالث را نیز تحت پوشش قرار دهد
        </p>
      </div><!--     END  panel1_kindergarten ****************-->
    </div>
    <!--***********  INFO ---   Person   --   Responsive   ********************************************************************************-->
    </div>
  </section>
  <section>
  <p style="font-size: 12pt;color: #fffccc;text-align: right">
            <span>
              <strong>خرید بیمه نامه :</strong>
            </span>
  </p>
  <p style="font-size: 12pt;text-align: justify">
    جهت خرید بیمه نامه لطفا فرم زیر را  دانلود و پس از تکمیل به یکی از روشها شبکه های اجتماعی (سروش ، تلگرام ، واتس آپ ) و یا ایمیل برای اینجانب ارسال نمایید تا فرم اعلام حق بیمه و متعاقب آن صدور بیمه نامه صورت پذیرد .
  </p>
  </section>
  <button class="btn btn-brown" onclick="window.location.href='/pdf/machinery'">دانلود فرم بیمه مسئولیت ماشین آلات</button>
</div>