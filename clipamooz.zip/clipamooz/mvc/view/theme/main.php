<!DOCTYPE html>

<html lang="FA" dir="rtl">
    <?require(getcwd() . "/mvc/view/theme/theme.php");?>
    <?require(getcwd() ."/mvc/view/menu/megamenu.php");?>
  <br><br><br>
    <?= $content ?>
  <?require(getcwd() . "/mvc/view/footer/footer.php");?>
</html>
<?
if (!isset($pageTitle)) {
  $pageTitle = _clipamooz;
}
if (!isset($description)) {
  $description = _description;
}
$ip=$_SERVER['REMOTE_ADDR'];
$table='ip_network';
$feild='ip';
$data=CommonModel::Fetch_by_every($table,$feild,$ip);
if($data)
{
  $_SESSION['ip']=$ip;
}else
{
  Ip_networkModel::insert($ip);
  $_SESSION['ip']=$ip;
}
?>