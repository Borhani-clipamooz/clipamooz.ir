<?php
function has_access($access,$targetaccess){
  return strhas($access,"|$targetaccess|")? true : false;

}
function get_access_name(){
  if(isGuest()){
    return "میهمان";
  }

  $accessName="";

  if(isSuperAdmin()){
      $accessName .=", "."مدیر کل";
  }else if(isAdmin()){
      $accessName .=", "."مدیر";
  }
  if(isVip()){
      $accessName .=", "."عضو ویژه";
  }else if(isUser()){
      $accessName .=", "."کاربر عادی";
  }

  if(isSuperAuthor()){
      $accessName .=", "."نویسنده ویژه";
  }else if(isAuthor()){
      $accessName .=", "."نویسنده";
  }

  return $accessName;
}

function isSuperAdmin(){
  if(isGuest()){return false;}
  $access=$_SESSION['user_access'];
  return(has_access($access,"superadmin"))? true : false;
}

function isAdmin(){
  if(isGuest()){return false;}
  $access=$_SESSION['user_access'];
  if(has_access($access,"superadmin")||has_access($access,"admin")){
    return true;
  }
  return false;
}
function isVip(){
  if(isGuest()){return false;}
  $access=$_SESSION['user_access'];
  return(has_access($access,"vip"))? true : false;
}

function isSuperAuthor(){
  if(isGuest()){return false;}
  $access=$_SESSION['user_access'];
  return(has_access($access,"vipauthor"))? true : false;
}

function isAuthor(){
  if(isGuest()){return false;}
  $access=$_SESSION['user_access'];
  if(has_access($access,"vipauthor")||has_access($access,"author")){
    return true;
  }
  return false;
}

function isGuest() {
  return (!isset($_SESSION['user_access']))?true : false;

}
function isUser() {
  return (isset($_SESSION['user_access']))?true : false;

}
function GrantSuperAdmin(){
  if(!isSuperAdmin()){
    echo 'Forbbiden';
    exit;
  }
}
function GrantAdmin(){
  if(!isAdmin()){
    echo 'Forbbiden';
    exit;
  }
}