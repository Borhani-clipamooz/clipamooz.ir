<div class="row">
  <section id="section-2">
    <div class="about-landing">
      <div class="container">
        <div class="about-text">
          <h2 style="color: #fffccc;">بیمه نامه دارندگان و سرویس کاران آسانسور</h2>
          <p style="margin-top: 50px">
            امروزه آسانسورها در ساختمان های تجاری و مسکونی جزء تاسیسات اساسی به شمار می روند و هرچند که تعمیر و نگهداری دوره ای آسانسور ها از طرف مالکین انجام می شود ولیکن بروز حوادث از سهل انگاری در نگهداری عیوب قسمت های مکانیکی و الکتریکی که ناگهانی بروز می نماید سبب ورود صدمات جانی به استفاده کنندگان از آسانسور می گردد بیمه مسئولیت آسانسور قراردادی است که غرامت فوت و نقص عضو سرنشینان آسانسور را در صورت وقوع حوادث جبران می نماید .
          </p>
        </div>
        <div class="thumb wow animated zoomIn"><img style="border-radius: 10px" src="/asset/images/insurance/elevator_service.jpg" alt="سرویس آسانسور"></div>
      </div>
    </div>
  </section>
  </div>
<div class="row">
  <section>
    <div class="container">
    <!--***********  INFO ---   Person   --   Responsive   ********************************************************************************-->
    <div class="info_person_responsive">
      <div id="panel1_elevator_service_responsive" class="titrbox"> <h1>&nbsp;&nbsp;خطرات تحت پوشش این بیمه نامه شامل موارد زیر <i id="icon_panel1_elevator_service_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="panel1_elevator_service_panel_responsive" style="display: none">
        <p style="font-size: 12pt;text-align: justify">
          جبران خسارت فوت و نقص عضو دائم اعم از کلی و جزئی هر نفر در هر حادثه در ماه های عادی *جبران خسارت فوت هرنفر در هر حادثه در ماه های حرام *جبران خسارت فوت و نقص عضو دائم اعم از کلی و جزئی طی دوره بیمه *جبران هزینه پزشکی های برای هر نفر در هر حادثه *جبران هزینه های پزشکی طی دوره بیمه
        </p>
        <p style="font-size: 12pt;text-align: justify">
          1- شرکت های نصب و نگهداری کننده آسانسور و یا هیئت مدیره ساختمان ها می توانند مسئولیت خود را در مقابل خسارت های جانی وارده به استفاده کنندگان آسانسورها را بیمه نمایند .
        </p>
        <p style="font-size: 12pt;text-align: justify">
          2- حداکثر تعهد بیمه گر برای هر نفر در هر حادثه برای خسارت های جانی فقط فوت و نقص عضو دائم ، اعم از کلی و جزئی معادل دیه یک مرد مسلمان خواهد بود .
        </p>
        <p style="font-size: 12pt;text-align: justify">
          3- حداکثر تعهد بیمه گر برای هزینه های پزشکی ناشی از حادثه برای هر نفر در هر حادثه می تواند تا معادل 10% مبلغ دیه انتخابی موضوع بند 2 تعهدات بیمه گر باشد.
        </p>
        <p style="font-size: 12pt;text-align: justify">
          مبنای محاسبه حق بیمه تعداد آسانسور ، سال ساخت ، محل نصب ، ظرفیت و تعداد توقف آسانسور خواهد بود . 4-
        </p>
      </div>    <!-- END panel1_responsive ******************-->
      </div><!--  END  panel7 Panle Responsive ******************-->
    </div><!--  END info person Responsive  ******************-->
  </section>
  <section style="padding:0 10px 0 10px">
  <p style="font-size: 12pt;color: #fffccc;text-align: right">
            <span>
              <strong>خرید بیمه نامه :</strong>
            </span>
  </p>
  <p style="font-size: 12pt;text-align: justify">
    جهت خرید بیمه نامه لطفا فرم زیر را  دانلود و پس از تکمیل به یکی از روشها شبکه های اجتماعی (سروش ، تلگرام ، واتس آپ ) و یا ایمیل برای اینجانب ارسال نمایید تا فرم اعلام حق بیمه و متعاقب آن صدور بیمه نامه صورت پذیرد .
  </p>
  </section>
  <div class="row">
  <button class="btn btn-brown" onclick="window.location.href='/pdf/elevator_service'">دانلود بیمه نامه دارندگان و سرویس کاران آسانسور</button>
  </div>
</div>