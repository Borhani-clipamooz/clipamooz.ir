<div class="rtl">
  <div class="row">
      <input  class="img_search" style=" padding:20px 20px 0;font-size: 20px"  type="text"  id="keyword_responsive" placeholder="تایپ کنید" value=""  autocomplete="off">
  </div>
  <div id="preview_responsive" style="margin-top: 12px"></div>

</div>

<script>
  $(function(){
    $("#preview_responsive").mCustomScrollbar({
      scrollButtons: {
        enable: true
      },
      theme: "dark"
    });
  });
  document.getElementById('keyword_responsive').focus();
  $("#keyword_responsive").on('keyup', function () {
    responsive_showSearch();
  });


  function responsive_showSearch() {
    var keyword_responsive = $("#keyword_responsive").val();
    if (keyword_responsive=="")
    {
      $("#preview_responsive").html("");
      $("#keyword_responsive").removeClass('loadingGif');
    }else{
      $("#keyword_responsive").removeClass('img_search');
      $("#keyword_responsive").addClass('loadingGif');
      $.ajax({
        url: '/menu/ShowSearch_responsive/',
        method: 'POST',
        dataType: 'json',
        data: {
          keyword_responsive: keyword_responsive
        },
        success: function (output) {
          //console.log(output.keyword1);
          $("#keyword_responsive").removeClass('loadingGif');
          $("#keyword_responsive").addClass('img_search');
          $("#preview_responsive").html(output.html);
        }
      });
    }
  }
</script>