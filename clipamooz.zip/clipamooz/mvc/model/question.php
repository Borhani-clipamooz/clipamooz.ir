<?php
class QuestionModel {
  public static function insert_Question($ticket_id,$subject,$sender_id,$reciver_id,$clip_id
    ,$clip_name,$body_question,$date_question,$status){
    $db = Db::getInstance();
    $db->query("INSERT INTO questions (ticket_id,subject,sender_id,reciver_id,clip_id,clip_name,body_question,date_question,status)
             VALUES ( :ticket_id,:subject,:sender_id,:reciver_id, :clip_id,:clip_name,:body_question,:date_question,:status)",
      array(
        'ticket_id'         => $ticket_id,
        'subject'         => $subject,
        'sender_id'         => $sender_id,
        'reciver_id'         => $reciver_id,
        'clip_id'         => $clip_id,
        'clip_name'         => $clip_name,
        'body_question'         => $body_question,
        'date_question'         => $date_question,
        'status'         => $status,
      ));
  }
  public static function Question_ConutNotRead($user_id)
  {
    $db=Db::getInstance();
    $record=$db->first("select count(*) AS total from questions where (sender_id=$user_id)AND(status like '0')",array(),'total');
    return $record;

  }
  public static function Question_ConutNotRead1($ticket_id)
  {
    $db=Db::getInstance();
    $record=$db->first("select count(*) AS total from questions where (ticket_id='$ticket_id')",array(),'total');
    return $record;

  }
  public static function Fetch_by_all_Distinct($NameTabel,$whichFeild,$content){
    $db = Db::getInstance();
    $record = $db->query("SELECT DISTINCT sender_id FROM $NameTabel WHERE $whichFeild='$content' ",array("$whichFeild"=>$content));
    return $record;
  }


  public static function update1($id,$body_replay,$date_replay,$status){
    $db = Db::getInstance();
    $db->modify("UPDATE questions SET
     body_replay=:$body_replay ,
     date_replay=:$date_replay ,
     status=:$status,

     WHERE id=:id",
      array(
        'id' => $id,
        'body_replay' => $body_replay,
        'date_replay' => $date_replay,
        'status' => $status,
      ));
  }
  public static function update($id,$body_replay,$date_replay,$status){
    $db = Db::getInstance();
    $db->modify("UPDATE questions SET
 body_replay=:body_replay
 , date_replay=:date_replay
 , status=:status
 WHERE id=:id", array(
      'body_replay' => $body_replay,
      'date_replay' => $date_replay,
      'status' => $status,
      'id' => $id,
    ));
  }

}