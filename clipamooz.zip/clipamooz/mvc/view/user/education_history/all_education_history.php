<div id="paginationUpdate"></div>

<script>

   $(function () {
     education_history(<?=$id?>);
  });

  function education_history(id) {
    $.ajax({
      url: '/user/Refresh_all_education_history/'+id,
      method: 'POST',
      dataType: 'json',
      data: {
      },
      success: function (output) {
        //console.log(output);
        $("#paginationUpdate").html(output.html);
      }
    });
  }


</script>









