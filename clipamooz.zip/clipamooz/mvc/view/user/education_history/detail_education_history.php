<div class=" content">
  <div id="education_history" class="titrbox "> <h1>&nbsp;&nbsp;سوابق تحصیلی :<i id="icon_education_history_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
  <div class="education_history_panel">
    <div class="row tac">
      <div class="colx-2 ">
        <h2 >مقطع تحصیلی</h2>
      </div>
      <div class="colx-2">
        <h2>رشته تحصیلی</h2>
      </div>
      <div class="colx-2">
        <h2>گرایش</h2>
      </div>

    </div>
      <div class="row tac">
        <div class="colx-2">
          <h3><input  type="text"  id="education_level"  name="" value="<?=$education_level  ?>"></h3>
        </div>
        <div class="colx-2">
          <h3><input  type="text"  id="field_of_study"  name="" value="<?= $field_of_study ?>"></h3>
        </div>
        <div class="colx-2">
          <h3><input  type="text"  id="trend"  name="" value="<?= $trend ?>"></h3>
        </div>
      </div>
    <div class="row tac">
      <div class="colx-2">
        <h2>زمان تحصیل</h2>
      </div>
      <div class="colx-2">
        <h2>نام واحد آموزشی</h2>
      </div>
      <div class="colx-2">
        <h2>کشور- شهر</h2>
      </div>
    </div>
    <div class="row tac">
      <div class="colx-2">
        <h3><input  type="text"  id="term_of_study"  name="" value="<?= $term_of_study ?>"></h3>
      </div>
      <div class="colx-2">
        <h3><input  type="text"  id="name_of_education_unit"  name="" value="<?= $name_of_education_unit ?>"></h3>
      </div>
      <div class="colx-2">
        <h3><input  type="text"  id="country"  name="" value="<?= $country ?>"></h3>
      </div>
    </div>
    <div class="row tac">
      <div class="colx-2">
        <h2>معدل</h2>
      </div>
      <div class="colx-2"></div>
      <div class="colx-2"></div>

    </div>
    <div class="row tac">
      <div class="colx-2">
        <h3><input class="tac" type="text"  id="average"  name="" value="<?= $average ?>"></h3>
      </div>
      <div class="colx-2">
        <button  class="btn_style btn-brown" onclick="back(<?=$user_id?>)">بازگشت</button>
      </div>
      <div class="colx-2"></div>
    </div>
    <input type="hidden"id="id"value="<?=$id?>">
  </div><!--     END  education_history ****************-->
</div>
<script>
$(function(){
  $("input").each(function () {
    $(this).on('keyup', function () {
      var id=$("#id").val();
      var education_level=$("#education_level").val();
      var field_of_study=$("#field_of_study").val();
      var trend=$("#trend").val();
      var term_of_study=$("#term_of_study").val();
      var name_of_education_unit=$("#name_of_education_unit").val();
      var country=$("#country").val();
      var average=$("#average").val();
     $("#loadsave").show();

      $.ajax({
        url:'/user/detail_education_history_update',
        type: 'POST',
        dataType:'json',
        data:{
          id:id,
          education_level:education_level,
          field_of_study:field_of_study,
          trend:trend,
          term_of_study:term_of_study,
          name_of_education_unit:name_of_education_unit,
          country:country,
          average:average
        },
        success:function(data){

     $("#loadsave").hide();
          //console.log(data);
        }
      });


    });
  });
});
  function back(id){
    education_history(id);
  }
</script>















