<div class="content">

      <table>
        <colgroup>
          <col width="3%">
          <col width="3%">
          <col width="5%">
          <col width="12%">
          <col width="65%">
          <col width="12%">
        </colgroup>
        <thead>
        <tr>

          <th class="tac">پاسخ</th>
          <th class="tac">حذف</th>
          <th class="tac">پروفایل</th>
          <th class="tac">نام کاربری</th>
          <th class="tac">پیام</th>
          <th class="tac">تاریخ</th>
        </tr>
        </thead>
        <tbody>

        <? foreach ($list as $feild) {?>
        <tr>
            <td ><span onclick="View(<?= $feild['id']?>,<?=$pageIndex?>,<?= $feild['sender_message_id']?>)"><i style="cursor: pointer;margin-top: 5px" class="icon-reply large"></i></span></td>
          <td ><span onclick="Remove_item(<?= $feild['id']?>,<?=$pageIndex?>)"><i style="cursor: pointer;margin-top: 5px" class="icon-bin large"></i></span></td>
          <?$data2=CommonModel::Fetch_by_every('users','id',$feild['sender_message_id']);?>
          <td>
            <?  if($data2['profile_pic'] !=''){?>
              <a  href="/profile/<?=$data2['id']?>" style="color: #f88;font-size: 14pt"><img style="width: 40px;height: 40px;border-radius: 50px" src="<?=$data2['profile_pic']?>"></a>
            <?}else{?>
              <a  href="/profile/<?=$data2['id']?>" style="color: #f88;font-size: 14pt"><img style="width: 40px;height: 40px;border-radius: 50px" src="/asset/images/empty/empty-profile/empty-profile-24.png"></a>
            <?}?>
          </td>
        <td ><?= $data2['user_name'] ?></td>
        <td ><?= $feild['body'] ?></td>
        <td ><?= DateTimeCommon($feild['date_receive_message']); ?></td>
        </tr>

        <? } ?>
        </tbody>
      </table>
    <br>
    <!--Buttons Filter-->
  <div style="margin-bottom: 15px"><?=pagination('',3,'btn_style btn-brown','btn',$pageIndex,$pageCount,'all_receiver_message')?></div>

</div>

<script>

  function View(Id,PageIndex,receiver_message_id) {
    $.ajax({
      url: '/user/view_receiver/' + Id,
      type: 'POST',
      dataType: 'json',
      data:{
        receiver_message_id:receiver_message_id,
        pageIndex:PageIndex
      },
      success: function (data) {
        $("#paginationUpdate").html(data.html);
      }
    });
  }
  function Remove_item(Id,PageIndex) {

    $.ajax({
      url: '/user/remove_receiver_message/' + Id,
      type: 'POST',
      dataType: 'json',
      data:{
        pageIndex:PageIndex
      },
      success: function (data) {
        $("#paginationUpdate").html(data.html);
      }
    });
  }
</script>


