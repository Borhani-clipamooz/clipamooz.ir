function _(el){

  return document.getElementById(el);
}
function uploadNEWFile(TypeUpload,select,id,table_name,feild_name,width,height){

  switch (select) {
    case 0:{

      if(_("FileImage").value=='' ) {
        //alert(file.name + " | " + file.size + " | " + file.type);
       swal("لطفا انتخاب فایل انجام دهید.");
        return;
      }
      file = _("FileImage").files[0];
      var size=Math.round(file.size/1024)
      /*if(size>=200 ) {
        //alert(file.name + " | " + file.size + " | " + file.type);
       swal("سایز تصویر بیش از 200 کیلو می باشد تصحیح بفرمایید.");
        return;
      }*/
      var formdata = new FormData();
      formdata.append("file1", file);
      var ajax  = new XMLHttpRequest();
      ajax.upload.addEventListener("progress", progressHandlerFileImage, false);
      ajax.addEventListener("load", completeHandlerFileImage, false);
      ajax.addEventListener("error", errorHandlerFileImage, false);
      ajax.addEventListener("abort", abortHandlerFileImage, false);
      ajax.open("POST", "/uploader/"+TypeUpload+"/"+id+"/"+table_name+"/"+feild_name+"/"+width+"/"+height);
     // ajax.open("POST", "/uploader/"+TypeUpload);
      ajax.send(formdata);
      break;}
    case 1:
    {
      if (_("FilePreviewClip").value == '') {
        swal("لطفا انتخاب فایل انجام دهید.");
        return;
      }
      file = _("FilePreviewClip").files[0];
      var formdata = new FormData();
      formdata.append("file1", file);
      var ajax = new XMLHttpRequest();
      ajax.upload.addEventListener("progress", progressHandlerFilePreviewClip, false);
      ajax.addEventListener("load", completeHandlerFilePreviewClip, false);
      ajax.addEventListener("error", errorHandlerFilePreviewClip, false);
      ajax.addEventListener("abort", abortHandlerFilePreviewClip, false);
      ajax.open("POST", "/uploader/" + TypeUpload + "/" + id + "/" + table_name + "/" + feild_name );
      ajax.send(formdata);
      break;
    }
      case 2:
      {
        if (_("FileClip").value == '') {
          swal("لطفا انتخاب فایل انجام دهید.");
          return;
        }
        file = _("FileClip").files[0];
        var formdata = new FormData();
        formdata.append("file1", file);
        var ajax = new XMLHttpRequest();
        ajax.upload.addEventListener("progress", progressHandlerFileClip, false);
        ajax.addEventListener("load", completeHandlerFileClip, false);
        ajax.addEventListener("error", errorHandlerFileClip, false);
        ajax.addEventListener("abort", abortHandlerFileClip, false);
        ajax.open("POST", "/uploader/" + TypeUpload + "/" + id + "/" + table_name + "/" + feild_name );
        ajax.send(formdata);
        break;
      }
      case 3:
      {
        if (_("FileZip").value == '') {
          swal("لطفا انتخاب فایل انجام دهید.");
          return;
        }
        file = _("FileZip").files[0];
        var formdata = new FormData();
        formdata.append("file1", file);
        var ajax = new XMLHttpRequest();
        ajax.upload.addEventListener("progress", progressHandlerFileZip, false);
        ajax.addEventListener("load", completeHandlerFileZip, false);
        ajax.addEventListener("error", errorHandlerFileZip, false);
        ajax.addEventListener("abort", abortHandlerFileZip, false);
        ajax.open("POST", "/uploader/" + TypeUpload + "/" + id + "/" + table_name + "/" + feild_name );
        ajax.send(formdata);
        break;
      }
      default:
        break;
  }
}
function progressHandlerFileImage(event){
  _("loaded_n_totalFileImage").innerHTML ="آپلود شد "+event.loaded+" بایت ها از "+event.total;
  var percent = (event.loaded / event.total) * 100;
  _("progressBarFileImage").value = Math.round(percent);
  _("statusFileImage").innerHTML = Math.round(percent)+"% در حال آپلود لطفا صبر کنید.";
}
function completeHandlerFileImage(event){
  _("statusFileImage").innerHTML ="فایل با موفقیت آپلود گردید";
  _("progressBarFileImage").value = 0;
  setTimeout(function() {
    location.reload();
  }, 3000);
}
function errorHandlerFileImage(event){
  _("statusFileImage").innerHTML = "Upload Failed";
}
function abortHandlerFileImage(event){
  _("statusFileImage").innerHTML = "Upload Aborted";
}

function progressHandlerFileZip(event){
  _("loaded_n_totalFileZip").innerHTML ="آپلود شد "+event.loaded+" بایت ها از "+event.total;
  var percent = (event.loaded / event.total) * 100;
  _("progressBarFileZip").value = Math.round(percent);
  _("statusFileZip").innerHTML = Math.round(percent)+"% در حال آپلود لطفا صبر کنید.";
}
function completeHandlerFileZip(event){
  _("statusFileZip").innerHTML ="فایل با موفقیت آپلود گردید";
  _("progressBarFileZip").value = 0;
  setTimeout(function() {
  location.reload();
  }, 3000);
}
function errorHandlerFileZip(event){
  _("statusFileZip").innerHTML = "Upload Failed";
}
function abortHandlerFileZip(event){
  _("statusFileZip").innerHTML = "Upload Aborted";
}

function progressHandlerFileClip(event){
  _("loaded_n_totalFileClip").innerHTML ="آپلود شد "+event.loaded+" بایت ها از "+event.total;
  var percent = (event.loaded / event.total) * 100;
  _("progressBarFileClip").value = Math.round(percent);
  _("statusFileClip").innerHTML = Math.round(percent)+"% در حال آپلود لطفا صبر کنید.";
}
function completeHandlerFileClip(event){
  _("statusFileClip").innerHTML ="فایل با موفقیت آپلود گردید";
  _("progressBarFileClip").value = 0;
 // location.reload();
}
function errorHandlerFileClip(event){
  _("statusFileClip").innerHTML = "Upload Failed";
}
function abortHandlerFileClip(event){
  _("statusFileClip").innerHTML = "Upload Aborted";
}
function progressHandlerFilePreviewClip(event){
  _("loaded_n_totalFilePreviewClip").innerHTML ="آپلود شد "+event.loaded+" بایت ها از "+event.total;
  var percent = (event.loaded / event.total) * 100;
  _("progressBarFilePreviewClip").value = Math.round(percent);
  _("statusFilePreviewClip").innerHTML = Math.round(percent)+"% در حال آپلود لطفا صبر کنید.";
}
function completeHandlerFilePreviewClip(event){
  _("statusFilePreviewClip").innerHTML ="فایل با موفقیت آپلود گردید";
  _("progressBarFilePreviewClip").value = 0;
  setTimeout(function() {
    location.reload();
  }, 3000);
}
function errorHandlerFilePreviewClip(event){
  _("statusFilePreviewClip").innerHTML = "Upload Failed";
}
function abortHandlerFilePreviewClip(event){
  _("statusFilePreviewClip").innerHTML = "Upload Aborted";
}