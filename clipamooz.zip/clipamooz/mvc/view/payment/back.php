<div class="content">
  <div class="signin" style="line-height: 30px">
  <div class="row">
    <img  style="width: 150px;height: 100px;" src="/asset/images/logo/logo.png">
  </div>
  <div class="row">
   رسید دیجیتال شما
  </div>
  <div class="row">
    <div class="colx-5">    شماره ارجاع:    </div>
    <div class="colx-5">  <?=$_POST['SaleReferenceId']?></div>
  </div>
    <div>
  <input style="display: none" id="RefId" value="<?=$_POST['RefId']?>">
  <input style="display: none" id="ResCode" value="<?=$_POST['ResCode']?>">
  <input style="display: none" id="SaleOrderId" value="<?=$_POST['SaleOrderId']?>">
  <input style="display: none" id="SaleReferenceId" value="<?=$_POST['SaleReferenceId']?>">
  <input style="display: none" id="Result" value="<?=$_POST['result']?>">
  <input style="display: none" id="user_id" value="<?=$user_id?>">
  <input style="display: none" id="user_cash" value="<?=$user_cash?>">
<?
if ($_POST['ResCode'] == 0) {
  try {
    $client = @new SoapClient('https://bpm.shaparak.ir/pgwchannel/services/pgw?wsdl');
  } catch (Exception $e) {
    die($e->getMessage());
  }
  $namespace = 'http://interfaces.core.sw.bps.com/';
  $terminalId = "2876682";
  $userName = "clipamooz1";
  $userPassword = "53321852";
  $parameters = array(
    'terminalId' => $terminalId,
    'userName' => $userName,
    'userPassword' => $userPassword,
    'orderId' => $_POST['SaleOrderId'],
    'saleOrderId' => $_POST['SaleOrderId'],
    'saleReferenceId' => $_POST['SaleReferenceId']
  );
  $result = $client->bpVerifyRequest($parameters, $namespace);

  $resultStr = $result->return;
  $res = @explode(',', $resultStr);
  if (is_array($res)) {
    $ResCode = $res[0];
    if ($ResCode == "0") {
// Update table, Save RefId
      $resultsettle = $client->bpSettleRequest($parameters, $namespace);
      $resultStrsettle = $resultsettle->return;
      $ressettle = @explode(',', $resultStrsettle);
      $ResCodesettle = $ressettle[0];
      if ($ResCodesettle == "0") {
        $paymentdone = "done";
        $total=0;
        PaymentModel::Update_back($_POST['SaleOrderId'], $_POST['RefId'], $_POST['SaleReferenceId'], $_POST['ResCode']);
        $data_cash = CommonModel::Fetch_by_every('users', 'id', $user_id);
        $data_mount = CommonModel::Fetch_by_every('pay', 'refid', $_POST['RefId']);
        $total = $data_cash['cash'] + $data_mount['amount'];
        CommonModel::update_spacial_field($user_id, 'users', 'cash', $total);
      }
    }
  }
}
?>
</div>