<?php
class AdminUsersModel {

    public static function insert($user_lastname,$user_email,$hashedPassword,$user_simcard,$user_imei,$user_appsname,$user_access,$user_member_date){
    $db = Db::getInstance();
   $db->query("INSERT INTO users (user_lastname,user_email,user_password,user_simcard,user_imei,user_appsname,user_access,user_member_date)
             VALUES ( :user_lastname, :user_email, :user_password,:user_simcard,:user_imei,:user_appsname,:user_access, :user_member_date)",
     array(
      'user_lastname'         => $user_lastname,
      'user_email'         => $user_email,
      'user_password'         => $hashedPassword,
      'user_simcard'         => $user_simcard,
      'user_imei'         => $user_imei,
      'user_appsname'         => $user_appsname,
      'user_access'     => $user_access,
      'user_member_date'    => $user_member_date,
    ));


  }
  public static function update($userId,$user_simcard,$user_appsname){
    $db = Db::getInstance();
    $db->modify("UPDATE users SET user_simcard=:user_simcard , user_appsname=:user_appsname WHERE user_id=:user_id", array(
      'user_simcard' => $user_simcard,
      'user_appsname' => $user_appsname,
      'user_id' => $userId,
    ));
  }
  public static function promote_user($userId, $user_access){
    $db = Db::getInstance();
    $db->modify("UPDATE users SET user_access=:user_access WHERE user_id=:user_id", array(
      'user_access' => $user_access,
      'user_id' => $userId,
    ));
  }
  public static function insertperson($person_name,$person_imei,$person_mobile_number){
    $db = Db::getInstance();
   $db->query("INSERT INTO person (person_name,person_imei,person_mobile_number) VALUES ( :person_name,:person_imei, :person_mobile_number)", array(
      'person_name'         => $person_name,
      'person_imei'            => $person_imei,
      'person_mobile_number'         => $person_mobile_number,
    ));


  }

  public static function delete_user($id)
  {
    $db=Db::getInstance();
    $db->query("DELETE FROM users where user_id=:user_id",array('user_id'=>$id,));

  }
  public static function view_user($id)
  {
    $db=Db::getInstance();
    $record=$db->query("select * from users where id=:id",array('id'=>$id,));
    return $record;

  }
  public static function view_users()
  {
    $db=Db::getInstance();
    $record=$db->query("select * from users ");
    return $record;

  }

  public static function ListAdmin($NameTable,$startIndex=0,$count=10,$SearchFiled,$keyword,$SortType)
  {
    //  $keyword="";
    $SortType1=$SortType." ASC";
    $db=Db::getInstance();
    $record=$db->query("select * from $NameTable where (user_access='|superadmin|' or user_access='|admin|')and ($SearchFiled LIKE '%$keyword%')  ORDER BY $SortType1 LIMIT $startIndex,$count");
    return $record;

  }



  public static function get_user_access($userId){
    $db = Db::getInstance();
    $record = $db->first("SELECT user_access FROM users WHERE user_id=:user_id", array(
      'user_id' => $userId,
    ));
    return $record['user_access'];
  }
}