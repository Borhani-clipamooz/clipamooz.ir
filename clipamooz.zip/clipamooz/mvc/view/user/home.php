<div class="tac content" >
  <div class="content_print">
    <div class="info_person">
    <div class="titrbox" style="text-align: center"><h2>داستان من : </h2></div>
      <?$field=CommonModel::Fetch_by_every('info_person','user_id',$id);?>
      <div class="row" style="padding:10px;text-align: justify "> <p><?=$field['mystory']?>     </p></div>
      <div class="titrbox"><h1>ایمیل  : <span><?=$email?></span></h1> </div>
   <div class="row">
     <div class="colx-2 colm-fill cols-fill">
       <? global $config;?>
       <?  if($profile_pic !=''){
         if($login_status==1){?>
           <img  src="<?= $config['upload'].$profile_pic ?>" style="width: 200px;height: 150px;border-radius: 5px;border:3px solid  greenyellow;">
         <?  }else{?>
          <img  src="<?= $config['upload']. $profile_pic ?>" style="width: 200px;height: 150px;border-radius: 5px;border:3px solid  red;">
         <?} ?>
       <?}else{
         if($login_status==1){ ?>
           <img  src="/asset/images/empty/empty-profile/empty-profile-128.png" style="width: 200px;height: 200px;border-radius: 5px;border:3px solid  greenyellow;">
         <?  }else{?>
           <img  src="/asset/images/empty/empty-profile/empty-profile-128.png" style="width: 200px;height: 200px;border-radius: 5px;border:3px solid  red;">
         <?}}?>
     </div>
     <div class="colx-10 cols-fill">

       <div class="row">
         <div class="colx-2 ">
           <h2>نام</h2>
         </div>
         <div class="colx-2">
           <h2>نام خانوادگی</h2>
         </div>
         <div class="colx-2">
           <h2>تاریخ تولد</h2>
         </div>
         <div class="colx-2">
           <h2>کشور</h2>
         </div>
         <div class="colx-4">
           <h2>استان - شهر</h2>
         </div>
       </div>
       <div class="row">
         <div class="colx-2">
           <h3><?=$field['first_name']?></h3>
         </div>
         <div class="colx-2">
           <h3><?=$field['last_name']?></h3>
         </div>
         <div class="colx-2">
           <h3><?=$field['birthday']?></h3>
         </div>
         <div class="colx-2">
           <h3><?=$field['country']?></h3>
         </div>
         <div class="colx-4">
           <h3><?=$field['province']?></h3>
         </div>
       </div>
       <div class="row">
         <div class="colx-2">
           <h2 >نوع کاربری</h2>
         </div>
         <div class="colx-2">
           <h2 >تاریخ عضویت</h2>
         </div>
         <div class="colx-2">
           <h2>وب سایت</h2>
         </div>
         <div class="colx-2">
           <h2>نام کاربری</h2>
         </div>
         <div class="colx-2">
           <h2>تلفن</h2>
         </div>
         <div class="colx-2">
           <h2>آخرین ورود</h2>
         </div>
       </div>
       <div class="row">
         <div class="colx-2">
           <?
           $access='';
           $access=CommonModel::identification_user($user_access);
           ?>
           <h3><?=$access?></h3>
         </div>
         <div class="colx-2">
           <h3><?=DateTimeCommon($member_date);?></h3>
         </div>
         <div class="colx-2">
          <a href="http://<?=$field['website']?>" target="_blank"><?=$field['website']?></a>
         </div>
         <div class="colx-2">
           <h3><?=$user_name?></h3>
         </div>
         <div class="colx-2">
           <h3><?=$field['telephone']?></h3>
         </div>
         <div class="colx-2">
           <h3><?=DateTimeCommon($last_entry);?></h3>
         </div>
       </div>
     </div>
   </div>
      <div id="education_history" class="titrbox "> <h1>&nbsp;&nbsp;سوابق تحصیلی :<i id="icon_education_history_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="education_history_panel" style="display: none">
       <div class="row">
         <div class="colx-2 ">
           <h2 >مقطع تحصیلی</h2>
         </div>
         <div class="colx-2">
           <h2>رشته تحصیلی</h2>
         </div>
         <div class="colx-2">
           <h2>گرایش</h2>
         </div>
         <div class="colx-2">
           <h2>زمان تحصیل</h2>
         </div>
         <div class="colx-2">
           <h2>نام واحد آموزشی</h2>
         </div>
         <div class="colx-2">
           <h2>معدل</h2>
         </div>
       </div>
         <?
         $data=CommonModel::Fetch_by_all('education_history','user_id',$id,'');
         foreach($data as $field)
         {?>
       <div class="row">
         <div class="colx-2">
           <h3><?=$field['education_level']?></h3>
         </div>
         <div class="colx-2">
           <h3><?=$field['field_of_study']?></h3>
         </div>
         <div class="colx-2">
           <h3><?=$field['trend']?></h3>
         </div>
         <div class="colx-2">
           <h3><?=$field['term_of_study']?></h3>
         </div>
         <div class="colx-2">
           <h3><?=$field['name_of_education_unit']?></h3>
         </div>
         <div class="colx-2">
           <h3><?=$field['average']?></h3>
         </div>
         </div>
      <?}?>
       </div><!--     END  education_history ****************-->
      <div id="professional_history" class="titrbox "> <h1>&nbsp;&nbsp;سوابق حرفه ای :<i id="icon_professional_history_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="professional_history_panel" style="display: none">
       <div class="row">
         <div class="colx-2 ">
           <h2 >نام سازمان / شرکت</h2>
         </div>
         <div class="colx-2">
           <h2>شروع همکاری</h2>
         </div>
         <div class="colx-2">
           <h2>پایان همکاری</h2>
         </div>
         <div class="colx-2">
           <h2>سمت</h2>
         </div>
         <div class="colx-2">
           <h2>نوع فعالیت (قراردادی، پیمانی، رسمی و ...) </h2>
         </div>
         <div class="colx-2">
           <h2>پاره وقت/ تمام وقت/ مشاوره</h2>
         </div>
       </div>
         <?
         $data=CommonModel::Fetch_by_all('professional_history','user_id',$id,'');
         foreach($data as $field)
         {?>
       <div class="row">
         <div class="colx-2">
           <h3><?=$field['name_company']?></h3>
         </div>
         <div class="colx-2">
           <h3><?=$field['start_collaboration']?></h3>
         </div>
         <div class="colx-2">
           <h3><?=$field['finish_collaboration']?></h3>
         </div>
         <div class="colx-2">
           <h3><?=$field['responsibility']?></h3>
         </div>
         <div class="colx-2">
           <h3><?=$field['type_of_activity']?></h3>
         </div>
         <div class="colx-2">
           <h3><?=$field['time_activity']?></h3>
         </div>
         </div>
      <?}?>
       </div>
      <div id="tutorial_history" class="titrbox "> <h1>&nbsp;&nbsp;دوره های آموزشی( زبان خارجی ،کامپيوتر و... ) :<i id="icon_tutorial_history_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="tutorial_history_panel" style="display: none">
        <div class="row">
          <div class="colx-2">
            <h2 >نام دوره</h2>
          </div>
          <div class="colx-2">
            <h2>سطح</h2>
          </div>
          <div class="colx-2">
            <h2>محل آموزش</h2>
          </div>
          <div class="colx-2">
            <h2>سال</h2>
          </div>
          <div class="colx-2">
            <h2>میزان ساعت دوره</h2>
          </div>
        </div>
        <?
        $data=CommonModel::Fetch_by_all('tutorial_history','user_id',$id,'');
        foreach($data as $field)
        {?>
        <div class="row">
          <div class="colx-2">
            <h3><?=$field['course_name']?></h3>
          </div>
          <div class="colx-2">
            <h3><?=$field['level_name']?></h3>
          </div>
          <div class="colx-2">
            <h3><?=$field['tutorial_place']?></h3>
          </div>
          <div class="colx-2">
            <h3><?=$field['tutorial_year']?></h3>
          </div>
          <div class="colx-2">
            <h3><?=$field['tutorial_times']?></h3>
          </div>
        </div>
        <?}?>
      </div>
      <div id="reasearch_pattern" class="titrbox "> <h1>&nbsp;&nbsp;سوابق طرح‌های پژوهشی و تحقيقاتی :<i id="icon_reasearch_pattern_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="reasearch_pattern_panel" style="display: none">
        <div class="row">
          <div class="colx-2">
            <h2 >عنوان طرح</h2>
          </div>
          <div class="colx-2">
            <h2>سمت</h2>
          </div>
          <div class="colx-2">
            <h2>کارفرما</h2>
          </div>
          <div class="colx-2">
            <h2 >تاريخ شروع</h2>
          </div>
          <div class="colx-2">
            <h2 >تاریخ پايان</h2>
          </div>
          <div class="colx-2">
            <h2 >اعتبار طرح (ریال)</h2>
          </div>
        </div>
          <?
          $data=CommonModel::Fetch_by_all('research_pattern','user_id',$id,'');
          foreach($data as $field)
          {?>
        <div class="row">
          <div class="colx-2">
            <h3><?=$field['research_name']?></h3>
          </div>
          <div class="colx-2">
            <h3><?=$field['responsibility']?></h3>
          </div>
          <div class="colx-2">
            <h3><?=$field['employer']?></h3>
          </div>
          <div class="colx-2">
            <h3><?=$field['start_date']?></h3>
          </div>
          <div class="colx-2">
            <h3><?=$field['finish_date']?></h3>
          </div>
          <div class="colx-2">
            <h3><?=number_format($field['schedule_validity'])?></h3>
          </div>
        </div>
        <?}?>
      </div>
      <div id="article_history" class="titrbox "> <h1>&nbsp;&nbsp;مهمترین کتاب‌ها و مقاله‌ها :<i id="icon_academic_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="article_history_panel" style="display: none">
        <div class="row">
          <div class="colx-3">
            <h2 >نوع(کتاب،مقالهISI،مقاله علمی-پژوهشی و...)</h2>
          </div>
          <div class="colx-4">
            <h2>عنوان</h2>
          </div>
          <div class="colx-2">
            <h2>سال انتشار</h2>
          </div>
          <div class="colx-3">
            <h2 >نام انتشارات، نشریه و ...</h2>
          </div>
        </div>
          <?
          $data=CommonModel::Fetch_by_all('article_history','user_id',$id,'');
          foreach($data as $field)
          {?>
        <div class="row">
          <div class="colx-3">
            <h3><?=$field['article_type']?></h3>
          </div>
          <div class="colx-4">
            <h3><?=$field['article_name']?></h3>
          </div>
          <div class="colx-2">
            <h3><?=$field['release_time']?></h3>
          </div>
          <div class="colx-3">
            <h3><?=$field['article_location']?></h3>
          </div>
        </div>
        <?}?>
      </div>
      <div id="prize_history" class="titrbox "> <h1>&nbsp;&nbsp;مهمترین جایزه‌ها و تقدیرنامه‌های کسب شده :<i id="icon_prize_history_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="prize_history_panel" style="display: none">
        <div class="row">
          <div class="colx-6">
            <h2 >عنوان جایزه و تقدیرنامه</h2>
          </div>
          <div class="colx-2">
            <h2>تاریخ دریافت</h2>
          </div>
          <div class="colx-4">
            <h2>اعطاکننده</h2>
          </div>
        </div>
          <?
          $data=CommonModel::Fetch_by_all('prize_history','user_id',$id,'');
          foreach($data as $field)
          {?>
        <div class="row">
          <div class="colx-6">
            <h3><?=$field['prize_name']?></h3>
          </div>
          <div class="colx-2">
            <h3><?=$field['receive_date']?></h3>
          </div>
          <div class="colx-4">
            <h3><?=$field['grantor']?></h3>
          </div>
        </div>
        <?}?>
      </div>
        <div id="clips" class="titrbox "> <h1>&nbsp;&nbsp;کلیپ ها :<i id="icon_clips_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
        <div id="clips_panel" style="display: none">
        <input type="text" style="display: none" id="user_id" value="<?=$id?>">
        <div style="position: relative;margin-top: 5px;">
          <span class="icon-search large" style="position: absolute;top: 5px;right: 28%"></span> &nbsp; <input type="text" style="width:40%;height: 30px;" id="keyword_home" autocomplete="off">
        </div>
        <div id="paginationUpdate_home"></div>

        <script>

          $(function () {
            clips_panel(1);
            $("#keyword_home").on('keyup', function () {
              clips_panel(1);
            });
          });
          function clips_panel(pageIndex) {
            var keyword = $("#keyword_home").val();
            var SearchFiled = $("#UserFind").val();
            var user_id = $("#user_id").val();
            console.log(keyword);
            $.ajax({
              url: '/RefreshData_user_home/'+pageIndex,
              method: 'POST',
              dataType: 'json',
              data: {
                user_id:user_id,
                keyword: keyword,
                SearchFiled: SearchFiled
              },
              success: function (output) {
                // console.log(output);
                $("#paginationUpdate_home").html(output.html);
              }
            });
          }
        </script>
      </div>
      <div id="send_message" class="titrbox "> <h1>&nbsp;&nbsp;ارتباط با کاربر:<i id="icon_send_message_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="send_message_panel" style="display: none">
        <?if(isVip() || isSuperAdmin()){?>
          <div class="content" style="margin:5px;">
            <div class="send_message">
              <input type="text"  style="display: none" id="date_question" value="<?=getCurrentDateTime()?>">
              <div class="row">
                <h1>کاربر عزیز پیام خود را ارسال نمایید.</h1>
              </div>
              <div class="row">
                <div class="colx-5 tal">ارسال کننده</div>
                <div class="colx-7 tar"><input  class="tac"  type="text"  value="<?=$_SESSION['user_name']?>" disabled></div>
                <input style="display: none"  class="tac"  type="text" id="sender_message_id" value="<?=$_SESSION['user_id']?>">
              </div>
              <div class="row">
                <div class="colx-5 tal">دریافت کننده</div>
                <input style="display: none" type="text" id="receiver_message_id" value="<?=$id?>">
                <?$data=CommonModel::Fetch_by_every('users','id',$id)?>
                <div class="colx-7 tar"> <input type="text" class="tac"   value="<?=$data['user_name']?>"></div>
              </div>
              <div class="row">
                <div class="colx-1 tal">متن پیام</div>
                <div class="colx-10"><textarea style="width:750px" class="tar" type="text" class="empty"  id="body" ></textarea></div>
                <div class="colx-1 tal"></div>
              </div>
              <div class="row" id="message1" style="display: none">
                <div> <h2 id="message"></h2></div>
              </div>
              <div class="row">
                <div class="colx-4 " style="border: none"></div>
                <div class="colx-1 "><img src="/mvc/view/common/captcha/captcha_image.jpg.php"></div>
                <div class="colx-2 " style="border: none"><input class="tac hf" type="text" id="captcha_Send_message" > </div>
                <div class="colx-1 "> <button id="btn_Send_Message" class="btn_style btn-brown" onclick="captcha_Send_message()">ارسال پیام</button></div>
                <div class="colx-4 "  style="border: none"></div>
              </div>
            </div>
          </div>
        <?}else{?>
          <h2>برای فرستادن پیام به کلیپ آموز وارد شوید.</h2>
        <?}?>
        <script>
          var input = document.getElementById("captcha_Send_message");
          input.addEventListener("keyup", function(event) {
            event.preventDefault();
            if (event.keyCode === 13) {
              document.getElementById("btn_Send_Message").click();
            }
          });
          function captcha_Send_message(){
            var captcha=$("#captcha_Send_message").val();
            $.ajax({
              url:'/captcha',
              type: 'POST',
              dataType:'json',
              data:{
                captcha:captcha
              },
              success:function(data){
                if(data.status === false){
                  swal("کد وارد شده ایراد دارد.");
                  return;
                }else{
                  Send_Message();
                }
              }
            });

          }
          function Send_Message(){
            var body=$('#body').val();
            if(body==''){
              $("#message1").show();
              document.getElementById("message").innerHTML="پیامی نوشته نشده است.";
              return;
            }
            $("#btn_Send_Message").after('<div id="loader"><span class="icon-spinner9 huge spin "></span></div>');

            var sender_message_id=$('#sender_message_id').val();
            var receiver_message_id=$('#receiver_message_id').val();
            $.ajax({
              url: '/save_message/',
              method: 'POST',
              dataType: 'json',
              data: {
                sender_message_id: sender_message_id,
                receiver_message_id: receiver_message_id,
                body: body
              },
              success: function (output) {
                document.getElementById("message").innerHTML="پیام شما با موفقیت ارسال گردید.";
                $('#loader').slideUp(1000, function() {
                  $(this).remove();
                window.location.reload();
                });
              }
            });
          }
        </script>
      </div>
    </div>
<!--***********  INFO ---   Person   --   Responsive   ********************************************************************************-->
    <div class="info_person_responsive">
      <div class="titrbox" style="text-align: center">درباره من : </div>
      <?$field=CommonModel::Fetch_by_every('info_person','user_id',$id);?>
      <div class="row" style="padding:10px;text-align: justify "> <p><?=$field['mystory']?>     </p></div>
    <div class="titrbox" style="color: yellow"> <b style="color: white">ایمیل  : </b><?=$email?> </div>
   <div class="row">
     <div class="colx-2 colm-fill cols-fill">
       <?  if($profile_pic !=''){
         if($login_status==1){?>
           <img  src="<?=$config['upload']. $profile_pic ?>" style="width: 200px;height: 150px;border-radius: 5px;border:3px solid  greenyellow;">
         <?  }else{?>
          <img  src="<?=$config['upload']. $profile_pic ?>" style="width: 200px;height: 150px;border-radius: 5px;border:3px solid  red;">
         <?} ?>
       <?}else{
         if($login_status==1){ ?>
           <img  src="/asset/images/empty/empty-profile/empty-profile-128.png" style="width: 200px;height: 200px;border-radius: 5px;border:3px solid  greenyellow;">
         <?  }else{?>
           <img  src="/asset/images/empty/empty-profile/empty-profile-128.png" style="width: 200px;height: 200px;border-radius: 5px;border:3px solid  red;">
         <?}}?>
     </div>
     <div class="colx-10 cols-fill">
       <div class="row">

         <div class="colx-2">
          <h2>نام</h2>
         </div>
         <div class="colx-2 ">
         <h2>نام خانوادگی</h2>
         </div>
         <div class="colx-2">
          <h2>تاریخ تولد</h2>
         </div>

       </div>
       <div class="row">
         <div class="colx-2">
           <span><?=$field['first_name']?></span>
         </div>
         <div class="colx-2 ">
           <span><?=$field['last_name']?></span>
         </div>
         <div class="colx-2 ">
           <span><?=$field['birthday']?></span>
         </div>
       </div>
       <div class="row">
         <div class="colx-2">
         <h2>کشور</h2>
         </div>
         <div class="colx-4">
          <h2>استان - شهر</h2>
         </div>
       </div>
       <div class="row">
         <div class="colx-2">
           <span><?=$field['country']?></span>
         </div>
         <div class="colx-4">
           <span><?=$field['province']?></span>
         </div>
       </div>
       <div class="row">
         <div class="colx-2">
       <h2>نوع کاربری</h2>
         </div>
         <div class="colx-2">
          <h2>تاریخ عضویت</h2>
         </div>
         <div class="colx-2">
         <h2>وب سایت</h2>
         </div>
       </div>
       <div class="row">
         <div class="colx-2">
           <?
           $access='';
           $access=CommonModel::identification_user($user_access);
           ?>
           <span><?=$access?></span>
         </div>
         <div class="colx-2">
           <span><?=DateTimeCommon($member_date)?></span>
         </div>
         <div class="colx-2">
           <a style="color: white" href="http://<?=$field['website']?>" target="_blank"><?=$field['website']?></a>
         </div>
       </div>
       <div class="row">
         <div class="colx-2">
        <h2>نام کاربری</h2>
         </div>
         <div class="colx-2">
           <h2>تلفن</h2>
         </div>
         <div class="colx-2">
          <h2>آخرین ورود</h2>
         </div>
       </div>
       <div class="row">
         <div class="colx-2">
           <span><?=$user_name?></span>
         </div>
         <div class="colx-2">
           <span><?=$field['telephone']?></span>
         </div>
         <div class="colx-2">
           <span><?echo DateTimeCommon($last_entry);?></span>
         </div>
       </div>
     </div>
   </div>
      <div id="education_history_responsive" class="titrbox "> <h1>&nbsp;&nbsp;سوابق تحصیلی :<i id="icon_education_history_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="education_history_panel_responsive" style="display: none">
        <?
        $data=CommonModel::Fetch_by_all('education_history','user_id',$id,'');
        foreach($data as $field)
        {?>
        <div class="row">
          <div class="colx-2 ">
            <h2 >مقطع تحصیلی</h2>
          </div>
          <div class="colx-2">
            <h3><?=$field['education_level']?></h3>
          </div>
        </div>
        <div class="row">
          <div class="colx-2">
            <h2>رشته تحصیلی</h2>
          </div>
            <div class="colx-2">
              <h3><?=$field['field_of_study']?></h3>
            </div>
        </div>
        <div class="row">
          <div class="colx-2">
            <h2>گرایش</h2>
          </div>
          <div class="colx-2">
            <h3><?=$field['trend']?></h3>
          </div>
        </div>
          <div class="row">
            <div class="colx-2">
              <h2>زمان تحصیل</h2>
            </div>
            <div class="colx-2">
              <h3><?=$field['term_of_study']?></h3>
            </div>
          </div>
          <div class="row">
            <div class="colx-2">
              <h2>نام واحد آموزشی</h2>
            </div>
            <div class="colx-2">
              <h3><?=$field['name_of_education_unit']?></h3>
            </div>

          </div>
        <div class="row">
          <div class="colx-2">
            <h2>معدل</h2>
          </div>
            <div class="colx-2">
              <h3><?=$field['average']?></h3>
            </div>
        </div>
          <hr>
          <?}?>
      </div>    <!-- END education_history_responsive ******************-->
      <div id="professional_history_responsive" class="titrbox "> <h1>&nbsp;&nbsp;سوابق حرفه ای :<i id="icon_professional_history_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="professional_history_panel_responsive" style="display: none">
        <?
        $data=CommonModel::Fetch_by_all('professional_history','user_id',$id,'');
        // $field=array();
        foreach($data as $field)
        {?>
        <div class="row">
          <div class="colx-6 ">
            <h2 >نام سازمان / شرکت : </h2>
          </div>
          <div class="colx-6">
            <h3><?=$field['name_company']?></h3>
          </div>
        </div>
        <div class="row">
          <div class="colx-2">
            <h2>شروع همکاری : </h2>
          </div>
            <div class="colx-2">
              <h3><?=$field['start_collaboration']?></h3>
            </div>
        </div>
        <div class="row">
          <div class="colx-2">
            <h2>پایان همکاری : </h2>
          </div>
          <div class="colx-2">
            <h3><?=$field['finish_collaboration']?></h3>
          </div>
        </div>

          <div class="row">
            <div class="colx-2">
              <h2>سمت : </h2>
            </div>
            <div class="colx-2">
              <h3><?=$field['responsibility']?></h3>
            </div>

          </div>
        <div class="row">
          <div class="colx-2">
            <h2>نوع فعالیت (قراردادی، پیمانی، رسمی و ...) :</h2>
          </div>
          <div class="colx-2">
            <h3><?=$field['type_of_activity']?></h3>
          </div>
        </div>
        <div class="row">
          <div class="colx-2">
            <h2>پاره وقت/ تمام وقت/ مشاوره:</h2>
          </div>
          <div class="colx-2">
            <h3><?=$field['time_activity']?></h3>
          </div>
        </div>
        <hr>
        <?}?>
      </div><!--  END professional_history_responsive  ******************-->
      <div id="tutorial_history_responsive" class="titrbox "> <h1>&nbsp;&nbsp;دوره آموزشی(زبان خارجی،کامپيوترو...):<i id="icon_tutorial_history_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="tutorial_history_panel_responsive" style="display: none">
        <?
        $data=CommonModel::Fetch_by_all('tutorial_history','user_id',$id,'');
        foreach($data as $field)
        {?>
        <div class="row">
          <div class="colx-2">
            <h2 >نام دوره</h2>
          </div>
          <div class="colx-2">
            <h3><?=$field['course_name']?></h3>
          </div>
        </div>
        <div class="row">
          <div class="colx-2">
            <h2>سطح</h2>
          </div>
          <div class="colx-2">
            <h3><?=$field['level_name']?></h3>
          </div>
        </div>
        <div class="row">
          <div class="colx-2">
            <h2>سال</h2>
          </div>
          <div class="colx-2">
            <h3><?=$field['tutorial_year']?></h3>
          </div>
        </div>
        <div class="row">
          <div class="colx-2">
            <h2>محل آموزش</h2>
          </div>
          <div class="colx-2">
            <h3><?=$field['tutorial_place']?></h3>
          </div>
        </div>
        <div class="row">
          <div class="colx-2">
            <h2>میزان ساعت دوره</h2>
          </div>
          <div class="colx-2">
            <h3><?=$field['tutorial_times']?></h3>
          </div>
        </div>
         <hr>
            <?}?>
      </div><!--  END tutorial_history_responsive ******************-->
      <div id="reasearch_pattern_responsive" class="titrbox "> <h1>&nbsp;&nbsp;سوابق طرح‌های پژوهشی و تحقيقاتی :<i id="icon_reasearch_pattern_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="reasearch_pattern_panel_responsive" style="display: none">
        <?
        $data=CommonModel::Fetch_by_all('research_pattern','user_id',$id,'');
        foreach($data as $field)
        {?>
        <div class="row">
         <div class="colx-6">
           <h2 >عنوان طرح</h2>
         </div>
          <div class="colx-6">
            <h3><?=$field['research_name']?></h3>
          </div>
       </div>
       <div class="row">
         <div class="colx-6">
           <h2>سمت</h2>
         </div>
         <div class="colx-6">
           <h3><?=$field['responsibility']?></h3>
         </div>
       </div>
       <div class="row">
         <div class="colx-6">
           <h2>کارفرما</h2>
         </div>
         <div class="colx-6">
           <h3><?=$field['employer']?></h3>
         </div>
       </div>
       <div class="row">
         <div class="colx-6">
           <h2 >تاريخ شروع</h2>
         </div>
         <div class="colx-6">
           <h3><?=$field['start_date']?></h3>
         </div>
       </div>
       <div class="row">
         <div class="colx-6">
           <h2 >تاریخ پايان</h2>
         </div>
         <div class="colx-6">
           <h3><?=$field['finish_date']?></h3>
         </div>
       </div>
       <div class="row">
         <div class="colx-6">
           <h2 >اعتبار طرح (ریال)</h2>
         </div>
         <div class="colx-6">
           <h3><?=number_format($field['schedule_validity'])?></h3>
         </div>
       </div>
          <hr>
        <?}?>
      </div><!--  END tutorial_history_responsive ******************-->
      <div id="article_history_responsive" class="titrbox "> <h1>&nbsp;&nbsp;مهمترین کتاب‌ها و مقاله‌ها :<i id="icon_article_history_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="article_history_panel_responsive" style="display: none">
        <?
        $data=CommonModel::Fetch_by_all('article_history','user_id',$id,'');
        foreach($data as $field)
        {?>
          <div class="row">
            <div class="colx-6">
              <h2 >نوع(کتاب،مقالهISI،مقاله علمی-پژوهشی و...)</h2>
            </div>
            <div class="colx-6">
              <h3><?=$field['article_type']?></h3>
            </div>
          </div>
          <div class="row">
            <div class="colx-6">
              <h2>عنوان</h2>
            </div>
            <div class="colx-6">
              <h3><?=$field['article_name']?></h3>
            </div>
          </div>
          <div class="row">
            <div class="colx-6">
              <h2>سال انتشار</h2>
            </div>
            <div class="colx-6">
              <h3><?=$field['release_time']?></h3>
            </div>
          </div>
        <div class="row">
          <div class="colx-6">
            <h2 >نام انتشارات، نشریه و ...</h2>
          </div>
          <div class="colx-6">
            <h3><?=$field['article_location']?></h3>
          </div>
        </div>
          <hr>
          <?}?>
      </div><!--  END academic_responsive_responsive ******************-->
      <div id="prize_history_responsive" class="titrbox "> <h1>&nbsp;&nbsp;جایزه‌ها و تقدیرنامه‌های کسب شده:<i id="icon_prize_history_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="prize_history_panel_responsive" style="display: none">
        <?
        $data=CommonModel::Fetch_by_all('prize_history','user_id',$id,'');
        foreach($data as $field)
        {?>
          <div class="row">
            <div class="colx-6">
              <h2 >عنوان جایزه و تقدیرنامه</h2>
            </div>
            <div class="colx-6">
              <h3><?=$field['prize_name']?></h3>
            </div>
          </div>
          <div class="row">
            <div class="colx-6">
              <h2>تاریخ دریافت</h2>
            </div>
            <div class="colx-6">
              <h3><?=$field['receive_date']?></h3>
            </div>
          </div>
          <div class="row">
            <div class="colx-6">
              <h2>اعطاکننده</h2>
            </div>
            <div class="colx-6">
              <h3><?=$field['grantor']?></h3>
            </div>
          </div>
          <hr>
        <?}?>
      </div><!--  END academic_responsive_responsive ******************-->
      <div id="clips_responsive" class="titrbox "> <h1>&nbsp;&nbsp;کلیپ ها :<i id="icon_clips_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="clips_panel_responsive" style="display: none">
        <input type="text" style="display: none" id="user_id_responsive" value="<?=$id?>">
        <div style="position: relative;margin-top: 5px;">
          <span class="icon-search large" style="position: absolute;top: 5px;right: 0%"></span> &nbsp; <input type="text" style="width:90%;height: 30px;" id="keyword_home_responsive" autocomplete="off">
        </div>
        <div id="paginationUpdate_responsive"></div>
        <script>
          $("#keyword_home_responsive").on('keyup', function () {
            clips_panel_responsive(<?=$pageIndex?>);
          });
          $(function () {
            clips_panel_responsive(1);
          });
          function clips_panel_responsive(pageIndex) {
            var keyword = $("#keyword_home_responsive").val();
            var SearchFiled = $("#UserFind_responsive").val();
            var user_id = $("#user_id_responsive").val();
            $.ajax({
              url: '/RefreshData_user_home/'+pageIndex,
              method: 'POST',
              dataType: 'json',
              data: {
                user_id:user_id,
                keyword: keyword,
                SearchFiled: SearchFiled
              },
              success: function (output) {
                // console.log(output);
                $("#paginationUpdate_responsive").html(output.html);
              }
            });
          }
        </script>
      </div><!--  END  Clips Panle Responsive ******************-->
      <div id="send_message_responsive" class="titrbox "> <h1>&nbsp;&nbsp;ارتباط با کاربر:<i id="icon_send_message_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="send_message_panel_responsive" style="display: none">
        <?if(isVip() || isSuperAdmin()){?>
          <div class="content" style="margin:5px;">
            <div class="send_message">
              <input type="text"  style="display: none" id="date_question" value="<?=getCurrentDateTime()?>">
              <div class="row">
                <h1>کاربر عزیز پیام خود را ارسال نمایید.</h1>
              </div>
              <div class="row">
                <div class="colx-fill ">ارسال کننده</div>
                <div class="colx-fill"><input  class="tac"  type="text"  value="<?=$_SESSION['user_name']?>" disabled></div>
                <input style="display: none"  class="tac"  type="text" id="sender_message_id_responsive" value="<?=$_SESSION['user_id']?>">
              </div>
              <div class="row">
                <div class="colx-fill">دریافت کننده</div>
                <input style="display: none" type="text" id="receiver_message_id_responsive" value="<?=$id?>">
                <?$data=CommonModel::Fetch_by_every('users','id',$id)?>
                <div class="colx-fill"> <input type="text" class="tac"   value="<?=$data['user_name']?>"></div>
              </div>
              <div class="row">
                <div class="colx-fill">متن پیام</div>
                <div class="colx-fill"><textarea class="tar" type="text" class="empty"  id="body_responsive" ></textarea></div>
                <div class="colx-fill"></div>
              </div>
              <div class="row" id="message1_responsive" style="display: none">
                <div> <h2 id="message_responsive"></h2></div>
              </div>
              <div class="row">
                <div class="colx-4 "><img src="/mvc/view/common/captcha/captcha_image.jpg.php"></div>
                <div class="colx-4 " style="border: none"><input class="tac hf" type="text" id="captcha_Send_message_responsive" > </div>
                <div class="colx- "> <button id="btn_Send_Message_responsive" class="btn_style btn-brown" onclick="captcha_Send_message_responsive()">ارسال پیام</button></div>
              </div>
            </div>
          </div>
        <?}else{?>
          <h2>برای فرستادن پیام به کلیپ آموز وارد شوید.</h2>
        <?}?>
        <script>
          function captcha_Send_message_responsive(){
            var captcha=$("#captcha_Send_message_responsive").val();
            $.ajax({
              url:'/captcha',
              type: 'POST',
              dataType:'json',
              data:{
                captcha:captcha
              },
              success:function(data){
                if(data.status === false){
                  swal("کد وارد شده ایراد دارد.");
                  return;
                }else{
                  Send_Message_responsive();
                }
              }
            });

          }
          function Send_Message_responsive(){
            var body=$('#body_responsive').val();
            if(body==''){
              $("#message1_responsive").show();
              document.getElementById("message_responsive").innerHTML="پیامی نوشته نشده است.";
              return;
            }
            $("#btn_Send_Message_responsive").after('<div id="loader_responsive"><span class="icon-spinner9 huge spin "></span></div>');
            var sender_message_id=$('#sender_message_id_responsive').val();
            var receiver_message_id=$('#receiver_message_id_responsive').val();
            $.ajax({
              url: '/save_message/',
              method: 'POST',
              dataType: 'json',
              data: {
                sender_message_id: sender_message_id,
                receiver_message_id: receiver_message_id,
                body: body
              },
              success: function (output) {
                //console.log(output.html);
                $('#loader_responsive').slideUp(1000, function() {
                  $(this).remove();
                  window.location.reload();
                });
              }
            });
          }
        </script>
      </div><!--  END SEND Message Responsive  ******************-->
    </div><!--  END info person Responsive  ******************-->
    </div><!-- END  content Print  ******************-->
  <div class="row">
    <div class="colx-1">
      <div class="dropdown">
        <span  class="icon-share2 huge"></span>
        <div class="dropdown_panel"style="display: none">
          <?$data=CommonModel::Fetch_by_every('info_person','user_id',$id);?>
          <ul>
            <li>
              <a target="_blank" href="https://t.me/share/url?url=<?=baseUrl()?>/profile/<?=$id?>&text=<?=_CV?> <?=$data['first_name']?> <?=$data['last_name']?>"> <span style="color: #2e87ca "class="icon-telegram huge"></span></a>
            </li>
            <li>
              <a target="_blank" href="https://plus.google.com/share?url=<?=baseUrl()?>/profile/<?=$id?>&text=<?=_CV?> <?=$data['first_name']?> <?=$data['last_name']?>"> <span style="color:#d34836"class="icon-google-plus huge" ></span></a>

            </li>
            <li>
              <a target="_blank" href="https://www.facebook.com/share.php?u=<?=baseUrl()?>/profile/<?=$id?>&t=<?=_CV?> <?=$data['first_name']?> <?=$data['last_name']?>"> <span style="color:#3b5998"class="icon-facebook2 huge"></span></a>

            </li>
            <li>
              <a target="_blank" href="https://www.linkedin.com/shareArticle?mini=true&url=<?=baseUrl()?>/profile/<?=$id?>&title=<?=_CV?> <?=$data['first_name']?> <?=$data['last_name']?>"> <span style="color:#0077B5"class="icon-linkedin huge"></span></a>
            </li>
            <li>
              <a target="_blank" href="https://twitter.com/intent/tweet?url=<?=baseUrl()?>/profile/<?=$id?>&text=<?=_CV?> <?=$data['first_name']?> <?=$data['last_name']?>"> <span style="color:#55acee"class="icon-twitter huge"></span></a>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <div class="colx-2">
      <button class="btn_style titrbox" onclick="copyUrl();"><h1><?=_btn_copy?></h1></button>
    </div>
    <div class="colx-9">
      <input type="text" style="width: 100%;text-align: center" value="<?=baseUrl()?>/profile/<?=$id?>" id="myInput" >
    </div>
  </div>
    </div><!--  End Content  ******************-->
<div id="btn" class="btn_style titrbox " style="text-align: center" > <h1><?=_btn_print_cv?></h1></div>

<script src="/asset/printer/jquery.PrintArea.js"></script>
<script>
  $(document).ready(function(){
    var icon_education_history_ON = document.getElementById("icon_education_history_ON");
    $("#education_history").click(function(){
      $("#education_history_panel").slideToggle("slow");
      icon_education_history_ON.classList.toggle("arrow");
    });

    var icon_education_history_responsive_ON = document.getElementById("icon_education_history_responsive_ON");
    $("#education_history_responsive").click(function(){
      $("#education_history_panel_responsive").slideToggle("slow");
      icon_education_history_responsive_ON.classList.toggle("arrow");
    });
//    **********************************************************************************************************************************
    var icon_professional_history_ON = document.getElementById("icon_professional_history_ON");
    $("#professional_history").click(function(){
      $("#professional_history_panel").slideToggle("slow");
      icon_professional_history_ON.classList.toggle("arrow");
    });
    var icon_professional_history_responsive_ON = document.getElementById("icon_professional_history_responsive_ON");
    $("#professional_history_responsive").click(function(){
      $("#professional_history_panel_responsive").slideToggle("slow");
      icon_professional_history_responsive_ON.classList.toggle("arrow");
    });
//    **********************************************************************************************************************************
    var icon_tutorial_history_ON = document.getElementById("icon_tutorial_history_ON");
    $("#tutorial_history").click(function(){
      $("#tutorial_history_panel").slideToggle("slow");
      icon_tutorial_history_ON.classList.toggle("arrow");
    });
    var icon_tutorial_history_responsive_ON = document.getElementById("icon_tutorial_history_responsive_ON");
    $("#tutorial_history_responsive").click(function(){
      $("#tutorial_history_panel_responsive").slideToggle("slow");
      icon_tutorial_history_responsive_ON.classList.toggle("arrow");
    });
//    *********************************************************************************************************************************
    var icon_reasearch_pattern_ON = document.getElementById("icon_reasearch_pattern_ON");
    $("#reasearch_pattern").click(function(){
      $("#reasearch_pattern_panel").slideToggle("slow");
      icon_reasearch_pattern_ON.classList.toggle("arrow");
    });
    var icon_reasearch_pattern_responsive_ON = document.getElementById("icon_reasearch_pattern_responsive_ON");
    $("#reasearch_pattern_responsive").click(function(){
      $("#reasearch_pattern_panel_responsive").slideToggle("slow");
      icon_reasearch_pattern_responsive_ON.classList.toggle("arrow");
    });
//    *********************************************************************************************************************************
    var icon_article_history_ON = document.getElementById("icon_article_history_ON");
    $("#article_history").click(function(){
      $("#article_history_panel").slideToggle("slow");
      icon_article_history_ON.classList.toggle("arrow");
    });
    var icon_article_history_responsive_ON = document.getElementById("icon_article_history_responsive_ON");
    $("#article_history_responsive").click(function(){
      $("#article_history_panel_responsive").slideToggle("slow");
      icon_article_history_responsive_ON.classList.toggle("arrow");
    });
//    *********************************************************************************************************************************
    var icon_clips_ON = document.getElementById("icon_clips_ON");
    $("#clips").click(function(){
      $("#clips_panel").slideToggle("slow");
      icon_clips_ON.classList.toggle("arrow");
    });
    var icon_clips_responsive_ON = document.getElementById("icon_clips_responsive_ON");
    $("#clips_responsive").click(function(){
      $("#clips_panel_responsive").slideToggle("slow");
      icon_clips_responsive_ON.classList.toggle("arrow");
    });
//    **********************************************************************************************************************************
    var icon_send_message_ON = document.getElementById("icon_send_message_ON");
    $("#send_message").click(function(){
      $("#send_message_panel").slideToggle("slow");
      icon_send_message_ON.classList.toggle("arrow");
    });
    var icon_send_message_responsive_ON = document.getElementById("icon_send_message_responsive_ON");
    $("#send_message_responsive").click(function(){
      $("#send_message_panel_responsive").slideToggle("slow");
      icon_send_message_responsive_ON.classList.toggle("arrow");
    });
//    **********************************************************************************************************************************
    var icon_prize_history_ON = document.getElementById("icon_prize_history_ON");
    $("#prize_history").click(function(){
      $("#prize_history_panel").slideToggle("slow");
      icon_prize_history_ON.classList.toggle("arrow");
    });
    var icon_prize_history_responsive_ON = document.getElementById("icon_prize_history_responsive_ON");
    $("#prize_history_responsive").click(function(){
      $("#prize_history_panel_responsive").slideToggle("slow");
      icon_prize_history_responsive_ON.classList.toggle("arrow");
    });
//    *********************************************************************************************************************************
    $("#btn").click(function () {
      var mode = 'iframe'; // popup
      var close = mode == "popup";
      var options = {mode: mode, popClose: close};
      $("div.content_print").printArea(options);
    });
    $(".dropdown").click(function(){
      $(".dropdown_panel").slideToggle("slow");
    });

  });
  function copyUrl() {
    var copyText = document.getElementById("myInput");

    copyText.select();
    document.execCommand("copy");
//    alert("Copied the text: " + copyText.value);
    swal(copyText.value);
  }
</script>


