<div class="content" >
  <div class="info_person_detail_responsive tac">
<!--    <div class="titrbox" style="color: yellow"> <b style="color: white">اطلاعات فردی :</b>--><?//=$email?><!-- </div>-->
    <div class="row">
      <?  global $config;   ?>
      <? $data=CommonModel::Fetch_by_every('info_person','user_id',$id);?>
      <div class="colx-2 colm-fill cols-fill">
        <? if ($profile_pic !='') {?>
          <div id="deleteImage">
            <img  src="<?=$config['upload']. $profile_pic ?>" alt="<?=$data['first_name']?>&nbsp;<?=$data['last_name']?>"style="width: 200px;height: 150px"><br>
            <h2 style="color: #a2120a" id="messageiImage"></h2>
            <button class="btn_style btn-brown" onclick="Remove_data('<?= $profile_pic ?>',0,'<?=$id?>','users','profile_pic','')"><?=_btn_delete?></button>
          </div>
        <?}else{?>
          <script>ShowUploaderImage('<?=$id?>','users','profile_pic','150','150');</script>
          <div id="ShowUploaderImage"></div>
        <?}?>
      </div>
      <div class="colx-10 cols-fill">

        <div class="row">
          <div class="colx-2  ">
            <h1>نام</h1>
          </div>
          <div class="colx-2 ">
            <h1>نام خانوادگی</h1>
          </div>
          <div class="colx-2">
            <h1>تاریخ تولد</h1>
          </div>

        </div>
        <div class="row">
          <div class="colx-2">
            <h3><input class="tac" type="text"  id="first_name"  name="" value="<?= $data['first_name'] ?>"></h3>
          </div>
          <div class="colx-2 ">
            <h3><input class="tac" type="text"  id="last_name"  name="" value="<?= $data['last_name'] ?>"></h3>
          </div>
          <div class="colx-2 ">
            <h3><input class="tac" type="text"  id="birthday"  name="" value="<?= $data['birthday'] ?>"></h3>
          </div>
        </div>
        <div class="row">
          <div class="colx-2">
            <h1>کشور</h1>
          </div>
          <div class="colx-2">
            <h1>استان - شهر</h1>
          </div>
          <div class="colx-2">
            <h1 >کد ملی</h1>
          </div>
        </div>
        <div class="row">
          <div class="colx-2">
            <h3><input class="tac" type="text"  id="country"  name="" value="<?= $data['country'] ?>"></h3>
          </div>
          <div class="colx-2">
            <h3><input class="tac" type="text"  id="province"  name="" value="<?= $data['province'] ?>"></h3>
          </div>
          <div class="colx-2">
            <h3><input class="tac" type="text"  id="codemelli"  name="" value="<?= $data['codemelli'] ?>"></h3>
          </div>
        </div>
        <div class="row">
          <div class="colx-2">
            <h1>نوع کاربری</h1>
          </div>
          <div class="colx-2">
            <h1 >تاریخ عضویت</h1>
          </div>
          <div class="colx-2">
            <h1>وب سایت</h1>
          </div>
        </div>
        <?
        $access='';
        $access=CommonModel::identification_user($user_access);
        ?>
        <div class="row">
          <div class="colx-2">
            <h3><?=$access?></h3>
          </div>
          <div class="colx-2">
            <h3><?=DateTimeCommon($member_date)?></h3>
          </div>
          <div class="colx-2">
            <span><input class="tac" type="text"  id="website"  name="" value="<?= $data['website'] ?>"></span>
          </div>
        </div>
        <div class="row">
          <div class="colx-2">
            <h1>نام کاربری</h1>
          </div>
          <div class="colx-2">
            <h1>تلفن</h1>
          </div>
          <div class="colx-2">
            <h1>آخرین ورود</h1>
          </div>
        </div>
        <div class="row">
          <div class="colx-2">
            <h3><?=$user_name?></h3>
          </div>
          <div class="colx-2">
            <span><input class="tac" type="text"  id="telephone"  name="" value="<?= $data['telephone'] ?>"></span>
          </div>
          <div class="colx-2">
            <h3><?echo DateTimeCommon($last_entry);?></h3>
            <input type="hidden"id="defaultStatus"value="<?=$status?>">
          </div>
        </div>
      </div>
    </div>
    <div class="row">
      <textarea id="mystory" name="mystory" placeholder="داستان من ..." style="height: 180px;width: 100%;color: white"><?= $data['mystory'] ?></textarea>
    </div>
    </div>
  <input style="display: none" type="text"  id="user_id"  name="" value="<?= $id ?>">
</div>
<script>
  $(function(){
    $("textarea").each(function () {
      $(this).on('keyup', function () {
        SaveTextArea();
      });
    });
    var validation = true;
    $("input").each(function () {
      $(this).on('keyup', function () {
        var id = $("#user_id").val();
        var first_name = $("#first_name").val();
        var last_name = $("#last_name").val();
        var country = $("#country").val();
        var province = $("#province").val();
        var codemelli = $("#codemelli").val();
        var telephone = $("#telephone").val();
        var website = $("#website").val();
        var birthday = $("#birthday").val();
        $.ajax({
          url: '/detail_info_person_update',
          type: 'POST',
          dataType: 'json',
          data: {
            id: id,
            first_name: first_name,
            last_name: last_name,
            birthday: birthday,
            country: country,
            province: province,
            codemelli: codemelli,
            telephone: telephone,
            website: website
          },
          success: function (data) {
            //console.log(data);
          }
        });
      });
    });
    function SaveTextArea(){
      var id = $("#user_id").val();
      var mystory=$("#mystory").val();
      $.ajax({
        url:'/detail_info_mystory_person_update',
        type: 'POST',
        dataType:'json',
        data:{
          id:id,
          mystory:mystory
        },
        success:function(data){
        //console.log(data);
        }
      });
    }
    $('#level').val($('#defaultLevel').val());
    var id=$("#IDAccess").val();
    $('#level').on('change',function(){
      var level=$("#level").val();
      $.ajax({
        url:'/user/changeLevel',
        type: 'POST',
        dataType:'json',
        data:{
          id:id,
          user_access:level

        },
        success:function(data){
          //console.log(data);
        }
      });
    });
    $('#Status').val($('#defaultStatus').val());
    var id=$("#id").val();
    $('#Status').on('change',function(){
      var Status=$("#Status").val();
      $.ajax({
        url:'/user/ChangeStatus',
        type: 'POST',
        dataType:'json',
        data:{
          id:id,
          Status:Status

        },
        success:function(data){
          //console.log(data);
        }
      });
    });
    });

</script>















