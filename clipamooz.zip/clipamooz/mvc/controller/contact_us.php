<?php


class Contact_usController {
  public function __construct() {

  }
  public function contact_us_home() {

    View::render("/contact_us/home.php", array());
  }
  public function contact_us_all($pageIndex) {
    if (!isSuperAdmin()) {
      header("Location:/");
      return;
    }
    $result = CommonModel::View_All('contact_us');
    if (count($result) == 0) {
      message("not-found-information", _not_found_information);
      return;
    }
    $NameTable = 'contact_us';
    $keyword = "";
    $SearchFiled = "subject";
    $SortType = "status";
    $groupby='';
    $data = ListAjax($NameTable, $pageIndex,$SearchFiled,$keyword,$SortType,$groupby);
    View::renderCPanelSuperAdmin("/contact_us/all_contact_us.php", $data);


  }
  public function RefreshData_contact_us($pageIndex) {
    $NameTable = 'contact_us';

    if (isset($_POST['SearchFiled'])) {
      $SearchFiled = $_POST['SearchFiled'];
    } else {
      $SearchFiled = "subject";
    }
    if (isset($_POST['keyword'])) {
      $keyword = $_POST['keyword'];
    } else {
      $keyword = "";
    }
    $SortType = "status";
    $groupby='';
    $data = ListAjax($NameTable, $pageIndex,$SearchFiled, $keyword,$SortType,$groupby);
    ob_start();
    View::renderPartial("/contact_us/all_contact_us_ajax.php", $data);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }
  public function view($id) {
    if (isset($_POST['pageIndex'])) {
      $pageIndex = $_POST['pageIndex'];
    } else {
      $pageIndex = 1;
    }
    $record = CommonModel::Fetch_by_every('contact_us','id',$id);
    ob_start();
    $receiver_message_id = $_POST['receiver_message_id'];
    $sender_message_id = $_POST['sender_message_id'];
    $record['receiver_message_id'] = $receiver_message_id;
    $record['sender_message_id'] = $sender_message_id;
    $record['pageIndex'] = $pageIndex;
    View::renderPartial("/contact_us/detail_contact_us.php", $record);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }
  public function Remove_sql_data($Id) {
    ob_start();
    Contact_usModel::DelSqlRecord($Id);
    ob_get_clean();
    if (isset($_POST['pageIndex'])) {
      $pageIndex = $_POST['pageIndex'];
    } else {
      $pageIndex = 1;
    }
    $this->RefreshData_contact_us($pageIndex);
  }

  public function Replay($id) {
    $sender_message_id=$_POST['sender_message_id'];
    $receiver_message_id=$_POST['receiver_message_id'];
    $body_replay = $_POST['body_replay'];
    Contact_usModel::Replay($id,$body_replay,1);
    UserModel::Save_Receive_message($receiver_message_id,$sender_message_id,$body_replay,getCurrentDateTime(),0);
  }
  //***************** RECECIVE EMAIL USERS  ****************************************************************************************************
  public function Receive_message_email() {
   // $g_recaptcha=$_POST['g_recaptcha'];
    $g_recaptcha='6Lf752AUAAAAAPzdy25QhXt-ONhder1bySkZkmwr';
    //your site secret key
    $secret = '6Lf752AUAAAAAE38R0EpPqr_XJMYkPvTHwfDDJMh';
    //get verify response data
    $verifyResponse = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.$secret.'&response='.$g_recaptcha);
    $responseData = json_decode($verifyResponse);
      echo json_encode(array('status' => $responseData,'g_recaptcha' => $g_recaptcha,));
    if($responseData->success){
    }
      //contact form submission code

  }
  //***********************************************************************************************************************************
  public function Send_Message_Contact_us() {
    $sender_message_id=$_POST['sender_message_id'];
    $receiver_message_id=$_POST['receiver_message_id'];
    $subject=$_POST['subject'];
    $body=$_POST['body_question'];
    UserModel::Save_Send_message($sender_message_id,$receiver_message_id,$body,getCurrentDateTime(),0);
    Contact_usModel::Save_Receive_message($sender_message_id,'','','',$subject,$body,'',0,getCurrentDateTime());
    ob_start();
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));
  }

}