<div class=" content">
  <div class="detail_prize_history_panel">
  <div id="prize_history" class="titrbox "> <h1>&nbsp;&nbsp;جایزه‌ها و تقدیرنامه‌های کسب شده:<i id="icon_academic_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
    <input type="hidden"id="id"value="<?=$id?>">
   <div class="row">
     <div class="colx-6">
       <h2 >عنوان جایزه و تقدیرنامه</h2>
     </div>
     <div class="colx-6">
       <h2>تاریخ دریافت</h2>
     </div>
   </div>
    <div class="row">
      <div class="colx-6">
        <h3><input  type="text"  id="prize_name"   value="<?=$prize_name?>"></h3>
      </div>
      <div class="colx-6">
        <h3><input  type="text"  id="receive_date"   value="<?=$receive_date?>"></h3>
      </div>
    </div>
    <div class="row">
      <div class="colx-6">
        <h2>اعطاکننده</h2>
      </div>
    </div>
      <div class="row">
        <div class="colx-6">
          <h3><input type="text"  id="grantor"  value="<?= $grantor?>"></h3>
        </div>
      </div>
  </div>
<div class="row tac">
  <button  class="btn_style btn-brown" onclick="back(<?=$pageIndex?>)">بازگشت</button>
</div>
</div>
<script>
$(function(){
  $("input").each(function () {
    $(this).on('keyup', function () {
      var id=$("#id").val();
      var prize_name=$("#prize_name").val();
      var receive_date=$("#receive_date").val();
      var grantor=$("#grantor").val();
      $.ajax({
        url:'/user/detail_prize_history_update',
        type: 'POST',
        dataType:'json',
        data:{
          id:id,
          prize_name:prize_name,
          receive_date:receive_date,
          grantor:grantor
        },
        success:function(data){
          //console.log(data);
        }
      });


    });
  });
});
  function back(pageIndex){
    prize_history(pageIndex);
  }
</script>















