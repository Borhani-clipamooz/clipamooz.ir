<?php
class RelationModel {

  public static function insert($clip_id_1,$clip_id_2){
    $db = Db::getInstance();
    $db->query("INSERT INTO relations (clip_id_1,clip_id_2) VALUES ( :clip_id_1, :clip_id_2)",
      array(
        'clip_id_1'         => $clip_id_1,
        'clip_id_2'         => $clip_id_2,
      ));


  }


  public static function view_single($id)
  {
    $db=Db::getInstance();
    $record=$db->query("select * from relations where clip_id_1=:clip_id_1",array('clip_id_1'=>$id,));
    return $record;

  }
  public static function DelSqlRecord($id)
  {
    $db=Db::getInstance();
    $db->query("DELETE FROM relations where id=:id",array('id'=>$id,));

  }
  public static function DelRelationClip($id)
  {
    $db=Db::getInstance();
    $db->query("DELETE FROM relations where clip_id_1=:clip_id_1",array('clip_id_1'=>$id,));

  }

}