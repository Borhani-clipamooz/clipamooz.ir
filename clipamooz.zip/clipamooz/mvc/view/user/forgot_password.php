<div class="tac content">
  <div class="signin">
    <div class="row">
      <img  style="width: 150px;height: 100px;" src="/asset/images/logo/logo.png">
    </div>
    <div class="row">
      <p id="message_forgot_password"></p>
    </div>
    <div class="row"><span>ایمیل خود را وارد نمایید</span>  </div>
    <div class="row">
      <div class="colx-4 colm-0 cols-0"></div>
      <div class="colx-4"> <input type="text" id="email_forgot_password"></div>
      <div class="colx-4 colm-0 cols-0"></div>
    </div>
    <div class="row">
      <div class="colx-4 colm-0 cols-0"></div>
      <div class="colx-1 colm-fill cols-fill"><img src="/mvc/view/common/captcha/captcha_image.jpg.php"></div>
      <div class="colx-2 colm-fill cols-fill"><input class="tac hf" type="text" id="captcha_forgot_password"></div>
      <div class="colx-1 colm-fill cols-fill"><button id="btn_captcha_forgot_password" onclick="captcha_forgot_password()" class="btn_style btn-brown" style="margin-top: 5px">ارسال</button></div>
      <div class="colx-4 colm-0 cols-0"></div>
    </div>
  </div>
</div>
<script>
  $(function () {
    var input = document.getElementById("captcha_forgot_password");
    input.addEventListener("keyup", function(event) {
      event.preventDefault();
      if (event.keyCode === 13) {
        document.getElementById("btn_captcha_forgot_password").click();
      }
    });
  });

  function captcha_forgot_password(){
    var captcha=$("#captcha_forgot_password").val();
    $.ajax({
      url:'/captcha',
      type: 'POST',
      dataType:'json',
      data:{
        captcha:captcha
      },
      success:function(data){
        if(data.status==false){
          swal("کد وارد شده ایراد دارد.");
          return;
        }else{
          forgot_password();
        }

      }
    });
  }
  function forgot_password(){
    $("#btn_captcha_forgot_password").after('<div id="loader"><span class="icon-spinner9 huge spin "></span></div>');
    var email=$("#email_forgot_password").val();
    $.ajax({
      url:'/send_link_forgot_password',
      type: 'POST',
      dataType:'json',
      data:{
        email:email
      },
      success:function(data){
console.log(data);
        switch(data.status) {
          case 'NOT_Exist_Email':
            $('#loader').slideUp(1000, function() {
              $(this).remove();
            });
            document.getElementById("message_forgot_password").innerHTML="ایمیل وارد شده در بانک اطلاعاتی کلیپ آموز وجود ندارد.";
            break;
          case true:
            $('#loader').slideUp(1000, function() {
              $(this).remove();
            });
          document.getElementById("message_forgot_password").innerHTML="لینک پسورد جدید به ایمیلتون ارسال گردید.";
            break;
          default:
        }

      }
    });
  }
</script>
