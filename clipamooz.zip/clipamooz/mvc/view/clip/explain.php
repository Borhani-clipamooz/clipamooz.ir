
<div class="content">
  <h3 class="summary"><?=makeClickableLinks($long_desc_fa)?></h3>
</div>
