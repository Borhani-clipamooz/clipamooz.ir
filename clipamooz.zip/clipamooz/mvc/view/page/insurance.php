<div class="tac content" >
    <div class="info_person">
      <div class="titrbox"><h1>بیمه پاسارگاد</h1> </div>
      <div class="row">
        <?require(getcwd().'/mvc/view/page/about_me.php');?>
        </div>

      <div id="education_history" class="titrbox "> <h1>&nbsp;&nbsp;بیمه عمر و تامین آتیه<i id="icon_education_history_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="education_history_panel" style="display: none">
        <?require(getcwd().'/mvc/view/page/insurance/omr.php');?>
      </div><!--     END  education_history ****************-->
      <div id="professional_history" class="titrbox "> <h1>&nbsp;&nbsp;بیمه مسئولیت مسئول فنی بیمارستان ، داروخانه ، درمانگاه ، کلینیک<i id="icon_professional_history_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="professional_history_panel" style="display: none">
        <?require(getcwd().'/mvc/view/page/insurance/pharmacy.php');?>
      </div>
      <div id="tutorial_history" class="titrbox "> <h1>&nbsp;&nbsp;بیمه نامه مسئولیت مدنی مدیران مهد کودک<i id="icon_tutorial_history_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="tutorial_history_panel" style="display: none">
        <?require(getcwd().'/mvc/view/page/insurance/kindergarten.php');?>
      </div>
      <div id="reasearch_pattern" class="titrbox "> <h1>&nbsp;&nbsp;بیمه نامه مسئولیت مدنی دارندگان ماشین آلات<i id="icon_reasearch_pattern_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="reasearch_pattern_panel" style="display: none">
        <?require(getcwd().'/mvc/view/page/insurance/machinery.php');?>
      </div>
      <div id="article_history" class="titrbox "> <h1>&nbsp;&nbsp;بیمه مسئولیت مدیر یا هیئت مدیره ساختمان<i id="icon_academic_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="article_history_panel" style="display: none">
        <?require(getcwd().'/mvc/view/page/insurance/residentialcomplex.php');?>
      </div>
      <div id="prize_history" class="titrbox "> <h1>&nbsp;&nbsp;بیمه نامه مدیران آژانس های مسافرتی<i id="icon_prize_history_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="prize_history_panel" style="display: none">
        <?require(getcwd().'/mvc/view/page/insurance/travel_agency.php');?>
      </div>
      <div id="clips" class="titrbox "> <h1>&nbsp;&nbsp;بیمه نامه مسئولیت ﻭﻳﮋه ﻓﻌﺎﻟﯿﺖ ﻫﺎی عمرانی<i id="icon_clips_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="clips_panel" style="display: none">
        <?require(getcwd().'/mvc/view/page/insurance/building_engineer.php');?>
      </div>
      <div id="send_message" class="titrbox "> <h1>&nbsp;&nbsp;بیمه نامه دارندگان و سرویس کاران آسانسور<i id="icon_send_message_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="send_message_panel" style="display: none">
        <?require(getcwd().'/mvc/view/page/insurance/elevator_service.php');?>
      </div>
      <div id="send_message" class="titrbox "> <h1>&nbsp;&nbsp;بیمه نامه دارندگان و سرویس کاران آسانسور<i id="icon_send_message_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="send_message_panel" style="display: none">
        <?require(getcwd().'/mvc/view/page/insurance/elevator_service.php');?>
      </div>
    </div>
    <!--***********  INFO ---   Person   --   Responsive   ********************************************************************************-->
    <div class="info_person_responsive">
      <div class="titrbox"><h1>بیمه پاسارگاد</h1> </div>
      <div class="row">
        <?require(getcwd().'/mvc/view/page/about_me.php');?>
      </div>
      <div id="education_history_responsive" class="titrbox "> <h1>&nbsp;&nbsp;بیمه عمر و تامین آتیه<i id="icon_education_history_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="education_history_panel_responsive" style="display: none">
        <?require(getcwd().'/mvc/view/page/insurance/omr_responsive.php');?>
      </div>    <!-- END education_history_responsive ******************-->
      <div id="professional_history_responsive" class="titrbox "> <h1>&nbsp;&nbsp; بیمه مسئول فنی بیمارستان ، داروخانه ، درمانگاه ، کلینیک     <i id="icon_professional_history_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="professional_history_panel_responsive" style="display: none">
        <?require(getcwd().'/mvc/view/page/insurance/pharmacy_responsive.php');?>
      </div><!--  END professional_history_responsive  ******************-->
      <div id="tutorial_history_responsive" class="titrbox"> <h1>&nbsp;&nbsp;بیمه نامه مسئولیت مدنی مدیران مهد کودک<i id="icon_tutorial_history_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="tutorial_history_panel_responsive" style="display: none">
        <?require(getcwd().'/mvc/view/page/insurance/kindergarten_responsive.php');?>
      </div><!--  END tutorial_history_responsive ******************-->
      <div id="reasearch_pattern_responsive" class="titrbox "> <h1>&nbsp;&nbsp;بیمه نامه مسئولیت مدنی دارندگان ماشین آلات<i id="icon_reasearch_pattern_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="reasearch_pattern_panel_responsive" style="display: none">
        <?require(getcwd().'/mvc/view/page/insurance/machinery_responsive.php');?>
      </div><!--  END tutorial_history_responsive ******************-->
      <div id="article_history_responsive" class="titrbox "> <h1>&nbsp;&nbsp;بیمه مسئولیت مدیر یا هیئت مدیره ساختمان<i id="icon_article_history_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="article_history_panel_responsive" style="display: none">
        <?require(getcwd().'/mvc/view/page/insurance/residentialcomplex_responsive.php');?>
      </div><!--  END academic_responsive_responsive ******************-->
      <div id="prize_history_responsive" class="titrbox "> <h1>&nbsp;&nbsp;بیمه نامه مدیران آژانس های مسافرتی<i id="icon_prize_history_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="prize_history_panel_responsive" style="display: none">
        <?require(getcwd().'/mvc/view/page/insurance/travel_agency_responsive.php');?>
      </div><!--  END academic_responsive_responsive ******************-->
      <div id="clips_responsive" class="titrbox "> <h1>&nbsp;&nbsp;بیمه نامه مسئولیت ﻭﻳﮋه ﻓﻌﺎﻟﯿﺖ ﻫﺎی عمرانی<i id="icon_clips_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="clips_panel_responsive" style="display: none">
        <?require(getcwd().'/mvc/view/page/insurance/building_engineer_responsive.php');?>
      </div><!--  END  Clips Panle Responsive ******************-->
      <div id="send_message_responsive" class="titrbox "> <h1>&nbsp;&nbsp;بیمه نامه دارندگان و سرویس کاران آسانسور<i id="icon_send_message_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="send_message_panel_responsive" style="display: none">
        <?require(getcwd().'/mvc/view/page/insurance/elevator_service_responsive.php');?>
      </div><!--  END SEND Message Responsive  ******************-->
    </div><!--  END info person Responsive  ******************-->
  </div><!-- END  content Print  ******************-->


<script>
  $(document).ready(function(){
//    **********************************************************************************************************************************
    var icon_panel1_elevator_service_ON = document.getElementById("icon_panel1_elevator_service_ON");
    $("#panel1_elevator_service").click(function(){
      $("#panel1_elevator_service_panel").slideToggle("slow");
      icon_panel1_elevator_service_ON.classList.toggle("arrow");
    });

    var icon_panel1_elevator_service_responsive_ON = document.getElementById("icon_panel1_elevator_service_responsive_ON");
    $("#panel1_elevator_service_responsive").click(function(){
      $("#panel1_elevator_service_panel_responsive").slideToggle("slow");
      icon_panel1_elevator_service_responsive_ON.classList.toggle("arrow");
    });
//    **********************************************************************************************************************************
    var icon_panel1_building_engineer_ON = document.getElementById("icon_panel1_building_engineer_ON");
    $("#panel1_building_engineer").click(function(){
      $("#panel1_building_engineer_panel").slideToggle("slow");
      icon_panel1_building_engineer_ON.classList.toggle("arrow");
    });

    var icon_panel1_building_engineer_responsive_ON = document.getElementById("icon_panel1_building_engineer_responsive_ON");
    $("#panel1_building_engineer_responsive").click(function(){
      $("#panel1_building_engineer_panel_responsive").slideToggle("slow");
      icon_panel1_building_engineer_responsive_ON.classList.toggle("arrow");
    });
//    **********************************************************************************************************************************
    var icon_panel2_building_engineer_ON = document.getElementById("icon_panel2_building_engineer_ON");
    $("#panel2_building_engineer").click(function(){
      $("#panel2_building_engineer_panel").slideToggle("slow");
      icon_panel2_building_engineer_ON.classList.toggle("arrow");
    });

    var icon_panel2_building_engineer_responsive_ON = document.getElementById("icon_panel2_building_engineer_responsive_ON");
    $("#panel2_building_engineer_responsive").click(function(){
      $("#panel2_building_engineer_panel_responsive").slideToggle("slow");
      icon_panel2_building_engineer_responsive_ON.classList.toggle("arrow");
    });
//    **********************************************************************************************************************************
    var icon_panel3_building_engineer_ON = document.getElementById("icon_panel3_building_engineer_ON");
    $("#panel3_building_engineer").click(function(){
      $("#panel3_building_engineer_panel").slideToggle("slow");
      icon_panel3_building_engineer_ON.classList.toggle("arrow");
    });

    var icon_panel3_building_engineer_responsive_ON = document.getElementById("icon_panel3_building_engineer_responsive_ON");
    $("#panel3_building_engineer_responsive").click(function(){
      $("#panel3_building_engineer_panel_responsive").slideToggle("slow");
      icon_panel3_building_engineer_responsive_ON.classList.toggle("arrow");
    });
//    **********************************************************************************************************************************
    var icon_panel4_building_engineer_ON = document.getElementById("icon_panel4_building_engineer_ON");
    $("#panel4_building_engineer").click(function(){
      $("#panel4_building_engineer_panel").slideToggle("slow");
      icon_panel4_building_engineer_ON.classList.toggle("arrow");
    });

    var icon_panel4_building_engineer_responsive_ON = document.getElementById("icon_panel4_building_engineer_responsive_ON");
    $("#panel4_building_engineer_responsive").click(function(){
      $("#panel4_building_engineer_panel_responsive").slideToggle("slow");
      icon_panel4_building_engineer_responsive_ON.classList.toggle("arrow");
    });
//    **********************************************************************************************************************************
    var icon_panel1_travel_agency_ON = document.getElementById("icon_panel1_travel_agency_ON");
    $("#panel1_travel_agency").click(function(){
      $("#panel1_travel_agency_panel").slideToggle("slow");
      icon_panel1_travel_agency_ON.classList.toggle("arrow");
    });

    var icon_panel1_travel_agency_responsive_ON = document.getElementById("icon_panel1_travel_agency_responsive_ON");
    $("#panel1_travel_agency_responsive").click(function(){
      $("#panel1_travel_agency_panel_responsive").slideToggle("slow");
      icon_panel1_travel_agency_responsive_ON.classList.toggle("arrow");
    });
//    **********************************************************************************************************************************
    var icon_panel2_travel_agency_ON = document.getElementById("icon_panel2_travel_agency_ON");
    $("#panel2_travel_agency").click(function(){
      $("#panel2_travel_agency_panel").slideToggle("slow");
      icon_panel2_travel_agency_ON.classList.toggle("arrow");
    });

    var icon_panel2_travel_agency_responsive_ON = document.getElementById("icon_panel2_travel_agency_responsive_ON");
    $("#panel2_travel_agency_responsive").click(function(){
      $("#panel2_travel_agency_panel_responsive").slideToggle("slow");
      icon_panel2_travel_agency_responsive_ON.classList.toggle("arrow");
    });
//    **********************************************************************************************************************************
    var icon_panel3_travel_agency_ON = document.getElementById("icon_panel3_travel_agency_ON");
    $("#panel3_travel_agency").click(function(){
      $("#panel3_travel_agency_panel").slideToggle("slow");
      icon_panel3_travel_agency_ON.classList.toggle("arrow");
    });

    var icon_panel3_travel_agency_responsive_ON = document.getElementById("icon_panel3_travel_agency_responsive_ON");
    $("#panel3_travel_agency_responsive").click(function(){
      $("#panel3_travel_agency_panel_responsive").slideToggle("slow");
      icon_panel3_travel_agency_responsive_ON.classList.toggle("arrow");
    });
//    **********************************************************************************************************************************
    var icon_panel1_residentialcomplex_ON = document.getElementById("icon_panel1_residentialcomplex_ON");
    $("#panel1_residentialcomplex").click(function(){
      $("#panel1_residentialcomplex_panel").slideToggle("slow");
      icon_panel1_residentialcomplex_ON.classList.toggle("arrow");
    });

    var icon_panel1_residentialcomplex_responsive_ON = document.getElementById("icon_panel1_residentialcomplex_responsive_ON");
    $("#panel1_residentialcomplex_responsive").click(function(){
      $("#panel1_residentialcomplex_panel_responsive").slideToggle("slow");
      icon_panel1_residentialcomplex_responsive_ON.classList.toggle("arrow");
    });
//    **********************************************************************************************************************************
    var icon_panel2_residentialcomplex_ON = document.getElementById("icon_panel2_residentialcomplex_ON");
    $("#panel2_residentialcomplex").click(function(){
      $("#panel2_residentialcomplex_panel").slideToggle("slow");
      icon_panel2_residentialcomplex_ON.classList.toggle("arrow");
    });

    var icon_panel2_residentialcomplex_responsive_ON = document.getElementById("icon_panel2_residentialcomplex_responsive_ON");
    $("#panel2_residentialcomplex_responsive").click(function(){
      $("#panel2_residentialcomplex_panel_responsive").slideToggle("slow");
      icon_panel2_residentialcomplex_responsive_ON.classList.toggle("arrow");
    });
//    **********************************************************************************************************************************
    var icon_panel3_residentialcomplex_ON = document.getElementById("icon_panel3_residentialcomplex_ON");
    $("#panel3_residentialcomplex").click(function(){
      $("#panel3_residentialcomplex_panel").slideToggle("slow");
      icon_panel3_residentialcomplex_ON.classList.toggle("arrow");
    });

    var icon_panel3_residentialcomplex_responsive_ON = document.getElementById("icon_panel3_residentialcomplex_responsive_ON");
    $("#panel3_residentialcomplex_responsive").click(function(){
      $("#panel3_residentialcomplex_panel_responsive").slideToggle("slow");
      icon_panel3_residentialcomplex_responsive_ON.classList.toggle("arrow");
    });
//    **********************************************************************************************************************************
    var icon_panel1_machinery_ON = document.getElementById("icon_panel1_machinery_ON");
    $("#panel1_machinery").click(function(){
      $("#panel1_machinery_panel").slideToggle("slow");
      icon_panel1_machinery_ON.classList.toggle("arrow");
    });

    var icon_panel1_machinery_responsive_ON = document.getElementById("icon_panel1_machinery_responsive_ON");
    $("#panel1_machinery_responsive").click(function(){
      $("#panel1_machinery_panel_responsive").slideToggle("slow");
      icon_panel1_machinery_responsive_ON.classList.toggle("arrow");
    });
//    **********************************************************************************************************************************
    var icon_panel1_kindergarten_ON = document.getElementById("icon_panel1_kindergarten_ON");
    $("#panel1_kindergarten").click(function(){
      $("#panel1_kindergarten_panel").slideToggle("slow");
      icon_panel1_kindergarten_ON.classList.toggle("arrow");
    });

    var icon_panel1_kindergarten_responsive_ON = document.getElementById("icon_panel1_kindergarten_responsive_ON");
    $("#panel1_kindergarten_responsive").click(function(){
      $("#panel1_kindergarten_panel_responsive").slideToggle("slow");
      icon_panel1_kindergarten_responsive_ON.classList.toggle("arrow");
    });
//    **********************************************************************************************************************************
    var icon_panel2_kindergarten_ON = document.getElementById("icon_panel2_kindergarten_ON");
    $("#panel2_kindergarten").click(function(){
      $("#panel2_kindergarten_panel").slideToggle("slow");
      icon_panel2_kindergarten_ON.classList.toggle("arrow");
    });

    var icon_panel2_kindergarten_responsive_ON = document.getElementById("icon_panel2_kindergarten_responsive_ON");
    $("#panel2_kindergarten_responsive").click(function(){
      $("#panel2_kindergarten_panel_responsive").slideToggle("slow");
      icon_panel2_kindergarten_responsive_ON.classList.toggle("arrow");
    });
//    **********************************************************************************************************************************
    var icon_panel3_kindergarten_ON = document.getElementById("icon_panel3_kindergarten_ON");
    $("#panel3_kindergarten").click(function(){
      $("#panel3_kindergarten_panel").slideToggle("slow");
      icon_panel3_kindergarten_ON.classList.toggle("arrow");
    });

    var icon_panel3_kindergarten_responsive_ON = document.getElementById("icon_panel3_kindergarten_responsive_ON");
    $("#panel3_kindergarten_responsive").click(function(){
      $("#panel3_kindergarten_panel_responsive").slideToggle("slow");
      icon_panel3_kindergarten_responsive_ON.classList.toggle("arrow");
    });
//    **********************************************************************************************************************************
    var icon_panel4_kindergarten_ON = document.getElementById("icon_panel4_kindergarten_ON");
    $("#panel4_kindergarten").click(function(){
      $("#panel4_kindergarten_panel").slideToggle("slow");
      icon_panel4_kindergarten_ON.classList.toggle("arrow");
    });

    var icon_panel4_kindergarten_responsive_ON = document.getElementById("icon_panel4_kindergarten_responsive_ON");
    $("#panel4_kindergarten_responsive").click(function(){
      $("#panel4_kindergarten_panel_responsive").slideToggle("slow");
      icon_panel4_kindergarten_responsive_ON.classList.toggle("arrow");
    });
//    **********************************************************************************************************************************
    var icon_panel5_kindergarten_ON = document.getElementById("icon_panel5_kindergarten_ON");
    $("#panel5_kindergarten").click(function(){
      $("#panel5_kindergarten_panel").slideToggle("slow");
      icon_panel5_kindergarten_ON.classList.toggle("arrow");
    });

    var icon_panel5_kindergarten_responsive_ON = document.getElementById("icon_panel5_kindergarten_responsive_ON");
    $("#panel5_kindergarten_responsive").click(function(){
      $("#panel5_kindergarten_panel_responsive").slideToggle("slow");
      icon_panel5_kindergarten_responsive_ON.classList.toggle("arrow");
    });
//    **********************************************************************************************************************************
    var icon_panel6_kindergarten_ON = document.getElementById("icon_panel6_kindergarten_ON");
    $("#panel6_kindergarten").click(function(){
      $("#panel6_kindergarten_panel").slideToggle("slow");
      icon_panel6_kindergarten_ON.classList.toggle("arrow");
    });

    var icon_panel6_kindergarten_responsive_ON = document.getElementById("icon_panel6_kindergarten_responsive_ON");
    $("#panel6_kindergarten_responsive").click(function(){
      $("#panel6_kindergarten_panel_responsive").slideToggle("slow");
      icon_panel6_kindergarten_responsive_ON.classList.toggle("arrow");
    });
//    **********************************************************************************************************************************
    var icon_panel7_kindergarten_ON = document.getElementById("icon_panel7_kindergarten_ON");
    $("#panel7_kindergarten").click(function(){
      $("#panel7_kindergarten_panel").slideToggle("slow");
      icon_panel7_kindergarten_ON.classList.toggle("arrow");
    });

    var icon_panel7_kindergarten_responsive_ON = document.getElementById("icon_panel7_kindergarten_responsive_ON");
    $("#panel7_kindergarten_responsive").click(function(){
      $("#panel7_kindergarten_panel_responsive").slideToggle("slow");
      icon_panel7_kindergarten_responsive_ON.classList.toggle("arrow");
    });
//    **********************************************************************************************************************************
    var icon_education_history_ON = document.getElementById("icon_education_history_ON");
    $("#education_history").click(function(){
      $("#education_history_panel").slideToggle("slow");
      icon_education_history_ON.classList.toggle("arrow");
    });

    var icon_education_history_responsive_ON = document.getElementById("icon_education_history_responsive_ON");
    $("#education_history_responsive").click(function(){
      $("#education_history_panel_responsive").slideToggle("slow");
      icon_education_history_responsive_ON.classList.toggle("arrow");
    });
//    **********************************************************************************************************************************
    var icon_professional_history_ON = document.getElementById("icon_professional_history_ON");
    $("#professional_history").click(function(){
      $("#professional_history_panel").slideToggle("slow");
      icon_professional_history_ON.classList.toggle("arrow");
    });
    var icon_professional_history_responsive_ON = document.getElementById("icon_professional_history_responsive_ON");
    $("#professional_history_responsive").click(function(){
      $("#professional_history_panel_responsive").slideToggle("slow");
      icon_professional_history_responsive_ON.classList.toggle("arrow");
    });
//    **********************************************************************************************************************************
    var icon_tutorial_history_ON = document.getElementById("icon_tutorial_history_ON");
    $("#tutorial_history").click(function(){
      $("#tutorial_history_panel").slideToggle("slow");
      icon_tutorial_history_ON.classList.toggle("arrow");
    });
    var icon_tutorial_history_responsive_ON = document.getElementById("icon_tutorial_history_responsive_ON");
    $("#tutorial_history_responsive").click(function(){
      $("#tutorial_history_panel_responsive").slideToggle("slow");
      icon_tutorial_history_responsive_ON.classList.toggle("arrow");
    });
//    *********************************************************************************************************************************
    var icon_reasearch_pattern_ON = document.getElementById("icon_reasearch_pattern_ON");
    $("#reasearch_pattern").click(function(){
      $("#reasearch_pattern_panel").slideToggle("slow");
      icon_reasearch_pattern_ON.classList.toggle("arrow");
    });
    var icon_reasearch_pattern_responsive_ON = document.getElementById("icon_reasearch_pattern_responsive_ON");
    $("#reasearch_pattern_responsive").click(function(){
      $("#reasearch_pattern_panel_responsive").slideToggle("slow");
      icon_reasearch_pattern_responsive_ON.classList.toggle("arrow");
    });
//    *********************************************************************************************************************************
    var icon_article_history_ON = document.getElementById("icon_article_history_ON");
    $("#article_history").click(function(){
      $("#article_history_panel").slideToggle("slow");
      icon_article_history_ON.classList.toggle("arrow");
    });
    var icon_article_history_responsive_ON = document.getElementById("icon_article_history_responsive_ON");
    $("#article_history_responsive").click(function(){
      $("#article_history_panel_responsive").slideToggle("slow");
      icon_article_history_responsive_ON.classList.toggle("arrow");
    });
//    *********************************************************************************************************************************
    var icon_clips_ON = document.getElementById("icon_clips_ON");
    $("#clips").click(function(){
      $("#clips_panel").slideToggle("slow");
      icon_clips_ON.classList.toggle("arrow");
    });
    var icon_clips_responsive_ON = document.getElementById("icon_clips_responsive_ON");
    $("#clips_responsive").click(function(){
      $("#clips_panel_responsive").slideToggle("slow");
      icon_clips_responsive_ON.classList.toggle("arrow");
    });
//    **********************************************************************************************************************************
    var icon_send_message_ON = document.getElementById("icon_send_message_ON");
    $("#send_message").click(function(){
      $("#send_message_panel").slideToggle("slow");
      icon_send_message_ON.classList.toggle("arrow");
    });
    var icon_send_message_responsive_ON = document.getElementById("icon_send_message_responsive_ON");
    $("#send_message_responsive").click(function(){
      $("#send_message_panel_responsive").slideToggle("slow");
      icon_send_message_responsive_ON.classList.toggle("arrow");
    });
//    **********************************************************************************************************************************
    var icon_prize_history_ON = document.getElementById("icon_prize_history_ON");
    $("#prize_history").click(function(){
      $("#prize_history_panel").slideToggle("slow");
      icon_prize_history_ON.classList.toggle("arrow");
    });
    var icon_prize_history_responsive_ON = document.getElementById("icon_prize_history_responsive_ON");
    $("#prize_history_responsive").click(function(){
      $("#prize_history_panel_responsive").slideToggle("slow");
      icon_prize_history_responsive_ON.classList.toggle("arrow");
    });

    $(".dropdown").click(function(){
      $(".dropdown_panel").slideToggle("slow");
    });
    //***************************************************************************************************************************
    var icon_panel1_ON = document.getElementById("icon_panel1_ON");
    $("#panel1").click(function(){
      $("#panel1_panel").slideToggle("slow");
      icon_panel1_ON.classList.toggle("arrow");
    });

    var icon_panel1_responsive_ON = document.getElementById("icon_panel1_responsive_ON");
    $("#panel1_responsive").click(function(){
      $("#panel1_panel_responsive").slideToggle("slow");
      icon_panel1_responsive_ON.classList.toggle("arrow");
    });
//    **********************************************************************************************************************************
    var icon_panel2_ON = document.getElementById("icon_panel2_ON");
    $("#panel2").click(function(){
      $("#panel2_panel").slideToggle("slow");
      icon_panel2_ON.classList.toggle("arrow");
    });
    var icon_panel2_responsive_ON = document.getElementById("icon_panel2_responsive_ON");
    $("#panel2_responsive").click(function(){
      $("#panel2_panel_responsive").slideToggle("slow");
      icon_panel2_responsive_ON.classList.toggle("arrow");
    });
//    **********************************************************************************************************************************
    var icon_panel3_ON = document.getElementById("icon_panel3_ON");
    $("#panel3").click(function(){
      $("#panel3_panel").slideToggle("slow");
      icon_panel3_ON.classList.toggle("arrow");
    });
    var icon_panel3_responsive_ON = document.getElementById("icon_panel3_responsive_ON");
    $("#panel3_responsive").click(function(){
      $("#panel3_panel_responsive").slideToggle("slow");
      icon_panel3_responsive_ON.classList.toggle("arrow");
    });
//    *********************************************************************************************************************************
    var icon_panel4_ON = document.getElementById("icon_panel4_ON");
    $("#panel4").click(function(){
      $("#panel4_panel").slideToggle("slow");
      icon_panel4_ON.classList.toggle("arrow");
    });
    var icon_panel4_responsive_ON = document.getElementById("icon_panel4_responsive_ON");
    $("#panel4_responsive").click(function(){
      $("#panel4_panel_responsive").slideToggle("slow");
      icon_panel4_responsive_ON.classList.toggle("arrow");
    });
//    *********************************************************************************************************************************
    var icon_panel5_ON = document.getElementById("icon_panel5_ON");
    $("#panel5").click(function(){
      $("#panel5_panel").slideToggle("slow");
      icon_panel5_ON.classList.toggle("arrow");
    });
    var icon_panel5_responsive_ON = document.getElementById("icon_panel5_responsive_ON");
    $("#panel5_responsive").click(function(){
      $("#panel5_panel_responsive").slideToggle("slow");
      icon_panel5_responsive_ON.classList.toggle("arrow");
    });
//    *********************************************************************************************************************************
    var icon_panel6_ON = document.getElementById("icon_panel6_ON");
    $("#panel6").click(function(){
      $("#panel6_panel").slideToggle("slow");
      icon_panel6_ON.classList.toggle("arrow");
    });
    var icon_panel6_responsive_ON = document.getElementById("icon_panel6_responsive_ON");
    $("#panel6_responsive").click(function(){
      $("#panel6_panel_responsive").slideToggle("slow");
      icon_panel6_responsive_ON.classList.toggle("arrow");
    });
    //    **********************************************************************************************************************************

    var icon_panel7_ON = document.getElementById("icon_panel7_ON");
    $("#panel7").click(function(){
      $("#panel7_panel").slideToggle("slow");
      icon_panel7_ON.classList.toggle("arrow");
    });
    var icon_panel7_responsive_ON = document.getElementById("icon_panel7_responsive_ON");
    $("#panel7_responsive").click(function(){
      $("#panel7_panel_responsive").slideToggle("slow");
      icon_panel7_responsive_ON.classList.toggle("arrow");
    });
//    **********************************************************************************************************************************
    var icon_panel8_ON = document.getElementById("icon_panel8_ON");
    $("#panel8").click(function(){
      $("#panel8_panel").slideToggle("slow");
      icon_panel8_ON.classList.toggle("arrow");
    });
    var icon_panel8_responsive_ON = document.getElementById("icon_panel8_responsive_ON");
    $("#panel8_responsive").click(function(){
      $("#panel8_panel_responsive").slideToggle("slow");
      icon_panel8_responsive_ON.classList.toggle("arrow");
    });
//    **********************************************************************************************************************************
    var icon_panel9_ON = document.getElementById("icon_panel9_ON");
    $("#panel9").click(function(){
      $("#panel9_panel").slideToggle("slow");
      icon_panel9_ON.classList.toggle("arrow");
    });
    var icon_panel9_responsive_ON = document.getElementById("icon_panel9_responsive_ON");
    $("#panel9_responsive").click(function(){
      $("#panel9_panel_responsive").slideToggle("slow");
      icon_panel9_responsive_ON.classList.toggle("arrow");
    });
//    **********************************************************************************************************************************
    var icon_panel10_ON = document.getElementById("icon_panel10_ON");
    $("#panel10").click(function(){
      $("#panel10_panel").slideToggle("slow");
      icon_panel10_ON.classList.toggle("arrow");
    });
    var icon_panel10_responsive_ON = document.getElementById("icon_panel10_responsive_ON");
    $("#panel10_responsive").click(function(){
      $("#panel10_panel_responsive").slideToggle("slow");
      icon_panel10_responsive_ON.classList.toggle("arrow");
    });
//    **********************************************************************************************************************************
    var icon_panel11_ON = document.getElementById("icon_panel11_ON");
    $("#panel11").click(function(){
      $("#panel11_panel").slideToggle("slow");
      icon_panel11_ON.classList.toggle("arrow");
    });
    var icon_panel11_responsive_ON = document.getElementById("icon_panel11_responsive_ON");
    $("#panel11_responsive").click(function(){
      $("#panel11_panel_responsive").slideToggle("slow");
      icon_panel11_responsive_ON.classList.toggle("arrow");
    });
//********* pharmacy  ************************************************************************************************************************
    //***************************************************************************************************************************
    var icon_panel1_pharmacy_ON = document.getElementById("icon_panel1_pharmacy_ON");
    $("#panel1_pharmacy").click(function(){
      $("#panel1_panel_pharmacy").slideToggle("slow");
      icon_panel1_pharmacy_ON.classList.toggle("arrow");
    });

    var icon_panel1_pharmacy_responsive_ON = document.getElementById("icon_panel1_pharmacy_responsive_ON");
    $("#panel1_pharmacy_responsive").click(function(){
      $("#panel1_panel_pharmacy_responsive").slideToggle("slow");
      icon_panel1_pharmacy_responsive_ON.classList.toggle("arrow");
    });
//    **********************************************************************************************************************************
    var icon_panel2_pharmacy_ON = document.getElementById("icon_panel2_pharmacy_ON");
    $("#panel2_pharmacy").click(function(){
      $("#panel2_pharmacy_panel").slideToggle("slow");
      icon_panel2_pharmacy_ON.classList.toggle("arrow");
    });
    var icon_panel2_pharmacy_responsive_ON = document.getElementById("icon_panel2_pharmacy_responsive_ON");
    $("#panel2_pharmacy_responsive").click(function(){
      $("#panel2_panel_pharmacy_responsive").slideToggle("slow");
      icon_panel2_pharmacy_responsive_ON.classList.toggle("arrow");
    });
//    **********************************************************************************************************************************
    var icon_panel3_pharmacy_ON = document.getElementById("icon_panel3_pharmacy_ON");
    $("#panel3_pharmacy").click(function(){
      $("#panel3_pharmacy_panel").slideToggle("slow");
      icon_panel3_pharmacy_ON.classList.toggle("arrow");
    });
    var icon_panel3_pharmacy_responsive_ON = document.getElementById("icon_panel3_pharmacy_responsive_ON");
    $("#panel3_pharmacy_responsive").click(function(){
      $("#panel3_pharmacy_panel_responsive").slideToggle("slow");
      icon_panel3_pharmacy_responsive_ON.classList.toggle("arrow");
    });
//    *********************************************************************************************************************************
    var icon_panel4_pharmacy_ON = document.getElementById("icon_pharmacy_panel4_ON");
    $("#panel4_pharmacy").click(function(){
      $("#panel4_pharmacy_panel").slideToggle("slow");
      icon_panel4_pharmacy_ON.classList.toggle("arrow");
    });
    var icon_panel4_pharmacy_responsive_ON = document.getElementById("icon_panel4_pharmacy_responsive_ON");
    $("#panel4_pharmacy_responsive").click(function(){
      $("#panel4_pharmacy_panel_responsive").slideToggle("slow");
      icon_panel4_pharmacy_responsive_ON.classList.toggle("arrow");
    });
//    *********************************************************************************************************************************
    var icon_panel5_pharmacy_ON = document.getElementById("icon_panel5_pharmacy_ON");
    $("#panel5_pharmacy").click(function(){
      $("#panel5_pharmacy_panel").slideToggle("slow");
      icon_panel5_pharmacy_ON.classList.toggle("arrow");
    });
    var icon_panel5_pharmacy_responsive_ON = document.getElementById("icon_panel5_pharmacy_responsive_ON");
    $("#panel5_pharmacy_responsive").click(function(){
      $("#panel5_pharmacy_panel_responsive").slideToggle("slow");
      icon_panel5_pharmacy_responsive_ON.classList.toggle("arrow");
    });
  });

</script>


