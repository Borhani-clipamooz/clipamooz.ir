<div class="signin">
   <div class="row">
    <img  style="width: 150px;height: 100px;" src="/asset/images/logo/logo1.jpg">
    <span id="messageUser"></span>
  </div>
  <div class="row">
    <div class="colx-4 colm-0 cols-0"></div>
    <div class="colx-4"> <input type="text" class="tac ltr" placeholder="<?=_ph_email?>" id="emailUser"  name="user_email"></div>
    <div class="colx-4 colm-0 cols-0"></div>
  </div>
  <div class="row">
    <div class="colx-4 colm-0 cols-0"></div>
    <div class="colx-4"><input type="password"  class="tac rtl" placeholder="<?=_ph_password?>" id="passwordUser" name="user_password"></div>
    <div class="colx-4 colm-0 cols-0"></div>
    <input type="hidden" id="passwordUserEncrypt" name="password">
  </div>
  <div class="row">
    <div class="colx-4 colm-0 cols-0"></div>
    <div class="colx-1 colm-fill cols-fill"><img src="/mvc/view/common/captcha/captcha_image.jpg.php"></div>
    <div class="colx-2 colm-fill cols-fill">
      <input class="tac hf" type="text" id="captcha_loginUser" >
    </div>
    <div class="colx-1 colm-fill cols-fill">
      <button id="btn_captcha_loginUser" onclick="captcha_loginUser();" class="btn_style btn-brown"><?=_btn_login?></button>
    </div>
    <div class="colx-4 colm-0 cols-0"></div>
  </div>
</div>
<script src="/asset/js/lib/hash/md5.min.js"></script>
<script src="/asset/js/lib/hash/sha1.min.js"></script>
<script>
  $(function () {
    $("#passwordUser").on("keyup", function (event) {

      $("#passwordUserEncrypt").val(js_encryptPassword($(this).val()));
    });
    $("#passwordUser").on("change", function (event) {
      $("#passwordUserEncrypt").val(js_encryptPassword($(this).val()));
    });
    var input = document.getElementById("captcha_loginUser");
    input.addEventListener("keyup", function(event) {
      event.preventDefault();
      if (event.keyCode === 13) {
        document.getElementById("btn_captcha_loginUser").click();
      }
    });
  });


  function captcha_loginUser(){
    var captcha=$("#captcha_loginUser").val();
    $.ajax({
      url:'/captcha',
      type: 'POST',
      dataType:'json',
      data:{
        captcha:captcha
      },
      success:function(data){
       if(data.status === false){
          swal("کد وارد شده ایراد دارد.");
          return;
        }else{
          loginUser();
        }
      }
    });
  }
  function loginUser(){
    var emailUser = $("#emailUser").val();
    var passwordUserEncrypt = $("#passwordUserEncrypt").val();
    $("#btn_captcha_loginUser").after('<div id="loader"><span class="icon-spinner9 huge spin "></span></div>');
    $.ajax({
      url: '/loginCheck/',
      type: 'POST',
      dataType: 'json',
      data:{
        emailUser:emailUser,
        passwordUserEncrypt:passwordUserEncrypt
      },
      success: function (data1) {
        $('#loader').slideUp(1000, function() {
          $(this).remove();
        });
        switch(data1.status) {
          case 'banded':
            document.getElementById("messageUser").innerHTML="حساب کاربری شما فعال نمی باشد.";
            break;
          case 'passwordISwronge':
            document.getElementById("messageUser").innerHTML="پسورد اشکال دارد دوباره سعی کنید.";
            break;
          case 'successlogin':
            window.location.href = "/main"
            break;
          case 'NotExistEmail':
            document.getElementById("messageUser").innerHTML="ایمیل وارد شده وجود ندارد.";
            break;
          default:
        }

      }
    });
  }

</script>


