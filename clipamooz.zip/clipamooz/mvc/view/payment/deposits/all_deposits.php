
<div class="rtl">
  <input type="text" style="display: none" id="user_id"  value="<?=$id?>" autocomplete="off">
</div>
<div id="paginationUpdate"></div>
<script>
  $(function () {
    all_deposits(<?=$pageIndex?>);
  });
  function all_deposits(pageIndex) {
    var user_id = $("#user_id").val();
    $.ajax({
      url: '/payment/all_deposits_ajax/'+pageIndex,
      method: 'POST',
      dataType: 'json',
      data: {
        user_id:user_id
      },
      success: function (output) {
       // console.log(output);
        $("#paginationUpdate").html(output.html);
      }
    });
  }


</script>









