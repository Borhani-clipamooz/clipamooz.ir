<div class="content">

      <table>
        <colgroup>
          <col width="5%">
          <col width="5%">
          <col width="15%">
          <col width="30%">
          <col width="30%">
          <col width="15%">
        </colgroup>
        <thead>
        <tr>
          <th class="tac"></th>
          <th class="tac">پروفایل</th>
          <th class="tac">نام کاربری</th>
          <th class="tac">نام کلیپ</th>
          <th class="tac">پیام کامنت</th>
          <th class="tac">تاریخ کامنت</th>
        </tr>
        </thead>
        <tbody>

        <? foreach ($list as $feild) {?>
        <tr>
          <td><span onclick="Remove_sql_data(<?= $feild['id']?>,<?=$pageIndex?>)" class="icon-bin large"</span></td>

          <?$data=CommonModel::Fetch_by_every('users','id',$feild['user_id']);?>
          <td>
            <?  if($data['profile_pic'] !=''){?>
              <a  href="/profile/<?=$data['id']?>" style="color: #f88;font-size: 14pt"><img style="width: 40px;height: 40px;border-radius: 50px" src="<?=$data['profile_pic']?>"></a>
            <?}else{?>
              <a  href="/profile/<?=$data['id']?>" style="color: #f88;font-size: 14pt"><img style="width: 40px;height: 40px;border-radius: 50px" src="/asset/images/empty/empty-profile/empty-profile-24.png"></a>
            <?}?>
          </td>
          <td ><?= $data['user_name'] ?></td>
          <td ><?= $feild['comment'] ?></td>
          <?$data=CommonModel::Fetch_by_every('clips','id',$feild['clip_id']);?>
          <td ><?= $data['name_fa'] ?></td>
          <td ><?=DateTimeCommon( $feild['created_at'] )?></td>
        </tr>

        <? } ?>
        </tbody>
      </table>
    <br>
    <!--Buttons Filter-->
    <?=pagination('/comment/all',3,'btn_style btn-brown','btn',$pageIndex,$pageCount,'getPage')?>

</div>

<script>

  function Remove_sql_data(Id,PageIndex) {
    swal({
        title: "آیا مطمئن هستید؟",
        text: "شما دیگر قادر به بازیابی این فایل نخواهید بود.",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#5d4126",
        confirmButtonText: "آره، آن را حذف کنید.",
        closeOnConfirm: false
      },
      function(){
        $.ajax({
          url: '/comment/Remove_sql_data/' + Id,
          type: 'POST',
          dataType: 'json',
          data:{
            pageIndex:PageIndex

          },
          success: function (data) {
            $("#paginationUpdate").html(data.html);
          }
        });
        swal("حذف گردید.");
      });


  }


</script>


