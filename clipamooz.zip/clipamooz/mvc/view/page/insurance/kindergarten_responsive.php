<div class="row">
  <section id="section-2">
    <div class="about-landing">
      <div class="container">
        <div class="about-text">
          <h2 style="color: #fffccc;">بیمه مسئولیت مدیران مهد کودک :</h2>
          <p style="margin-top: 50px">
            عبارتست از بیمه مسئولیت مدنی بیمه گذار در برابر کودکان ، بدین معنی که چنانچه در طول مدت نگهداری کودکان در مهد کودک ،خسارت بدنی ناشی از حادثه به کودکان وارد آید و بیمه گذار مسئول جبران آن شناخته شود ، بیمه گر پس از احراز مسئولیت بیمه گذار و در صورت لزوم بر اساس رای مراجع ذیصلاح قضایی نسبت به جبران خسارت اقدام خواهد نمود .مدیران مهد کودک با خرید این بیمه نامه در حاشیه امنیت کامل در برابر حوادث احتمالی ناشی از قصور و کوتاهی ، سهل انگاری خود و پرسنل مهد قرار خواهند گرفت . بیمه حوادث تحصیلی کودکان بیمه نامه دیگری است که مدیران مهد کودک می توانند علاوه بر بیمه مسئولیت مدیران مهد کودک به عنوان مکمل تهیه نمایند  .
          </p>
        </div>
        <div class="thumb wow animated zoomIn"><img style="border-radius: 10px" src="/asset/images/insurance/kindergarten.jpg" alt="مهدکودک"></div>
      </div>
    </div>
  </section>
  </div>
<div class="row">
  <section>
    <div class="container">
    <!--***********  INFO ---   Person   --   Responsive   ********************************************************************************-->
    <div class="info_person_responsive">
      <div id="panel1_kindergarten_responsive" class="titrbox"> <h1>&nbsp;&nbsp;استثنائات بیمه مسئولیت مدیران مهد کودک :<i id="icon_panel1_kindergarten_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="panel1_kindergarten_panel_responsive" style="display: none">
        <p style="font-size: 12pt;text-align: justify">
          1- خسارت های ناشی از عمد و تقلب بیمه گذار
        </p>
        <p style="font-size: 12pt;text-align: justify">
          2- خسارت های ناشی از انفجار هسته ای ، تشعشعات رادیو اکتیو
        </p>
        <p style="font-size: 12pt;text-align: justify">
          3-خسارت های ناشی از جنگ و انقلاب و شورش ، اعتصاب و عوامل دیگری از این قبیل
        </p>
        <p style="font-size: 12pt;text-align: justify">
          4- خسارت های ناشی از تخلف از قوانین نظامات دولتی
        </p>
      </div>    <!-- END panel1_responsive ******************-->
      <div id="panel2_kindergarten_responsive" class="titrbox "> <h1>&nbsp;&nbsp;حق بیمه بیمه مسئولیت مدیران مهد کودک:<i id="icon_panel2_kindergarten_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="panel2_kindergarten_panel_responsive" style="display: none">
        <p style="font-size: 12pt;text-align: justify">
          عوامل موثر در محاسبه حق بیمه عبارتند از :
        </p>
        <p style="font-size: 12pt;text-align: justify">
          1- ظرفیت نگهداری کودک
        </p>
        <p style="font-size: 12pt;text-align: justify">
          2- مدت بیمه نامه
        </p>
        <p style="font-size: 12pt;text-align: justify">
          3- میزان تعهدات هزینه پزشکی و غرامت فوت و نقص عضو
        </p>
        <p style="font-size: 12pt;text-align: justify">
          4- نگهداری یا عدم نگهداری از کودکان استثنائی
        </p>
        <p style="font-size: 12pt;text-align: justify">
          4- نگهداری یا عدم نگهداری از کودکان استثنائی
        </p>
        <p style="font-size: 12pt;text-align: justify">
          5- نگهداری یا عدم نگهداری از کودکان شیرخوار
        </p>
        <p style="font-size: 12pt;text-align: justify">
          6- برگزاری یا عدم برگزاری تورها و سفرهای گردشی  بیرون از مهد کودک
        </p>
        <p style="font-size: 12pt;text-align: justify">
          نکته مهم :
        </p>
        <p style="font-size: 12pt;text-align: justify">
          از آنجاییکه تعداد ظرفیت نگهداری کودک از عوامل مهم تعیین حق بیمه محسوب میگردد جهت جلوگیری از مشکلات حقوقی در زمان پرداخت خسارت حتما تعداد واقعی کودکان اعلام شود و چنانچه در طول مدت بیمه تغییراتی ایجاد شد حتما مراتب به اطلاع شرکت بیمه رسانیده شود .
        </p>
      </div><!--  END panel2_responsive  ******************-->
      <div id="panel3_kindergarten_responsive" class="titrbox "> <h1>&nbsp;&nbsp;نمونه حق بیمه بیمه مسئولیت مدنی مدیران مهد کودک :<i id="icon_panel3_kindergarten_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="panel3_kindergarten_panel_responsive" style="display: none">
        <p style="font-size: 12pt;text-align: justify">
          مدت : یکسال ، ظرفیت نگهداری کودک 30 نفر ، کودک شیر خوار ندارد ، کودک استثنائی ندارد ، تورها و سفرهای گردشی ندارد
        </p>
        <p style="font-size: 12pt;text-align: justify">
          هزینه پزشکی هر نفر در هر حادثه :                                    100/000/000        ریال
        </p>
        <p style="font-size: 12pt;text-align: justify">
          غرامت فوت و نقص عضو هر نفر در هر حادثه                       3/600/000/000      ریال
        </p>
        <p style="font-size: 12pt;text-align: justify">
          غرامت فوت و نقص عضو در طول مدت بیمه نامه                 10/800/000/000     ریال
        </p>
        <p style="font-size: 12pt;text-align: justify">
          حق بیمه سالیانه با احتساب مالیات ارزش افزوده :                   10/154/000      ریال
        </p>
      </div><!--  END panel3_responsive ******************-->
      <div id="panel4_kindergarten_responsive" class="titrbox "> <h1>&nbsp;&nbsp;بیمه حوادث تحصیلی نوباوگان مهد کودک :          <i id="icon_panel4_kindergarten_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="panel4_kindergarten_panel_responsive" style="display: none">
        <p style="font-size: 12pt;text-align: justify">
          بیمه حوادث تحصیلی نوباوگان مهد کودک بیمه نامه ای است که مدیران محترم مهد کودک می توانند علاوه بر بیمه مسئولیت مدنی مدیران تهیه کنند .این بیمه نامه غرامت فوت و نقص عضو و هزینه های پزشکی ناشی از حادثه را پرداخت میکند .
        </p>
      </div><!--  END panel3_responsive ******************-->
      <div id="panel5_kindergarten_responsive" class="titrbox "> <h1>&nbsp;&nbsp;شرایط بیمه نامه حوادث تحصیلی :<i id="icon_panel5_kindergarten_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="panel5_kindergarten_panel_responsive" style="display: none">
        <p style="font-size: 12pt;text-align: justify">
          مدت بیمه نامه : یکسال
        </p>
        <p style="font-size: 12pt;text-align: justify">
          1- پرداخت غرامت فوت ناشی از حادثه :                                                                            60/000/000 ریال
        </p>
        <p style="font-size: 12pt;text-align: justify">
          2- پرداخت غرامت نقص عضو کلی و جزیی دایم ناشی از حادثه تا سقف :                                  60/000/000 ریال
        </p>
        <p style="font-size: 12pt;text-align: justify">
          3- پرداخت هزینه های پزشکی ناشی از حادثه و اعمال جراحی آپاندیسیت ،

          فتق ، انسداد روده و مسمومیت غذایی ( حداکثر طبق تعرفه وزارت بهداشت

          و درمان و آموزش پزشکی ) تا سقف:                                                                                12/000/000 ریال
        </p>
      </div><!--  END academic_responsive_responsive ******************-->
      <div id="panel6_kindergarten_responsive" class="titrbox "> <h1>&nbsp;&nbsp;حق بیمه بیمه نامه حوادث تحصیلی :<i id="icon_panel6_kindergarten_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="panel6_kindergarten_panel_responsive" style="display: none">
        <p style="font-size: 12pt;text-align: justify">
          حق بیمه سالیانه هر یک از بیمه شدگان بصورت بانام با ارائه فایل مشخصات بیمه شدگان سالیانه نفری  10/000 ریال
          تبصره :  صدور بیمه حوادث تحصیلی نوباوگان مهدکودک بصورت بی نام منوط به اعلام حداکثر ظرفیت مهد کودک و پرداخت 20% حق بیمه بیشتر امکان پذیر است .
        </p>
      </div><!--  END academic_responsive_responsive ******************-->
      <div id="panel7_kindergarten_responsive" class="titrbox "> <h1>&nbsp;&nbsp;تفاوت بیمه مسئولیت مدنی مدیران مهد کودک با بیمه حوادث تحصیلی چیست ؟<i id="icon_panel7_kindergarten_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="panel7_kindergarten_panel_responsive" style="display: none">
        <p style="font-size: 12pt;text-align: justify">
          در بیمه حوادث تحصیلی چنانچه کودک به دلیل وقوع یک حادثه آسیب ببیند بدون در نظر گرفتن اینکه مقصر حادثه چه کسی است خسارت پرداخت میشود لیکن در بیمه مسئولیت مدنی مدیران مهد کودک خسارت صرفا زمانی پرداخت خواهد شد که مدیر مهد کودک مسئول و مقصر شناخته شود و مسئولیت وی محرز گردد .
        </p>
        <p style="font-size: 12pt;text-align: justify">
          تصور کنید کودکی در یک مهد کودک بدلیل برق گرفتگی فوت نماید در چنین شرایطی از محل بیمه حوادث تحصیلی غرامت فوت ناشی از حادثه به مبلغ 60/000/000 ریال پرداخت خواهد شد اما خانواده کودک با شکایت از مهد کودک موضوع را به دادگاه می کشانند و پس از انجام کارشناسی ها مدیر مهد کودک مقصر شناخته میشود و با صدور رای دادگاه به پرداخت یک فقره دیه کامل ( ماههای غیر حرام 270 و ماههای حرام 360 میلیون تومان در سال 1398 ) به خانواده کودک فوت شده محکوم می گردد . در چنین شرایطی بیمه مسئولیت مدیران مهد کودک با حمایت از مدیر مهد کودک دیه را پرداخت خواهد کرد . بنابراین بیمه حوادث تحصیلی هرگز نمی تواند جایگزین بیمه مسئولیت مدیران مهد کودک باشد هرچند مکمل مناسبی است . لذا اکیدا به مدیران مهد کودک توصیه میگردد برای قرار گرفتن در حاشیه امنیت در برابر خطرهایی احتمالی نسبت به تهیه بیمه مسئولیت مدیران مهد کودک اقدام نمایند . همچنین مدیران مهد کودک در برابر حوادث احتمالی که ممکن است برای کارکنان رخ دهد نیز مسئولیت دارند لذا علاوه بر بیمه نامه های ذکر شده فوق تهیه بیمه مسئولیت مدنی کارفرما در قبال کارکنان توصیه میگردد .
        </p>
      </div><!--  END  panel7 Panle Responsive ******************-->
    </div><!--  END info person Responsive  ******************-->
    </div>
  </section>
  <section style="padding:0 10px 0 10px">
  <p style="font-size: 12pt;color: #fffccc;text-align: right">
            <span>
              <strong>خرید بیمه نامه :</strong>
            </span>
  </p>
  <p style="font-size: 12pt;text-align: justify">
    جهت خرید بیمه نامه لطفا فرم زیر را  دانلود و پس از تکمیل به یکی از روشها شبکه های اجتماعی (سروش ، تلگرام ، واتس آپ ) و یا ایمیل برای اینجانب ارسال نمایید تا فرم اعلام حق بیمه و متعاقب آن صدور بیمه نامه صورت پذیرد .
  </p>
  </section>
  <div class="row">
  <button class="btn btn-brown" onclick="window.location.href='/pdf/kindergarten'">دانلود فرم بیمه مسئولیت مهدکودک</button>
  </div>
</div>