<div class="content">

      <table>
        <colgroup>
          <col width="4%">
          <col width="4%">
          <col width="15%">
          <col width="65%">
          <col width="12%">
        </colgroup>
        <thead>
        <tr>

          <th class="tac">جزئیات</th>
          <th class="tac">پروفایل</th>
          <th class="tac">نام کاربری</th>
          <th class="tac">پیام</th>
          <th class="tac">تاریخ</th>
        </tr>
        </thead>
        <tbody>

        <? foreach ($list as $feild) {?>
        <tr>
            <td ><span onclick="Remove_item(<?= $feild['id']?>,<?=$pageIndex?>)"><i style="cursor: pointer;margin-top: 5px" class="icon-bin large"></i></span></td>

          <?$data2=CommonModel::Fetch_by_every('users','id',$feild['receiver_message_id']);?>
          <td>
            <?  if($data2['profile_pic'] !=''){?>
              <a  href="/profile/<?=$data2['id']?>" style="color: #f88;font-size: 14pt"><img style="width: 40px;height: 40px;border-radius: 50px" src="<?=$data2['profile_pic']?>"></a>
            <?}else{?>
              <a  href="/profile/<?=$data2['id']?>" style="color: #f88;font-size: 14pt"><img style="width: 40px;height: 40px;border-radius: 50px" src="/asset/images/empty/empty-profile/empty-profile-24.png"></a>
            <?}?>
          </td>
        <td ><?= $data2['user_name'] ?></td>
        <td ><?= $feild['body'] ?></td>
          <td ><?= DateTimeCommon($feild['date_send_message']); ?></td>
        </tr>

        <? } ?>
        </tbody>
      </table>
    <br>
    <!--Buttons Filter-->
  <div style="margin-bottom: 15px"><?=pagination('',3,'btn_style btn-brown','btn',$pageIndex,$pageCount,'all_sender_message')?></div>

</div>

<script>

  function View(Id,PageIndex) {

    $.ajax({
      url: '/question/view/' + Id,
      type: 'POST',
      dataType: 'json',
      data:{
        pageIndex:PageIndex
      },
      success: function (data) {
        $("#paginationUpdate").html(data.html);
      }
    });
  }
  function Remove_item(Id,PageIndex) {

    $.ajax({
      url: '/user/remove_sender_message/' + Id,
      type: 'POST',
      dataType: 'json',
      data:{
        pageIndex:PageIndex
      },
      success: function (data) {
        $("#paginationUpdate").html(data.html);
      }
    });
  }
</script>


