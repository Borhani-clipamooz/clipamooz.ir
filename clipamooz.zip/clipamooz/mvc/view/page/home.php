<section>
  <div>
    <?require(getcwd() . "/mvc/view/clip/new_clip.php");?>
  </div>
<div>
  <?require(getcwd() . "/mvc/view/clip/most_view_clip.php");?>
</div>
<div>
  <?require(getcwd() . "/mvc/view/clip/popular_clip.php");?>
</div>
<div  id="popular_clip"></div>
</section>
<div class="clearfix"></div>
<section id="section-2">
  <div class="about-landing">
    <div class="container">
      <div class="about-text">
        <h3>درباره ما</h3>
        <p>
          عرض سلام ادب و احترام خدمت کاربر عزیز و محترم: هدف این وب سایت مکانی برای ارائه آموزش های خودتون می باشد و صرفا کارش آموزش می باشد. دروب سایت حاضر شما آموزش هایی که تولید می کنید را در این وب سایت به معرض نمایش گذاشته و حال در صورت تمایل هزینه ای از کاربر دریافت می نمایید و می توانید این هزینه را به صورت اهدایی قرار دهید .  سرور این وب سایت ایرانی می باشد لذا مصرف اینترنت شما از این سایت رایگان می باشد.
        </p>
      </div>
      <div class="thumb wow animated zoomIn"><img style="border-radius: 5px" src="/asset/images/logo/logo1.jpg" alt="تصویر لوگو وب سایت"></div>
    </div>
  </div>
</section>
<div class="clearfix"></div>
<section id="section-3">
  <div class="contact-landing">
    <div class="container">
      <div class="map">
        <h3><i class="icon-question">&nbsp;</i>سوالات متداول</h3>
          <div class="questions text" id="cloud">
<!--           UPLOAD VIEDO  ************************************************************************************************-->
            <div id="upload_video">
              <h1><i id="icon_upload_video" style="float: right" class="icon-circle-left huge"></i>&nbsp;&nbsp;بارگذاری ویدیو</h1>
            </div>
<!--            *******************************************************************************************-->
            <div id="upload_video_panel" style="display: none">
            <h2><i id="icon_upload_video1" style="float: right" class="icon-circle-left large"></i>&nbsp;&nbsp;چگونه می‌توانم ویدیو بارگذاری کنم؟</h2>
              <div id="upload_video_panel1" style="display: none">
                <h3>بعد از اینکه در سایت ثبت نام کرده و به کاربری خود وارد شدید، در قسمت مدیریت کلیپ ،آپلود ها میتوانید ویدیوی خود را بارگذاری کنید.</h3>
              </div>
<!--            *******************************************************************************************-->
            <h2><i id="icon_upload_video2" style="float: right" class="icon-circle-left large"></i>&nbsp;&nbsp;حجم بارگذاری ویدیوها حداکثر چقدر است؟</h2>
              <div id="upload_video_panel2" style="display: none">
                <h3>محدودیتی نداریم.</h3>
              </div>
<!--            *******************************************************************************************-->
            <h2><i id="icon_upload_video3" style="float: right" class="icon-circle-left large"></i>&nbsp;&nbsp;برای دیده شدن ویدیوی بارگذاری شده چقدر زمان لازم است؟</h2>
              <div id="upload_video_panel3" style="display: none">
                <h3>معمولا حدود ۱۵ دقیقه زمان می برد تا ویدیو از حالت "در حال پردازش" خارج شده و در دسترس قرار گیرد.</h3>
              </div>
<!--        END   UPLOAD VIEDO  ************************************************************************************************-->
            </div>
            <!--           profile  ************************************************************************************************-->
            <div id="profile">
              <h1><i id="icon_profile" style="float: right" class="icon-circle-left huge"></i>&nbsp;&nbsp;حساب کاربری</h1>
            </div>
            <!--            *******************************************************************************************-->
            <div id="profile_panel" style="display: none">
              <h2><i id="icon_profile1" style="float: right" class="icon-circle-left large"></i>&nbsp;&nbsp;تصویر پروفایل را کجا بار گذاری کنم؟</h2>
              <div id="profile_panel1" style="display: none">
                <h3>ابتدا وارد حساب کاربری خود شوید سپس در قسمت اطلاعات پایه بخش اطلاعات فردی میتوانید تصویر مورد نظر خود را بارگذاری کنید.</h3>
              </div>
            </div>
              <!--        END   profile  ************************************************************************************************-->
          </div>
      </div>
      <div class="contact-form">
          <p><input type="text" id="family_send_email" placeholder="نام و نام خانوادگی"></p>
          <p><input type="email" id="email_send_email" data-rule="email_is_Free" placeholder="پست الکترونیک"></p>
          <p><input type="text" id="subject_send_email" placeholder="موضوع"></p>
          <p><textarea id="message_send_email" placeholder="پیام شما"></textarea></p>
        <div class="row">
          <div class="colx-3"><button class="btn_style btn-brown" id="submit_send_email">ارسال</button></div>
          <div class="colx-3" ><input class="tac hf" type="text" id="captcha"> </div>
          <div class="colx-3"> <img src="/mvc/view/common/captcha/captcha_image.jpg.php" alt="image-captcha"></div>
        </div>
      </div>
    </div>
  </div>
</section>
<script>
  $(function () {

    <!--           UPLOAD VIEDO  ************************************************************************************************-->
    var icon_upload_video=document.getElementById("icon_upload_video");
    $("#upload_video").click(function(){
      $("#upload_video_panel").slideToggle("slow");
      icon_upload_video.classList.toggle("arrow90");
    });
    var icon_upload_video1=document.getElementById("icon_upload_video1");
    $("#icon_upload_video1").click(function(){
      $("#upload_video_panel1").slideToggle("slow");
      icon_upload_video1.classList.toggle("arrow90");
    });
    var icon_upload_video2=document.getElementById("icon_upload_video2");
    $("#icon_upload_video2").click(function(){
      $("#upload_video_panel2").slideToggle("slow");
      icon_upload_video2.classList.toggle("arrow90");
    });
    var icon_upload_video3=document.getElementById("icon_upload_video3");
    $("#icon_upload_video3").click(function(){
      $("#upload_video_panel3").slideToggle("slow");
      icon_upload_video3.classList.toggle("arrow90");
    });
    <!--           profile   ************************************************************************************************-->
    var icon_upload_video=document.getElementById("icon_profile");
    $("#profile").click(function(){
      $("#profile_panel").slideToggle("slow");
      icon_upload_video.classList.toggle("arrow90");
    });
    var icon_profile1=document.getElementById("icon_profile1");
    $("#icon_profile1").click(function(){
      $("#profile_panel1").slideToggle("slow");
      icon_profile1.classList.toggle("arrow90");
    });
    $("#cloud").mCustomScrollbar({
      scrollButtons: {
        enable: true
      },
      theme: "dark-thick"
    });
    <!--    END       profile  ************************************************************************************************-->
    function captcha(handleData){
      var captcha=$("#captcha").val();
      $.ajax({
        url:'/captcha',
        type: 'POST',
        dataType:'json',
        data:{
          captcha:captcha
        },
        success:function(data){
          handleData(data);
        }
      });
    }
    var input = document.getElementById("captcha");
    input.addEventListener("keyup", function(event) {
      event.preventDefault();
      if (event.keyCode === 13) {
        document.getElementById("submit_send_email").click();
      }
    });
    $("#submit_send_email").on('click', function () {
      var validation = true;
      $("input").each(function () {
        var family_send_email= $("#family_send_email").val();
        var email_send_email=  $("#email_send_email").val();
        var subject_send_email=$("#subject_send_email").val();
        var message_send_email=$("#message_send_email").val();
        var captcah=$("#captcha").val();
        if (family_send_email==''||email_send_email==''||subject_send_email==''||message_send_email==''||captcah=='') {
          validation = false;
          return;
        }
      })
      captcha(function(data){
        if(data.status==false){
          swal("کد وارد شده ایراد دارد.");
          validation = false;
          return;
        }else{
          if (!validation) {
            swal("اطلاعات وارد شده دارای اشکال می باشد.");
          }else{
            send_email();
          }
        }
      });
    });
  });
  function send_email(){
    var family_send_email=$("#family_send_email").val();
    var email_send_email=$("#email_send_email").val();
    var subject_send_email=$("#subject_send_email").val();
    var message_send_email=$("#message_send_email").val();
    $("#submit_send_email").after('<div id="loader"><span class="icon-spinner9 huge spin "></span></div>');
    $.ajax({
      url:'/Receive_message_email/',
      type: 'POST',
      dataType:'json',
      data:{
        family_send_email:family_send_email,
        email_send_email:email_send_email,
        subject_send_email:subject_send_email,
        message_send_email:message_send_email
      },
      success:function(data){
        $('#loader').slideUp(200, function() {
          $(this).remove();
        });
        if(data.status==true){
          swal({
              title: "از پیام شما بسیار سپاسگزاریم .",
              text: "پس از بررسی پاسخ شما خواهد داده شد",
              imageUrl: "/asset/images/logo/logo1.jpg",
              closeOnConfirm: false,
              showLoaderOnConfirm: true
            },
            function () {
              setTimeout(function () {
                $("#family_send_email").val('');
                $("#email_send_email").val('');
                $("#subject_send_email").val('');
                $("#message_send_email").val('');
                $("#captcha").val('');
                swal.close();
              }, 2000);
            });
        }
      }
    });
  }
</script>