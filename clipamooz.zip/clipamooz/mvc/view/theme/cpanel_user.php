<?
if (!isset($pageTitle)) {
  $pageTitle = "پنل کاربری";
}

?>
<!DOCTYPE html>
<html lang="FA">
<head>
  <?require(getcwd() . "/mvc/view/theme/theme.php");?>
  <script src="/mvc/view/uploader/upload.js"></script>
</head>

<script>
  $(function () {
    $(".nav-bar").click(function(){
      $(".Cpanel_user_right_menu_responsive").toggle(200);
    });
  });
</script>

<body>
<div class="info_menu_user">
  <div class="nav-bar tac">
    <span class="icon-bar"></span>
    <span class="icon-bar"></span>
    <span class="icon-bar"></span>
  </div>
</div>

<div class="row">
  <div class="box-new">
    <div class="colx-2 colm-fill">
          <div class="landing-boxnew1">
            <h1>پنل کاربری</h1>
          </div>
    </div>
    <div class="colx-5 colm-fill tac">
      <img src="/asset/images/468-60.gif">
    </div>
    <div class="colx-5 colm-fill tac">
      <img src="/asset/images/468-60.gif">
    </div>
  </div>
</div>
<div class="Cpanel_user_right_menu_responsive" style="display: none">
  <div>
    <?require(getcwd() . "/mvc/view/user/cpanel_user_right_menu.php")?>
  </div>
</div>
<div class="container">
  <div class="row">
    <div class="colx-2 colm-0 cols-0" style=" vertical-align: top;">
      <?require(getcwd() . "/mvc/view/user/cpanel_user_right_menu.php")?>
    </div>
    <div class="colx-10 colm-fill cols-fill" style=" vertical-align: top;" >
      <?= $content ?>
    </div>
  </div>
</div>
<section>
<!--  --><?//require(getcwd() . "/mvc/view/footer/footer.php");?>
</section>
</body>
</html>