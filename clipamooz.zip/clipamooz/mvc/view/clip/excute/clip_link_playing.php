<!--<script type="text/javascript" src="/jwplayer-7.12.2/jwplayer.js"></script>-->
<!--<script type="text/javascript">jwplayer.key="e+FEhSmQKBoyj9D2dsPFaySjoz51O3VrlthwSg==";</script>-->
<?
global $config;
?>
<!--  <input   type="hidden" id="play" value="--><?//=$config['upload'].$clip_link?><!--">-->
<input     type="hidden" id="img_link" value="<?=$config['upload'].$img_link?>">
<?
$secret = 'clipamoozsecret';
$baseUrl ='https://clipamooz.ir';
$path = $clip_link;
$ttl = 10; //no of seconds this link is active
$userIp = $_SESSION['ip']; // normally you would read this from something like $_SERVER['REMOTE_ADDR'];
function buildSecureLink($baseUrl, $path, $secret, $ttl, $userIp)
{
  $expires = time() + $ttl;
  $md5 = md5("$expires$path$userIp $secret", true);
  $md5 = base64_encode($md5);
  $md5 = strtr($md5, '+/', '-_');
  $md5 = str_replace('=', '', $md5);
  return $baseUrl . $path . '?md5=' . $md5 . '&expires=' . $expires;
}
?>
<video width="100%" height="100%" controls autoplay>
<!--  <source src="--><?//=$config['upload'].$clip_link?><!--" type="video/mp4">-->
    <source src="<?echo buildSecureLink($baseUrl, $path, $secret, $ttl, $userIp);?>" type="video/mp4">
</video>
<!--<script type="text/javascript">
  var play=$('#play').val();
  var img_link=$('#img_link').val();
  var playerinstance=jwplayer('myplayer_clip_link');
  playerinstance.setup({
    file:play,
    image:img_link,
    height:250,
    width:"100%",
    logo: {
      file: '/asset/images/logo/logo3.png',
      link: 'http://clipamooz.ir'
    }
  });
</script>-->