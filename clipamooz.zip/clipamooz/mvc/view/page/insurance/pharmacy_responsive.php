<div class="row">
  <section id="section-2">
    <div class="about-landing">
      <div class="container">
        <div class="about-text">
          <h2 style="color: #fffccc;">بیمه مسئولیت مسئول فنی بیمارستان : </h2>
          <p>
            بيمه مسئوليت مدنی مسئول فنی بيمارستان ، کلينيک ، درمانگاه ، داروخانه ، آزمايشگاه در قبال بيماران ، اشخاص ثالث مانند مراجعه کنندگان و همراهان بیمارو ذوی الحقوق آنان ، بدين معنی که چنانچه در جريان اجرای وظایف مسئولين فنی مراکز ياد شده فوق که از طرف وزارت بهداشت و درمان و آموزش پزشکی تعيين و تاييد گرديده حادثه ای رخ دهد و مسئولين فنی در قبال بيماران و اشخاص ثالث طبق قانون مسئول و ملزم به جبران خسارت گردند بيمه پاسارگاد با رعايت شرايط بيمه نامه خسارت ادعا شده از مسئول فنی را پرداخت خواهد کرد .
          </p>
        </div>
        <div class="thumb wow animated zoomIn"><img style="border-radius: 2%;width: 100%;height: 240px" src="/asset/images/insurance/Pharmacy.jpg" alt="بیمارستان"></div>
      </div>
    </div>
  </section>
</div>
<div class="row">
  <section>
    <div class="container">
      <!--***********  INFO ---   Person   --   Responsive   ********************************************************************************-->
      <div class="info_person_responsive">
        <div id="panel1_pharmacy_responsive" class="titrbox"> <h1>&nbsp;&nbsp;تعهدات بيمه گر در بیمه مسئول فنی بیمارستان :<i id="icon_panel1_pharmacy_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
        <div id="panel1_panel_pharmacy_responsive" style="display: none">
          <p style="font-size: 12pt;text-align: justify">
            1-	 پرداخت هزينه هاي دادرسی در صورت اقامه دعوی عليه بيمه گذار در حد متعارف و منوط به اينکه از 10% مبلغ خسارت بيشتر نباشد در تعهد بيمه پاسارگاد خواهد بود.
          </p>
          <p style="font-size: 12pt;text-align: justify">
            2-  تعهد بيمه پاسارگاد منحصر به مسئوليت های مسئول فني در مدت اعتبار بيمه نامه می باشد مشروط بر اينکه ادعای خسارت حداکثر ظرف 3 سال پس ازتاريخ پايان بيمه نامه به بیمه پاسارگاد علام گردد . به عبارت ديگر ادعاهایی که پس از گذشت سه سال از تاريخ پايان بيمه مطرح گردد مسموع نخواهد بود.
          </p>
        </div>    <!-- END panel1_responsive ******************-->
        <div id="panel2_pharmacy_responsive" class="titrbox "> <h1>&nbsp;&nbsp;تعهدات مسئول فنی در بیمه نامه :<i id="icon_panel2_pharmacy_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
        <div id="panel2_panel_pharmacy_responsive" style="display: none">
          <p style="font-size: 12pt;text-align: justify">
            1-	  مسئول فنی ميبايست ترتيبی اتخاذ نمايد تا مرکز درمانی شرايط زير را داشته باشد
          </p>
          <p style="font-size: 12pt;text-align: justify">
            الف : کليه کارکنان متناسب با وظايف خود تجربه و مهارت که عرفا لازم است را داشته باشند.
          </p>
          <p style="font-size: 12pt;text-align: justify">
            ب : در مرکز درمانی وسايل و تجهيزات ايمنی،فوريتی (اورژانسی)، حفاظتی و اطفاء حريق را که عرفا لازم است تعبيه نموده و به طور صحيح استفاده و مورد عمل قرار گيرند.
          </p>
          <p style="font-size: 12pt;text-align: justify">
            2- مسئول فنی بدون موافقت بيمه پاسارگاد در مورد مسئوليت های خود در حوادث احتمالی تعهدی در قبال مدعی بعهده نگيرد ويا وجهی نپردازد مگر با موافقت شرکت بيمه
          </p>
          <p style="font-size: 12pt;text-align: justify">
            3-  مسئول فنی متعهد است هرگونه حادثه احتمالی مرتبط با بيمه نامه را و يا هرنوع ادعا و مطالبه اشخاص ثالث عليه خود را بدون فوت وقت و حداکثر ظرف مدت پنج روز از تاريخ اطلاع به بيمه پاسارگاد اعلام کند.
          </p>
        </div><!--  END panel2_responsive  ******************-->
        <div id="panel3_pharmacy_responsive" class="titrbox "> <h1>&nbsp;&nbsp;استثنائات بيمه مسئولیت مسئول فنی بیمارستان :<i id="icon_panel3_pharmacy_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
        <div id="panel3_pharmacy_panel_responsive" style="display: none">
          <p style="font-size: 12pt;text-align: justify">
            1-	خسارات ناشی از جنگ ، انقلاب ، شورش ، اعتصاب و عوامل ديگر از اين قبيل
          </p>
          <p style="font-size: 12pt;text-align: justify">
            2-  خسارات ناشی از انفجار اتمی و تشعشعات راديو اکتيو و يونيزه
          </p>
          <p style="font-size: 12pt;text-align: justify">
            3-  خسارات ناشی از عمد و تقلب بيمه گذار
          </p>
          <p style="font-size: 12pt;text-align: justify">
            4-  خسارات ناشی از تخلف از اجرای قوانين و مقررات دولتی و جرائم
          </p>
          <p style="font-size: 12pt;text-align: justify">
            5-  خسارات ناشی از وقوع حوادث طبيعی
          </p>
          <p style="font-size: 12pt;text-align: justify">
            6- خسارات تحت پوشش در بيمه نامه مسئوليت حرفه ای پزشکان
          </p>
          <p style="font-size: 12pt;text-align: justify">
            7- خسارات مربوط به مسئوليت مدنی ناشی از قراردادهايی که بيمه گذار با ديگران منعقد کرده است
          </p>
          <p style="font-size: 12pt;text-align: justify">
            8- مسئوليت خساراتی که به مرکز درمانی وارد ميشود از قبيل تاسيسات ، ساختمان ، وسائط نقليه  و ...
          </p>
          <p style="font-size: 12pt;text-align: justify">
            9-  مسئوليت زيانهای مالی يا از دست دادن درآمد مرکز درمانی
          </p>
          <p style="font-size: 12pt;text-align: justify">
            10- خسارت وارده به کارکنان بيمه گذار
          </p>
        </div><!--  END panel3_responsive ******************-->
        <div id="panel4_pharmacy_responsive" class="titrbox "> <h1>&nbsp;&nbsp;چند نمونه از شرح وظایف مسئولین فنی مراکز درمانی طبق دستورالعمل وزارت بهداشت :<i id="icon_panel4_pharmacy_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
        <div id="panel4_pharmacy_panel_responsive" style="display: none">
          <p style="font-size: 12pt;text-align: justify">
            1- جلوگیری از اعمال پزشکی غیر مجاز یا بدون اندیکاسیون های علمی
          </p>
          <p style="font-size: 12pt;text-align: justify">
            2- نظارت بر کیفیت و قابلیت استفاده تجهیزات و ملزومات پزشکی در مرکز درمانی
          </p>
          <p style="font-size: 12pt;text-align: justify">
            3- کنترل و مراقبت وضعیت بهداشتی ، درمانی تجهیزات پزشکی و دارویی مرکز درمانی
          </p>
          <p style="font-size: 12pt;text-align: justify">
            4- نظارت بر کلیه امور فنی خدمات انجام شده در مرکز درمانی و پاسخگویی در ارتباط با اقدامات انجام شده مبتنی بر قوانین و مقررات و دستورالعمل های وزارت بهداشت
          </p>
          <p style="font-size: 12pt;text-align: justify">
            5- کنترل و نظارت بر پذیرش موارد فوریت های پزشکی بدون پیش شرط و انجام خدمات درمانی لازم در مورد بیماران اورژانس و در صورت لزوم هماهنگی جهت اعزام بیمار به مراکز تخصصی واجد شرایط
          </p>
        </div><!--  END panel3_responsive ******************-->
        <div id="panel5_pharmacy_responsive" class="titrbox "> <h1>&nbsp;&nbsp;فرانشيز بیمه مسئولیت مسئول فنی بیمارستان:<i id="icon_panel5_pharmacy_responsive_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
        <div id="panel5_pharmacy_panel_responsive" style="display: none">
          <p style="font-size: 12pt;text-align: justify">
            حق بيمه بر اساس نوع مرکز درمانی (بيمارستان ،درمانگاه،کلينيک ، آزمايشگاه و ...) و ظرفيت نگهداری بيمار ، مدت بيمه نامه و تعهدات درخواست شده محاسبه ميگردد .
          </p>
          <p style="font-size: 12pt;text-align: justify">
            به عنوان مثال :
          </p>
          <p style="font-size: 12pt;text-align: justify">
            تعهد بيمه گر در رابطه با فوت ، نقص عضو، ازکارفتادگی و ساير صدمات بدنی برای هر نفر تا سقف :         3/600/000/000  ريال
          </p>
          <p style="font-size: 12pt;text-align: justify">
            تعهد بيمه گر در رابطه با فوت، نقص عضو، ازکارافتادگی و ساير صدمات بدنی در هر حادثه تا سقف :        18/000/000/000 ريال
          </p>
          <p style="font-size: 12pt;text-align: justify">
            تعهد بيمه گر در رابطه با فوت، نقص عضو، ازکارافتادگی و ساير صدمات بدنی در طول مدت بيمه نامه   :  30/000/000/000 ريال
          </p>
          <p style="font-size: 12pt;text-align: justify">
            حق بيمه سالیانه بیمه مسئولیت مسئول فنی بيمارستان با تعداد 100 تخت : 70/630/000 ريال
          </p>
          <p style="font-size: 12pt;text-align: justify">
            حق بیمه سالیانه بیمه مسئولیت مسئول فنی درمانگاه شبانه روزی :                                              52/974/000  ریال
          </p>
          <p style="font-size: 12pt;text-align: justify">
            حق بیمه سالیانه بیمه مسئولیت مسئول فنی  داروخانه شبانه روزی :                                             26/487/000  ریال
          </p>
          <p style="font-size: 12pt;text-align: justify">
            حق بیمه سالیانه بیمه مسئولیت مسئول فنی آزمایشگاه :                                                            35/316/000  ریال
          </p>
        </div><!--  END academic_responsive_responsive ******************-->
      </div><!--  END info person Responsive  ******************-->
    </div>
  </section>
  <section style="padding:0 10px 0 10px">
    <p style="font-size: 12pt;color: #fffccc;text-align: right">
            <span>
              <strong>خرید بیمه نامه :</strong>
            </span>
    </p>
    <p style="font-size: 12pt;text-align: justify">
      جهت خرید بیمه نامه لطفا فرم زیر را  دانلود و پس از تکمیل به یکی از روشها شبکه های اجتماعی (سروش ، تلگرام ، واتس آپ ) و یا ایمیل برای اینجانب ارسال نمایید تا فرم اعلام حق بیمه و متعاقب آن صدور بیمه نامه صورت پذیرد .
    </p>
  </section>
  <div class="row">
  <button class="btn btn-brown" onclick="window.location.href='/pdf/pharmacy'">بیمه نامه مسئولیت حرفه ای مسئول فنی بیمارستان درمانگاه کلینیک داروخانه </button>
  </div>
</div>