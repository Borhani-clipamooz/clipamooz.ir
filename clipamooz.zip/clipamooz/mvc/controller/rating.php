<?php

class RatingController {
  public function __construct() {

  }
//**************************************************************************************
  public function AddRating($id) {
    $clip_name=$_POST['clip_name'];
    $user_id=$_POST['user_id'];
    $pageIndex=$_POST['pageIndex'];
     $data['id']=$id;
     $data['clip_name']=$clip_name;
     $data['user_id']=$user_id;
     $data['pageIndex']=$pageIndex;
    ob_start();
    View::renderPartial("/rating/add_rating.php",$data);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));
  }
  public function Save_Rating() {
    $clip_id=$_POST['clip_id'];
    $last_count=$_POST['last_count'];
    $user_id=$_POST['user_id'];
    $data_clip_buy=CommonModel::Fetch_by_two('clips_buy','user_id',$user_id,'clip_id',$clip_id);
    CommonModel::update_spacial_field($data_clip_buy['id'],'clips_buy','status_vote',1);

    $data=  CommonModel::Fetch_by_every('rating','clip_id',$clip_id);
    CommonModel::update_spacial_field($data['id'],'rating','voters',$last_count.$user_id);
    $count_rate=$data['count_rate']+1;
    CommonModel::update_spacial_field($data['id'],'rating','count_rate',$count_rate);
    $vote=$_POST['vote'];
    switch($vote){
      case 1: {
        $rate1 = $data['rate1'] + 1;
        CommonModel::update_spacial_field($data['id'], 'rating', 'rate1', $rate1);
        break;
      }
      case 2: {
        $rate2 = $data['rate2'] + 1;
        CommonModel::update_spacial_field($data['id'], 'rating', 'rate2', $rate2);
        break;
      }
      case 3: {
        $rate3 = $data['rate3'] + 1;
        CommonModel::update_spacial_field($data['id'], 'rating', 'rate3', $rate3);
        break;
      }
      case 4: {
        $rate4 = $data['rate4'] + 1;
        CommonModel::update_spacial_field($data['id'], 'rating', 'rate4', $rate4);
        break;
      }
      case 5: {
        $rate5 = $data['rate5'] + 1;
        CommonModel::update_spacial_field($data['id'], 'rating', 'rate5', $rate5);
        break;
      }
    }
    $data2=  CommonModel::Fetch_by_every('rating','clip_id',$clip_id);
    $Count=($data2['rate1']*1)+($data2['rate2']*2)+($data2['rate3']*3)+($data2['rate4']*4)+($data2['rate5']*5);
    $Average=round($Count/$data2['count_rate'],1);
   // $Average=round(4.5,1);

    CommonModel::update_spacial_field($data2['id'], 'rating', 'average', $Average);
    CommonModel::update_spacial_field($clip_id, 'clips', 'rating', $Average);
    ob_start();
    View::renderPartial("/rating/detail_rating.php",$data);
    $output = ob_get_clean();
    echo json_encode(array('status' => $Average, 'html' => $output,));
  }


 }