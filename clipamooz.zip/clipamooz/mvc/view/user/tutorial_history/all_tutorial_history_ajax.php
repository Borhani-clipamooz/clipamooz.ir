<div class="content">
  <div class="all_tutorial_history_panel">
  <div id="tutorial_history" class="titrbox "> <h1>&nbsp;&nbsp;دوره های آموزشی( زبان خارجی ،کامپيوتر و... ) :<i id="icon_tutorial_history_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
    <div class="row">
      <div class="colx-1">
        <h2 >جزئیات</h2>
      </div>
      <div class="colx-1">
        <h2 >حذف</h2>
      </div>
      <div class="colx-2">
        <h2 >نام دوره</h2>
      </div>
      <div class="colx-2">
        <h2>سطح</h2>
      </div>
      <div class="colx-2">
        <h2>محل آموزش</h2>
      </div>
      <div class="colx-2">
        <h2>سال</h2>
      </div>
      <div class="colx-2">
        <h2>میزان ساعت دوره</h2>
      </div>
    </div>
    <? foreach ($list as $field) {?>
      <div class="row">
        <div class="colx-1">
          <h3 style="cursor: pointer" onclick="View_Detail(<?= $field['id']?>)"><i class="icon-folder-open large"></i></h3>
        </div>
        <div class="colx-1">
          <h3 style="cursor: pointer" onclick="Remove_item(<?= $field['id']?>,<?=$pageIndex?>,'tutorial_history',<?=$field['user_id']?>)"><i class="icon-bin"></i></h3>
        </div>
        <div class="colx-2">
          <h3><?=$field['course_name']?></h3>
        </div>
        <div class="colx-2">
          <h3><?=$field['level_name']?></h3>
        </div>
        <div class="colx-2">
          <h3><?=$field['tutorial_place']?></h3>
        </div>
        <div class="colx-2">
          <h3><?=$field['tutorial_year']?></h3>
        </div>
        <div class="colx-2">
          <h3><?=$field['tutorial_times']?></h3>
        </div>
      </div>
    <?}?>
    <br>
    <div class="row tac">
      <?=pagination('',3,'btn_style btn-brown','btn',$pageIndex,$pageCount,'tutorial_history')?>
    </div>
    <br>
  </div>
  <div class="all_tutorial_history_panel_responsive">
    <div id="tutorial_history" class="titrbox "> <h1>&nbsp;&nbsp;دوره آموزشی( زبان خارجی ،کامپيوتر و... ) :<i id="icon_tutorial_history_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
    <? foreach ($list as $field) {?>
    <div class="row">
      <div class="colx-6">
        <h2 >جزئیات</h2>
      </div>
      <div class="colx-6">
        <h3 style="cursor: pointer" onclick="View_Detail(<?= $field['id']?>)"><i class="icon-folder-open large"></i></h3>
      </div>
    </div>
    <div class="row">
      <div class="colx-6">
        <h2 >حذف</h2>
      </div>
      <div class="colx-6">
        <h3 style="cursor: pointer" onclick="Remove_item(<?= $field['id']?>,<?=$pageIndex?>,'tutorial_history',<?=$field['user_id']?>)"><i class="icon-bin"></i></h3>
      </div>
    </div>
    <div class="row">
      <div class="colx-6">
        <h2 >نام دوره</h2>
      </div>
      <div class="colx-6">
        <h3><?=$field['course_name']?></h3>
      </div>
    </div>
    <div class="row">
      <div class="colx-6">
        <h2>سطح</h2>
      </div>
      <div class="colx-6">
        <h3><?=$field['level_name']?></h3>
      </div>
    </div>
    <div class="row">
      <div class="colx-6">
        <h2>محل آموزش</h2>
      </div>
      <div class="colx-6">
        <h3><?=$field['tutorial_place']?></h3>
      </div>
    </div>
    <div class="row">
      <div class="colx-6">
        <h2>سال</h2>
      </div>
      <div class="colx-6">
        <h3><?=$field['tutorial_year']?></h3>
      </div>
    </div>
    <div class="row">
      <div class="colx-6">
        <h2>میزان ساعت دوره</h2>
      </div>
      <div class="colx-6">
        <h3><?=$field['tutorial_times']?></h3>
      </div>
    </div>

      <hr>
    <?}?>
    <div class="row">
      <?=pagination_responsive('',3,'btn_style btn-brown','btn',$pageIndex,$pageCount,'tutorial_history')?>
    </div>
  </div>
  <div class="row tac">
  <button class="btn_style btn-brown" onclick="Insert_all_tutorial_history_ToSql(<?=$pageIndex?>,<?=$_SESSION['user_id']?>)" >سابقه جدید را اضافه بفرمایید</button>
  </div>
</div>

<script>

  function View_Detail(id){
    $.ajax({
      url: '/user/detail_tutorial_history/' + id,
      method: 'POST',
      dataType: 'json',
      data: {
      },
      success: function (output) {
        //console.log(output);
        $("#paginationUpdate").html(output.html);
      }
    });
  }
  function Insert_all_tutorial_history_ToSql(pageIndex,user_id) {
    $.ajax({
      url: '/user/Insert_all_tutorial_history_ToSql/'+pageIndex,
      type: 'POST',
      dataType: 'json',
      data:{
        user_id:user_id
      },
      success: function (data) {
        $("#paginationUpdate").html(data.html);
      }
    });
  }
  function Remove_item(id,pageIndex,table_name,user_id) {
    swal({
        title: "آیا مطمئن هستید؟",
        text: "شما دیگر قادر به بازیابی این فایل نخواهید بود.",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#5d4126",
        confirmButtonText: "آره، آن را حذف کنید.",
        cancelButtonText: "لغو",
        closeOnConfirm: false
      },
      function(){
        $.ajax({
          url: '/user/Remove_item_tutorial_history/'+pageIndex,
          type: 'POST',
          dataType: 'json',
          data:{
            id:id,
            user_id:user_id,
            table_name:table_name
          },
          success: function (data) {
            $("#paginationUpdate").html(data.html);
          }
        });
        swal("حذف گردید.");
      });

  }
</script>


