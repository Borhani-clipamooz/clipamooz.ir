<?php


class NotificationController {
  public function __construct() {

  }


  public function notification_detail($ticket_id) {
    if (isset($_POST['pageIndex'])) {
      $pageIndex = $_POST['pageIndex'];
    } else {
      $pageIndex = 1;
    }
    $data=CommonModel::Fetch_by_every('notifications','ticket_id',$ticket_id);
    $record['list'] = CommonModel::Fetch_by_all('notifications','ticket_id',$ticket_id,'order by id DESC');
    $record['subject']=$data['subject'];
    $record['clip_id']=$data['clip_id'];
    $record['clip_name']=$data['clip_name'];
    $record['sender_id']=$data['sender_id'];
    $record['ticket_id']=$ticket_id;
    ob_start();
    $record['pageIndex'] = $pageIndex;
    View::renderPartial("/notification/detail_notification.php", $record);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }

  public function Replay_notification() {
    $sender_id = $_POST['user_id'];
    $ticket_id = $_POST['ticket_id'];
    $reciver_id = $_POST['reciver_id'];
    $clip_id = $_POST['clip_id'];
    $clip_name = $_POST['clip_name'];
    $subject = $_POST['subject'];
    $body_question = $_POST['body'];
    $date_question=getCurrentDateTime();
    QuestionModel::insert_Question($ticket_id,$subject,$sender_id,$reciver_id,$clip_id,$clip_name,$body_question,$date_question,0);
    NotificationModel::insert_Notification($ticket_id,$subject,$sender_id,$reciver_id,$clip_id,$clip_name,$body_question,$date_question);
    echo json_encode(array('status' => true,));
  }
  public function Replay_notification_notice() {
    $sender_id = $_POST['sender_id'];
    $ticket_id = $_POST['ticket_id'];
    $reciver_id = $_POST['reciver_id'];
    $clip_id = $_POST['clip_id'];
    $clip_name = $_POST['clip_name'];
    $subject = $_POST['subject'];
    $body_question = $_POST['body_question'];
    $date_question=getCurrentDateTime();
   // QuestionModel::insert_Question($ticket_id,$subject,$sender_id,$reciver_id,$clip_id,$clip_name,$body_question,$date_question,0);
    NotificationModel::insert_Notification($ticket_id,$subject,$sender_id,$reciver_id,$clip_id,$clip_name,$body_question,$date_question);
    echo json_encode(array('status' => true,));
  }
 /* public function RegisterCategory() {


    $content = $_POST['name_fa'];
    $NameTable = "category";
    $whichFeild = "name_fa";
    $record = CommonModel::Fetch_by_every($NameTable, $whichFeild, $content);
      if($record == null){
      $name_fa = $_POST['name_fa'];
      $name_en = $_POST['name_en'];
      $description_fa = $_POST['description_fa'] ;
      $description_en = $_POST['description_en'];
      $image =$_POST['upload'];
      CategoryModel::insert($name_fa, $name_en, $description_fa, $description_en, $image);
    }

  }*/




  public function all_notifications($id,$pageIndex) {
    if (!isVip()) {
      header("Location:/");
      return;
    }
    $data['pageIndex']=$pageIndex;
    $data['id']=$id;
    View::renderCPanelUser("/notification/all_notification.php", $data);
  }
  public function RefreshData_notification($pageIndex) {
    $NameTable = 'notifications';
      $user_id = $_POST['user_id'];
    if (isset($_POST['SearchFiled'])) {
      $SearchFiled = $_POST['SearchFiled'];
    } else {
      $SearchFiled = "title";
    }
    if (isset($_POST['keyword'])) {
      $keyword = $_POST['keyword'];
    } else {
      $keyword = "";
    }
    $SortType = "created_at";
    $count=10;
    $groupby='';
    $result = CommonModel::View_All('notifications');
   if (count($result) == 0) {
  //   message("not-found-information", _not_found_information);
     ob_start();
     $data['message']='اطلاعاتی وجود ندارد.';
     View::renderPartial("/message/not-exist-information.php", $data);
     $output = ob_get_clean();
     echo json_encode(array('status' => true, 'html' => $output,));
   }else{
    $data = ListAjaxPartial($NameTable, $pageIndex,'reciver_id',$user_id,$SearchFiled,$keyword,$SortType,$count,$groupby);
    ob_start();
    View::renderPartial("/notification/all_notification_ajax.php", $data);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));
   }

  }
  public function remove_notification_message($id){
    $pageIndex = $_POST['pageIndex'];
    $reciver_id = $_POST['reciver_id'];
    ob_start();
    CommonModel::Remove_item($id,'notifications');
    $output = ob_get_clean();
    $this-> RefreshData_notification($pageIndex,$reciver_id);
  }

  public function insert_node_ajax() {
    if (isset($_POST['pageIndex'])) {
      $pageIndex = $_POST['pageIndex'];
    } else {
      $pageIndex = 1;
    }
        ob_start();
    $record['pageIndex'] = $pageIndex;
    View::renderPartial("/notification/insert_node_ajax.php", $record);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }
  public function Remove_sql_data($Id) {
    ob_start();
    NotificationModel::DelSqlRecord($Id);
    ob_get_clean();
    if (isset($_POST['pageIndex'])) {
      $pageIndex = $_POST['pageIndex'];
    } else {
      $pageIndex = 1;
    }
    $this->RefreshData($pageIndex);
  }



}