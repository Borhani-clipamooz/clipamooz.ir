<div class="content">
<div class="comment_clip">
  <div class="row">
  <div class="colx-1 colm-0 cols-0"><h2>پروفایل</h2></div>
  <div class="colx-3"><h2>نام کاربری</h2></div>
  <div class="colx-6"><h2>نظر داده شده</h2></div>
  <div class="colx-2 colm-0 cols-0"><h2>تاریخ</h2></div>
</div>
  <? foreach ($list as $feild) {
     $data=CommonModel::Fetch_by_every('users','id',$feild['user_id']);?>
<div class="row">
  <div class="colx-1 colm-0 cols-0">
    <?global $config;?>
    <?  if($data['profile_pic'] !=''){?>
      <a  href="/profile/<?=$data['id']?>" style="color: #f88;font-size: 14pt"><img style="width: 40px;height: 40px;border-radius: 50px" src="<?=$config['upload'].$data['profile_pic']?>"></a>
    <?}else{?>
      <a  href="/profile/<?=$data['id']?>" style="color: #f88;font-size: 14pt"><img style="width: 40px;height: 40px;border-radius: 50px" src="/asset/images/empty/empty-profile/empty-profile-24.png"></a>
    <?}?>
  </div>
  <div class="colx-3"><a href="/profile/<?=$data['id']?>"><?= $data['user_name'] ?></a></div>
  <div class="colx-6"><h3><?= $feild['comment'] ?></h3></div>
  <div class="colx-2 colm-0 cols-0"><?=DateTimeCommon( $feild['created_at'] )?></div>
</div>
  <? } ?>
</div>
  <br>
  <!--Buttons Filter-->
  <div class="pagination_comment" >
  <?=pagination('',3,'btn_style btn-brown','btn',$pageIndex,$pageCount,'Comments')?>
  </div>
  <br>
  <div class="pagination_comment_responsive tac" >
  <?=pagination_responsive('',3,'btn_style btn-brown','btn',$pageIndex,$pageCount,'Comments')?>
  </div>
</div>


