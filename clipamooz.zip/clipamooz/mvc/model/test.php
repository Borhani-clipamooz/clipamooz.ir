<?php
class TestModel {

  public static function insert_test($title,$description){
    $db = Db::getInstance();
    $db->query("INSERT INTO test (test_title,test_description) VALUES (:test_title, :test_description)", array(
      'test_title'            => $title,
      'test_description'         => $description,
    ));


  }
  public static function view_test()
  {
    $db=Db::getInstance();
    $record=$db->query("select * from test ");
    return $record;

  }
  public static function catalogByPage($startIndex=0,$count=10)
  {
    $db=Db::getInstance();
    $record=$db->query("select * from test  LIMIT $startIndex,$count");
    return $record;

  }
  public static function catalogConutPage()
  {
    $db=Db::getInstance();
    $record=$db->query("select count(*) AS total from test ");
    return $record['0']['total'];

  }
  public static function deleteDir($dirPath) {
    if (! is_dir($dirPath)) {
      throw new InvalidArgumentException("$dirPath must be a directory");
    }
  //  echo substr($dirPath, strlen($dirPath) - 1, 1);
 /*   if (substr($dirPath, strlen($dirPath) - 1, 1) != '/') {
      $dirPath .= '/';
    }
   echo $dirPath;*/
    $files = glob($dirPath.'*');
    foreach ($files as $file) {
      if (is_dir($file)) {
        self::deleteDir($file);
      } else {
        unlink($file);
      }
    }
   // rmdir($dirPath);
  }
}