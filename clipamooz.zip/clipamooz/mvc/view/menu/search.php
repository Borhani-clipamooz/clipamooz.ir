<div class="rtl">
  <input class="img_search" style=" padding-right: 20px;"  type="text"  id="keyword" placeholder="جستجو" value=""  autocomplete="off">
  <div id="preview" style="margin-top: 12px"></div>

</div>


<script>
  $(function(){
    $("#preview").mCustomScrollbar({
      scrollButtons: {
        enable: true
      },
      theme: "dark"
    });
  });
  $("#keyword").on('keyup', function () {
   showSearch();
  });


  function showSearch() {
    var keyword = $("#keyword").val();
    if (keyword=="")
    {
      $("#preview").html("");
      $("#keyword").removeClass('loadingGif');
    }else{
      $("#keyword").removeClass('img_search');
      $("#keyword").addClass('loadingGif');
      $.ajax({
        url: '/menu/ShowSearch/',
        method: 'POST',
        dataType: 'json',
        data: {
          keyword: keyword
        },
        success: function (output) {
          //console.log(output.keyword);
          $("#keyword").removeClass('loadingGif');
          $("#keyword").addClass('img_search');
          $("#preview").html(output.html);
        }
      });
    }

  }


</script>









