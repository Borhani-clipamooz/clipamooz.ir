<script>
  $(function () {
    $("input").each(function () {
      $(this).on('keyup', function () {

        SaveInput();
      });
    });

    $("textarea").each(function () {
      $(this).on('keyup', function () {
        SaveTextArea();
      });

    });
    $('#parent_cat').val($('#defaultCategory').val());
    $('#sub_cat').val($('#defaultSubCategory').val());
    $("#parent_cat").change(function() {
      var parent_cat=$("#parent_cat").val();
      $('#defaultCategory').val($('#parent_cat').val());
      $(this).after('<div id="loader"><span class="icon-spinner9 huge spin "></span></div>');
      $.ajax({
        url:'/clip/ChangeSelectSubCategory',
        type: 'POST',
        dataType:'json',
        data:{
          parent_cat:parent_cat
        },
        success:function(data){
          $("#sub_cat").html(data.html);
          $('#defaultSubCategory').val($('#sub_cat').val());
          $('#loader').slideUp(200, function() {
            $(this).remove();
          });

          //console.log(data);
          SaveCategory_Subcategory();

        }
      });

    });
    $("#sub_cat").change(function() {
      $('#defaultSubCategory').val($('#sub_cat').val());
      Save_Subcategory();
    });
  });

  $(function(){
    $('#Change_Status_clip').val($('#defaultStatus').val());

    var id=$("#id").val();
    var clip_name=$("#name_fa").val();
    var clip_api_key=$("#clip_api_key").val();
    var subcategory=$("#subcategory").val();
    var long_desc_fa=$("#long_desc_fa").val();
    $('#Change_Status_clip').on('change',function(){
      var Status=$("#Change_Status_clip").val();
      $.ajax({
        url:'/clip/superadmin_Change_Status_clip',
        type: 'POST',
        dataType:'json',
        data:{
          id:id,
          Status:Status,
          clip_name:clip_name,
          clip_api_key:clip_api_key,
          subcategory:subcategory,
          long_desc_fa:long_desc_fa

        },
        success:function(data){
          //console.log(data);
        }
      });
    });
  });

</script>
<div class=" content">
  <?global $config?>
  <table>
    <colgroup>
      <col style="width: 10%">
      <col style="width: 60%">
      <col style="width: 30%">
    </colgroup>
    <tr>
      <input type="hidden"id="id" value="<?=$id?>">
      <input type="hidden"id="user_id" value="<?=$user_id?>">
      <input type="hidden"id="clip_api_key" value="<?=$clip_api_key?>">
      <input type="hidden"id="subcategory" value="<?=$subcategory?>">
      <input type="hidden"id="long_desc_fa" value="<?=$long_desc_fa?>">
      <td class="comlmn">نام فارسی</td>
      <td><input  type="text"  id="name_fa"  name="name_fa" value="<?= $name_fa ?>"></td>
      <td>
        <input type="hidden"id="defaultStatus"value="<?=$status?>">
        <select id="Change_Status_clip" style="background-color:#a97b50 ; border: 1px solid #322010">
          <option value="0">غیر فعال</option>
          <option value="1">فعال</option>
        </select>
      </td>
    </tr>
    <tr>
      <td class="comlmn">توضیحات</td>
      <td> <textarea id="long_desc_fa" name="long_desc_fa" style="height: 80px;width: 600px"><?= $long_desc_fa ?></textarea></td>
      <?$data2=CommonModel::Fetch_by_every('users','id',$user_id);?>
      <td>
        <span> <?=$data2['user_name']?></span>
        <?  if($data2['profile_pic'] !=''){?>
          <a  href="/profile/<?=$data2['id']?> " target="_blank" style="color: #f88;font-size: 14pt"><img style="width: 60px;height: 60px;border-radius: 50px" src="<?=$config['upload'].$data2['profile_pic']?>"></a>
        <?}else{?>
          <a  href="/profile/<?=$data2['id']?>" target="_blank" style="color: #f88;font-size: 14pt"><img style="width: 60px;height: 60px;border-radius: 50px" src="/asset/images/empty/empty-profile/empty-profile-24.png"></a>
        <?}?>
      </td>
    </tr>
    <tr style="display: none">
      <td class="comlmn"> زمان</td>
      <td> <input class="tac" id="clip_long_time" name="clip_long_time" value="<?= $clip_long_time ?>" ></td>
    </tr>
    <tr style="display: none">
      <td class="comlmn"> سایز</td>
      <td> <input class="tac" id="clip_size" name="clip_size" value="<?= $clip_size ?>"></td>
    </tr>
    <tr>
      <td class="comlmn"> قیمت</td>
      <td> <input class="tac" id="price" name="price" value="<?= $price ?>"></td>
    </tr>
    <tr>
      <td class="comlmn">دسته بندی</td>
      <td>
        <input type="hidden"id="defaultCategory"value="<?=$category?>">
        <?
        $dataCategory=CommonModel::View_All('category');
        ?>
        <label>&nbsp;&nbsp;&nbsp;&nbsp;دسته</label>
        <select  name="parent_cat" id="parent_cat" style="width:150px;background-color:#a97b50 ; border: 1px solid #322010">
          <?
          foreach($dataCategory as $row){?>
            <option value="<?php echo $row['id']; ?>"><?php echo $row['name_fa']; ?></option>
          <?} ?>
        </select>
        <br/>

        <label>زیردسته</label>

        <input type="hidden" id="defaultSubCategory" value="<?=$subcategory?>">
        <select name="sub_cat" id="sub_cat" style="width:150px;background-color:#a97b50 ; border: 1px solid #322010">
          <?
          $dataSubCategoryID=ClipModel::ViewSubCategoryID($category);
          foreach($dataSubCategoryID as $row){?>
            <option value="<?php echo $row['id']; ?>"><?php echo $row['subcategory_name']; ?></option>
          <?} ?>
        </select>

      </td>
    </tr>

    <tr>
      <td class="comlmn"> عکس</td>

      <td>

        <? if ($img_link!=null) {?>
          <div id="deleteImage">
            <img  src="<?=$config['upload']. $img_link ?>" alt="محل قرار گرفتن تصویر"style=" padding-top:5px;width: 150px;height: 150px"><br>
            <span style="color: #a2120a" id="messageiImage"></span>
            <button class="btn_style btn-brown" onclick="Remove_data('<?=$config['upload']. $img_link ?>',0,'<?=$id?>','clips','img_link','')"><?=_btn_delete?></button>
          </div>
          <script>ShowUploaderImage('<?=$id?>','clips','img_link');</script>
          <div id="ShowUploaderImage" style="display: none;text-align: center;"></div>
        <?}else{?>
          <script>ShowUploaderImage('<?=$id?>','clips','img_link');</script>
          <div id="ShowUploaderImage"></div>
        <?}?>

      </td>
    </tr>
    <tr>
      <td class="comlmn">پیش نمایش</td>
      <td>
        <ul style="display: inline">
          <? if ($clip_prev_link) {?>
            <div id="delete_clip_prev_link">
              <li>
                <video style="width: 300px;height: 250px" controls>
                  <source src="<?=$config['upload']. $clip_prev_link ?>" type="video/mp4">
                </video><br>
              <li>
                <button class="btn_style btn-brown" onclick="Remove_data('<?=$config['upload']. $clip_prev_link ?>',1,'<?=$id?>','clips','clip_prev_link','')"><?=_btn_delete?></button>
                &nbsp; &nbsp;&nbsp;&nbsp;
              </li>
              <span style="color: #a2120a" id="messagePrevClip"></span>
              </li>
            </div>
            <script>ShowUploaderPrevClip('<?=$id?>','clips','clip_prev_link');</script>
            <div id="ShowUploaderPrevClip" style="display: none;text-align: center;"></div>
          <?}else{   ?>
            <script>ShowUploaderPrevClip('<?=$id?>','clips','clip_prev_link');</script>
            <div id="ShowUploaderPrevClip"></div>


          <?}?>

        </ul>
      </td>
    </tr>
    <tr>
      <td class="comlmn">فایل اصلی</td>

      <td>
        <ul style="display: inline">
          <? if ($clip_link) {?>
            <div id="delete_clip_link">
              <li>
                <video  src="<?=$config['upload']. $clip_link ?>" style="width: 300px;height: 200px" controls></video><br>
                <span style="color: #a2120a" id="messageClip"></span>
              </li>
              <li>
                <button class="btn_style btn-brown" onclick="Remove_data('<?=$config['upload']. $clip_link ?>',2,'<?=$id?>','clips','clip_link','')"><?=_btn_delete?></button>
                &nbsp; &nbsp;&nbsp;&nbsp;
              </li>
            </div>
            <script>ShowUploaderClip('<?=$id?>','clips','clip_link','<?=$clip_long_time?>','<?=$clip_size?>');</script>
            <div id="ShowUploaderClip" style="display: none;text-align: center;" ></div>
          <?}else{  ?>
            <script>ShowUploaderClip('<?=$id?>','clips','clip_link','<?=$clip_long_time?>','<?=$clip_size?>');</script>
            <div id="ShowUploaderClip"></div>

          <?     }?>
        </ul>
      </td>
    </tr>

  </table>

  <button class="btn_style btn-brown" onclick="back(<?= $pageIndex ?>)">برگشت</button>
  <img id="img_SaveCategory" src="/asset/images/loading.gif" style="display: none" />
</div>
<script>
  function back(pageIndex){
    superadmin_all_clip(pageIndex);
  }
  function SaveInput(){
    var id=$("#id").val();
    var user_id=$("#user_id").val();
    var name_fa=$("#name_fa").val();
    var name_en=$("#name_en").val();
    var price=$("#price").val();
    $.ajax({
      url:'/clip/update',
      type: 'POST',
      dataType:'json',
      data:{
        id:id,
        user_id:user_id,
        name_fa:name_fa,
        name_en:name_en,
        price:price

      },
      success:function(data){
        //console.log(data);
      }
    });
  }
  function SaveTextArea(){
    var id=$("#id").val();
    var long_desc_fa=$("#long_desc_fa").val();
    var long_desc_en=$("#long_desc_en").val();
    $.ajax({
      url:'/clip/update_long_desc',
      type: 'POST',
      dataType:'json',
      data:{
        id:id,
        long_desc_fa:long_desc_fa,
        long_desc_en:long_desc_en

      },
      success:function(data){
        //console.log(data);
      }
    });
  }
  function SaveCategory_Subcategory(){
    var id=$("#id").val();
    var parent_cat=$("#defaultCategory").val();
    var sub_cat=$("#defaultSubCategory").val();
    $('#img_SaveCategory').show();
    $.ajax({
      url:'/clip/ChangeSelectCategory_SubCategory',
      type: 'POST',
      dataType:'json',
      data:{
        id:id,
        parent_cat:parent_cat,
        sub_cat:sub_cat
      },
      success:function(data){
        $("#sub_cat").html(data.html);
        $('#img_SaveCategory').hide();
      }
    });
  }
  function Save_Subcategory(){
    var id=$("#id").val();
    var sub_cat=$("#defaultSubCategory").val();
    $.ajax({
      url:'/clip/Change_Select_SubCategory',
      type: 'POST',
      dataType:'json',
      data:{
        id:id,
        sub_cat:sub_cat
      },
      success:function(data){
      }
    });
  }
</script>
