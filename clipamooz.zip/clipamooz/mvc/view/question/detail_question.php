<script>
  $(document).ready(function(){
    $("#replay").click(function(){
      $(".replay_panel").slideToggle("slow");
    });
  });

</script>
<div class="content">
  <div class="detail_question">
  <input   style="display: none" id="sender_id" value="<?=$_SESSION['user_id']?>">
  <input style="display: none" id="ticket_id" value="<?=$ticket_id?>">
  <input style="display: none" id="pageIndex" value="<?=$pageIndex?>">
  <input style="display: none"  id="subject" value="<?=$subject?>">
  <input style="display: none"  id="clip_id" value="<?=$clip_id?>">
  <input style="display: none"  id="clip_name" value="<?=$clip_name?>">
  <input style="display: none"  id="reciver_id" value="<?=$reciver_id?>">

  <div class="row ">
    <h1 class="read-more"><?= $subject ?></h1>
  </div>
 <div class="row">
  <div style="cursor: pointer" id="replay" class="row"><i class="icon-reply large"></i>پاسخ: <i class="icon-arrow-down large"></i></div>
 </div>
   <div class="row">
    <div class="replay_panel" style="display: none">
      <div class="row">
      <textarea style="width: 100%" id="body_question"></textarea>
      </div>
      <div class="row">
        <button class="btn_style btn-brown"  id="send" onclick="Replay_question()">ارسال</button>
      </div>
    </div>
   </div>
  <div class="row">
    <div class="colx-2 cols-0"><h2>پروفایل</h2></div>
    <div class="colx-2"><h2>نام کاربری</h2></div>
    <div class="colx-4"><h2>پیام</h2></div>
    <div class="colx-2 cols-0"><h2>تاریخ</h2></div>
  </div>
    <?global $config;?>
  <? foreach ($list as $feild) {?>
  <?$data=CommonModel::Fetch_by_every('users','id',$feild['sender_id']);?>
  <div class="row">
    <div class="colx-2 cols-0">
      <?  if($data['profile_pic'] !=''){?>
        <a  href="/profile/<?=$data['id']?>" style="color: #f88;font-size: 14pt"><img style="width: 40px;height: 40px;border-radius: 50px" src="<?=$config['upload'].$data['profile_pic']?>"></a>
      <?}else{?>
        <a  href="/profile/<?=$data['id']?>" style="color: #f88;font-size: 14pt"><img style="width: 40px;height: 40px;border-radius: 50px" src="/asset/images/empty/empty-profile/empty-profile-24.png"></a>
      <?}?>
    </div>
    <div class="colx-2"><?= $data['user_name'] ?></div>
    <div class="colx-4"><h3><?= $feild['body_question'] ?></h3></div>
    <div class="colx-2 cols-0"><?=DateTimeCommon( $feild['date_question'] )?></div>
  </div>
  <?}?>
 <div class="row">
  <button class="btn_style btn-brown" onclick="back(<?= $pageIndex ?>)">برگشت</button>
 </div>
</div>
</div>
<script>

  function Call_DataBase_question(){
    var clip_id=$("#clip_id").val();
    $.ajax({
      url:'/Call_DataBase_question/',
      type: 'POST',
      dataType:'json',
      data:{
        clip_id:clip_id
      },
      success:function(data){
   //  var obj=JSON.parse(data);
        console.log(data);

      }

    });
   // return data.list[0].clip_id;
  }
  function Replay_question(){
  //  var cars = ["BMW", "Volvo", "Saab", "Ford", "Fiat", "Audi"];
  Replay_question1();
   // var cars = $("#list").val();
    var clip_id=$("#clip_id").val();
    var ticket_id=$("#ticket_id").val();
    $.ajax({
      url:'/Call_DataBase_question/',
      type: 'POST',
      dataType:'json',
      data:{
        clip_id:clip_id,
        ticket_id:ticket_id

      },
      success:function(data){
        console.log(data);
     
        var myObj, i, j, x = "";
        myObj = {
          "name":"John",
          "age":30,
          "cars2": [
            { "name":"Ford", "models":[ "Fiesta", "Focus", "Mustang" ] },
            { "name":"BMW", "models":[ "320", "X3", "X5" ] },
            { "name":"Fiat", "models":[ "500", "Panda" ] }
          ],
          "cars":data.list
        }
        var sender_id=$("#sender_id").val();
        for (i in myObj.cars) {
          x += "<h2>" + myObj.cars[i].reciver_id + "</h2>";
        document.getElementById("demo").innerHTML = x;

         if( myObj.cars[i].reciver_id==sender_id){
        // continue;
          }else{
         //  alert(sender_id);
            Replay_notification_notice(myObj.cars[i].reciver_id);
           // return;
          }
          /*for (j in myObj.cars[i].models) {
           x += myObj.cars[i].models[j] + "<br>";
           }*/
        }
        //   console.log(cars);
        //  document.getElementById("demo").innerHTML = cars;

      }

    });


  }
  function Replay_question1(){
    var reciver_id=$("#reciver_id").val();
    var clip_id=$("#clip_id").val();
    var clip_name=$("#clip_name").val();
    var sender_id=$("#sender_id").val();
    var ticket_id=$("#ticket_id").val();
    var subject=$("#subject").val();
    var body_question=$("#body_question").val();
    var pageIndex=$("#pageIndex").val();
    $.ajax({
      url:'/Replay_question/',
      type: 'POST',
      dataType:'json',
      data:{
        sender_id:sender_id,
        reciver_id:reciver_id,
        clip_id:clip_id,
        clip_name:clip_name,
        ticket_id:ticket_id,
        subject:subject,
        body_question:body_question
      },
      success:function(data){
        //console.log(data);
        list_question(pageIndex);
      }
    });

  }
  function Replay_notification_notice(reciver_id){
   // var reciver_id=$("#reciver_id").val();
    var reciver_id=reciver_id;
    var clip_id=$("#clip_id").val();
    var clip_name=$("#clip_name").val();
    var sender_id=$("#sender_id").val();
    var ticket_id=$("#ticket_id").val();
    var subject=$("#subject").val();
    var body_question=$("#body_question").val();
    var pageIndex=$("#pageIndex").val();
    $.ajax({
      url:'/Replay_notification_notice/',
      type: 'POST',
      dataType:'json',
      data:{
        sender_id:sender_id,
        reciver_id:reciver_id,
        clip_id:clip_id,
        clip_name:clip_name,
        ticket_id:ticket_id,
        subject:subject,
        body_question:body_question
      },
      success:function(data){
        //console.log(data);
        list_question(pageIndex);
      }
    });

  }
  function back(pageIndex){
    list_question(pageIndex);
  }
</script>
