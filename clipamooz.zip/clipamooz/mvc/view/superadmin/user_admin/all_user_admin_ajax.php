<div class="content">
<div class="row">aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa</div>
     <div class="row">
       <div class="colx-2">جزئیات</div>
       <div class="colx-2">حذف</div>
       <div class="colx-2">نام کاربر</div>
       <div class="colx-2">ایمیل</div>
       <div class="colx-2">دسترسی</div>
       <div class="colx-2">تاریخ عضویت</div>
     </div>
  <? foreach ($list as $feild) {
  if (isSuperAdmin()){?>
  <div class="row">
    <div class="colx-2"><span onclick="ViewUser(<?= $feild['id']?>,<?=$pageIndex?>)"><i class="icon-profile"></i></span></div>
    <div class="colx-2"><span onclick="RemoveUser(<?= $feild['id']?>,<?=$pageIndex?>)" class="icon-bin small"></span></div>
    <div class="colx-2"><?= $feild['user_name'] ?></div>
    <div class="colx-2"><?= $feild['email'] ?></div>
    <div class="colx-2">
      <?
      $access='';
      $access=CommonModel::identification_user($feild['user_access']);
      echo $access;
      ?>
    </div>
    <div class="colx-2"><?= $feild['member_date'] ?> </div>
  </div>
      <table>
          <?}else if (isAdmin()){?>
            <?if(($feild['user_access']!="|admin|")&&($feild['user_access']!="|superadmin|") ){ ?>
            <tr>
              <td ><span onclick="ViewUser(<?= $feild['user_id']?>,<?=$pageIndex?>)"><i class="fa fa-ellipsis-h fa-2x"></i></span></td>

              <td><span> <?= $feild['user_id'] ?></span></td>

              <td><?= $feild['user_lastname'] ?></td>
              <td><p style="direction: ltr;"><?= $feild['user_email'] ?> </td>
              <td>
                <?
                $access='';
                $access=CommonModel::identification_user($feild['user_access']);
                echo $access;

                ?>
              </td>
              <td><?= $feild['user_last_update'] ?> </td>
            </tr>
        <? }}} ?>
        </tbody>
      </table>
    <br>
    <!--Buttons Filter-->
    <?=pagination(baseUrl().'/user/allAjax',3,'btn btn-brown','btn',$pageIndex,$pageCount,'getPage')?>
  </div>

<script>
  function InsertSuperAdminToSql(PageIndex,currentDate) {
    $.ajax({
      url: '/superadmin/InsertSuperAdminToSql/',
      type: 'POST',
      dataType: 'json',
      data:{
        PageIndex:PageIndex
      },
      success: function (data) {
        $("#paginationUpdate").html(data.html);
      }
    });
  }
  function ViewUser(UserId,PageIndex) {
    $.ajax({
      url: '/superadmin/detail_user_admin/' + UserId,
      type: 'POST',
      dataType: 'json',
      data:{
        pageIndex:PageIndex
      },
      success: function (data) {
        $("#paginationUpdate").html(data.html);
      }
    });
  }
  function RemoveUser(UserId,PageIndex) {
    swal({
        title: "آیا مطمئن هستید؟",
        text: "شما دیگر قادر به بازیابی این فایل نخواهید بود.",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#5d4126",
        confirmButtonText: "آره، آن را حذف کنید.",
        closeOnConfirm: false
      },
      function(){
        $.ajax({
          url: '/superadmin/Remove/' + UserId,
          type: 'POST',
          dataType: 'json',
          data:{
            pageIndex:PageIndex

          },
          success: function (data) {
            $("#paginationUpdate").html(data.html);
          }
        });
        swal("حذف گردید.");
      });


  }

</script>


