<input style="display: none" id="clip_api_key" type="text" value="<?=$clip_api_key?>">
<div id="pageUpdate_prev_clip"></div>
<script>

  $(function () {
    single_clip();
  });

  function single_clip() {
    var clip_api_key = $("#clip_api_key").val();
    $.ajax({
      url: '/SingleClip_ajax/',
      method: 'POST',
      dataType: 'json',
      data: {
        clip_api_key: clip_api_key
      },
      success: function (output) {
        //console.log(output);
        $("#pageUpdate_prev_clip").html(output.html);
      }
    });
  }


</script>









