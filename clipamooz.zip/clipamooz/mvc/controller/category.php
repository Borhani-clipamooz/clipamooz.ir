<?php


class CategoryController {
  public function __construct() {

  }

  public function all($pageIndex) {
    if (!isSuperAdmin()) {
      header("Location:/");
      return;
    }
    $result = CommonModel::View_All('category');
    if (count($result) == 0) {
      message_CPanelSuperAdmin("not-found-information", _not_found_information);
      return;
    }
    $NameTable = 'category';
    $keyword = "";
    $SearchFiled = "name_fa";
    $SortType = "name_fa";
    $groupby='';
    $data = ListAjax($NameTable, $pageIndex,$SearchFiled,$keyword,$SortType,$groupby);
    View::renderCPanelSuperAdmin("/category/all_category.php", $data);


  }
  public function RefreshData($pageIndex) {
    $NameTable = 'category';

    if (isset($_POST['SearchFiled'])) {
      $SearchFiled = $_POST['SearchFiled'];
    } else {
      $SearchFiled = "name_fa";
    }
    if (isset($_POST['keyword'])) {
      $keyword = $_POST['keyword'];
    } else {
      $keyword = "";
    }
    $SortType = "name_fa";
    $groupby='';
    $data = ListAjax($NameTable, $pageIndex,$SearchFiled, $keyword,$SortType,$groupby);
    ob_start();
    View::renderPartial("/category/all-category-ajax.php", $data);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }
  public function view($id) {
    if (isset($_POST['pageIndex'])) {
      $pageIndex = $_POST['pageIndex'];
    } else {
      $pageIndex = 1;
    }
    $result = CategoryModel::view_single($id);
    $record = $result[0];
    ob_start();
    $record['pageIndex'] = $pageIndex;
    View::renderPartial("/category/detail_category.php", $record);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }
  public function Remove_sql_data($Id) {
      $PathFile = $_POST['pathFile'];
    ob_start();
    CommonModel::DeleteFile_Remote_Host($PathFile);
    CategoryModel::DelSqlRecord($Id);
    ob_get_clean();
    if (isset($_POST['pageIndex'])) {
      $pageIndex = $_POST['pageIndex'];
    } else {
      $pageIndex = 1;
    }
    $this->RefreshData($pageIndex);
  }
  public function Remove_data() {
      $PathFile = $_POST['pathFile'];
    ob_start();
  CommonModel::DeleteFile_Remote_Host($PathFile);
   ob_get_clean();

  }
  public function Update() {

    $id = $_POST['id'];
    $name_fa = $_POST['name_fa'];
    $name_en = $_POST['name_en'];
    $description_fa = $_POST['description_fa'];
    $description_en = $_POST['description_en'];
    CategoryModel::update($id,$name_fa,$name_en,$description_fa,$description_en);
  }

  public function InsertCategoryToSql() {

    ob_start();
    CategoryModel::insert("","","","","");
    ob_get_clean();
    if (isset($_POST['pageIndex'])) {
      $pageIndex = $_POST['pageIndex'];
    } else {
      $pageIndex = 1;
    }
    $this->RefreshData($pageIndex);
  }

}