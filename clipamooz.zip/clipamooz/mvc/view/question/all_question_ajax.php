<div class="content">
<div class="all_question">
  <div class="row">
  <div class="colx-1"><h2>جزئیات</h2> </div>
  <div class="colx-2 cols-0"><h2>نام کاربری </h2></div>
  <div class="colx-6"><h2>موضوع سوال</h2></div>
  <div class="colx-1"><h2>تعداد</h2></div>
  <div class="colx-2 cols-0"><h2>تاریخ ارسال</h2></div>
</div>
  <? foreach ($list as $feild) {?>
<div class="row">
  <div class="colx-1"><h3 onclick="View('<?= $feild['ticket_id']?>',<?=$pageIndex?>)"><i style="cursor: pointer;margin-top: 5px" class="icon-question large"></i></h3> </div>
  <?$data2=CommonModel::Fetch_by_every('users','id',$feild['sender_id']);?>
  <div class="colx-2 cols-0"><h3><?= $data2['user_name'] ?></h3></div>
  <div class="colx-6"><h3><?= $feild['subject'] ?></h3></div>
  <?$RecordCount=QuestionModel::Question_ConutNotRead1($feild['ticket_id']);?>
  <div class="colx-1"><h3><?=$RecordCount ?></h3></div>
  <div class="colx-2 cols-0"><h3><?=DateTimeCommon($feild['date_question'])?></h3></div>
</div>
  <? } ?>
    <!--Buttons Filter-->
  <div class="pagination_comment" style="margin: 15px" >
    <?=pagination('',3,'btn_style btn-brown','btn',$pageIndex,$pageCount,'list_question')?>
  </div>
  <div class="pagination_comment_responsive tac" >
    <?=pagination_responsive('',3,'btn_style btn-brown','btn',$pageIndex,$pageCount,'list_question')?>
  </div>
</div>
</div>
<script>

  function View(Id,PageIndex) {

    $.ajax({
      url: '/view_question/' + Id,
      type: 'POST',
      dataType: 'json',
      data:{
        pageIndex:PageIndex
      },
      success: function (data) {
        $("#paginationUpdate").html(data.html);
      }
    });
  }
</script>


