<?php


class SubcategoryController {
  public function __construct() {

  }




  public function all($pageIndex) {
    if (!isSuperAdmin()) {
      header("Location:/");
      return;
    }
    $result = CommonModel::View_All('subcategories');
    if (count($result) == 0) {
      message_CPanelSuperAdmin("not-found-information", _not_found_information);
      return;
    }
    $NameTable = 'subcategories';
    $keyword = "";
    $SearchFiled = "subcategory_name";
    $SortType = "subcategory_name";
    $groupby='';
    $data = ListAjax($NameTable, $pageIndex,$SearchFiled,$keyword,$SortType,$groupby);
    View::renderCPanelSuperAdmin("/category/all_subcategory.php", $data);
  }
  public function RefreshData($pageIndex) {
    $NameTable = 'subcategories';

    if (isset($_POST['SearchFiled'])) {
      $SearchFiled = $_POST['SearchFiled'];
    } else {
      $SearchFiled = "subcategory_name";
    }
    if (isset($_POST['keyword'])) {
      $keyword = $_POST['keyword'];
    } else {
      $keyword = "";
    }
    $SortType = "subcategory_name";
    $groupby='';
    $data = ListAjax($NameTable, $pageIndex,$SearchFiled, $keyword,$SortType,$groupby);
    ob_start();
    View::renderPartial("/category/all_subcategory_ajax.php", $data);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }
  public function view($id) {
    if (isset($_POST['pageIndex'])) {
      $pageIndex = $_POST['pageIndex'];
    } else {
      $pageIndex = 1;
    }
    $result = SubcategoryModel::view_single($id);
    $record = $result[0];
    ob_start();
    $record['pageIndex'] = $pageIndex;
    View::renderPartial("/category/detail_subcategory.php", $record);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }
  public function Remove_sql_data($Id) {
    ob_start();
    SubcategoryModel::DelSqlRecord($Id);
    ob_get_clean();
    if (isset($_POST['pageIndex'])) {
      $pageIndex = $_POST['pageIndex'];
    } else {
      $pageIndex = 1;
    }
    $this->RefreshData($pageIndex);
  }

  public function SaveSubCategory() {

    $id = $_POST['id'];
    $parent_cat = $_POST['parent_cat'];
    $name_fa = $_POST['name_fa'];
    $name_en = $_POST['name_en'];
    SubcategoryModel::update($id,$parent_cat,$name_fa,$name_en);
  }

  public function InsertSubCategoryToSql() {

    ob_start();
    SubcategoryModel::insert(0,"","");
    ob_get_clean();
    if (isset($_POST['pageIndex'])) {
      $pageIndex = $_POST['pageIndex'];
    } else {
      $pageIndex = 1;
    }
    $this->RefreshData($pageIndex);
  }
  public function compelete_clips_subcategory($goal) {
    $data=CommonModel::Fetch_by_every('subcategories','id',$goal);
    $data['pageTitle']=_clipamooz." | ". $data['subcategory_name'];
    $data['keyword']=$data['id'];
    View::render("/clip/subcategory/complete_clips_subcategory.php", $data);
  }
  public function compelete_clips_subcategory_ajax() {
    if (isset($_POST['count'])) {
      $count = $_POST['count'];
    } else {
      $count = 15;
    }
    if (isset($_POST['startIndex'])) {
      $startIndex = $_POST['startIndex'];
    } else {
      $startIndex = 0;
    }

    if (isset($_POST['keyword'])) {
      $goal = $_POST['keyword'];
    } else {
      $goal = "";
    }
    ob_start();
    $data['list']=SubcategoryModel::compelete_clips_subcategory_ajax($startIndex,$count,$goal);
    View::renderPartial("/clip/subcategory/complete_clips_subcategory_ajax.php", $data);
    $output = ob_get_clean();
    if(!empty($data['list'])){
      echo json_encode(array('status' => true, 'html' => $output,));
    }else{
      echo json_encode(array('status' =>false, 'html' => $output,));
    }

  }
}