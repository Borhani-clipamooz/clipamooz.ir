<div class="content">

      <table>
        <colgroup>
          <col width="3%">
          <col width="3%">
          <col width="5%">
          <col width="15%">
          <col width="30%">
          <col width="30%">
          <col width="14%">
        </colgroup>
        <thead>
        <tr>

          <th class="tac">جزئیات</th>
          <th class="tac">حذف</th>
          <th class="tac">پروفایل</th>
          <th class="tac">موضوع</th>
          <th class="tac">پرسش</th>
          <th class="tac">پاسخ</th>
          <th class="tac">تاریخ ارسال</th>
        </tr>
        </thead>
        <tbody>

        <? foreach ($list as $feild) {?>
        <tr>
            <td ><span onclick="View(<?= $feild['id']?>,<?=$pageIndex?>)"><i class="icon-eye large"></i></span></td>

            <td><span onclick="Remove_sql_data(<?= $feild['id']?>,<?=$pageIndex?>)" <i class="icon-bin large"></i></span></td>
          <?$data2=CommonModel::Fetch_by_every('users','id',$feild['user_id']);?>
          <input style="display: none"id="receiver_message_id" value="<?=$feild['user_id']?>">
          <input style="display: none"id="sender_message_id" value="53">
          <td>
            <?  if($data2['profile_pic'] !=''){?>
              <a  href="/profile/<?=$data2['id']?>"target="_blank" style="color: #f88;font-size: 14pt"><img style="width: 40px;height: 40px;border-radius: 50px" src="<?=$data2['profile_pic']?>"></a>
            <?}else{?>
              <a  href="/profile/<?=$data2['id']?>"target="_blank" style="color: #f88;font-size: 14pt"><img style="width: 40px;height: 40px;border-radius: 50px" src="/asset/images/empty/empty-profile/empty-profile-24.png"></a>
            <?}?>
          </td>
        <td ><?= $feild['subject'] ?></td>
        <td ><?= $feild['body_question'] ?></td>
        <td ><?= $feild['body_replay'] ?></td>
          <td ><?= DateTimeCommon($feild['date_receive_message']) ?></td>
        </tr>

        <? } ?>
        </tbody>
      </table>
    <br>
    <!--Buttons Filter-->
    <?=pagination(baseUrl().'/category/all',3,'btn_style btn-brown','btn',$pageIndex,$pageCount,'getPage')?>

</div>

<script>

  function View(Id,PageIndex) {
var receiver_message_id=$('#receiver_message_id').val();
var sender_message_id=$('#sender_message_id').val();
    $.ajax({
      url: '/contact_us/view/' + Id,
      type: 'POST',
      dataType: 'json',
      data:{
        receiver_message_id:receiver_message_id,
        sender_message_id:sender_message_id,
        pageIndex:PageIndex
      },
      success: function (data) {
        $("#paginationUpdate").html(data.html);
      }
    });
  }
  function Remove_sql_data(Id,PageIndex,PathFile) {
    swal({
        title: "آیا مطمئن هستید؟",
        text: "شما دیگر قادر به بازیابی این فایل نخواهید بود.",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#5d4126",
        confirmButtonText: "آره، آن را حذف کنید.",
        closeOnConfirm: false
      },
      function(){
        $.ajax({
          url: '/contact_us/Remove_sql_data/' + Id,
          type: 'POST',
          dataType: 'json',
          data:{
            pageIndex:PageIndex

          },
          success: function (data) {
            $("#paginationUpdate").html(data.html);
          }
        });
      swal("حذف گردید.");
      });


  }

</script>


