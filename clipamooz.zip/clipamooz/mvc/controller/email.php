<?php
class EmailController{

  public function send_message3() {
   // echo 'a';
    require_once ("PHPMailer5.2.1/class.phpmailer.php");
    $mail = new PHPMailer(true);
    $mail->IsSMTP();
    try {
      $mail->Host       = "localhost"; // آدرس SMTP سایت گوگل
      $mail->SMTPAuth   = 'yes';                  // استفاده از SMTP authentication
      $mail->SMTPSecure = "none";                 // استفاده از پروتکل امن
      $mail->Port       = 25;                   // درگاه خروجی سرویس ایمیل گوگل
      $mail->Username   = "info@clipamooz.ir"; // نام کاربری حساب گوگل
      $mail->Password   = "Borhan@8683054";        // کلمه عبور حساب گوگل
    $mail->AddReplyTo('info@clipamooz.ir', 'info@clipamooz.ir'); // افزودن پاسخ به ارسال کننده
     // $mail->AddAddress($_POST['email'], 'Daneshjooyar'); // تنظیم آدرس گیرنده ایمیل
     $mail->AddAddress('borhani_mo@yahoo.com', 'borhani_mo@yahoo.com'); // تنظیم آدرس گیرنده ایمیل
     // $mail->AddAddress('android.borhani@gmail.com', 'Daneshjooyar'); // تنظیم آدرس گیرنده ایمیل
      $mail->SetFrom('info@clipamooz.ir', 'info@clipamooz.ir'); // تنظیم قسمت ارسال کننده ایمیل
     // $mail->Subject = ''.$_POST['subject'].''; // موضوع ایمیل
      $mail->Subject = ''.'arbaeen karbala'.''; // موضوع ایمیل
      //$mail->AltBody = 'برنامه شما از این ایمیل پشتیبانی نمی کند، برای دیدن آن، لطفا از برنامه دیگری استفاده نمائید'; // متنی برای کاربرانی که نمی توانند ایمیل را به درستی مشاهده کنند
      $mail->CharSet = 'UTF-8'; // یونیکد برای زبان فارسی
     //$mail->ContentType = 'text/html'; // استفاده از html
      //$mail->MsgHTML(''.$_POST['messagetext'].''); // متن پیام به صورت html
      $mail->MsgHTML(''.'be name khoda arezoye salamate baraye tamami zaeran arbaeen mikanam'.''); // متن پیام به صورت html
      $mail->Send(); // ارسال
      echo 'b';
      echo "<span style='text-align:center;color:green;'>ایمیل اسال شد</span>";
    }
    catch (phpmailerException $e)
    {
      echo $e->errorMessage(); // پیام خطا از phpmailer
    }
    catch (Exception $e)
    {
      echo $e->getMessage(); // سایر خطاها
    }
  }

}