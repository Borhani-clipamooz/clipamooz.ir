<?php
class NotificationModel {

  public static function insert_Notification($ticket_id,$subject,$sender_id,$reciver_id,$clip_id,$clip_name,$body_notification,$created_at){
    $db = Db::getInstance();
    $db->query("INSERT INTO notifications (ticket_id,subject,sender_id,reciver_id,clip_id,clip_name,body_notification,created_at)
             VALUES ( :ticket_id, :subject,:sender_id,:reciver_id,:clip_id,:clip_name,:body_notification,:created_at)",
      array(
        'ticket_id'         => $ticket_id,
        'subject'         => $subject,
        'sender_id'         => $sender_id,
        'reciver_id'         => $reciver_id,
        'clip_id'         => $clip_id,
        'clip_name'         => $clip_name,
        'body_notification'         => $body_notification,
        'created_at'         => $created_at,
      ));


  }

  public static function notification_ConutNotRead($user_id)
  {
    $db=Db::getInstance();
    $record=$db->first("select count(*) AS total from notifications where (reciver_id=$user_id)",array(),'total');
    return $record;

  }



  public static function DelSqlRecord($id)
  {
    $db=Db::getInstance();
    $db->query("DELETE FROM notifications where id=:id",array('id'=>$id,));

  }
}