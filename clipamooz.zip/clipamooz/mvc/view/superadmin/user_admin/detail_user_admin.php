<script>

  $(function(){

      $('#level').val($('#defaultLevel').val());
    var id=$("#id").val();
    $('#level').on('change',function(){
    var level=$("#level").val();
      $.ajax({
         url:'/user/changeLevel',
        type: 'POST',
        dataType:'json',
        data:{
          user_id:id,
          user_access:level

        },
        success:function(data){
          console.log(data);
        }
      });
    });
  });
</script>
<div class=" content">
<table style="margin-right: 228px">
    <colgroup>
        <col style="width: 250px">
        <col style="width: 250px">
    </colgroup>
     <tr>
        <td class="comlmn">نام خانوادگی</td>
        <td><span><?= $user_name ?></span></td>
    </tr>
    <tr>
        <td class="comlmn">ایمیل</td>
        <td> <p style="direction: ltr;"><?= $email ?></td>
    </tr>



    <tr>
        <td class="comlmn">سطح دسترسی</td>
        <td class="ltr tar " style="padding :5px;">
          <span>
            &nbsp;&nbsp;
           <? if (isSuperAdmin()) { ?>
             <select id="level" style="background-color:#a97b50 ; border: 1px solid #322010">
               <option value="|superadmin|">مدیر کل</option>
               <option value="|admin|">مدیر</option>
               <option value="|vip|">کاربر ویژه</option>
               <option value="|author|">نویسنده</option>
               <option value="|vipauthor|">نویسنده ویژه</option>
               <option value="|user|">کاربر عادی</option>
             </select>
             <input type="hidden"id="id"value="<?=$id?>">
             <input type="hidden"id="defaultLevel"value="<?=$user_access?>">
            <? } elseif (isAdmin()) { ?>
              <select id="level" style="background-color:#a97b50 ; border: 1px solid #322010">
                <option value="|vip|">کاربر ویژه</option>
                <option value="|author|">نویسنده</option>
                <option value="|vipauthor|">نویسنده ویژه</option>
                <option value="|user|">کاربر عادی</option>
              </select>
              <input type="hidden"id="id"value="<?=$id?>">
              <input type="hidden"id="defaultLevel"value="<?=$user_access?>">
            <?}?>
          </span>

        </td>
    </tr>
    <tr>
        <td class="comlmn">تاریخ عضویت</td>
        <td class="ltr tar c"><span><?= $member_date ?></span></td>
    </tr>


</table>
  <button class="btn_style btn-brown" onclick="back(<?= $pageIndex ?>)">برگشت و ذخیره</button>
</div>
<script>
  function back(pageIndex){
    getPage(pageIndex);
  }
</script>
