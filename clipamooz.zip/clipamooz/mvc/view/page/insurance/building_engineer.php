<div class="row">
  <section id="section-2">
    <div class="about-landing">
      <div class="container">
        <div class="about-text">
          <h2 style="color: #fffccc;">بیمه نامه مسئولیت ﻭﻳﮋه ﻓﻌﺎﻟﯿﺖ ﻫﺎی عمرانی</h2>
          <p style="margin-top: 50px">
            در این بیمه نامه مسئولیت پیمانکاران در ارتباط با زیانهای جانی و مالی وارد به کارگران شاغل در پروژه های عمرانی مانند نیروگاهها ، سدها ، پلها ، تونلها ، کانالها ، شبکه های آب و فاضلاب ، خطوط گاز ، مترو و ... تحت پوشش می باشد .
          </p>
        </div>
        <div class="thumb wow animated zoomIn"><img style="border-radius: 10px" src="/asset/images/insurance/building_engineer.jpg" alt="مهدکودک"></div>
      </div>
    </div>
  </section>
  </div>
<div class="row">
  <section>
    <div class="container">
    <div class="info_person">
      <div id="panel1_building_engineer" class="titrbox "> <h1>&nbsp;&nbsp;معرفی پروژه<i id="icon_panel1_building_engineer_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="panel1_building_engineer_panel" style="display: none">
        <p style="font-size: 12pt;text-align: justify">
          پروژه عبارتست از کلیه فعالیت های عمرانی که معمولا دارای ویژگی های ذیل می باشند :
        </p>
        <p style="font-size: 12pt;text-align: justify">
          1- برای مدت زمان محدودی انجام می شوند. برای مثال ساخت سد برای مدت سه سال یا لکه گیری آسفالت برای مدت 4 ماه
        </p>
        <p style="font-size: 12pt;text-align: justify">
          2- در محدوده مکانی خاصی انجام می گردد. برای مثال انجام لکه گیری آسفالت در حد فاصل کیلومتر 2 تا 4 جاده قدیم کرج
        </p>
        <p style="font-size: 12pt;text-align: justify">
          3- معمولا برای انجام آنها قراردادی بین کارفرما و پیمانکار بسته می شود که در این قرارداد شماره قرارداد، موضوع پروژه، مدت پروژه و مبلغ پروژه و محدوده سایت کاری و ...... مشخص است
        </p>
      </div><!--     END  panel1_kindergarten ****************-->
      <div id="panel2_building_engineer" class="titrbox "> <h1>&nbsp;&nbsp;تعهدات بیمه گر :<i id="icon_panel2_building_engineer_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="panel2_building_engineer_panel" style="display: none">
        <p style="font-size: 12pt;text-align: justify">
          1- جهت صدور بیمه نامه ، حداقل و حداکثر تعهد قابل ارائه توسط بیمه گر برای خسارات فوت و صدمات جسمانی برای هر نفر مطابق این تعرفه منحصراً دیه مصوب ماه های عادی و حرام سال صدور بیمه نامه خواهد بود .
        </p>
        <p style="font-size: 12pt;text-align: justify">
          2- حداکثرتعهد قابل ارائه برای هزینه پزشکی ناشی ازحوادث موضوع این بیمه برای هر نفر در هر حادثه طبق این تعرفه 500،000،000 ریال خواهد بود اما با توافق بیمه گر این مبلغ می تواند حداکثر تا 10% دیه ماه حرام افزایش یابد . ضمناً فرانشیز هزینه های پزشکی 10% هر خسارت و حد
        </p>
      </div>
      <div id="panel3_building_engineer" class="titrbox "> <h1>&nbsp;&nbsp;سقف تعهد بیمه گر :<i id="icon_panel3_building_engineer_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="panel3_building_engineer_panel" style="display: none">
        <p style="font-size: 12pt;text-align: justify">
          1-	حداکثر تعهد قابل ارائه توسط بیمه گر در طول مدت بیمه نامه معادل ضریب نیروی کار محاسبه شده خواهد بود و حداکثر تعهدات در طول مدت بیمه نامه از 20 برابر تجاوز نخواهد کرد . در صورت درخواست بیمه گذاربرای سقف تعهد بیشتر از 20 برابر با توافق بیمه گر این درخواست قابل ارائه می باشد .
        </p>
        <p style="font-size: 12pt;text-align: justify">
          2-	در صورتی که حداکثر نیروی کار اعلام شده از سوی بیمه گذارکمتر یا مساوی 10 نفر باشد ،حداکثر سقف تعهد قابل ارائه در طول مدت بیمه نامه 5 برابر خواهد بود . در صورت درخواست بیمه گذاربرای سقف تعهد بیشتر از 5 برابر اخذ مجوز از اداره فروش بيمه هاي مسئوليت مرکز الزامیست .
        </p>
      </div>
      <div id="panel4_building_engineer" class="titrbox "> <h1>&nbsp;&nbsp;مدت بیمه نامه :<i id="icon_panel4_building_engineer_ON" style="float: right" class="icon-arrow-down2"></i></h1></div>
      <div id="panel4_building_engineer_panel" style="display: none">
        <p style="font-size: 12pt;text-align: justify">
          مدت بیمه نامه یکساله بوده، در صورت درخواست بیمه گذاربرای مدت کمتر از یکسال، حق بیمه براساس جدول تعرفه کوتاه مدت محاسبه می گردد .
        </p>
        <p style="font-size: 12pt;text-align: justify">
          تبصره : صدور بيمه نامه برای مدت بيشتر از يكسال در صورت توافق با بیمه گر طبق شرایط خاص امکانپذیر می باشد .
        </p>
      </div>
    </div>
    <!--***********  INFO ---   Person   --   Responsive   ********************************************************************************-->
    </div>
  </section>
  <section>
  <p style="font-size: 12pt;color: #fffccc;text-align: right">
            <span>
              <strong>خرید بیمه نامه :</strong>
            </span>
  </p>
  <p style="font-size: 12pt;text-align: justify">
    جهت خرید بیمه نامه لطفا فرم زیر را  دانلود و پس از تکمیل به یکی از روشها شبکه های اجتماعی (سروش ، تلگرام ، واتس آپ ) و یا ایمیل برای اینجانب ارسال نمایید تا فرم اعلام حق بیمه و متعاقب آن صدور بیمه نامه صورت پذیرد .
  </p>
  </section>
  <button class="btn btn-brown" onclick="window.location.href='/pdf/building_engineer'"> دانلود بیمه نامه مسئولیت ﻭﻳﮋﻩﻓﻌﺎﻟﯿﺖ ﻫﺎی  عمرانی</button>
</div>