<div class="rtl">
  <strong style="color: #fff">نوع نمایش</strong>
  <select id="UserFind">
    <option value="subject">نام دسته</option>
  </select>
  <input type="text" style="width:100px;height: 20px" id="keyword" placeholder="جستجو" value="" autocomplete="off">
  <input type="text" style="display: none" id="user_id"  value="<?=$id?>" autocomplete="off">
</div>
<div id="paginationUpdate"></div>
<script>

  $("#keyword").on('keyup', function () {
    all_support_ticket(<?=$pageIndex?>);
  });
  $(function () {
    all_support_ticket(<?=$pageIndex?>);
  });

  function all_support_ticket(pageIndex) {

    var keyword = $("#keyword").val();
    var SearchFiled = $("#UserFind").val();
    var user_id = $("#user_id").val();
    $.ajax({
      url: '/RefreshData_support_ticket/' + pageIndex,
      method: 'POST',
      dataType: 'json',
      data: {
        user_id:user_id,
        keyword: keyword,
        SearchFiled: SearchFiled
      },
      success: function (output) {
        $("#paginationUpdate").html(output.html);
      }
    });
  }


</script>









