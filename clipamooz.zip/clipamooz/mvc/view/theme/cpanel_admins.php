<!DOCTYPE html>
<?if (!isset($pageTitle)) {  $pageTitle = "پنل مدیر میانی";}?>
<html lang="en-FA">
<head>
  <?require(getcwd() . "/mvc/view/theme/theme.php");?>
</head>

<body>

<script>
  $(function () {
    //Footer();
    $(".nav-bar").click(function(){
      $(".Cpanel_superadmin_user_right_menu_responsive").toggle(200);
    });
  });
</script>
<div class="info_menu_superadmin">
  <div class="nav-bar tac">
    <span class="icon-bar"></span>
    <span class="icon-bar"></span>
    <span class="icon-bar"></span>
  </div>
</div>

<div class="Cpanel_superadmin_user_right_menu_responsive" style="display: none">
  <div>
    <?require(getcwd() . "/mvc/view/admins/Cpanel_admin_user_right_menu.php")?>
  </div>
</div>
<div class="wrapper">
  <div style="padding-bottom: 20px" class="row tac">
    <h1 style="margin-top:10px">پنل مدیر میانی</h1>
  </div>
  <div class="row">
    <div class="colx-2 colm-0 cols-0" style=" vertical-align: top;">
      <div>
        <?require(getcwd() . "/mvc/view/admins/Cpanel_admin_user_right_menu.php")?>
      </div>
    </div>
    <div class="colx-10 colm-fill cols-fill" style=" vertical-align: top;">
      <?= $content ?>
    </div>
  </div>
</div>
</body>
</html>