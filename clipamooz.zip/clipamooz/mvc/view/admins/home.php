<div class="signin">
  <div class="row" style="padding: 10px">
    <span class="icon-search large"></span>
    جستجو ...
  </div>
  <div class="row">
    <div class="colx-2 colm-fill cols-fill"><div id="search_admins" onclick="search_admins()"  class="tooltip searchbtn"><i  class="large icon-filter"></i></div></div>
    <div class="colx-9 colm-fill cols-fill show_search_admin" >
      <input id="codemelli" type="text"  placeholder="کد ملی را وارد کنید ...">
    </div>
    <div class="colx-1 colm-fill cols-fill"></div>
  </div>
  <div class="row">
    <div class="colx-2 colm-fill cols-fill"></div>
    <div class="colx-9" >
      <table id="userTable" border="1"  >
        <thead>
        <tr>
          <th width="5%">ردیف</th>
          <th width="30%">نام </th>
          <th width="30%">نام خانوادگی</th>
          <th width="45%">کد ملی</th>
        </tr>
        <br>
        </thead>
        <tbody ></tbody>
      </table>
    </div>
    <div class="colx-1 colm-fill cols-fill"></div>
  </div>
  <div class="row" style="padding: 10px">&nbsp; </div>
  <div class="row">
    <div class="colx-2 colm-fill cols-fill">
          <select style="font-family: Sahel-FD" id="mySelect">
            <option style="font-family: Sahel-FD" id="left" value="0">گره سمت چپ</option>
            <option style="font-family: Sahel-FD" id="right" value="1">گره سمت راست</option>
          </select>
    </div>
    <div class="colx-9 colm-fill cols-fill show_search_admin" >
      <input id="main_codemelli" type="text"  placeholder="کد ملی فرد اصلی سرشاخه را وارد کنید ...">
    </div>
    <div class="colx-1 colm-fill cols-fill"></div>
  </div>
  <div class="row" style="padding: 10px">&nbsp; </div>
  <div class="row">
    <div class="colx-2 colm-fill cols-fill"><div id="save_network" onclick="save_network()" class="tooltip searchbtn"><i  class="large icon-floppy-disk"></i></div></div>
    <div class="colx-9 colm-fill cols-fill show_search_admin" >
      <input id="sub_codemelli" type="text"  placeholder="کد ملی فرد فرعی زیر شاخه را وارد کنید ...">
    </div>
    <div class="colx-1 colm-fill cols-fill"></div>
  </div>
  <div class="row" style="padding: 10px">&nbsp; </div>
<script>
  $('.tooltip').tooltipster({
    animation: 'fade',
    delay: 100,
    theme: 'tooltipster-punk',
    trigger: 'click'
  });
  function save_network() {
    var leg = document.getElementById("mySelect").value;
    $("#mySelect").change(function() {
       leg = document.getElementById("mySelect").value;
    });
    var main_codemelli = $("#main_codemelli").val();
    var sub_codemelli = $("#sub_codemelli").val();
    if(main_codemelli != sub_codemelli){
  $("#save_network").after('<div id="loader_save_network"><span class="icon-spinner9 huge spin "></span></div>');
    $.ajax({
      url: '/user/save_network/',
      type: 'POST',
      dataType: 'JSON',
      data: {
        main_codemelli: main_codemelli,
        sub_codemelli: sub_codemelli,
        leg: leg
      },
      success: function (data) {
        console.log(data.status);
        $('#loader_save_network').slideUp(1000, function() {
          $(this).remove();
        });
        switch (data.status) {
          case 'duplicate_sub_user':
          {
            $(".tooltip").tooltipster('content', 'این کاربر تکراری می باشد');
            break;
          }
          case 'not_save_this_tree':
          {
            $(".tooltip").tooltipster('content', 'زیردرخت را اشتباه وارد کردید');
            break;
          }
          case 'main_codemelli_not_exist':
          {
            $(".tooltip").tooltipster('content', 'کد ملی فرد اصلی وجود ندارد');
            break;
          }
          case 'sub_codemelli_not_exist':
          {
            $(".tooltip").tooltipster('content', 'کد ملی فرد فرعی وجود ندارد');
            break;
          }
          case 'compelete_tree':
          {
            $(".tooltip").tooltipster('content', 'زیرمجموعه چپ و راست پر می باشد');
            break;
          }
          case 'ok':
          {
            $(".tooltip").tooltipster('content', 'کاربر مورد نظر با موفقیت ثبت گردید.');
            window.location.reload();
            break;
          }
          default:
          //  window.location.href = "/h"+name_fa+"/"+subcategory;
        }
      }
    });
    }else{
      $(".tooltip").tooltipster('content', 'کد ملی ها باهم برابر است');
    }
  }
  function search_admins() {
    var keyword = $("#codemelli").val();
    if (keyword == '') {
      $(".tooltip").tooltipster('content', 'کد ملی را وارد کنید.');
    } else {
     $("#search_admins").after('<div id="loader"><span class="icon-spinner9 huge spin "></span></div>');
    $.ajax({
      url: '/admins/search_admins/',
      type: 'POST',
      dataType: 'JSON',
      data: {
        keyword: keyword
      },
      success: function (response) {
        if (response.status === 'not_codemelli') {
          $(".tooltip").tooltipster('content', 'کد ملی وارد شده وجود ندارد.');
          $('#loader').slideUp(1000, function() {
            $(this).remove();
          });
        } else {
          $(".tooltip").tooltipster('content', '');
          $('#loader').slideUp(1000, function() {
            $(this).remove();
          });
          var len = response.length;
          for (var i = 0; i < len; i++) {
            var id = response[i].id;
            var first_name = response[i].first_name;
            var last_name = response[i].last_name;
            var codemelli = response[i].codemelli;
            var tr_str ;
             tr_str =
              "<tr>" +
              "<td align='center'>" + (i + 1) + "</td>" +
              "<td align='center'>" + first_name + "</td>" +
              "<td align='center'>" + last_name + "</td>" +
              "<td align='center'>" + codemelli + "</td>" +
              "</tr>";

            $("#userTable tbody").append(tr_str);
          }
        }
      }
    });
  }
  }
  $(document).ready(function() {

  });
 /* $(function(){

  });*/

</script>



