let express = require('express');
let app = express();
var resumable = require('./resumable-node')();
var multipart = require('connect-multiparty');
var crypto = require('crypto');
let uuid = require('uuid');
let Configs = require('./configs');

// Host most stuff in the public folder
app.use(express.static(__dirname + '/public'));

app.use(multipart());

// Uncomment to allow CORS
app.use(function (req, res, next) {
    res.header('Access-Control-Allow-Origin', '*');
    next();
});

// retrieve file id. invoke with /fileid?filename=my-file.jpg
// app.get('/fileid', function(req, res){
//     if(!req.query.filename){
//       return res.status(500).end('query parameter missing');
//     }
//     // create md5 hash from filename
//     res.end(
//       crypto.createHash('md5')
//       .update(req.query.filename)
//       .digest('hex')
//     );
// });
  
// Handle uploads through Resumable.js
app.post('/upload', function(req, res){
    let id ='www.clipamooz.ir_'+ uuid();
    resumable.post(req, function(status, filename, original_filename, identifier, numberOfChunks){
        // console.log('POST', status, filename, original_filename, identifier);
        let name = '';
        if('done' == status) {
            let filetype = filename.substr(filename.lastIndexOf('.'));
            name = id+filetype;
            console.log('save now');
            var concat = require('concat-files');
            var chunknames = [];
            for(var i=1; i <= numberOfChunks; i++){ 
                var uploadname = `${Configs.uploader.tempDir}/resumable-${identifier}.${i}`;
                chunknames.push(uploadname);
            }
         
            concat(chunknames, `${Configs.uploader.mainDir}/${name}`, (err) => { 
                if(err) {
                    console.log("concatenation has problem =>", err);
                }
                resumable.clean(identifier);
            });

        }

        if(status === 'done')
            // send file address to client
            res.send(`${Configs.uploader.mainDir}/${name}`) 
        else 
            res.send(status);
    });
});

// Handle status checks on chunks through Resumable.js
// app.get('/upload', function(req, res){
//     resumable.get(req, function(status, filename, original_filename, identifier){
//         console.log('GET', status);
//         res.send((status == 'found' ? 200 : 404), status);
//     });
// });

// app.get('/download/:identifier', function(req, res){
//     resumable.write(req.params.identifier, res);
// });
// app.get('/resumable.js', function (req, res) {
//     var fs = require('fs');
//     res.setHeader("content-type", "application/javascript");
//     fs.createReadStream("../../resumable.js").pipe(res);
// });


module.exports = app;
