<div class="tac content">
  <br>
  <img src="/asset/images/logo/logo250.png">
  <br>
  <br>
  <div><?=$message?></div>
  <br>
  <br>
</div>
