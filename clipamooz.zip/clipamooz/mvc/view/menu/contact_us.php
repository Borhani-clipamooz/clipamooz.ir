<div class="tac content">
  <img src="/asset/images/logo/logo250.png">
    <table style="position: relative;border: 2px solid #603813;border-radius: 5px;">
        <colgroup>
        </colgroup>
        <tr>
          <td>آدرس:</td>
          <td>مشهد:مطهری جنوبی 18 نبش چهارراه اول باباطاهر 12 پلاک 98</td>
        </tr>
      <tr>
        <td>تلفن:</td>
        <td>05137297711</td>
      </tr>
<tr>
  <td>همراه:</td>
  <td>09153018177</td>
</tr>
      <tr>
        <td>کدپستی:</td>
        <td>9189884658</td>
      </tr>
      <tr>
        <td>ایمیل:</td>
        <td>info@clipamooz.ir,clipamooz@yahoo.com</td>
      </tr>
    </table>



</div>
