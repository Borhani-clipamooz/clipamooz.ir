<?header("Content-Type: text/html; charset=utf-8");?>
<div class="row">
  <div class="box-new">
    <div class="colx-2 colm-fill">
      <div class="landing-boxnew1">
        <span>محبوب ترین ها</span>
      </div>
    </div>
    <div class="colx-5 colm-fill tac">
      <img src="/asset/images/468-60.gif">
    </div>
    <div class="colx-5 colm-fill tac">
      <img src="/asset/images/468-60.gif">
    </div>
  </div>
</div>
<!--  Demos -->
<section style="line-height: 25px">
  <div id="owl-popularclip" class="owl-carousel owl-theme">
    <? foreach ($list as $feild) {?>
      <div class="item">
        <div class="box-items">
          <div class="row">
            <div class="box-image">
              <?
              if($feild['img_link']!=''){?>
                <? global $config;?>
                <a  href="/g/<?=$feild['clip_api_key']?>" title="<?= $feild['name_fa']?>"><img  src="<?=$config['upload'].$feild['img_link']?>" alt="" /></a>
              <? } else{ ?>
                <a  href="/g/<?=$feild['clip_api_key']?>"  title="<?= $feild['name_fa']?>"><img  src="/asset/images/empty/empty-play/play.png" alt="" /></a>
              <?}?>
            </div>
          </div>
          <div class="row box-one">
            <div class="colx-4 tar">
              <?

              if($x>=3600){
                echo gmdate("H:i:s", $feild['clip_long_time']);
                }else{
                  echo gmdate("i:s", $feild['clip_long_time']);
                 }
              ?>
              </i>
              <span class="icon-clock"></span>
            </div>
            <div class="colx-4 tac">
                <span class=" icon-eye" aria-hidden="true"><span style="font-family: traffic">&nbsp;<?
                    $number =  number_format( $feild['opens']);
                    echo $number;?></span>
                </span>
            </div>
            <div class="colx-4 tal">
              <span class="icon-play" aria-hidden="true"><span style="font-family: traffic">&nbsp;<?= $feild['views']?></span></span>
            </div>
          </div>
          <div class="row tac box-two">
            <h1 class="tac"><?= $feild['name_fa']?></h1>
          </div>
          <div class="row box-three">
            <?
            $data=CommonModel::Fetch_by_every('category','id',$feild['category']);
            $name_category="";
            $name_category=$data['name_fa'];

            $data=CommonModel::Fetch_by_every('subcategories','id',$feild['subcategory']);
            $name_sub_category="";
            $name_sub_category=$data['subcategory_name'];
            ?>
            <h2>دسته بندی : &nbsp;<span style="color:#3f250e"><?= $name_category?>:<?= $name_sub_category?></span></h2>
          </div>
          <div class="row box-four">
            <div class="colx-1 tac">
              <?
              $data=CommonModel::Fetch_by_every('users','id',$feild['user_id']);
              if($data['profile_pic'] !=''){?>
                <img style="width: 30px;height: 30px;border-radius: 2px" src="<?=$config['upload'].$data['profile_pic']?>">
              <?}else{?>
                <img style="width: 30px;height: 30px;border-radius: 2px" src="/asset/images/empty/empty-profile/empty-profile-24.png">
              <?}?>
            </div>
            <div class="colx-4 tar">
              <h3><?=$data['user_name']?></h3>
            </div>
            <div class="colx-7 tal">
              <div class="rating">
                <?
                if (strpos($feild['rating'], '.5') !== false) {
                  $R_rating=$feild['rating'];
                }else{
                  $R_rating=round($feild['rating']);
                }
                ?>
                <?=rating($R_rating,'20px','20px');?>
              </div>
            </div>
          </div>
        </div>
      </div>
    <?}?>
  </div>
</section>
<script>

  $("#owl-popularclip").owlCarousel({
    loop:true,
    //  margin:10,
    dots:false,
    autoplay:true,
    autoplayTimeout:6000,
    rtl:true,
    responsive:{
      0:{
        items:1
      },
      640:{
        items:2
      },
      1000:{
        items:4
      }
    }
  });
</script>