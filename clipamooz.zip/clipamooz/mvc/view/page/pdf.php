<br>
<div class="row tac">
   <a class="btn btn-brown" href="/asset/images/insurance/pdf/<?=$value?>.pdf" download><i class="icon-download"></i>&nbsp;&nbsp;دانلود فایل </a>

</div>
<br>
<div class="row tac">

  <embed src="/asset/images/insurance/pdf/<?=$value?>.pdf"   type="application/pdf" width="100%" height="1200px" />
</div>

