<?php
$file = "sitemap.xml";
chmod($file, 0755);
$file_handle = fopen($file, 'w+')
or die("خطا: سطح دسترسی برای ویرایش فایل در سرور تنظیم نیست!");
$empty = "";
$string_data = $empty;
fwrite($file_handle, $string_data);
fclose($file_handle);
$file = "sitemap.xml";
chmod($file, 0755);
$file_handle = fopen($file, 'a') or die("خطا: سطح دسترسی برای ویرایش فایل در سرور تنظیم نیست!");
$start = "<?xml version='1.0' encoding='UTF-8'?>
<urlset xmlns='http://www.sitemaps.org/schemas/sitemap/0.9'
        xmlns:video='http://www.google.com/schemas/sitemap-video/1.1'>\n";
$string_data = $start;
fwrite($file_handle, $string_data);
$clips=CommonModel::View_All('clips');
$users=CommonModel::View_All('users');
global $config;
$uploadfile=$config['upload'];
$current_date=getCurrentDateTime2().'+03:30';
$url_category ="
<url>
     <loc>https://www.clipamooz.ir</loc>
     <priority>0.5</priority>
     <lastmod>2019-01-29T18:32:33+03:30</lastmod>
     <changefreq>daily</changefreq>
</url>
<url>
     <loc>https://www.clipamooz.ir/insurance</loc>
     <priority>0.5</priority>
     <lastmod>2019-01-29T18:32:33+03:30</lastmod>
     <changefreq>daily</changefreq>
</url>
<url>
     <loc>https://www.clipamooz.ir/login</loc>
     <priority>0.5</priority>
     <lastmod>2019-01-29T18:32:33+03:30</lastmod>
     <changefreq>daily</changefreq>
</url>
<url>
     <loc>https://www.clipamooz.ir/registerForm</loc>
     <priority>0.5</priority>
     <lastmod>2019-01-29T18:32:33+03:30</lastmod>
     <changefreq>daily</changefreq>
</url>
<url>
     <loc>https://www.clipamooz.ir/forgot_password</loc>
     <priority>0.5</priority>
     <lastmod>2019-01-29T18:32:33+03:30</lastmod>
     <changefreq>daily</changefreq>
</url>
<url>
     <loc>https://www.clipamooz.ir/request_link_active</loc>
     <priority>0.5</priority>
     <lastmod>2019-01-29T18:32:33+03:30</lastmod>
     <changefreq>daily</changefreq>
</url>
";
  $string_data = $url_category;
  fwrite($file_handle, $string_data);
foreach ($users as $value) {
  $profile_person=CommonModel::Fetch_by_every('info_person','user_id',$value['id']);
  $profile_uploader=$profile_person['first_name'].' '.$profile_person['last_name'];
  $last_entry=DateTimeTimeZone($value['last_entry']).'+03:30';
  $profile=baseUrl().'/profile/'.$value['id'].'/'.$profile_uploader;
  $url_profile = "
<url>
     <loc>$profile</loc>
     <lastmod>$last_entry</lastmod>
     <changefreq>daily</changefreq>
</url>";
  $string_data = $url_profile;
  fwrite($file_handle, $string_data);
}
/*<video:restriction relationship='allow'></video:restriction>
       <video:price currency='IRR'>$price</video:price>
       <video:requires_subscription>yes</video:requires_subscription>*/
foreach ($clips as $feild) {
  $info_person=CommonModel::Fetch_by_every('info_person','user_id',$feild['user_id']);
  $user_uploader=$info_person['first_name'].':'.$info_person['last_name'];
  $users=CommonModel::Fetch_by_every('users','id',$feild['user_id']);
  $info_email=$users['email'];
  $user_id=$users['id'];
  $link=baseUrl().'/g/'.$feild['clip_api_key'];
  $uploadfileLink=$feild['clip_prev_link'];
  $uploadIMGLink=$feild['img_link'];
  $title=$feild['name_fa'];
  if($feild['short_desc_fa']!=''){
  $description=$feild['short_desc_fa'];
  }else{
    $description='null';
  }
  $publication_date=DateTimeTimeZone($feild['created_at']).'+03:30';
  $view_count=$feild['opens'];
  $rating=$feild['rating'];
  $duration=$feild['clip_long_time'];
  $price=$feild['price'];
  $video_tag1=$feild['video_tag1'];
  $video_tag2=$feild['video_tag2'];
  $video_tag3=$feild['video_tag3'];
  $video_tag4=$feild['video_tag4'];
  $video_tag5=$feild['video_tag5'];
  $url_video = "
<url>
     <loc>$link</loc>
     <lastmod>$current_date</lastmod>
     <changefreq>daily</changefreq>
     <video:video>
       <video:thumbnail_loc>$uploadfile.$uploadIMGLink</video:thumbnail_loc>
       <video:title>$title</video:title>
       <video:description>$description</video:description>
       <video:content_loc>$uploadfile.$uploadfileLink</video:content_loc>
       <video:player_loc>$uploadfile.$uploadfileLink</video:player_loc>
       <video:duration>$duration</video:duration>
       <video:rating>$rating</video:rating>
       <video:view_count>$view_count</video:view_count>
       <video:publication_date>$publication_date</video:publication_date>
       <video:family_friendly>yes</video:family_friendly>
       <video:tag>$video_tag1</video:tag>
       <video:tag>$video_tag2</video:tag>
       <video:tag>$video_tag3</video:tag>
       <video:tag>$video_tag4</video:tag>
       <video:tag>$video_tag5</video:tag>
       <video:uploader
          info='http://www.clipamooz.ir/profile/$user_id'>$user_uploader
       </video:uploader>
     </video:video>
   </url>";
  $string_data = $url_video;
  fwrite($file_handle, $string_data);
}
$end = "</urlset>";
$string_data = $end;
fwrite($file_handle, $string_data);
fclose($file_handle);
mysqli_close($conn);
?>