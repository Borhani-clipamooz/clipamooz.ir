let router = require('./routes');
let Configs = require('./configs');

router.listen(Configs.server.port, 
    () => console.log(`the service is running to ${Configs.server.host}:${Configs.server.port}`)
);