<div class="content">
<div class="all_clip_upload">
  <div class="row">
  <div class="colx-1"><h2>جزئیات</h2>  </div>
  <div class="colx-1"><h2>حذف  </h2></div>
  <div class="colx-1">  <h2>وضعیت</h2></div>
  <div class="colx-5"><h2> عنوان</h2></div>
<!--  <div class="colx-1"> <h2>سایز</h2></div>-->
  <div class="colx-2"> <h2>دسته بندی</h2></div>
  <div class="colx-1"><h2>تاریخ بارگزاری</h2></div>
</div>
  <? foreach ($list as $feild) {?>
<div class="row">
  <div class="colx-1" style="cursor: pointer"><h3 onclick="View(<?= $feild['id']?>,<?=$pageIndex?>)" class="icon-file-video large"></h3></div>
  <div class="colx-1" style="cursor: pointer"><h3 onclick="Remove_all_clip_upload_ajax(<?= $feild['id']?>,<?=$pageIndex?>,'<?= $feild['img_link'] ?>','<?= $feild['uploadfile'] ?>','<?=$_SESSION['user_id']?>')" class="icon-bin large" ></h3></div>
  <div class="colx-1">
    <?if($feild['status']==0){?>
      <span  class="icon-checkmark2 large"></span>
    <?}else{?>
      <span  class="icon-checkmark large"></span>
    <?}?>
  </div>
  <div class="colx-5"><p><?= $feild['name_fa'] ?></p></div>
<!--  <div class="colx-1"> --><?//= $feild['clip_size'] ?><!--</div>-->
    <?
    $data=CommonModel::Fetch_by_every('category','id',$feild['category']);
    $data2=CommonModel::Fetch_by_every('subcategories','id',$feild['subcategory']);
    ?>
  <div class="colx-2"><?= $data['name_fa'] ?>/<?=$data2['subcategory_name']?></div>
  <div class="colx-1"><?=DateTimeCommon_without_time( $feild['created_at'] )?></div>
</div>
    <? } ?>
  <div class="row">
  <button class="btn_style btn-brown" onclick="InsertClipToSql(<?=$pageIndex?>,<?=$_SESSION['user_id']?>,'<?=getCurrentDateTime()?>')" >اضافه کردن کلیپ جدید</button>
  </div>
  <br>
  <div class="row">
    <?=pagination('',3,'btn_style btn-brown','btn',$pageIndex,$pageCount,'all_clip_upload')?>
  </div>
  <br>
</div>
<div class="all_clip_upload_responsive">
  <? foreach ($list as $feild) {?>
 <div class="row">
   <div class="colx-2">
     <h2>جزئیات</h2>
   </div>
   <div class="colx-10">
     <h3 onclick="View(<?= $feild['id']?>,<?=$pageIndex?>)" class="icon-file-video large"></h3>
   </div>
 </div>
 <div class="row">
   <div class="colx-2">
     <h2>حذف</h2>
   </div>
   <div class="colx-10">
     <h3 onclick="Remove_all_clip_upload_ajax(<?= $feild['id']?>,<?=$pageIndex?>,'<?= $feild['img_link'] ?>','<?= $feild['uploadfile'] ?>','<?=$_SESSION['user_id']?>')" class="icon-bin large" ></h3>
   </div>
 </div>
 <div class="row">
   <div class="colx-2">
     <h2>وضعیت</h2>
   </div>
   <div class="colx-10">
     <?if($feild['status']==0){?>
       <span  class="icon-checkmark2 large"></span>
     <?}else{?>
       <span  class="icon-checkmark large"></span>
     <?}?>
   </div>
 </div>
 <div class="row">
   <div class="colx-2">
     <h2>عنوان</h2>
   </div>
   <div class="colx-10"><?= $feild['name_fa'] ?></div>
 </div>
 <div class="row">
   <div class="colx-2">
     <h2>دسته بندی</h2>
   </div>
   <?
   $data=CommonModel::Fetch_by_every('category','id',$feild['category']);
   $data2=CommonModel::Fetch_by_every('subcategories','id',$feild['subcategory']);
   ?>
   <div class="colx-10"><?= $data['name_fa'] ?>/<?=$data2['subcategory_name']?></div>
 </div>
  <div class="row">
    <div class="colx-2">
      <h2>تاریخ بارگزاری</h2>
    </div>
    <div class="colx-10"><?=DateTimeCommon_without_time( $feild['created_at'] )?></div>
  </div>
  <hr>
  <? } ?>
  <div class="row">
  <button class="btn_style btn-brown" onclick="InsertClipToSql(<?=$pageIndex?>,<?=$_SESSION['user_id']?>,'<?=getCurrentDateTime()?>')" >اضافه کردن کلیپ جدید</button>
  </div>
  <div class="row">
    <?=pagination_responsive('',3,'btn_style btn-brown','btn',$pageIndex,$pageCount,'all_clip_upload')?>
  </div>
</div>
  <!--Buttons Filter-->
</div>

<script>
  function View(Id,PageIndex) {
    $.ajax({
      url: '/clip/detail_clip_upload_user/' + Id,
      type: 'POST',
      dataType: 'json',
      data:{
        pageIndex:PageIndex
      },
      success: function (data) {
        $("#paginationUpdate").html(data.html);
      }
    });
  }
  function InsertClipToSql(PageIndex,user_id,currentDate) {
    $.ajax({
      url: '/clip/InsertClipToSql/'+PageIndex,
      type: 'POST',
      dataType: 'json',
      data:{
        user_id:user_id,
        currentDate:currentDate
      },
      success: function (data) {
        $("#paginationUpdate").html(data.html);
      }
    });
  }
  function Remove_all_clip_upload_ajax(Id,PageIndex,img_link,uploadfile,user_id) {

    swal({
        title: "آیا مطمئن هستید؟",
        text: "شما دیگر قادر به بازیابی این فایل نخواهید بود.",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#5d4126",
        confirmButtonText: "آره، آن را حذف کنید.",
        closeOnConfirm: false,
        cancelButtonText: "لغو"
      },
      function(){
        $.ajax({
          url: '/clip/Remove_all_clip_upload_ajax/'+PageIndex,
          type: 'POST',
          dataType: 'json',
          data:{
            Id:Id,
            img_link:img_link,
            uploadfile:uploadfile,
            user_id:user_id
          },
          success: function (data) {
            window.location.reload();
          }
        });
        swal("حذف گردید.");
      });


  }


</script>


