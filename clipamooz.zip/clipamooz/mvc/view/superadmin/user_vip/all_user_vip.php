<div id="search" style=" position: relative;margin-top: 5px;margin-bottom: 5px">
  <strong style="color: #fff">نوع نمایش</strong>
  <select id="UserFind_all_user_vip">
    <option value="user_name">نام کاربری</option>
    <option value="name_fa">نام کلیپ</option>
  </select>
  <span class="icon-search large" style="position: absolute;top: 5px;right: 14%"></span> &nbsp; <input type="text" style="width:40%;height: 30px;padding-right: 2.5%" id="keyword_all_user_vip" autocomplete="off">
</div>
<div id="paginationUpdate"></div>
<script>

  $("#keyword_all_user_vip").on('keyup', function () {
    getPage(<?=$pageIndex?>);
  });
  $(function () {
     getPage(<?=$pageIndex?>);
  });

  function getPage(pageIndex) {
    var keyword = $("#keyword_all_user_vip").val();
    var SearchFiled = $("#UserFind_all_user_vip").val();
    $.ajax({
      url: '/superadmin/Refresh_all_user_vip/' + pageIndex,
      method: 'POST',
      dataType: 'json',
      data: {
        keyword: keyword,
        SearchFiled: SearchFiled
      },
      success: function (output) {
        //console.log(output);
        $("#paginationUpdate").html(output.html);
      }
    });
  }


</script>









