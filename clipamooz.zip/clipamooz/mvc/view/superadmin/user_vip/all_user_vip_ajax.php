<div class="content">
 <div class="all_user_vip_ajax">
   <div class="row">
   <div class="colx-1"><h2>جزئیات</h2></div>
   <div class="colx-2"><h2>نام کاربری</h2></div>
   <div class="colx-4 colm-0 cols-0"><h2>ایمیل</h2></div>
   <div class="colx-1 colm-0 cols-0"><h2>وضعیت</h2></div>
   <div class="colx-2 colm-0 cols-0"><h2>آخرین ورود</h2></div>
   <div class="colx-2 colm-0 cols-0"><h2>تاریخ عضویت</h2></div>
   </div>
    <? foreach ($list as $feild) {?>
   <div class="row">
   <!--  <div class="colx-1"><h3><span onclick="RemoveUser(<?/*= $feild['id']*/?>,<?/*=$pageIndex*/?>)"><i class="icon-profile large"></i></span></h3></div>-->
     <div class="colx-1"><h3><span onclick="ViewUser(<?= $feild['id']?>,<?=$pageIndex?>)"><i class="icon-profile large"></i></span></h3></div>
     <div class="colx-2"><h3><?= $feild['user_name'] ?></h3></div>
     <div class="colx-4 colm-0 cols-0"><h3><?= $feild['email'] ?></h3></div>
     <div class="colx-1 colm-0 cols-0"><h3>
         <?
         switch( $feild['status']){
           case "0": echo "غیر فعال";break;
           case "1": echo "فعال";break;
           default: echo ""; break;
         }

         ?>
       </h3></div>
     <div class="colx-2 colm-0 cols-0"><h3><?= DateTimeCommon($feild['last_entry'])?></h3></div>
     <div class="colx-2 colm-0 cols-0"><h3><?=DateTimeCommon($feild['member_date']) ?></h3></div>
   </div>
   <? } ?>
 </div>
      <br>
    <!--Buttons Filter-->
  <div class="row">
    <div><?=pagination_responsive('',3,'btn_style btn-brown','btn',$pageIndex,$pageCount,'getPage')?></div>
  </div>
  </div>

<script>
  function ViewUser(UserId,PageIndex) {

    $.ajax({
      url: '/superadmin/detail_user_vip/' + UserId,
      type: 'POST',
      dataType: 'json',
      data:{
        pageIndex:PageIndex
      },
      success: function (data) {
        console.log(data);
        $("#paginationUpdate").html(data.html);
      }
    });
  }
  function RemoveUser(UserId,PageIndex) {
    swal({
        title: "آیا مطمئن هستید؟",
        text: "شما دیگر قادر به بازیابی این فایل نخواهید بود.",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#5d4126",
        confirmButtonText: "آره، آن را حذف کنید.",
        closeOnConfirm: false
      },
      function(){
        $.ajax({
          url: '/superadmin/remove_users/' + UserId,
          type: 'POST',
          dataType: 'json',
          data:{
            pageIndex:PageIndex

          },
          success: function (data) {
            $("#paginationUpdate").html(data.html);
          }
        });
        swal("حذف گردید.");
      });
  }

</script>


