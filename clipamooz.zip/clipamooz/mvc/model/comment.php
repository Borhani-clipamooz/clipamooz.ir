<?php
class CommentModel {

  public static function insert($clip_id,$user_id,$comment,$created_at){
    $db = Db::getInstance();
    $db->query("INSERT INTO comments (clip_id,user_id,comment,created_at)
             VALUES ( :clip_id, :user_id, :comment,:created_at)",
      array(
        'clip_id'         => $clip_id,
        'user_id'         => $user_id,
        'comment'         => $comment,
        'created_at'         => $created_at,
      ));


  }
  public static function Comment_Vote_ConutNotRead($user_id)
  {
    $db=Db::getInstance();
    $record=$db->first("select count(*) AS total from clips_buy where (user_id=$user_id)AND((status_vote like '0')OR (status_comment like '0'))",array(),'total');
    return $record;

  }



  public static function View_ClipName($name_fa)
  {
    $db=Db::getInstance();
    $record=$db->query("select *  from clips where name_fa like '%$name_fa%'");
    return $record;

  }

  public static function view_single($id)
  {
    $db=Db::getInstance();
    $record=$db->query("select * from comments where id=:id",array('id'=>$id,));
    return $record;

  }
  public static function DelSqlRecord($id)
  {
    $db=Db::getInstance();
    $db->query("DELETE FROM comments where id=:id",array('id'=>$id,));

  }
}