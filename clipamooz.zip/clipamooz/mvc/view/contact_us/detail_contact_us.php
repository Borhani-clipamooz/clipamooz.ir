<script>

</script>
<div class=" content">

<table>
    <colgroup>
        <col style="width: 100px">
        <col style="width: 550px">
    </colgroup>
     <tr>
       <input type="hidden"id="id" value="<?=$id?>">
       <input type="hidden"id="status" value="<?=$status?>">
       <input type="hidden"id="sender_message_id" value="<?=$sender_message_id?>">
       <input type="hidden"id="receiver_message_id" value="<?=$receiver_message_id?>">
        <td class="comlmn">موضوع</td>
       <td><input  type="text"  id="name_fa"  name="name_fa" value="<?= $subject ?>"></td>
    </tr>
    <tr>
        <td class="comlmn">پیام درخواست</td>
       <td><?= $body_question ?></td>
    </tr>
    <tr>
        <td class="comlmn">پاسخ مدیر</td>
      <td> <textarea id="body_replay"  style="height: 150px;width: 500px"><?= $body_replay ?></textarea></td>
    </tr>
    <tr>
    </tr>



</table>

  <button class="btn_style btn-brown" onclick="Replay(),back(<?= $pageIndex ?>)">برگشت و ذخیره</button>
</div>
<script>
  function Replay(){
    var id=$("#id").val();
    var body_replay=$("#body_replay").val();
    var sender_message_id=$("#sender_message_id").val();
    var receiver_message_id=$("#receiver_message_id").val();
    $.ajax({
      url:'/contact_us/Replay/'+id,
      type: 'POST',
      dataType:'json',
      data:{
        sender_message_id:sender_message_id,
        receiver_message_id:receiver_message_id,
        body_replay:body_replay
      },
      success:function(data){
        //console.log(data);
      }
    });

  }
  function back(pageIndex){
    getPage(pageIndex);
  }
</script>
