<div class=" content">
<table>
    <colgroup>
        <col style="width: 100px">
        <col style="width: 550px">
    </colgroup>
     <tr>
       <input type="hidden"id="id" value="<?=$id?>">
        <td class="comlmn">پیام</td>
       <td><?= $body ?></td>
    </tr>
    <tr>
     <input  class="tac" style="display: none"  type="text" id="sender_message_id" value="<?=$_SESSION['user_id']?>">
      <input  type="text"  style="display: none" id="receiver_message_id" value="<?=$receiver_message_id?>">
        <td class="comlmn">پاسخ</td>
      <td> <textarea id="body"  style="height: 100px;width: 500px"></textarea></td>
    </tr>
  <tr id="message1" style="display: none">
    <td colspan="2"> <span id="message"></span></td>

  </tr>
</table>
  <button class="btn_style btn-brown" onclick="Save()">ارسال</button>
  <button class="btn_style btn-brown" onclick="back(<?= $pageIndex ?>)">برگشت</button>
</div>
<script>
  function Save(){
    var sender_message_id=$('#sender_message_id').val();
    var receiver_message_id=$('#receiver_message_id').val();
    var body=$("#body").val();
    $.ajax({
      url:'/user/Send_message/',
      type: 'POST',
      dataType:'json',
      data:{
        sender_message_id:sender_message_id,
        receiver_message_id:receiver_message_id,
        body:body

      },
      success:function(data){
        console.log(data);
        $("#message1").show();
        document.getElementById("message").innerHTML="پیام شما با موفقیت ارسال گردید.";
      }
    });

  }
  function back(pageIndex){
    all_receiver_message(pageIndex);
  }
</script>
