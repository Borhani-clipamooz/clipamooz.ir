<?php


class QuestionController {
  public function __construct() {

  }

  public function question_all($id,$pageIndex) {
    if (isVip()||isSuperAdmin()) {
      $data['pageIndex']=$pageIndex;
      $data['id']=$id;
      View::renderCPanelUser("/question/all_question.php", $data);
    }else{
      header("Location:/");
      return;
    }
      }
  public function Call_DataBase_question() {
    $groupby='ticket_id';
    $content=$_POST['clip_id'];
    $ticket_id=$_POST['ticket_id'];
    $SortType = "id DESC";
   // $data = ListAjaxPartial('questions', 1,'clip_id',$content,'','',$SortType, 100,$groupby);
    $data['list']=QuestionModel::Fetch_by_all_Distinct('questions','ticket_id',$ticket_id);
    echo json_encode($data);
  }
  public function RefreshData_question($pageIndex) {
    $NameTable = 'questions';

    if (isset($_POST['SearchFiled'])) {
      $SearchFiled = $_POST['SearchFiled'];
    } else {
      $SearchFiled = "id";
    }
    if (isset($_POST['keyword'])) {
      $keyword = $_POST['keyword'];
    } else {
      $keyword = "";
    }
    $SortType = "id DESC";
    $count=10;
    $content=$_POST['clip_id'];
   // $data = ListAjaxPartial($NameTable, $pageIndex,'user_id',$_SESSION['user_id'],$SearchFiled,$keyword,$SortType, $count);
    $result = CommonModel::View_All('questions');
    if (count($result) == 0) {

    }else{
    $groupby='ticket_id';
    $data = ListAjaxPartial($NameTable, $pageIndex,'clip_id',$content,$SearchFiled,$keyword,$SortType, $count,$groupby);
    ob_start();
    View::renderPartial("/question/all_question_ajax.php", $data);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));
    }

  }
  public function view_question($ticket_id) {
    if (isset($_POST['pageIndex'])) {
      $pageIndex = $_POST['pageIndex'];
    } else {
      $pageIndex = 1;
    }
    $data=CommonModel::last_record_with_if('questions','ticket_id',$ticket_id,'id');
    $record['list'] = CommonModel::Fetch_by_all('questions','ticket_id',$ticket_id,'ORDER BY id DESC');
    $record['subject']=$data['subject'];
    $record['clip_id']=$data['clip_id'];
    $record['clip_name']=$data['clip_name'];
   // $record['sender_id']=$data['sender_id'];
    $record['reciver_id']=$data['sender_id'];
    $record['ticket_id']=$ticket_id;
    ob_start();
    $record['pageIndex'] = $pageIndex;
    View::renderPartial("/question/detail_question.php", $record);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));

  }

  // ********   Questions    *********************************************************************************************************


  public function Save_Questions() {
    $reciver_id=$_POST['owner_clip_id'];
    $clip_id=$_POST['clip_id'];
    $clip_name=$_POST['clip_name'];
    $sender_id=$_POST['user_id_question'];
    $date_question=$_POST['date_question'];
    $subject=$_POST['subject'];
    $body_question=$_POST['body_question'];
    $ticket_id=generateRandomString();
    ob_start();
    QuestionModel::insert_Question($ticket_id,$subject,$sender_id,$reciver_id,$clip_id,$clip_name,$body_question,$date_question,0);
    NotificationModel::insert_Notification($ticket_id,$subject,$sender_id,$reciver_id,$clip_id,$clip_name,$body_question,$date_question);
    $output = ob_get_clean();
    echo json_encode(array('status' => true, 'html' => $output,));
  }
  public function Replay_question() {
    $sender_id = $_POST['sender_id'];
    $ticket_id = $_POST['ticket_id'];
    $reciver_id = $_POST['reciver_id'];
    $clip_id = $_POST['clip_id'];
    $clip_name = $_POST['clip_name'];
    $subject = $_POST['subject'];
    $body_question = $_POST['body_question'];
    $date_question=getCurrentDateTime();
    QuestionModel::insert_Question($ticket_id,$subject,$sender_id,$reciver_id,$clip_id,$clip_name,$body_question,$date_question,0);
    $data=QuestionModel::Fetch_by_all_Distinct('questions','ticket_id',$ticket_id,'');
    foreach($data as $feild){
      if($feild['sender_id']!=$sender_id){
    NotificationModel::insert_Notification($ticket_id,$subject,$sender_id,$feild['sender_id'],$clip_id,$clip_name,$body_question,$date_question);
      }
    }
    echo json_encode(array('status' => true,));
  }
  // ******** END   Questions    *********************************************************************************************************

  public function Update() {
    $id = $_POST['id'];
    $body_replay = $_POST['answer'];
    QuestionModel::update($id,$body_replay,getCurrentDateTime(),1);
  }
}